import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class InfoPage extends StatefulWidget {
  final String sessionKey;
  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "CHECKING...";
  Timer? _pingTimer;

  late AnimationController _pulseCtrl;
  late Animation<double> _pulse;
  late AnimationController _glowCtrl;
  late Animation<double> _glow;

  final List<Map<String, dynamic>> rulesList = [
    {
      "title": "NO ACCOUNT BARTERING",
      "icon": Icons.swap_horizontal_circle_outlined,
      "desc":
          "Akun eksklusif Null Tr4sher tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau.",
    },
    {
      "title": "STRICTLY PERSONAL USE",
      "icon": Icons.person_off_outlined,
      "desc":
          "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).",
    },
    {
      "title": "RESELLING PROHIBITED",
      "icon": Icons.money_off_csred_outlined,
      "desc":
          "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller).",
    },
    {
      "title": "ILLEGAL DURATION SALES",
      "icon": Icons.timer_off_outlined,
      "desc":
          "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi.",
    },
    {
      "title": "PRICE DUMPING BAN",
      "icon": Icons.trending_down_rounded,
      "desc":
          "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami.",
    },
  ];

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.2, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.15, end: 1.0).animate(
        CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _pulseCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      await http
          .get(Uri.parse(
              '$baseUrl/getServerInfo?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 5));
      if (mounted) setState(() => isLoading = false);
    } catch (_) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer =
        Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final C = AppTheme.current.value;
    final start = DateTime.now();
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final duration = DateTime.now().difference(start).inMilliseconds;

      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          apiStatusColor = C.primaryHi;
          apiStatusText = "SYS.ONLINE  ::  ${duration}ms";
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          isApiOnline = false;
          apiPingMs = 0;
          apiStatusColor = C.textSub;
          apiStatusText = "SYS.OFFLINE  ::  UNREACHABLE";
        });
      }
    }
  }

  Widget _buildLoadingScreen(AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Scaffold(
      backgroundColor: isHud ? C.hudBg() : C.bgDeep,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) => Container(
                width: 64, height: 64,
                decoration: BoxDecoration(
                  shape: isHud ? BoxShape.rectangle : BoxShape.circle,
                  border: Border.all(
                    color: C.primaryHi
                        .withValues(alpha: 0.3 + _pulse.value * 0.5),
                    width: isHud ? 1.4 : 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: C.primaryHi
                          .withValues(alpha: _pulse.value * 0.25),
                      blurRadius: 30,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: C.primaryHi,
                    backgroundColor: C.bg,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 28),
            Text(
              "AUTHENTICATING",
              style: TextStyle(
                color: isHud ? C.hudTextDim() : C.textSub,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w700,
                fontSize: 11,
                letterSpacing: 4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusHeader(AppPalette C, bool isHud) {
    return AnimatedBuilder(
      animation: _glow,
      builder: (_, __) => Container(
        margin: const EdgeInsets.only(bottom: 24),
        padding: const EdgeInsets.all(18),
        decoration: isHud
            ? BoxDecoration(
                color: C.hudPanel(),
                border: Border.all(
                  color: apiStatusColor.withValues(
                      alpha: 0.15 + _glow.value * 0.4),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: apiStatusColor
                        .withValues(alpha: _glow.value * 0.15),
                    blurRadius: 30,
                    spreadRadius: 2,
                  ),
                ],
              )
            : BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: apiStatusColor.withValues(
                      alpha: 0.15 + _glow.value * 0.2),
                ),
                boxShadow: [
                  BoxShadow(
                    color:
                        apiStatusColor.withValues(alpha: _glow.value * 0.05),
                    blurRadius: 30,
                    spreadRadius: 2,
                  ),
                ],
              ),
        child: Row(
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) => Container(
                width: 10, height: 10,
                decoration: isHud
                    ? BoxDecoration(
                        color: apiStatusColor,
                        boxShadow: [
                          BoxShadow(
                            color: apiStatusColor
                                .withValues(alpha: _pulse.value * 0.9),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: apiStatusColor,
                        boxShadow: [
                          BoxShadow(
                            color: apiStatusColor
                                .withValues(alpha: _pulse.value * 0.7),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    apiStatusText,
                    style: TextStyle(
                      color: isApiOnline
                          ? C.primaryHi
                          : (isHud ? C.hudTextDim() : C.textSub),
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isApiOnline ? "CONNECTION STABLE" : "NO SIGNAL",
                    style: TextStyle(
                      color: (isHud ? C.hudTextDim() : C.textSub)
                          .withValues(alpha: 0.5),
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.bgDeep.withValues(alpha: 0.5),
                      border: Border.all(
                          color: C.accent.withValues(alpha: 0.3), width: 1),
                    )
                  : BoxDecoration(
                      color: C.bg.withValues(alpha: 0.4),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: C.bg),
                    ),
              child: Icon(Icons.memory,
                  color: (isHud ? C.hudTextDim() : C.textSub)
                      .withValues(alpha: 0.5),
                  size: 16),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(AppPalette C, String title, bool isHud) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, top: 4),
      child: Row(
        children: [
          Container(
            width: isHud ? 4 : 3, height: 14,
            decoration: BoxDecoration(
              color: C.primaryHi,
              borderRadius: BorderRadius.circular(isHud ? 0 : 2),
              boxShadow: [
                BoxShadow(
                  color: C.primaryHi.withValues(alpha: 0.5),
                  blurRadius: 8,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            title,
            style: TextStyle(
              color: isHud ? C.hudTextDim() : C.textSub,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 3,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRuleCard(
      AppPalette C, int index, Map<String, dynamic> rule, bool isHud) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: C.accent.withValues(alpha: 0.1),
                  blurRadius: 10,
                ),
              ],
            )
          : BoxDecoration(
              color: C.bgDark,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: C.bg),
            ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: isHud ? BorderRadius.zero : BorderRadius.circular(20),
          onTap: () {},
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    Container(
                      width: 46, height: 46,
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.accent.withValues(alpha: 0.12),
                              border: Border.all(
                                  color: C.accent.withValues(alpha: 0.5),
                                  width: 1.2),
                            )
                          : BoxDecoration(
                              color: C.primaryHi.withValues(alpha: 0.07),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                  color: C.primaryHi.withValues(alpha: 0.15)),
                            ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(rule['icon'] as IconData,
                              color: isHud
                                  ? C.accent
                                  : C.primaryHi.withValues(alpha: 0.7),
                              size: 19),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "0${index + 1}",
                            style: TextStyle(
                              color: isHud
                                  ? C.accent.withValues(alpha: 0.6)
                                  : C.primaryHi.withValues(alpha: 0.35),
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 9,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                              width: 1,
                              height: 10,
                              color: isHud
                                  ? C.accent.withValues(alpha: 0.3)
                                  : C.bg),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              rule['title'] as String,
                              style: TextStyle(
                                color: isHud ? C.hudText() : C.text,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                                fontFamily: 'Orbitron',
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 9),
                      Text(
                        rule['desc'] as String,
                        style: TextStyle(
                          color: isHud ? C.hudTextDim() : C.textSub,
                          fontSize: 12,
                          height: 1.65,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPenaltyBox(AppPalette C, bool isHud) {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 14, bottom: 28),
        padding: const EdgeInsets.all(24),
        decoration: isHud
            ? BoxDecoration(
                color: C.hudPanel(),
                border: Border.all(
                  color: C.primaryHi.withValues(
                      alpha: 0.3 + _pulse.value * 0.5),
                  width: 1.4,
                ),
                boxShadow: [
                  BoxShadow(
                    color: C.primaryHi
                        .withValues(alpha: _pulse.value * 0.2),
                    blurRadius: 30,
                    spreadRadius: 4,
                  ),
                ],
              )
            : BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: C.primaryHi
                      .withValues(alpha: 0.18 + _pulse.value * 0.12),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color:
                        C.primaryHi.withValues(alpha: _pulse.value * 0.05),
                    blurRadius: 40,
                    spreadRadius: 4,
                  ),
                ],
              ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 7),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.primaryHi.withValues(alpha: 0.15),
                      border: Border.all(
                          color: C.primaryHi, width: 1.2),
                    )
                  : BoxDecoration(
                      color: C.primaryHi.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: C.primaryHi.withValues(alpha: 0.25)),
                    ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.warning_amber_rounded,
                      color: C.primaryHi, size: 17),
                  const SizedBox(width: 8),
                  Text(
                    "VIOLATION PENALTY",
                    style: TextStyle(
                      color: C.primaryHi,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.8,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Colors.transparent,
                  isHud ? C.accent.withValues(alpha: 0.3) : C.bg,
                  Colors.transparent,
                ]),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              "Jika pengguna terdeteksi melanggar salah satu protokol kerahasiaan & aturan di atas secara sengaja:",
              style: TextStyle(
                color: isHud ? C.hudTextDim() : C.textSub,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                height: 1.7,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 18),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                  horizontal: 18, vertical: 14),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.primaryHi.withValues(alpha: 0.1),
                      border: Border.all(
                          color: C.primaryHi.withValues(alpha: 0.5),
                          width: 1.2),
                    )
                  : BoxDecoration(
                      color: C.primaryHi.withValues(alpha: 0.07),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: C.primaryHi.withValues(alpha: 0.2)),
                    ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.delete_forever_rounded,
                      color: C.primaryHi, size: 20),
                  const SizedBox(width: 10),
                  Text(
                    "AKUN DIHAPUS PERMANEN",
                    style: TextStyle(
                      color: isHud ? C.hudText() : C.text,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "TIDAK ADA PENGEMBALIAN SALDO ATAU KOMPENSASI.",
              style: TextStyle(
                color: (isHud ? C.hudTextDim() : C.textSub)
                    .withValues(alpha: 0.6),
                fontSize: 9,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter(AppPalette C, bool isHud) {
    return Column(
      children: [
        Container(
          width: 48, height: 48,
          decoration: isHud
              ? BoxDecoration(
                  color: C.bgDeep.withValues(alpha: 0.6),
                  border: Border.all(
                      color: C.accent.withValues(alpha: 0.3), width: 1),
                )
              : BoxDecoration(
                  shape: BoxShape.circle,
                  color: C.bgDark,
                  border: Border.all(color: C.bg),
                ),
          child: Center(
            child: Icon(Icons.shield_moon_rounded,
                color: isHud ? C.hudTextDim() : C.bg, size: 22),
          ),
        ),
        const SizedBox(height: 18),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            "Peraturan ini dibuat semata-mata untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem server XTROVIE. Dengan mengakses aplikasi, Anda secara otomatis menyetujui seluruh protokol di atas.",
            style: TextStyle(
              color: (isHud ? C.hudTextDim() : C.textSub)
                  .withValues(alpha: 0.45),
              fontSize: 11,
              fontStyle: FontStyle.italic,
              fontFamily: 'ShareTechMono',
              height: 1.75,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 22),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
                width: 28,
                height: 1,
                color: isHud
                    ? C.accent.withValues(alpha: 0.3)
                    : C.bg),
            const SizedBox(width: 8),
            Container(
              width: 4, height: 4,
              decoration: BoxDecoration(
                  color: isHud ? C.accent : C.bg,
                  shape: BoxShape.circle),
            ),
            const SizedBox(width: 8),
            Container(
                width: 28,
                height: 1,
                color: isHud
                    ? C.accent.withValues(alpha: 0.3)
                    : C.bg),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          "XTROVIE © ${DateTime.now().year}",
          style: TextStyle(
            color: (isHud ? C.hudTextDim() : C.textSub)
                .withValues(alpha: 0.3),
            fontSize: 9,
            fontFamily: 'Orbitron',
            letterSpacing: 3,
          ),
        ),
        const SizedBox(height: 40),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isHud = style == ThemeStyle.hudTactical;

            if (isLoading) return _buildLoadingScreen(C);

            return Scaffold(
              backgroundColor: isHud ? C.hudBg() : C.bgDeep,
              body: Stack(
                children: [
                  if (isHud)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(
                          painter: _HudGridPainter(
                              color: C.hudGridLine()),
                        ),
                      ),
                    ),
                  SafeArea(
                    child: CustomScrollView(
                      physics: const BouncingScrollPhysics(),
                      slivers: [
                        SliverAppBar(
                          backgroundColor:
                              isHud ? C.hudBg() : C.bgDeep,
                          elevation: 0,
                          pinned: true,
                          automaticallyImplyLeading: false,
                          expandedHeight: 64,
                          flexibleSpace: FlexibleSpaceBar(
                            titlePadding: const EdgeInsets.symmetric(
                                horizontal: 22, vertical: 14),
                            title: Row(
                              children: [
                                AnimatedBuilder(
                                  animation: _pulse,
                                  builder: (_, __) => Container(
                                    width: 6, height: 6,
                                    decoration: isHud
                                        ? BoxDecoration(
                                            color: C.primaryHi,
                                            boxShadow: [
                                              BoxShadow(
                                                color: C.primaryHi
                                                    .withValues(
                                                        alpha: _pulse.value *
                                                            0.9),
                                                blurRadius: 10,
                                                spreadRadius: 1,
                                              ),
                                            ],
                                          )
                                        : BoxDecoration(
                                            color: C.primaryHi,
                                            shape: BoxShape.circle,
                                            boxShadow: [
                                              BoxShadow(
                                                color: C.primaryHi
                                                    .withValues(
                                                        alpha: _pulse.value *
                                                            0.7),
                                                blurRadius: 10,
                                                spreadRadius: 1,
                                              ),
                                            ],
                                          ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  "EULA & SYSTEM INFO",
                                  style: TextStyle(
                                    color: isHud ? C.hudNeon() : C.text,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 2,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                            centerTitle: false,
                          ),
                          bottom: PreferredSize(
                            preferredSize: const Size.fromHeight(1),
                            child: Container(
                              height: 1,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Colors.transparent,
                                  C.primaryHi.withValues(alpha: 0.18),
                                  Colors.transparent,
                                ]),
                              ),
                            ),
                          ),
                        ),
                        SliverPadding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 18, vertical: 16),
                          sliver: SliverList(
                            delegate: SliverChildListDelegate([
                              _buildStatusHeader(C, isHud),
                              _buildSectionTitle(C, "USER PROTOCOLS", isHud),
                              ...rulesList
                                  .asMap()
                                  .entries
                                  .map((e) =>
                                      _buildRuleCard(C, e.key, e.value, isHud))
                                  .toList(),
                              _buildPenaltyBox(C, isHud),
                              _buildFooter(C, isHud),
                            ]),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}