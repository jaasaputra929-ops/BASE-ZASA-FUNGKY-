// lib/send_bug_loading.dart — Countdown 5 detik send bug (3 Style Support)
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';

class SendBugLoading extends StatefulWidget {
  final int countdownSeconds;
  final String targetLabel;
  final Future<bool> Function() onProcess;
  final VoidCallback? onComplete;

  const SendBugLoading({
    super.key,
    this.countdownSeconds = 5,
    required this.targetLabel,
    required this.onProcess,
    this.onComplete,
  });

  static Future<bool> show(
    BuildContext context, {
    required String targetLabel,
    required Future<bool> Function() onProcess,
    int countdownSeconds = 5,
  }) async {
    bool success = false;
    await showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.9),
      useRootNavigator: true,
      builder: (_) => SendBugLoading(
        countdownSeconds: countdownSeconds,
        targetLabel: targetLabel,
        onProcess: onProcess,
        onComplete: () {
          Navigator.of(context, rootNavigator: true).pop();
        },
      ),
    ).then((_) {
      success = true;
    });
    return success;
  }

  @override
  State<SendBugLoading> createState() => _SendBugLoadingState();
}

class _SendBugLoadingState extends State<SendBugLoading>
    with TickerProviderStateMixin {
  late AnimationController _rotateCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _ringCtrl;

  int _countdown = 0;
  Timer? _timer;
  bool _isProcessing = false;
  bool _isDone = false;
  bool _isSuccess = false;

  @override
  void initState() {
    super.initState();
    _countdown = widget.countdownSeconds;

    _rotateCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..repeat(reverse: true);

    _ringCtrl = AnimationController(
      vsync: this,
      duration: Duration(seconds: widget.countdownSeconds),
    )..forward();

    _startCountdown();
  }

  void _startCountdown() {
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_countdown > 1) {
        setState(() => _countdown--);
        HapticFeedback.selectionClick();
      } else {
        t.cancel();
        setState(() => _countdown = 0);
        _runProcess();
      }
    });
  }

  Future<void> _runProcess() async {
    if (_isProcessing) return;
    setState(() => _isProcessing = true);
    HapticFeedback.mediumImpact();

    try {
      final result = await widget.onProcess();
      if (!mounted) return;
      setState(() {
        _isSuccess = result;
        _isDone = true;
      });

      if (result) {
        HapticFeedback.heavyImpact();
      } else {
        HapticFeedback.vibrate();
      }

      await Future.delayed(const Duration(milliseconds: 1400));

      if (!mounted) return;
      widget.onComplete?.call();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSuccess = false;
        _isDone = true;
      });
      await Future.delayed(const Duration(milliseconds: 1400));
      if (!mounted) return;
      widget.onComplete?.call();
    }
  }

  @override
  void dispose() {
    _rotateCtrl.dispose();
    _pulseCtrl.dispose();
    _ringCtrl.dispose();
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return PopScope(
              canPop: false,
              child: Dialog(
                backgroundColor: Colors.transparent,
                insetPadding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
                child: Container(
                  padding: const EdgeInsets.all(28),
                  decoration: isComic
                      ? BoxDecoration(
                          color: C.bgDark,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: Colors.black, width: 4),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(8, 8),
                              blurRadius: 0,
                            ),
                          ],
                        )
                      : (isHud
                          ? BoxDecoration(
                              color: C.hudPanel(),
                              border: Border.all(
                                  color: C.hudBorder(), width: 1.2),
                              boxShadow: [
                                BoxShadow(
                                  color: C.accent.withOpacity(0.4),
                                  blurRadius: 25,
                                ),
                              ],
                            )
                          : BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [C.bg, C.bgDark, C.bgDeep],
                              ),
                              border:
                                  Border.all(color: C.accent, width: 2),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.9),
                                  offset: const Offset(0, 10),
                                  blurRadius: 20,
                                ),
                                BoxShadow(
                                  color: C.accent.withOpacity(0.4),
                                  blurRadius: 30,
                                  spreadRadius: 2,
                                ),
                              ],
                            )),
                  child: Stack(
                    children: [
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _buildHeader(C, isComic, isHud),
                          const SizedBox(height: 24),
                          _buildCountdownRing(C, isComic, isHud),
                          const SizedBox(height: 24),
                          _buildTargetInfo(C, isComic, isHud),
                          const SizedBox(height: 20),
                          _buildStatusText(C, isComic, isHud),
                        ],
                      ),
                      if (isHud) ...[
                        Positioned(
                            top: 0,
                            left: 0,
                            child: _corner(C)),
                        Positioned(
                            top: 0,
                            right: 0,
                            child: _corner(C)),
                        Positioned(
                            bottom: 0,
                            left: 0,
                            child: _corner(C)),
                        Positioned(
                            bottom: 0,
                            right: 0,
                            child: _corner(C)),
                      ],
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 14,
        height: 14,
        child: CustomPaint(
          painter: _HudCornerPainter(
              color: C.accent.withOpacity(0.85)),
        ),
      );

  Widget _buildHeader(AppPalette C, bool isComic, bool isHud) {
    final doneColor = _isSuccess ? C.primaryHi : C.accent;
    final color = _isDone
        ? doneColor
        : (isComic ? Colors.black : (isHud ? C.hudNeon() : C.accent));

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _PulseLed2(
            color: _isDone ? doneColor : C.accent,
            isComic: isComic,
            isHud: isHud),
        const SizedBox(width: 10),
        Flexible(
          child: Text(
            _isDone
                ? (_isSuccess ? 'SEND BERHASIL' : 'SEND GAGAL')
                : 'MENGIRIM BUG...',
            style: TextStyle(
              color: color,
              fontSize: isComic ? 18 : (isHud ? 12 : 13),
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: isComic ? 2 : 2.5,
              shadows: isComic
                  ? [
                      Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(2, 2),
                          blurRadius: 0),
                    ]
                  : (isHud
                      ? [
                          Shadow(
                              color: color.withOpacity(0.6),
                              blurRadius: 12),
                          const Shadow(
                              color: Colors.black,
                              offset: Offset(0, 1),
                              blurRadius: 2),
                        ]
                      : [
                          Shadow(
                              color: color.withOpacity(0.6),
                              blurRadius: 12),
                          const Shadow(
                              color: Colors.black,
                              offset: Offset(0, 1),
                              blurRadius: 2),
                        ]),
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(width: 10),
        _PulseLed2(
            color: _isDone ? doneColor : C.accent,
            isComic: isComic,
            isHud: isHud),
      ],
    );
  }

  Widget _buildCountdownRing(AppPalette C, bool isComic, bool isHud) {
    return SizedBox(
      width: 160,
      height: 160,
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (!isComic)
            AnimatedBuilder(
              animation: _rotateCtrl,
              builder: (_, __) => Transform.rotate(
                angle: _rotateCtrl.value * 2 * math.pi,
                child: CustomPaint(
                  size: const Size(160, 160),
                  painter: _DashedRingPainter(
                      color: isHud ? C.hudNeon() : C.accent),
                ),
              ),
            ),
          AnimatedBuilder(
            animation: _ringCtrl,
            builder: (_, __) => SizedBox(
              width: 140,
              height: 140,
              child: CircularProgressIndicator(
                value: _isDone ? 1.0 : (1 - _ringCtrl.value),
                strokeWidth: isComic ? 6 : 5,
                backgroundColor:
                    isComic ? Colors.white : (isHud ? C.bgDeep : C.bgDeep),
                valueColor: AlwaysStoppedAnimation(
                  _isDone
                      ? (_isSuccess ? C.primaryHi : C.accent)
                      : (isComic
                          ? C.primaryHi
                          : (isHud ? C.hudNeon() : C.accent)),
                ),
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              final scale = 0.95 + _pulseCtrl.value * 0.08;
              final glowColor = _isDone
                  ? (_isSuccess ? C.primaryHi : C.accent)
                  : (isComic
                      ? C.primaryHi
                      : (isHud ? C.hudNeon() : C.accent));

              return Transform.scale(
                scale: _isDone ? 1.0 : scale,
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: isHud
                      ? BoxDecoration(
                          color: glowColor.withOpacity(0.1),
                          border: Border.all(
                              color: glowColor, width: 1.5),
                          boxShadow: [
                            BoxShadow(
                                color: glowColor.withOpacity(0.6),
                                blurRadius: 20,
                                spreadRadius: 2),
                          ],
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic
                              ? null
                              : RadialGradient(
                                  center: const Alignment(-0.3, -0.3),
                                  colors: [C.bg, C.bgDark, C.bgDeep],
                                ),
                          color: isComic ? glowColor : null,
                          border: Border.all(
                            color: isComic ? Colors.black : glowColor,
                            width: isComic ? 4 : 2.5,
                          ),
                          boxShadow: isComic
                              ? null
                              : [
                                  BoxShadow(
                                    color: glowColor.withOpacity(0.6),
                                    blurRadius: 20,
                                    spreadRadius: 2,
                                  ),
                                ],
                        ),
                  child: Center(
                    child: _isDone
                        ? Icon(
                            _isSuccess
                                ? Icons.check_circle_rounded
                                : Icons.cancel_rounded,
                            color: isComic
                                ? C.contrastTextOn(glowColor)
                                : (isHud ? glowColor : Colors.white),
                            size: 50,
                            shadows: isComic
                                ? [
                                    Shadow(
                                        color: C.contrastTextOn(glowColor) ==
                                                Colors.white
                                            ? Colors.black
                                            : Colors.white,
                                        offset: const Offset(2, 2),
                                        blurRadius: 0),
                                  ]
                                : (isHud
                                    ? [
                                        Shadow(
                                            color: glowColor
                                                .withOpacity(0.8),
                                            blurRadius: 15),
                                      ]
                                    : [
                                        Shadow(
                                            color: glowColor
                                                .withOpacity(0.8),
                                            blurRadius: 15),
                                      ]),
                          )
                        : Text(
                            '$_countdown',
                            style: TextStyle(
                              color: isComic
                                  ? C.contrastTextOn(glowColor)
                                  : glowColor,
                              fontSize: isComic ? 60 : 56,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              height: 1,
                              shadows: isComic
                                  ? [
                                      Shadow(
                                          color: C.contrastTextOn(
                                                      glowColor) ==
                                                  Colors.white
                                              ? Colors.black
                                              : Colors.white,
                                          offset: const Offset(3, 3),
                                          blurRadius: 0),
                                    ]
                                  : [
                                      Shadow(
                                          color:
                                              glowColor.withOpacity(0.9),
                                          blurRadius: 20),
                                      const Shadow(
                                          color: Colors.black,
                                          offset: Offset(0, 2),
                                          blurRadius: 4),
                                    ],
                            ),
                          ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTargetInfo(AppPalette C, bool isComic, bool isHud) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: isHud
          ? BoxDecoration(
              color: C.bgDeep.withOpacity(0.6),
              border: Border.all(
                  color: C.accent.withOpacity(0.4), width: 1),
            )
          : BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 12 : 8),
              color: isComic ? Colors.white : Colors.black.withOpacity(0.4),
              border: Border.all(
                color: isComic ? Colors.black : C.accent.withOpacity(0.4),
                width: isComic ? 3 : 1,
              ),
            ),
      child: Column(
        children: [
          Text(
            'TARGET',
            style: TextStyle(
              color: isComic
                  ? Colors.black.withOpacity(0.6)
                  : (isHud
                      ? C.hudTextDim()
                      : C.text.withOpacity(0.5)),
              fontSize: isComic ? 12 : 8,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 2,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            widget.targetLabel,
            style: TextStyle(
              color: isComic
                  ? Colors.black
                  : (isHud ? C.hudText() : C.text),
              fontSize: isComic ? 14 : 12,
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w700,
              letterSpacing: isHud ? 1 : 0,
            ),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildStatusText(AppPalette C, bool isComic, bool isHud) {
    String text;
    Color color;

    if (_isDone) {
      if (_isSuccess) {
        text = 'Bug berhasil dikirim!';
        color = isComic
            ? Colors.black
            : (isHud ? C.hudSuccess() : C.primaryHi);
      } else {
        text = 'Gagal mengirim bug';
        color = isComic
            ? Colors.black
            : (isHud ? C.hudWarning() : C.accent);
      }
    } else if (_isProcessing) {
      text = 'Mengirim ke server...';
      color = isComic
          ? Colors.black
          : (isHud ? C.hudNeon() : C.accent);
    } else {
      text = 'Menunggu countdown...';
      color = isComic
          ? Colors.black.withOpacity(0.6)
          : (isHud
              ? C.hudTextDim()
              : C.text.withOpacity(0.6));
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (!_isDone)
          SizedBox(
            width: 12,
            height: 12,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: color,
            ),
          ),
        if (!_isDone) const SizedBox(width: 10),
        Flexible(
          child: Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: isComic ? 13 : 10,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w700,
              letterSpacing: isHud ? 1 : 1,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DASHED RING PAINTER
// ═══════════════════════════════════════════════════════════
class _DashedRingPainter extends CustomPainter {
  final Color color;
  _DashedRingPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.5)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 2;
    const segments = 24;
    const gap = 0.6;

    for (int i = 0; i < segments; i++) {
      final startAngle = (i / segments) * 2 * math.pi;
      final sweep = (1 / segments) * 2 * math.pi - gap / segments;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweep,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_DashedRingPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// PULSE LED
// ═══════════════════════════════════════════════════════════
class _PulseLed2 extends StatefulWidget {
  final Color color;
  final double size;
  final bool isComic;
  final bool isHud;
  const _PulseLed2({
    required this.color,
    this.size = 8,
    this.isComic = false,
    this.isHud = false,
  });

  @override
  State<_PulseLed2> createState() => _PulseLed2State();
}

class _PulseLed2State extends State<_PulseLed2>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isComic) {
      return Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.color,
          border: Border.all(
              color: Colors.black, width: widget.size * 0.18),
        ),
      );
    }
    if (widget.isHud) {
      return AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          final o = 0.4 + _c.value * 0.6;
          return Container(
            width: widget.size,
            height: widget.size,
            decoration: BoxDecoration(
              color: widget.color.withOpacity(o),
              boxShadow: [
                BoxShadow(
                  color: widget.color.withOpacity(0.9 * o),
                  blurRadius: widget.size * 1.8,
                  spreadRadius: widget.size * 0.3,
                ),
              ],
            ),
          );
        },
      );
    }
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final o = 0.4 + _c.value * 0.6;
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              center: const Alignment(-0.35, -0.35),
              colors: [
                Colors.white.withOpacity(o),
                widget.color.withOpacity(o),
                widget.color.withOpacity(0.5 * o),
              ],
              stops: const [0.0, 0.4, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.8 * o),
                blurRadius: widget.size * 1.5,
                spreadRadius: widget.size * 0.3,
              ),
            ],
          ),
        );
      },
    );
  }
}