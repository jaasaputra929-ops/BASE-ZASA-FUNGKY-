// lib/iqc.dart
import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:image_gallery_saver_plus/image_gallery_saver_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'api_config.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class IqcPage extends StatefulWidget {
  const IqcPage({Key? key}) : super(key: key);

  @override
  State<IqcPage> createState() => _IqcPageState();
}

class _IqcPageState extends State<IqcPage> {
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _batteryController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();

  bool _isLoading = false;
  bool _imageGenerated = false;
  Uint8List? _generatedImage;
  bool _isSharing = false;

  final List<String> _carrierOptions = [
    "Telkomsel",
    "Indosat",
    "XL",
    "Tri",
    "Smartfren",
    "Axis",
    "By.U",
  ];

  String _selectedCarrier = "Telkomsel";

  @override
  void initState() {
    super.initState();
    _timeController.text = "18:00";
    _batteryController.text = "40";
    _selectedCarrier = "Telkomsel";
    _messageController.text = "Halo bang";
  }

  Future<void> _generateIqc() async {
    if (_timeController.text.isEmpty) {
      _showToast("Masukkan waktu");
      return;
    }

    if (_batteryController.text.isEmpty) {
      _showToast("Masukkan persentase baterai");
      return;
    }

    if (_messageController.text.isEmpty) {
      _showToast("Masukkan pesan");
      return;
    }

    setState(() {
      _isLoading = true;
      _imageGenerated = false;
    });

    try {
      final battery = int.tryParse(
              _batteryController.text.replaceAll(RegExp(r'[^\d]'), '')) ??
          0;

      if (battery < 0 || battery > 100) {
        _showToast("Baterai harus antara 0-100");
        setState(() {
          _isLoading = false;
        });
        return;
      }

      final params = {
        'time': _timeController.text,
        'batteryPercentage': battery.toString(),
        'carrierName': _selectedCarrier,
        'messageText': _messageController.text,
        'emojiStyle': 'apple'
      };

      final queryString = Uri(queryParameters: params).query;
      final apiUrl = '$baseUrl/iqc/generate?$queryString';

      final response = await http.get(
        Uri.parse(apiUrl),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          _generatedImage = response.bodyBytes;
          _imageGenerated = true;
        });
        _showToast("IQC berhasil dibuat!");
      } else {
        await _generateIqcFallback(battery);
      }
    } catch (e) {
      final battery = int.tryParse(
              _batteryController.text.replaceAll(RegExp(r'[^\d]'), '')) ??
          0;
      await _generateIqcFallback(battery);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _generateIqcFallback(int battery) async {
    try {
      final params = {
        'time': _timeController.text,
        'batteryPercentage': battery.toString(),
        'carrierName': _selectedCarrier,
        'messageText': _messageController.text,
        'emojiStyle': 'apple'
      };

      final queryString = Uri(queryParameters: params).query;
      final fallbackUrl = 'https://brat.siputzx.my.id/iphone-quoted?$queryString';

      final response = await http.get(
        Uri.parse(fallbackUrl),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          _generatedImage = response.bodyBytes;
          _imageGenerated = true;
        });
        _showToast("IQC berhasil dibuat (fallback)!");
      } else {
        throw Exception('Gagal membuat IQC. Status: ${response.statusCode}');
      }
    } catch (e) {
      _showToast("Error: ${e.toString()}");
    }
  }

  Future<void> _saveToGallery() async {
    if (_generatedImage == null) {
      _showToast("Buat IQC terlebih dahulu!");
      return;
    }

    try {
      setState(() {
        _isSharing = true;
      });

      final result = await ImageGallerySaverPlus.saveImage(
        _generatedImage!,
        name: "iqc_${DateTime.now().millisecondsSinceEpoch}.png",
        quality: 100,
      );

      if (result['isSuccess'] == true) {
        _showToast("✅ IQC disimpan ke galeri!");
      } else {
        _showToast("❌ Gagal menyimpan IQC");
      }
    } catch (e) {
      _showToast("Error: ${e.toString()}");
    } finally {
      setState(() {
        _isSharing = false;
      });
    }
  }

  Future<void> _shareImage() async {
    if (_generatedImage == null) {
      _showToast("Buat IQC terlebih dahulu!");
      return;
    }

    try {
      setState(() {
        _isSharing = true;
      });

      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/iqc_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_generatedImage!);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Lihat iPhone Quote Chat ini!',
        subject: 'iPhone Quote Chat',
      );
    } catch (e) {
      _showToast("Error membagikan gambar");
    } finally {
      setState(() {
        _isSharing = false;
      });
    }
  }

  void _showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.black87,
      textColor: Colors.white,
      fontSize: 14.0,
    );
  }

  void _resetForm() {
    setState(() {
      _timeController.clear();
      _batteryController.clear();
      _messageController.clear();
      _selectedCarrier = "Telkomsel";
      _generatedImage = null;
      _imageGenerated = false;
    });
    _timeController.text = "18:00";
    _batteryController.text = "40";
    _messageController.text = "Halo bang";
  }

  // ═══════ BUILD ═══════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor: isHud ? C.hudBg() : null,
              appBar: AppBar(
                title: Text(
                  "iPhone Quote Chat",
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: isHud
                        ? C.hudNeon()
                        : (isComic ? C.comicText : Colors.white),
                    fontSize: 18,
                    letterSpacing: 0.5,
                    fontFamily: isComic ? 'Bangers' : null,
                  ),
                ),
                centerTitle: true,
                backgroundColor: isHud
                    ? C.hudPanel()
                    : (isComic ? C.primaryHi : const Color(0xFF2C3E50)),
                elevation: 0,
                iconTheme: IconThemeData(
                    color: isHud ? C.hudText() : Colors.white),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.refresh, size: 22),
                    onPressed: _resetForm,
                    tooltip: "Reset Form",
                  ),
                ],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(isHud ? 0 : 20),
                    bottomRight: Radius.circular(isHud ? 0 : 20),
                  ),
                ),
              ),
              body: Container(
                decoration: isHud
                    ? BoxDecoration(color: C.hudBg())
                    : BoxDecoration(
                        gradient: isComic
                            ? null
                            : const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color(0xFFF8F9FA),
                                  Color(0xFFE9ECEF),
                                ],
                              ),
                        color: isComic ? C.bg : null,
                      ),
                child: Stack(
                  children: [
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()),
                          ),
                        ),
                      ),
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HalftonePainter(
                                color: C.primaryLo.withValues(alpha: 0.12)),
                          ),
                        ),
                      ),
                    SingleChildScrollView(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _buildPreviewCard(C, isComic, isHud),
                          const SizedBox(height: 25),
                          _buildFormCard(C, isComic, isHud),
                          const SizedBox(height: 25),
                          _buildGuideCard(C, isComic, isHud),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════
  // PREVIEW CARD
  // ═══════════════════════════════════════════════════════
  Widget _buildPreviewCard(AppPalette C, bool isComic, bool isHud) {
    return Container(
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: C.accent.withValues(alpha: 0.15),
                  blurRadius: 12,
                ),
              ],
            )
          : (isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withValues(alpha: 0.08),
                      blurRadius: 25,
                      spreadRadius: 0,
                      offset: const Offset(0, 8),
                    ),
                  ],
                  border:
                      Border.all(color: const Color(0xFFE9ECEF), width: 1),
                )),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 6),
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withValues(alpha: 0.15),
                          border: Border.all(color: C.accent, width: 1),
                        )
                      : (isComic
                          ? BoxDecoration(
                              color: C.primaryHi,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: Colors.black, width: 3),
                            )
                          : BoxDecoration(
                              color: const Color(0xFF2C3E50)
                                  .withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                            )),
                  child: Text(
                    "Pratinjau iPhone Quote",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: isHud
                          ? C.hudNeon()
                          : (isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : const Color(0xFF2C3E50)),
                      letterSpacing: 0.3,
                      fontFamily: isComic ? 'Bangers' : null,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _generatedImage != null
                ? Container(
                    decoration: isHud
                        ? BoxDecoration(
                            border: Border.all(color: C.accent, width: 1.4),
                            boxShadow: [
                              BoxShadow(
                                color: C.accent.withValues(alpha: 0.4),
                                blurRadius: 12,
                              ),
                            ],
                          )
                        : BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(isComic ? 0 : 16),
                            border: Border.all(
                                color: isComic
                                    ? Colors.black
                                    : Colors.grey.shade200,
                                width: isComic ? 4 : 1),
                            boxShadow: isComic
                                ? null
                                : [
                                    BoxShadow(
                                      color:
                                          Colors.black.withValues(alpha: 0.08),
                                      blurRadius: 20,
                                    ),
                                  ],
                          ),
                    child: ClipRRect(
                      borderRadius:
                          BorderRadius.circular(isHud ? 0 : (isComic ? 0 : 16)),
                      child: Image.memory(
                        _generatedImage!,
                        fit: BoxFit.contain,
                        height: 300,
                      ),
                    ),
                  )
                : Container(
                    height: 300,
                    decoration: isHud
                        ? BoxDecoration(
                            color: C.bgDeep.withValues(alpha: 0.6),
                            border: Border.all(
                                color: C.accent.withValues(alpha: 0.4),
                                width: 1),
                          )
                        : BoxDecoration(
                            color: isComic
                                ? Colors.white
                                : Colors.grey.shade50,
                            borderRadius: BorderRadius.circular(
                                isComic ? 0 : 16),
                            border: Border.all(
                              color: isComic
                                  ? Colors.black
                                  : Colors.grey.shade300,
                              width: isComic ? 4 : 2,
                            ),
                          ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: isHud
                              ? BoxDecoration(
                                  color: C.accent.withValues(alpha: 0.1),
                                  border: Border.all(
                                      color: C.accent, width: 1),
                                )
                              : BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: (isComic
                                          ? C.primaryHi
                                          : const Color(0xFF2C3E50))
                                      .withValues(alpha: 0.05),
                                ),
                          child: Icon(
                            Icons.phone_iphone_outlined,
                            size: 60,
                            color: isHud
                                ? C.accent
                                : (isComic
                                    ? C.primaryHi
                                    : Colors.grey.shade500),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          "iPhone Quote akan muncul di sini",
                          style: TextStyle(
                            color: isHud
                                ? C.hudText()
                                : (isComic
                                    ? C.comicText
                                    : Colors.grey.shade700),
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                            fontFamily: isComic ? 'ComicNeue' : null,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Isi form untuk membuat pratinjau",
                          style: TextStyle(
                            color: isHud
                                ? C.hudTextDim()
                                : (isComic
                                    ? C.comicTextSub
                                    : Colors.grey.shade500),
                            fontSize: 13,
                            fontFamily: isComic ? 'ComicNeue' : null,
                          ),
                        ),
                      ],
                    ),
                  ),
            const SizedBox(height: 20),
            if (_imageGenerated)
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20, vertical: 12),
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withValues(alpha: 0.15),
                        border: Border.all(color: C.accent, width: 1.4),
                        boxShadow: [
                          BoxShadow(
                            color: C.accent.withValues(alpha: 0.35),
                            blurRadius: 10,
                          ),
                        ],
                      )
                    : (isComic
                        ? BoxDecoration(
                            color: C.primaryHi,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.black, width: 3),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black,
                                offset: Offset(3, 3),
                                blurRadius: 0,
                              ),
                            ],
                          )
                        : BoxDecoration(
                            color: const Color(0xFF27AE60)
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: const Color(0xFF27AE60),
                              width: 1,
                            ),
                          )),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.check_circle,
                      color: isHud
                          ? C.accent
                          : (isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : const Color(0xFF27AE60)),
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      "iPhone Quote Siap!",
                      style: TextStyle(
                        color: isHud
                            ? C.hudNeon()
                            : (isComic
                                ? C.contrastTextOn(C.primaryHi)
                                : const Color(0xFF229954)),
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                        fontFamily: isComic ? 'Bangers' : null,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // FORM CARD
  // ═══════════════════════════════════════════════════════
  Widget _buildFormCard(AppPalette C, bool isComic, bool isHud) {
    return Container(
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: C.accent.withValues(alpha: 0.15),
                  blurRadius: 12,
                ),
              ],
            )
          : (isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withValues(alpha: 0.08),
                      blurRadius: 25,
                      spreadRadius: 0,
                      offset: const Offset(0, 8),
                    ),
                  ],
                  border:
                      Border.all(color: const Color(0xFFE9ECEF), width: 1),
                )),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            // Time and Battery Row
            Row(
              children: [
                Expanded(
                  child: _buildInputField(
                    C: C,
                    isComic: isComic,
                    isHud: isHud,
                    label: "Waktu",
                    icon: Icons.access_time,
                    controller: _timeController,
                    hint: "18:00",
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildInputField(
                    C: C,
                    isComic: isComic,
                    isHud: isHud,
                    label: "Baterai (%)",
                    icon: Icons.battery_charging_full,
                    controller: _batteryController,
                    hint: "40",
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Carrier Dropdown
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.network_cell,
                      size: 18,
                      color: isHud
                          ? C.hudText()
                          : (isComic
                              ? C.comicText
                              : Colors.grey.shade700),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "Operator",
                      style: TextStyle(
                        color: isHud
                            ? C.hudText()
                            : (isComic
                                ? C.comicText
                                : Colors.grey.shade800),
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        fontFamily: isComic ? 'ComicNeue' : null,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.bgDeep.withValues(alpha: 0.7),
                          border: Border.all(
                              color: C.accent.withValues(alpha: 0.4),
                              width: 1),
                        )
                      : BoxDecoration(
                          borderRadius: BorderRadius.circular(isComic ? 0 : 12),
                          border: Border.all(
                            color: isComic
                                ? Colors.black
                                : Colors.grey.shade300,
                            width: isComic ? 3 : 1,
                          ),
                          color: isComic ? Colors.white : null,
                        ),
                  child: DropdownButtonFormField<String>(
                    value: _selectedCarrier,
                    dropdownColor: isHud
                        ? C.hudPanelHi()
                        : (isComic ? Colors.white : Colors.white),
                    style: TextStyle(
                      color: isHud
                          ? C.hudText()
                          : (isComic ? Colors.black : Colors.grey.shade900),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      fontFamily: isComic ? 'ComicNeue' : null,
                    ),
                    decoration: InputDecoration(
                      filled: !isHud,
                      fillColor: isHud
                          ? null
                          : (isComic
                              ? Colors.white
                              : Colors.grey.shade50),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(isHud ? 0 : 12),
                        borderSide: BorderSide.none,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(isHud ? 0 : 12),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(isHud ? 0 : 12),
                        borderSide: BorderSide(
                          color: isHud
                              ? C.accent
                              : (isComic
                                  ? C.primaryHi
                                  : const Color(0xFF2C3E50)),
                          width: 2,
                        ),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                    ),
                    icon: Icon(
                      Icons.arrow_drop_down,
                      color: isHud
                          ? C.accent
                          : (isComic
                              ? C.comicText
                              : Colors.grey.shade700),
                    ),
                    items: _carrierOptions.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Text(
                            value,
                            style: TextStyle(
                              color: isHud
                                  ? C.hudText()
                                  : (isComic
                                      ? Colors.black
                                      : Colors.grey.shade900),
                              fontSize: 16,
                              fontFamily: isComic ? 'ComicNeue' : null,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedCarrier = newValue!;
                      });
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Message Field
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.message_outlined,
                      size: 18,
                      color: isHud
                          ? C.hudText()
                          : (isComic
                              ? C.comicText
                              : Colors.grey.shade700),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "Pesan",
                      style: TextStyle(
                        color: isHud
                            ? C.hudText()
                            : (isComic
                                ? C.comicText
                                : Colors.grey.shade800),
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        fontFamily: isComic ? 'ComicNeue' : null,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _messageController,
                  style: TextStyle(
                    color: isHud
                        ? C.hudText()
                        : (isComic ? Colors.black : Colors.grey.shade900),
                    fontSize: 16,
                    fontFamily: isComic ? 'ComicNeue' : null,
                  ),
                  cursorColor: isHud
                      ? C.accent
                      : (isComic ? Colors.black : const Color(0xFF2C3E50)),
                  decoration: InputDecoration(
                    hintText: "Tulis pesan di sini...",
                    hintStyle: TextStyle(
                      color: isHud
                          ? C.hudTextDim()
                          : (isComic
                              ? Colors.black.withValues(alpha: 0.4)
                              : null),
                      fontFamily: isComic ? 'ComicNeue' : null,
                    ),
                    filled: true,
                    fillColor: isHud
                        ? C.bgDeep.withValues(alpha: 0.7)
                        : (isComic ? Colors.white : Colors.grey.shade50),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(isHud ? 0 : 12),
                      borderSide: isHud
                          ? BorderSide(
                              color: C.accent.withValues(alpha: 0.4),
                              width: 1)
                          : BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(isHud ? 0 : 12),
                      borderSide: isHud
                          ? BorderSide(
                              color: C.accent.withValues(alpha: 0.4),
                              width: 1)
                          : BorderSide(
                              color: isComic
                                  ? Colors.black
                                  : Colors.grey.shade300,
                              width: isComic ? 3 : 1,
                            ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(isHud ? 0 : 12),
                      borderSide: BorderSide(
                        color: isHud
                            ? C.accent
                            : (isComic
                                ? C.primaryHi
                                : const Color(0xFF2C3E50)),
                        width: 2,
                      ),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                  ),
                  maxLines: 3,
                  maxLength: 100,
                ),
              ],
            ),
            const SizedBox(height: 15),

            // Info Box
            Container(
              padding: const EdgeInsets.all(14),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.bgDeep.withValues(alpha: 0.7),
                      border: Border.all(
                          color: C.accent.withValues(alpha: 0.4), width: 1),
                    )
                  : (isComic
                      ? BoxDecoration(
                          color: C.bg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.black, width: 3),
                        )
                      : BoxDecoration(
                          color: const Color(0xFFF2F4F8),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: const Color(0xFFD5DBE1),
                            width: 1,
                          ),
                        )),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline_rounded,
                    size: 18,
                    color: isHud
                        ? C.accent
                        : (isComic
                            ? C.comicText
                            : const Color(0xFF2C3E50)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "Format: waktu (contoh: 18:00), baterai (0-100), operator, dan pesan",
                      style: TextStyle(
                        color: isHud
                            ? C.hudText()
                            : (isComic
                                ? C.comicText
                                : Colors.grey.shade700),
                        fontSize: 13.5,
                        fontWeight: FontWeight.w500,
                        fontFamily: isComic ? 'ComicNeue' : null,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 25),

            // Generate Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _generateIqc,
                style: isHud
                    ? ElevatedButton.styleFrom(
                        backgroundColor:
                            C.accent.withValues(alpha: 0.15),
                        foregroundColor: C.hudText(),
                        padding: const EdgeInsets.symmetric(
                            vertical: 18, horizontal: 24),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(0),
                          side: BorderSide(color: C.accent, width: 1.4),
                        ),
                        elevation: 0,
                        shadowColor: C.accent.withValues(alpha: 0.4),
                      )
                    : (isComic
                        ? ElevatedButton.styleFrom(
                            backgroundColor: C.primaryHi,
                            foregroundColor:
                                C.contrastTextOn(C.primaryHi),
                            padding: const EdgeInsets.symmetric(
                                vertical: 18, horizontal: 24),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(0),
                              side: const BorderSide(
                                  color: Colors.black, width: 4),
                            ),
                            elevation: 6,
                            shadowColor: Colors.black,
                          )
                        : ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2C3E50),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                vertical: 18, horizontal: 24),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                            elevation: 4,
                            shadowColor: const Color(0xFF2C3E50)
                                .withValues(alpha: 0.3),
                          )),
                child: _isLoading
                    ? const SizedBox(
                        height: 24,
                        width: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 3,
                          valueColor:
                              AlwaysStoppedAnimation(Colors.white),
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.auto_awesome,
                            size: 22,
                            color: isHud
                                ? C.accent
                                : (isComic
                                    ? C.contrastTextOn(C.primaryHi)
                                    : Colors.white),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            "BUAT IPHONE QUOTE",
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                              letterSpacing: 0.5,
                              color: isHud
                                  ? C.hudText()
                                  : (isComic
                                      ? C.contrastTextOn(C.primaryHi)
                                      : Colors.white),
                              fontFamily: isComic ? 'Bangers' : null,
                            ),
                          ),
                        ],
                      ),
              ),
            ),

            if (_imageGenerated) ...[
              const SizedBox(height: 30),
              Divider(
                  height: 1,
                  color: isHud
                      ? C.accent.withValues(alpha: 0.3)
                      : const Color(0xFFE0E0E0)),
              const SizedBox(height: 20),
              Text(
                "Bagikan Hasil Anda",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: isHud
                      ? C.hudNeon()
                      : (isComic
                          ? C.comicText
                          : Colors.grey.shade800),
                  letterSpacing: 0.3,
                  fontFamily: isComic ? 'Bangers' : null,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: isHud
                        ? _buildHudButton(
                            C: C,
                            icon: _isSharing
                                ? Icons.hourglass_bottom
                                : Icons.save_alt_rounded,
                            label: _isSharing ? "Menyimpan..." : "SIMPAN",
                            onTap: _isSharing ? null : _saveToGallery,
                          )
                        : OutlinedButton(
                            onPressed: _isSharing ? null : _saveToGallery,
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(
                                  color: isComic
                                      ? Colors.black
                                      : const Color(0xFF2C3E50),
                                  width: isComic ? 3 : 1.5),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                    isComic ? 0 : 12),
                              ),
                              backgroundColor: isComic ? Colors.white : null,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  _isSharing
                                      ? Icons.hourglass_bottom
                                      : Icons.save_alt_rounded,
                                  color: isComic
                                      ? Colors.black
                                      : const Color(0xFF2C3E50),
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  _isSharing ? "Menyimpan..." : "SIMPAN",
                                  style: TextStyle(
                                    color: isComic
                                        ? Colors.black
                                        : const Color(0xFF2C3E50),
                                    fontWeight: FontWeight.w700,
                                    fontSize: 15,
                                    fontFamily:
                                        isComic ? 'Bangers' : null,
                                  ),
                                ),
                              ],
                            ),
                          ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: isHud
                        ? _buildHudButton(
                            C: C,
                            icon: _isSharing
                                ? Icons.hourglass_bottom
                                : Icons.share_rounded,
                            label: _isSharing ? "Membagikan..." : "BAGIKAN",
                            onTap: _isSharing ? null : _shareImage,
                            filled: true,
                          )
                        : ElevatedButton(
                            onPressed: _isSharing ? null : _shareImage,
                            style: isComic
                                ? ElevatedButton.styleFrom(
                                    backgroundColor: C.primaryHi,
                                    foregroundColor:
                                        C.contrastTextOn(C.primaryHi),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 16),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(0),
                                      side: const BorderSide(
                                          color: Colors.black, width: 3),
                                    ),
                                    elevation: 6,
                                    shadowColor: Colors.black,
                                  )
                                : ElevatedButton.styleFrom(
                                    backgroundColor:
                                        const Color(0xFF3498DB),
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 16),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    elevation: 4,
                                    shadowColor: const Color(0xFF3498DB)
                                        .withValues(alpha: 0.3),
                                  ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  _isSharing
                                      ? Icons.hourglass_bottom
                                      : Icons.share_rounded,
                                  size: 20,
                                  color: isComic
                                      ? C.contrastTextOn(C.primaryHi)
                                      : Colors.white,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  _isSharing ? "Membagikan..." : "BAGIKAN",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 15,
                                    color: isComic
                                        ? C.contrastTextOn(C.primaryHi)
                                        : Colors.white,
                                    fontFamily:
                                        isComic ? 'Bangers' : null,
                                  ),
                                ),
                              ],
                            ),
                          ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // GUIDE CARD
  // ═══════════════════════════════════════════════════════
  Widget _buildGuideCard(AppPalette C, bool isComic, bool isHud) {
    return Container(
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: C.accent.withValues(alpha: 0.15),
                  blurRadius: 12,
                ),
              ],
            )
          : (isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withValues(alpha: 0.08),
                      blurRadius: 25,
                      spreadRadius: 0,
                      offset: const Offset(0, 8),
                    ),
                  ],
                  border:
                      Border.all(color: const Color(0xFFE9ECEF), width: 1),
                )),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withValues(alpha: 0.15),
                          border: Border.all(color: C.accent, width: 1),
                        )
                      : BoxDecoration(
                          shape: isComic ? BoxShape.rectangle : BoxShape.circle,
                          borderRadius:
                              isComic ? BorderRadius.circular(8) : null,
                          color: isComic
                              ? C.primaryHi
                              : const Color(0xFF2C3E50)
                                  .withValues(alpha: 0.1),
                          border: isComic
                              ? Border.all(color: Colors.black, width: 3)
                              : null,
                        ),
                  child: Icon(
                    Icons.help_outline_rounded,
                    color: isHud
                        ? C.accent
                        : (isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : const Color(0xFF2C3E50)),
                    size: 22,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  "Panduan Penggunaan",
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                    color: isHud
                        ? C.hudNeon()
                        : (isComic
                            ? C.comicText
                            : Colors.grey.shade900),
                    letterSpacing: 0.3,
                    fontFamily: isComic ? 'Bangers' : null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildStep(C, isComic, isHud, 1,
                    "Masukkan waktu (contoh: 18:00)"),
                _buildStep(C, isComic, isHud, 2,
                    "Masukkan persentase baterai (0-100)"),
                _buildStep(C, isComic, isHud, 3, "Pilih operator seluler"),
                _buildStep(C, isComic, isHud, 4,
                    "Tulis pesan yang ingin ditampilkan"),
                _buildStep(C, isComic, isHud, 5,
                    "Klik 'Buat iPhone Quote'"),
                _buildStep(C, isComic, isHud, 6,
                    "Simpan atau bagikan hasilnya"),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.bgDeep.withValues(alpha: 0.7),
                      border: Border.all(
                          color: C.accent.withValues(alpha: 0.4), width: 1),
                    )
                  : (isComic
                      ? BoxDecoration(
                          color: C.bg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.black, width: 3),
                        )
                      : BoxDecoration(
                          color: const Color(0xFFF2F4F8),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: const Color(0xFFD5DBE1),
                            width: 1,
                          ),
                        )),
              child: Row(
                children: [
                  Icon(
                    Icons.lightbulb_outline_rounded,
                    color: isHud
                        ? C.accent
                        : (isComic
                            ? C.comicText
                            : const Color(0xFF2C3E50)),
                    size: 20,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "Contoh format lengkap: Waktu = 18:00, Baterai = 40%, Operator = Indosat, Pesan = Halo bang",
                      style: TextStyle(
                        fontSize: 14,
                        color: isHud
                            ? C.hudText()
                            : (isComic
                                ? C.comicText
                                : const Color(0xFF4A5568)),
                        fontWeight: FontWeight.w500,
                        height: 1.5,
                        fontFamily: isComic ? 'ComicNeue' : null,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════
  Widget _buildHudButton({
    required AppPalette C,
    required IconData icon,
    required String label,
    VoidCallback? onTap,
    bool filled = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: filled
              ? C.accent.withValues(alpha: 0.15)
              : Colors.transparent,
          border: Border.all(color: C.accent, width: 1.4),
          boxShadow: [
            BoxShadow(
              color: C.accent.withValues(alpha: 0.3),
              blurRadius: 10,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: C.accent, size: 20),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                color: C.hudText(),
                fontWeight: FontWeight.w700,
                fontSize: 15,
                fontFamily: 'Orbitron',
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required String label,
    required IconData icon,
    required TextEditingController controller,
    required String hint,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              size: 18,
              color: isHud
                  ? C.hudText()
                  : (isComic ? C.comicText : Colors.grey.shade700),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isHud
                    ? C.hudText()
                    : (isComic ? C.comicText : Colors.grey.shade800),
                fontWeight: FontWeight.w600,
                fontSize: 14,
                fontFamily: isComic ? 'ComicNeue' : null,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          style: TextStyle(
            color: isHud
                ? C.hudText()
                : (isComic ? Colors.black : Colors.grey.shade900),
            fontSize: 16,
            fontFamily: isComic ? 'ComicNeue' : null,
          ),
          cursorColor: isHud
              ? C.accent
              : (isComic ? Colors.black : const Color(0xFF2C3E50)),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: isHud
                  ? C.hudTextDim()
                  : (isComic ? Colors.black.withValues(alpha: 0.4) : null),
              fontFamily: isComic ? 'ComicNeue' : null,
            ),
            filled: true,
            fillColor: isHud
                ? C.bgDeep.withValues(alpha: 0.7)
                : (isComic ? Colors.white : Colors.grey.shade50),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(isHud ? 0 : 12),
              borderSide: isHud
                  ? BorderSide(
                      color: C.accent.withValues(alpha: 0.4), width: 1)
                  : BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(isHud ? 0 : 12),
              borderSide: isHud
                  ? BorderSide(
                      color: C.accent.withValues(alpha: 0.4), width: 1)
                  : BorderSide(
                      color:
                          isComic ? Colors.black : Colors.grey.shade300,
                      width: isComic ? 3 : 1,
                    ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(isHud ? 0 : 12),
              borderSide: BorderSide(
                color: isHud
                    ? C.accent
                    : (isComic
                        ? C.primaryHi
                        : const Color(0xFF2C3E50)),
                width: 2,
              ),
            ),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          ),
        ),
      ],
    );
  }

  Widget _buildStep(
      AppPalette C, bool isComic, bool isHud, int number, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: isHud
                ? BoxDecoration(
                    color: C.accent.withValues(alpha: 0.15),
                    border: Border.all(color: C.accent, width: 1.2),
                    boxShadow: [
                      BoxShadow(
                        color: C.accent.withValues(alpha: 0.35),
                        blurRadius: 8,
                      ),
                    ],
                  )
                : (isComic
                    ? BoxDecoration(
                        color: C.primaryHi,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.black, width: 3),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        color: const Color(0xFF2C3E50),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF2C3E50)
                                .withValues(alpha: 0.3),
                            blurRadius: 6,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      )),
            child: Center(
              child: Text(
                "$number",
                style: TextStyle(
                  color: isHud
                      ? C.hudNeon()
                      : (isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : Colors.white),
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  fontFamily: isComic ? 'Bangers' : null,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                text,
                style: TextStyle(
                  color: isHud
                      ? C.hudText()
                      : (isComic
                          ? C.comicText
                          : Colors.grey.shade800),
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  height: 1.5,
                  fontFamily: isComic ? 'ComicNeue' : null,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timeController.dispose();
    _batteryController.dispose();
    _messageController.dispose();
    super.dispose();
  }
}

// ═══════════════════════════════════════════════════════════
// HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _HalftonePainter extends CustomPainter {
  final Color color;
  const _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}