// lib/tiktok_page.dart — 3 Style Support
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'api_config.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ═══════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      if (!blink) {
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: color,
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3,
              ),
            ],
          ),
        );
      }
      return ValueListenableBuilder<double>(
        valueListenable: _Pulse.v,
        builder: (_, v, __) => Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: color.withOpacity(0.4 + v * 0.6),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3,
              ),
            ],
          ),
        ),
      );
    }

    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
            color: Colors.black.withOpacity(0.85),
            width: size * 0.1,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.75 * opacity),
              blurRadius: size * 1.4,
              spreadRadius: size * 0.2,
            ),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final double size;
  const _Screw({this.size = 14});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: Alignment(-0.35, -0.35),
          colors: [Color(0xFF9A9286), Color(0xFF5A554C),
              Color(0xFF3D3933), Color(0xFF2A2723)],
          stops: [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final double size;
  const _Rivet({this.size = 10});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withOpacity(0.6), width: 1),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: Alignment(-0.35, -0.35),
          colors: [Color(0xFFF5DEB3), Color(0xFFE8C87F),
              Color(0xFFC9A961), Color(0xFF6B5015)],
          stops: [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _MetalPlate({
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
                color: C.accent.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF9A9286), Color(0xFF3D3933),
              Color(0xFF2A2723), Color(0xFF1A1815)],
          stops: [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF3D2E22), Color(0xFF2A1F18), Color(0xFF1A1310)],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12,
        height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.8)),
        ),
      );
}

// ═══════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ═══════════════════════════════════════════════════════
class _IndustrialButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.child,
    required this.onTap,
    this.color = const Color(0xFFC9A961),
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final enabled = widget.onTap != null;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);

    final textColor = isComic
        ? C.contrastTextOn(widget.color)
        : (isHud ? widget.color : Colors.white);

    return GestureDetector(
      onTapDown:
          enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              HapticFeedback.mediumImpact();
              widget.onTap?.call();
            }
          : null,
      onTapCancel:
          enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(
                _pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: isHud
            ? BoxDecoration(
                color: widget.color.withOpacity(
                    _pressed ? 0.25 : (enabled ? 0.15 : 0.05)),
                border: Border.all(
                    color: widget.color
                        .withOpacity(enabled ? 1 : 0.4),
                    width: 1.4),
                boxShadow: _pressed || !enabled
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withOpacity(0.4),
                          blurRadius: 12,
                        ),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: isComic
                    ? null
                    : LinearGradient(
                        begin: _pressed
                            ? Alignment.bottomCenter
                            : Alignment.topCenter,
                        end: _pressed
                            ? Alignment.topCenter
                            : Alignment.bottomCenter,
                        colors: _pressed
                            ? [dark, dark, widget.color]
                            : [light, widget.color, dark],
                        stops: const [0.0, 0.5, 1.0],
                      ),
                color: isComic ? widget.color : null,
                boxShadow: isComic
                    ? (_pressed
                        ? []
                        : const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ])
                    : (_pressed
                        ? [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.9),
                              offset: const Offset(0, 1),
                              blurRadius: 3,
                            ),
                          ]
                        : [
                            BoxShadow(
                              color: widget.color.withOpacity(0.45),
                              offset: const Offset(0, 5),
                              blurRadius: 10,
                              spreadRadius: -2,
                            ),
                            BoxShadow(
                              color: Colors.black.withOpacity(0.75),
                              offset: const Offset(0, 4),
                              blurRadius: 6,
                            ),
                          ]),
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : dark.withOpacity(0.9),
                    width: isComic ? 3.5 : 1.5),
              ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic && !isHud) ...[
              const Positioned(top: 5, left: 5, child: _Rivet(size: 6)),
              const Positioned(top: 5, right: 5, child: _Rivet(size: 6)),
              const Positioned(
                  bottom: 5, left: 5, child: _Rivet(size: 6)),
              const Positioned(
                  bottom: 5, right: 5, child: _Rivet(size: 6)),
            ],
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Opacity(
                opacity: enabled ? 1 : 0.5,
                child: DefaultTextStyle(
                  style: TextStyle(
                    color: textColor,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                  child: IconTheme(
                    data: IconThemeData(color: textColor),
                    child: widget.child,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(c.alpha,
      (c.red + 40).clamp(0, 255),
      (c.green + 40).clamp(0, 255),
      (c.blue + 30).clamp(0, 255));
  static Color _darken(Color c) => Color.fromARGB(c.alpha,
      (c.red - 60).clamp(0, 255),
      (c.green - 50).clamp(0, 255),
      (c.blue - 40).clamp(0, 255));
}

// ═══════════════════════════════════════════════════════
// TIKTOK DOWNLOADER PAGE
// ═══════════════════════════════════════════════════════
class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() =>
      _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  bool _isSharing = false;
  bool _hd = false;
  String? _errorMessage;
  Map<String, dynamic>? _videoData;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
  }

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _downloadTiktok() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _errorMessage = 'URL TikTok tidak boleh kosong.';
        _videoData = null;
      });
      return;
    }

    if (!url.contains('tiktok.com') &&
        !url.contains('vt.tiktok') &&
        !url.contains('vm.tiktok') &&
        !url.contains('douyin')) {
      setState(() {
        _errorMessage =
            'Link harus dari TikTok (vt.tiktok.com / tiktok.com)';
        _videoData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });

    try {
      final apiUrl =
          '$baseUrl/tiktok/download?url=${Uri.encodeComponent(url)}&hd=${_hd ? '1' : '0'}';
      print('[TIKTOK] Fetch: $apiUrl');

      final res = await http.get(
        Uri.parse(apiUrl),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 45));

      if (res.statusCode != 200) {
        setState(() {
          _errorMessage =
              'Server error (${res.statusCode}). Coba lagi nanti.';
        });
        return;
      }

      final json = jsonDecode(res.body) as Map<String, dynamic>;

      if (json['valid'] != true) {
        setState(() {
          _errorMessage = json['message'] ?? 'Gagal ambil data video';
        });
        return;
      }

      final videos =
          json['videos'] as Map<String, dynamic>? ?? {};
      final author =
          json['author'] as Map<String, dynamic>? ?? {};
      final audio = json['audio'] as Map<String, dynamic>? ?? {};

      final parsed = {
        'title': json['title'] ?? 'TikTok Video',
        'videoUrl': videos['noWatermark'] ??
            videos['hd'] ??
            videos['withWatermark'] ??
            '',
        'videoWm': videos['withWatermark'] ?? '',
        'videoHd': videos['hd'] ?? '',
        'audioUrl': audio['url'] ?? '',
        'thumbnail': json['cover'] ?? '',
        'creator':
            author['nickname'] ?? author['uniqueId'] ?? 'Unknown',
        'duration': json['duration'] ?? 0,
        'source': json['source'] ?? 'unknown',
      };

      setState(() => _videoData = parsed);
      _initializeVideoPlayer();
    } catch (e) {
      setState(() {
        _errorMessage = 'Terjadi kesalahan: $e';
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _initializeVideoPlayer() {
    final url = _videoData?['videoUrl'] as String?;
    if (url == null || url.isEmpty) {
      setState(() {
        _errorMessage = 'URL video kosong.';
      });
      return;
    }

    _videoController = VideoPlayerController.networkUrl(
      Uri.parse(url),
      httpHeaders: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
        'Accept': '*/*',
      },
    );

    Future.delayed(const Duration(seconds: 20), () {
      if (!mounted) return;
      if (_videoController?.value.isInitialized != true) {
        setState(() {
          _errorMessage =
              'Video loading timeout. Koneksi lambat / URL ga valid.';
        });
        _videoController?.dispose();
      }
    });

    _videoController!.initialize().then((_) {
      if (!mounted) return;
      final C = AppTheme.current.value;
      setState(() {
        _chewieController = ChewieController(
          videoPlayerController: _videoController!,
          autoPlay: true,
          looping: false,
          showControls: true,
          materialProgressColors: ChewieProgressColors(
            playedColor: C.accent,
            handleColor: C.accentShine,
            backgroundColor: C.bgDark,
            bufferedColor: C.bg,
          ),
        );
      });
    }).catchError((e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Gagal load video player: $e';
        });
      }
    });
  }

  Future<void> _shareVideo() async {
    if (_videoData == null) return;
    setState(() => _isSharing = true);

    try {
      final videoUrl = _videoData!['videoUrl'] as String?;
      if (videoUrl == null || videoUrl.isEmpty) {
        _showSnack('URL video tidak tersedia', isError: true);
        return;
      }

      final response = await http.get(
        Uri.parse(videoUrl),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
          'Accept': '*/*',
        },
      ).timeout(const Duration(seconds: 60));

      if (response.statusCode != 200) {
        _showSnack('Gagal download video: ${response.statusCode}',
            isError: true);
        return;
      }

      final tempDir = await getTemporaryDirectory();
      final fileName =
          'tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Video TikTok dari: ${_videoData!['creator']}',
      );
    } catch (e) {
      _showSnack('Error sharing: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSharing = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final c = isError ? C.primaryHi : C.primaryHi;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: c, size: 8, blink: true),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudText() : Colors.white),
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isHud ? C.hudPanel() : C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(
            color: isComic ? Colors.black : c,
            width: isComic ? 3 : 1.5,
          ),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _pasteFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data != null && data.text != null && data.text!.isNotEmpty) {
      setState(() {
        _urlController.text = data.text!.trim();
      });
      HapticFeedback.lightImpact();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor: isComic
                  ? C.bg
                  : (isHud ? C.hudBg() : const Color(0xFF0A0806)),
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color:
                                      C.primaryLo.withOpacity(0.12)),
                            ),
                          )
                        : (isHud
                            ? Container(
                                color: C.hudBg(),
                                child: CustomPaint(
                                  painter: _HudGridPainter(
                                      color: C.hudGridLine()),
                                ),
                              )
                            : Container(
                                decoration: const BoxDecoration(
                                  gradient: RadialGradient(
                                    center: Alignment(-0.3, -0.3),
                                    radius: 1.2,
                                    colors: [
                                      Color(0xFF2A1F18),
                                      Color(0xFF1A1310),
                                      Color(0xFF0A0806),
                                    ],
                                    stops: [0.0, 0.6, 1.0],
                                  ),
                                ),
                              )),
                  ),
                  SafeArea(
                    child: Column(
                      children: [
                        const SizedBox(height: 8),
                        _buildAppBar(C, isComic, isHud),
                        const SizedBox(height: 12),
                        Expanded(
                          child: SingleChildScrollView(
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14),
                            child: Column(
                              children: [
                                _buildInputPlate(C, isComic, isHud),
                                const SizedBox(height: 14),
                                if (_errorMessage != null)
                                  _buildErrorPlate(C, isComic, isHud),
                                if (_videoData != null)
                                  _buildVideoPlate(C, isComic, isHud),
                                const SizedBox(height: 30),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: _MetalPlate(
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                Navigator.pop(context);
              },
              child: Container(
                width: 40, height: 40,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: isComic
                            ? null
                            : const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                    Color(0xFF5A554C),
                                    Color(0xFF3D3933),
                                    Color(0xFF2A2723)
                                  ],
                              ),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : Colors.black.withOpacity(0.7),
                            width: isComic ? 3 : 1.2),
                        boxShadow: isComic
                            ? const [
                                BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(3, 3),
                                    blurRadius: 0),
                              ]
                            : null,
                      ),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : (isHud ? C.hudNeon() : C.accent),
                    size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border:
                              Border.all(color: C.accent, width: 1.2),
                          boxShadow: [
                            BoxShadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 10),
                          ],
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic
                              ? null
                              : const RadialGradient(
                                  colors: [
                                    Color(0xFF9A9286),
                                    Color(0xFF3D3933),
                                    Color(0xFF2A2723)
                                  ],
                                ),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                              color:
                                  isComic ? Colors.black : C.primaryHi,
                              width: isComic ? 3 : 2),
                          boxShadow: isHud
                              ? null
                              : [
                                  BoxShadow(
                                    color:
                                        C.primaryHi.withOpacity(0.5),
                                    blurRadius: 10,
                                    spreadRadius: 1,
                                  ),
                                ],
                        ),
                  child: Icon(
                    Icons.music_note_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.hudNeon() : C.primaryHi),
                    size: 20,
                  ),
                ),
                Positioned(
                  top: -2,
                  right: -2,
                  child: _Led(
                      color: isHud ? C.accent : C.accent,
                      size: 6,
                      blink: true),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'TIKTOK DL',
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudNeon() : C.accentHi),
                      fontSize: isComic ? 18 : 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2,
                      height: 1,
                      shadows: isComic
                          ? [
                              Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0),
                            ]
                          : (isHud
                              ? [
                                  Shadow(
                                      color: C.accent
                                          .withOpacity(0.5),
                                      blurRadius: 8),
                                ]
                              : [
                                  const Shadow(
                                      color: Color(0xFF6B5015),
                                      offset: Offset(0, 1),
                                      blurRadius: 1),
                                  const Shadow(
                                      color: Colors.black,
                                      offset: Offset(0, 2),
                                      blurRadius: 3),
                                ]),
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(
                          color: isHud
                              ? C.accent
                              : C.primaryHi,
                          size: 4,
                          blink: true),
                      const SizedBox(width: 5),
                      Text(
                        'NO WATERMARK',
                        style: TextStyle(
                          color: isComic
                              ? C.comicTextSub
                              : (isHud
                                  ? C.hudTextDim()
                                  : const Color(0xFFE8DFC8)
                                      .withOpacity(0.55)),
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            _Led(
                color: isHud ? C.hudNeon() : C.primaryHi,
                size: 7,
                blink: true),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPlate(AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (!isComic && !isHud) const _Screw(size: 12),
              if (!isComic && !isHud) const SizedBox(width: 10),
              Expanded(
                child: Center(
                  child: Text(
                    'PASTE URL TIKTOK',
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudNeon() : C.accent),
                      fontSize: isComic ? 16 : 11,
                      fontWeight: FontWeight.w900,
                      fontFamily:
                          isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2,
                      shadows: isComic
                          ? [
                              Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0),
                            ]
                          : (isHud
                              ? [
                                  Shadow(
                                      color: C.accent
                                          .withOpacity(0.5),
                                      blurRadius: 8),
                                ]
                              : null),
                    ),
                  ),
                ),
              ),
              if (!isComic && !isHud)
                const _Screw(size: 12),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              if (!isComic && !isHud) const _Rivet(size: 6),
              if (!isComic && !isHud) const SizedBox(width: 6),
              Icon(Icons.link_rounded,
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  size: 14),
              const SizedBox(width: 6),
              Text(
                'TIKTOK LINK',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontSize: isComic ? 12 : 9,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _hd = !_hd);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: isHud
                        ? C.accent.withOpacity(_hd ? 0.25 : 0.08)
                        : (isComic
                            ? (_hd ? C.accent : C.bgDark)
                            : (_hd
                                ? C.primaryHi.withOpacity(0.2)
                                : const Color(0xFF2A2723))),
                    borderRadius: BorderRadius.circular(isComic ? 6 : 4),
                    border: Border.all(
                      color: isComic
                          ? Colors.black
                          : (_hd
                              ? (isHud ? C.accent : C.primaryHi)
                              : (isHud
                                  ? C.accent.withOpacity(0.4)
                                  : const Color(0xFF5A554C))),
                      width: isComic ? 2 : 1.2,
                    ),
                    boxShadow: isHud && _hd
                        ? [
                            BoxShadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 8),
                          ]
                        : null,
                  ),
                  child: Row(
                    children: [
                      Icon(
                        _hd ? Icons.hd_rounded : Icons.hd_outlined,
                        color: isComic
                            ? C.contrastTextOn(C.accent)
                            : (_hd
                                ? (isHud ? C.hudNeon() : C.primaryHi)
                                : (isHud
                                    ? C.hudTextDim()
                                    : const Color(0xFFE8DFC8)
                                        .withOpacity(0.5))),
                        size: 12,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'HD',
                        style: TextStyle(
                          color: isComic
                              ? C.contrastTextOn(C.accent)
                              : (_hd
                                  ? (isHud
                                      ? C.hudNeon()
                                      : C.primaryHi)
                                  : (isHud
                                      ? C.hudTextDim()
                                      : const Color(0xFFE8DFC8)
                                          .withOpacity(0.5))),
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            decoration: isHud
                ? BoxDecoration(
                    color: C.bgDeep.withOpacity(0.6),
                    border: Border.all(
                        color: C.accent.withOpacity(0.5), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: C.accent.withOpacity(0.2),
                          blurRadius: 8),
                    ],
                  )
                : BoxDecoration(
                    borderRadius: BorderRadius.circular(
                        isComic ? 10 : 10),
                    gradient: isComic
                        ? null
                        : const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                                Color(0xFF0A0806),
                                Color(0xFF151210)
                              ],
                          ),
                    color: isComic ? Colors.white : null,
                    border: Border.all(
                      color: isComic
                          ? Colors.black
                          : const Color(0xFF2A2723),
                      width: isComic ? 3 : 1.5,
                    ),
                    boxShadow: isComic
                        ? const [
                            BoxShadow(
                                color: Colors.black,
                                offset: Offset(3, 3),
                                blurRadius: 0),
                          ]
                        : [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.9),
                              offset: const Offset(0, 2),
                              blurRadius: 4,
                            ),
                          ],
                  ),
            child: TextField(
              controller: _urlController,
              style: TextStyle(
                color: isComic
                    ? Colors.black
                    : (isHud
                        ? C.hudText()
                        : const Color(0xFFF5DEB3)),
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily:
                    isComic ? 'ComicNeue' : 'ShareTechMono',
                letterSpacing: 0.3,
              ),
              cursorColor: isComic
                  ? Colors.black
                  : (isHud ? C.accent : C.primaryHi),
              maxLines: 2,
              minLines: 1,
              decoration: InputDecoration(
                hintText: 'https://vt.tiktok.com/xxx/',
                hintStyle: TextStyle(
                  color: isComic
                      ? Colors.black.withOpacity(0.4)
                      : (isHud
                          ? C.hudTextDim()
                          : const Color(0xFFE8DFC8)
                              .withOpacity(0.3)),
                  fontSize: 11,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
                prefixIcon: Padding(
                  padding: const EdgeInsets.only(
                      left: 10, right: 6, top: 2, bottom: 2),
                  child: Icon(Icons.download_rounded,
                      color: isComic
                          ? C.primaryHi
                          : (isHud
                              ? C.hudNeon()
                              : C.primaryHi),
                      size: 18),
                ),
                suffixIcon: GestureDetector(
                  onTap: _pasteFromClipboard,
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      color: isHud
                          ? C.accent.withOpacity(0.15)
                          : (isComic
                              ? C.primaryHi
                              : const Color(0xFF3D3933)),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                          color: isComic
                              ? Colors.black
                              : (isHud
                                  ? C.accent
                                  : const Color(0xFF5A554C)),
                          width: isComic ? 2 : 1),
                    ),
                    child: Center(
                      widthFactor: 1,
                      child: Text(
                        'PASTE',
                        style: TextStyle(
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : (isHud
                                  ? C.hudNeon()
                                  : const Color(0xFFE8C87F)),
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ),
                prefixIconConstraints: const BoxConstraints(
                    minWidth: 32, minHeight: 32),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 14),
          _IndustrialButton(
            color: _isLoading
                ? (isHud ? C.bg : const Color(0xFF3D3933))
                : (isHud ? C.accent : C.primaryHi),
            height: 54,
            onTap: _isLoading ? null : _downloadTiktok,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isLoading)
                  SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(
                          isHud ? C.hudNeon() : C.accent),
                    ),
                  )
                else
                  const Icon(Icons.download_rounded, size: 18),
                const SizedBox(width: 10),
                Text(
                  _isLoading ? 'MEMPROSES...' : 'DOWNLOAD',
                  style: TextStyle(
                    fontSize: isComic ? 16 : 13,
                    fontWeight: FontWeight.w900,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2,
                    shadows: isComic
                        ? [
                            Shadow(
                              color:
                                  C.contrastTextOn(C.primaryHi) ==
                                          Colors.white
                                      ? Colors.black
                                      : Colors.white,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorPlate(
      AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: isHud
                ? BoxDecoration(
                    color: C.primaryHi.withOpacity(0.15),
                    border:
                        Border.all(color: C.primaryHi, width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: C.primaryHi.withOpacity(0.5),
                          blurRadius: 10),
                    ],
                  )
                : BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic
                        ? null
                        : RadialGradient(
                            colors: [
                              const Color(0xFFC41E1E)
                                  .withOpacity(0.5),
                              const Color(0xFF8B1818)
                                  .withOpacity(0.15),
                              Colors.black.withOpacity(0.9),
                            ],
                          ),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : C.primaryHi.withOpacity(0.6),
                        width: isComic ? 3 : 1.5),
                  ),
            child: Icon(Icons.error_outline_rounded,
                color: isComic
                    ? C.contrastTextOn(C.primaryHi)
                    : C.primaryHi,
                size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudText() : C.primaryHi),
                fontSize: 11,
                fontFamily:
                    isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w600,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlate(
      AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _Led(color: C.primaryHi, size: 7, blink: true),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'VIDEO READY',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: isComic ? 13 : 11,
                    fontWeight: FontWeight.w900,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2,
                    shadows: isComic
                        ? [
                            Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0),
                          ]
                        : null,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: isHud
                      ? C.accent.withOpacity(0.15)
                      : (isComic ? C.bgDark : const Color(0xFF2A2723)),
                  borderRadius: BorderRadius.circular(isComic ? 4 : 3),
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : (isHud
                              ? C.accent
                              : const Color(0xFF5A554C)),
                      width: isComic ? 2 : 1),
                ),
                child: Text(
                  (_videoData!['source'] ?? 'N/A')
                      .toString()
                      .toUpperCase(),
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: 7,
                    fontFamily:
                        isComic ? 'Bangers' : 'ShareTechMono',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              if (!isComic && !isHud) const _Screw(size: 10),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              if (!isComic && !isHud) const _Rivet(size: 6),
              if (!isComic && !isHud) const SizedBox(width: 6),
              Icon(Icons.person_rounded,
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  size: 12),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  '${_videoData!['creator']}',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: 10,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            '${_videoData!['title']}',
            style: TextStyle(
              color: isComic
                  ? C.comicText.withOpacity(0.75)
                  : (isHud
                      ? C.hudText()
                      : const Color(0xFFE8DFC8).withOpacity(0.75)),
              fontSize: 10,
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              height: 1.4,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 10 : 10),
              border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (isHud
                          ? C.accent.withOpacity(0.5)
                          : Colors.black.withOpacity(0.7)),
                  width: isComic ? 3 : 1.5),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                          color: Colors.black,
                          offset: Offset(3, 3),
                          blurRadius: 0),
                    ]
                  : null,
            ),
            child: ClipRRect(
              borderRadius:
                  BorderRadius.circular(isComic ? 8 : 9),
              child: AspectRatio(
                aspectRatio:
                    _videoController?.value.isInitialized == true
                        ? _videoController!.value.aspectRatio
                        : 9 / 16,
                child: _chewieController != null
                    ? Chewie(controller: _chewieController!)
                    : Container(
                        color: Colors.black,
                        child: Center(
                          child: CircularProgressIndicator(
                            color: isHud
                                ? C.hudNeon()
                                : C.primaryHi,
                            strokeWidth: 2,
                          ),
                        ),
                      ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: _IndustrialButton(
                  color: _isSharing
                      ? (isHud
                          ? C.bg
                          : const Color(0xFF3D3933))
                      : (isHud ? C.accent : C.accent),
                  height: 48,
                  onTap: _isSharing ? null : _shareVideo,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (_isSharing)
                        SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(
                                    isHud
                                        ? C.hudNeon()
                                        : C.accent),
                          ),
                        )
                      else
                        const Icon(Icons.share_rounded, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        _isSharing ? 'SHARING...' : 'SHARE',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _IndustrialButton(
                  color: isHud ? C.accent : C.primaryHi,
                  height: 48,
                  onTap: () {
                    if (_videoData!['audioUrl'] != null &&
                        (_videoData!['audioUrl'] as String)
                            .isNotEmpty) {
                      Clipboard.setData(ClipboardData(
                          text: _videoData!['audioUrl']));
                      _showSnack('Link audio disalin');
                    } else {
                      _showSnack('Audio ga tersedia',
                          isError: true);
                    }
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.music_note_rounded, size: 16),
                      const SizedBox(width: 6),
                      Text(
                        'AUDIO',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) =>
      old.color != color;
}

// ═══════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}