// market_page.dart — Halaman utama Pasar Online (FINAL)
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_theme.dart';
import 'market_api.dart';
import 'market_add_page.dart';
import 'market_detail_page.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(
        Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// MARKET PAGE
// ═══════════════════════════════════════════════════════════
class MarketPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;

  const MarketPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<MarketPage> createState() => _MarketPageState();
}

class _MarketPageState extends State<MarketPage> {
  final TextEditingController _searchCtrl = TextEditingController();
  List<MarketProduct> _products = [];
  List<MarketProduct> _filtered = [];
  bool _loading = true;
  String _selectedKategori = 'Semua';

  final List<String> _kategoriList = [
    'Semua',
    'Elektronik',
    'Fashion',
    'Makanan',
    'Jasa',
    'Digital',
    'Lainnya',
  ];

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProducts() async {
    setState(() => _loading = true);
    final result = await MarketApi.getProducts(
      sessionKey: widget.sessionKey,
      kategori: _selectedKategori,
    );
    if (!mounted) return;
    setState(() {
      _products = result;
      _filtered = result;
      _loading = false;
    });
  }

  void _filterLocal(String query) {
    if (query.isEmpty) {
      setState(() => _filtered = _products);
      return;
    }
    final q = query.toLowerCase();
    setState(() {
      _filtered = _products.where((p) {
        return p.nama.toLowerCase().contains(q) ||
            p.deskripsi.toLowerCase().contains(q) ||
            p.penjual.toLowerCase().contains(q);
      }).toList();
    });
  }

  Future<void> _openAddPage() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MarketAddPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
    if (result == true) _loadProducts();
  }

  Future<void> _openDetail(MarketProduct product) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MarketDetailPage(
          product: product,
          sessionKey: widget.sessionKey,
          username: widget.username,
        ),
      ),
    );
    if (result == true) _loadProducts();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              radius: 1.2,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                              stops: const [0.0, 0.6, 1.0],
                            ),
                          )),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildAppBar(C, isComic, isHud),
                          const SizedBox(height: 8),
                          _buildSearchBar(C, isComic, isHud),
                          const SizedBox(height: 8),
                          _buildKategoriBar(C, isComic, isHud),
                          const SizedBox(height: 8),
                          Expanded(
                            child: _loading
                                ? Center(
                                    child: CircularProgressIndicator(
                                        color: isComic
                                            ? Colors.black
                                            : (isHud
                                                ? C.accent
                                                : C.accent),
                                        strokeWidth: 2))
                                : _filtered.isEmpty
                                    ? _buildEmpty(C, isComic, isHud)
                                    : _buildGrid(C, isComic, isHud),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              floatingActionButton: FloatingActionButton.extended(
                onPressed: _openAddPage,
                backgroundColor: C.primaryHi,
                foregroundColor: isComic
                    ? C.contrastTextOn(C.primaryHi)
                    : (isHud ? C.hudNeon() : Colors.white),
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(isHud ? 2 : (isComic ? 16 : 14)),
                  side: BorderSide(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.accent : C.accentShine),
                    width: isComic ? 4 : (isHud ? 1.4 : 0),
                  ),
                ),
                icon: const Icon(Icons.add_rounded),
                label: Text('JUAL PRODUK',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1,
                      fontSize: isComic ? 14 : 11)),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            _IconButton(
              C: C,
              isComic: isComic,
              isHud: isHud,
              icon: Icons.arrow_back_rounded,
              color: C.accent,
              onTap: () => Navigator.pop(context),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.primaryHi.withOpacity(0.15),
                          border: Border.all(
                              color: C.primaryHi, width: 1.4),
                          boxShadow: [
                            BoxShadow(
                              color: C.primaryHi.withOpacity(0.35),
                              blurRadius: 10,
                            ),
                          ],
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic
                              ? null
                              : RadialGradient(
                                  colors: [C.text, C.bg, C.bgDark]),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                              color: isComic
                                  ? Colors.black
                                  : C.primaryHi,
                              width: isComic ? 3 : 2),
                        ),
                  child: Icon(Icons.storefront_rounded,
                      color: isComic
                          ? Colors.white
                          : (isHud ? C.primaryHi : C.primaryHi),
                      size: 20),
                ),
                if (!isComic)
                  Positioned(
                      top: -2,
                      right: -2,
                      child: _Led(
                          color: C.primaryHi, size: 6, blink: true)),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('PASAR ONLINE',
                      style: TextStyle(
                        color: isComic
                            ? Colors.black
                            : (isHud ? C.hudNeon() : C.accentHi),
                        fontSize: isComic ? 18 : 13,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1.5 : 2,
                        height: 1,
                        shadows: isComic
                            ? null
                            : [
                                Shadow(
                                    color: C.primaryLo,
                                    offset: const Offset(0, 1),
                                    blurRadius: 1),
                                const Shadow(
                                    color: Colors.black,
                                    offset: Offset(0, 2),
                                    blurRadius: 3),
                              ]),
                      )),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(
                          color: C.primaryHi,
                          size: 4,
                          blink: !isComic),
                      const SizedBox(width: 5),
                      Text('${_products.length} PRODUK',
                          style: TextStyle(
                            color: isComic
                                ? Colors.black.withOpacity(0.5)
                                : (isHud
                                    ? C.hudTextDim()
                                    : C.text.withOpacity(0.55)),
                            fontSize: 8,
                            fontWeight: FontWeight.w700,
                            fontFamily: isComic
                                ? 'ComicNeue'
                                : 'ShareTechMono',
                            letterSpacing: 1.2)),
                    ],
                  ),
                ],
              ),
            ),
            _IconButton(
              C: C,
              isComic: isComic,
              isHud: isHud,
              icon: Icons.refresh_rounded,
              color: C.accent,
              onTap: _loadProducts,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: isHud
            ? BoxDecoration(
                color: C.bgDeep.withOpacity(0.7),
                border: Border.all(
                    color: C.accent.withOpacity(0.4), width: 1),
              )
            : BoxDecoration(
                color: isComic ? Colors.white : null,
                borderRadius: BorderRadius.circular(isComic ? 14 : 10),
                gradient: isComic
                    ? null
                    : LinearGradient(colors: [C.bgDeep, C.bgDark]),
                border: Border.all(
                    color: isComic ? Colors.black : C.bgDark,
                    width: isComic ? 3 : 1.5),
                boxShadow: isComic
                    ? null
                    : [
                        BoxShadow(
                            color: Colors.black.withOpacity(0.6),
                            offset: const Offset(0, 1),
                            blurRadius: 2),
                      ]),
        child: TextField(
          controller: _searchCtrl,
          onChanged: (v) {
            _filterLocal(v);
            setState(() {});
          },
          style: TextStyle(
            color: isComic
                ? Colors.black
                : (isHud ? C.hudText() : C.text),
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontWeight: FontWeight.w700,
            fontSize: isComic ? 14 : 13),
          cursorColor: isComic ? Colors.black : C.accent,
          decoration: InputDecoration(
            hintText: 'Cari produk...',
            hintStyle: TextStyle(
              color: isComic
                  ? Colors.black.withOpacity(0.4)
                  : (isHud
                      ? C.hudTextDim()
                      : C.text.withOpacity(0.4)),
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: isComic ? 13 : 12),
            prefixIcon: Icon(Icons.search_rounded,
                color: isComic
                    ? Colors.black
                    : (isHud ? C.accent : C.accent),
                size: 18),
            suffixIcon: _searchCtrl.text.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchCtrl.clear();
                      _filterLocal('');
                      setState(() {});
                    },
                    child: Icon(Icons.close_rounded,
                        color: isComic
                            ? Colors.black
                            : (isHud
                                ? C.hudTextDim()
                                : C.textSub),
                        size: 16))
                : null,
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 14)),
        ),
      ),
    );
  }

  Widget _buildKategoriBar(AppPalette C, bool isComic, bool isHud) {
    return SizedBox(
      height: 44,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: _kategoriList.length,
        itemBuilder: (_, i) {
          final kat = _kategoriList[i];
          final isActive = kat == _selectedKategori;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                setState(() => _selectedKategori = kat);
                _loadProducts();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 8),
                decoration: isHud
                    ? BoxDecoration(
                        color: isActive
                            ? C.accent.withOpacity(0.15)
                            : C.bgDeep.withOpacity(0.6),
                        border: Border.all(
                          color: isActive
                              ? C.accent
                              : C.accent.withOpacity(0.3),
                          width: isActive ? 1.4 : 1,
                        ),
                        boxShadow: isActive
                            ? [
                                BoxShadow(
                                  color: C.accent.withOpacity(0.4),
                                  blurRadius: 8,
                                ),
                              ]
                            : null,
                      )
                    : BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(isComic ? 12 : 10),
                        gradient: isActive && !isComic
                            ? LinearGradient(colors: [
                                C.accentHi.withOpacity(0.9),
                                C.accent.withOpacity(0.6)
                              ])
                            : (isComic
                                ? null
                                : LinearGradient(colors: [
                                    C.textSub.withOpacity(0.9),
                                    C.bg.withOpacity(0.6)
                                  ])),
                        color: isComic
                            ? (isActive ? C.primaryHi : C.bgDark)
                            : null,
                        border: Border.all(
                          color: isComic
                              ? Colors.black
                              : (isActive
                                  ? C.accentHi
                                  : C.text.withOpacity(0.4)),
                          width: isComic ? 3 : (isActive ? 1.8 : 1),
                        ),
                        boxShadow: isComic
                            ? const [
                                BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(3, 3),
                                    blurRadius: 0),
                              ]
                            : (isActive
                                ? [
                                    BoxShadow(
                                        color: C.accentHi
                                            .withOpacity(0.4),
                                        blurRadius: 8)
                                  ]
                                : null),
                      ),
                child: Center(
                  child: Text(kat,
                      style: TextStyle(
                        color: isComic
                            ? (isActive
                                ? Colors.white
                                : Colors.black)
                            : (isHud
                                ? (isActive
                                    ? C.hudNeon()
                                    : C.hudText())
                                : (isActive ? C.bgDeep : C.text)),
                        fontSize: isComic ? 13 : 11,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5)),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildGrid(AppPalette C, bool isComic, bool isHud) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 100),
      physics: const BouncingScrollPhysics(),
      gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.68,
      ),
      itemCount: _filtered.length,
      itemBuilder: (_, i) {
        final product = _filtered[i];
        return GestureDetector(
          onTap: () => _openDetail(product),
          child: _MetalPlate(
            C: C,
            padding: EdgeInsets.zero,
            radius: isHud ? 2 : 12,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.vertical(
                      top: Radius.circular(isHud ? 0 : 9)),
                  child: Stack(
                    children: [
                      Image.network(
                        MarketApi.getFotoUrl(product.fotoUrl),
                        height: 130,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        loadingBuilder: (_, child, progress) =>
                            progress == null
                                ? child
                                : Container(
                                    height: 130,
                                    color: C.bgDark,
                                    child: Center(
                                        child:
                                            CircularProgressIndicator(
                                                color: isComic
                                                    ? Colors.black
                                                    : (isHud
                                                        ? C.accent
                                                        : C.accent),
                                                strokeWidth: 2))),
                        errorBuilder: (_, __, ___) => Container(
                          height: 130,
                          color: C.bgDark,
                          child: Icon(
                              Icons.broken_image_outlined,
                              color: isComic
                                  ? Colors.white
                                  : (isHud
                                      ? C.hudTextDim()
                                      : C.text),
                              size: 36),
                        ),
                      ),
                      if (product.isMine)
                        Positioned(
                          top: 6,
                          right: 6,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: isHud
                                ? BoxDecoration(
                                    color: C.primaryHi
                                        .withOpacity(0.2),
                                    border: Border.all(
                                        color: C.primaryHi,
                                        width: 1),
                                  )
                                : BoxDecoration(
                                    color: isComic
                                        ? C.primaryHi
                                        : C.accentHi,
                                    borderRadius:
                                        BorderRadius.circular(
                                            isComic ? 6 : 6),
                                    border: Border.all(
                                        color: Colors.black,
                                        width: 2),
                                  ),
                            child: Text('MILIK LU',
                                style: TextStyle(
                                  color: isComic
                                      ? Colors.white
                                      : (isHud
                                          ? C.hudNeon()
                                          : C.bgDeep),
                                  fontSize: 7,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: isComic
                                      ? 'Bangers'
                                      : 'Orbitron',
                                  letterSpacing: 0.5)),
                          ),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(product.nama,
                          style: TextStyle(
                            color: isComic
                                ? Colors.black
                                : (isHud ? C.hudText() : C.text),
                            fontSize: isComic ? 14 : 11,
                            fontWeight: FontWeight.w900,
                            fontFamily: isComic
                                ? 'Bangers'
                                : 'ShareTechMono',
                            height: 1.2),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 4),
                      Text(product.hargaFormatted,
                          style: TextStyle(
                            color: C.primaryHi,
                            fontSize: isComic ? 15 : 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: isComic
                                ? 'Bangers'
                                : 'Orbitron',
                            letterSpacing: 0.3)),
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          Icon(Icons.person_rounded,
                              color: isComic
                                  ? Colors.black
                                  : (isHud
                                      ? C.hudTextDim()
                                      : C.textSub),
                              size: 10),
                          const SizedBox(width: 3),
                          Expanded(
                            child: Text(product.penjual,
                                style: TextStyle(
                                  color: isComic
                                      ? Colors.black
                                          .withOpacity(0.6)
                                      : (isHud
                                          ? C.hudTextDim()
                                          : C.text
                                              .withOpacity(0.55)),
                                  fontSize: 9,
                                  fontFamily: isComic
                                      ? 'ComicNeue'
                                      : 'ShareTechMono',
                                  fontWeight: FontWeight.w600),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmpty(AppPalette C, bool isComic, bool isHud) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.primaryHi.withOpacity(0.15),
                        border: Border.all(
                            color: C.primaryHi, width: 1.4),
                        boxShadow: [
                          BoxShadow(
                            color: C.primaryHi.withOpacity(0.35),
                            blurRadius: 15,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isComic
                            ? null
                            : RadialGradient(
                                colors: [C.text, C.bg, C.bgDark]),
                        color: isComic ? C.primaryHi : null,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : C.primaryHi,
                            width: isComic ? 4 : 2)),
                child: Icon(Icons.storefront_rounded,
                    color: isComic
                        ? Colors.white
                        : (isHud ? C.primaryHi : C.primaryHi),
                    size: 36),
              ),
              const SizedBox(height: 16),
              Text('BELUM ADA PRODUK',
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: isComic ? 16 : 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2)),
              const SizedBox(height: 6),
              Text('Jadi yang pertama jual di sini!',
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withOpacity(0.6)
                        : (isHud
                            ? C.hudTextDim()
                            : C.text.withOpacity(0.5)),
                    fontSize: isComic ? 12 : 10,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono')),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HELPER WIDGETS
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(
              color: Colors.black, width: size * 0.18)),
      );
    }

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.9),
              blurRadius: size * 1.8,
              spreadRadius: size * 0.3,
            ),
          ],
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [
            Colors.white.withOpacity(0.85),
            color.withOpacity(0.9),
            color.withOpacity(0.55),
          ],
          stops: const [0.0, 0.4, 1.0],
        ),
        border: Border.all(
            color: Colors.black.withOpacity(0.85),
            width: size * 0.1),
        boxShadow: [
          BoxShadow(
              color: color.withOpacity(0.75),
              blurRadius: size * 1.4,
              spreadRadius: size * 0.2),
        ],
      ),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black,
                offset: Offset(6, 6),
                blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
                color: C.accent.withOpacity(0.15),
                blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(
                top: 0,
                left: 0,
                child: SizedBox(
                    width: 12,
                    height: 12,
                    child: CustomPaint(
                        painter: _HudCornerPainter(
                            color: C.accent.withOpacity(0.7))))),
            Positioned(
                top: 0,
                right: 0,
                child: SizedBox(
                    width: 12,
                    height: 12,
                    child: CustomPaint(
                        painter: _HudCornerPainter(
                            color: C.accent.withOpacity(0.7))))),
            Positioned(
                bottom: 0,
                left: 0,
                child: SizedBox(
                    width: 12,
                    height: 12,
                    child: CustomPaint(
                        painter: _HudCornerPainter(
                            color: C.accent.withOpacity(0.7))))),
            Positioned(
                bottom: 0,
                right: 0,
                child: SizedBox(
                    width: 12,
                    height: 12,
                    child: CustomPaint(
                        painter: _HudCornerPainter(
                            color: C.accent.withOpacity(0.7))))),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6),
              blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border:
              Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

class _IconButton extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  final bool isHud;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final double size;
  const _IconButton({
    required this.C,
    required this.isComic,
    required this.isHud,
    required this.icon,
    required this.onTap,
    required this.color,
    this.size = 40,
  });

  @override
  State<_IconButton> createState() => _IconButtonState();
}

class _IconButtonState extends State<_IconButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size,
        height: widget.size,
        transform: widget.isComic
            ? Matrix4.translationValues(
                _pressed ? 2 : 0, _pressed ? 2 : 0, 0)
            : null,
        decoration: widget.isHud
            ? BoxDecoration(
                color: _pressed
                    ? C.accent.withOpacity(0.25)
                    : C.accent.withOpacity(0.1),
                border: Border.all(color: C.accent, width: 1.2),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: C.accent.withOpacity(0.35),
                          blurRadius: 8,
                        ),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: widget.isComic
                    ? null
                    : LinearGradient(
                        begin: _pressed
                            ? Alignment.bottomCenter
                            : Alignment.topCenter,
                        end: _pressed
                            ? Alignment.topCenter
                            : Alignment.bottomCenter,
                        colors: _pressed
                            ? [C.bgDark, C.bg]
                            : [C.textSub, C.bg, C.bgDark]),
                color: widget.isComic ? C.accent : null,
                border: Border.all(
                    color: widget.isComic
                        ? Colors.black
                        : Colors.black.withOpacity(0.7),
                    width: widget.isComic ? 3 : 1.2),
                boxShadow: widget.isComic
                    ? (_pressed
                        ? []
                        : const [
                            BoxShadow(
                                color: Colors.black,
                                offset: Offset(3, 3),
                                blurRadius: 0),
                          ])
                    : null,
              ),
        child: Icon(widget.icon,
            color: widget.isComic
                ? Colors.white
                : (widget.isHud ? C.accent : widget.color),
            size: widget.size * 0.5),
      ),
    );
  }
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0;
          y < size.height + spacing;
          y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) =>
      old.color != color;
}