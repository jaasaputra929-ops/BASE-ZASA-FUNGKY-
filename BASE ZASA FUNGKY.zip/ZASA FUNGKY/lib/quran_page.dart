// quran_page.dart — List Surah (3 Style Support)
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'quran_api.dart';
import 'quran_detail_page.dart';

class QuranPage extends StatefulWidget {
  const QuranPage({super.key});

  @override
  State<QuranPage> createState() => _QuranPageState();
}

class _QuranPageState extends State<QuranPage> {
  List<QuranSurah> _surahs = [];
  List<QuranSurah> _filtered = [];
  bool _loading = true;
  String _error = '';
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _loading = true;
      _error = '';
    });
    final result = await QuranApi.getSurahList();
    if (!mounted) return;
    setState(() {
      _surahs = result;
      _filtered = result;
      _loading = false;
      if (result.isEmpty) _error = 'Gagal memuat surah';
    });
  }

  void _onSearch(String q) {
    if (q.isEmpty) {
      setState(() => _filtered = _surahs);
      return;
    }
    final query = q.toLowerCase();
    setState(() {
      _filtered = _surahs.where((s) {
        return s.namaLatin.toLowerCase().contains(query) ||
            s.arti.toLowerCase().contains(query) ||
            s.nomor.toString() == query;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: RadialGradient(
                                center: const Alignment(-0.3, -0.3),
                                radius: 1.2,
                                colors: [C.bg, C.bgDark, C.bgDeep],
                                stops: const [0.0, 0.6, 1.0]))),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withValues(
                                    alpha: 0.12))))),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()))),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _buildTopBar(C, isComic, isHud),
                          const SizedBox(height: 8),
                          _buildSearchBar(C, isComic, isHud),
                          const SizedBox(height: 8),
                          Expanded(
                            child: _loading
                                ? Center(
                                    child: CircularProgressIndicator(
                                        color: isComic
                                            ? Colors.black
                                            : (isHud
                                                ? C.hudNeon()
                                                : C.accent),
                                        strokeWidth: 2))
                                : _error.isNotEmpty
                                    ? _buildError(C, isComic, isHud)
                                    : _filtered.isEmpty
                                        ? _buildEmpty(C, isComic, isHud)
                                        : ListView.builder(
                                            padding:
                                                const EdgeInsets
                                                    .symmetric(
                                                    horizontal: 14,
                                                    vertical: 4),
                                            itemCount: _filtered.length,
                                            itemBuilder: (_, i) =>
                                                _buildSurahTile(C,
                                                    isComic, isHud, _filtered[i]),
                                          ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36, height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border:
                            Border.all(color: C.accent, width: 1.2))
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: isComic ? null
                            : LinearGradient(
                                colors: [C.text, C.bg, C.bgDark]),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color: isComic ? Colors.black : C.primaryLo,
                            width: isComic ? 3 : 1.5)),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : (isHud ? C.hudNeon() : C.accent),
                    size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36, height: 36,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border: Border.all(color: C.accent, width: 1.2))
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic ? null
                          : RadialGradient(colors: [
                              C.accentHi, C.accent, C.primaryLo]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color: isComic ? Colors.black : C.accentShine,
                          width: isComic ? 3 : 1.5)),
              child: Icon(Icons.menu_book_rounded,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : C.bgDeep),
                  size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('AL-QUR\'AN',
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 20 : (isHud ? 13 : 13),
                        letterSpacing: isComic ? 1.5 : 2.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0),
                              ]
                            : (isHud
                                ? [
                                    Shadow(
                                        color: C.accent
                                            .withOpacity(0.5),
                                        blurRadius: 8),
                                  ]
                                : null),
                      )),
                  const SizedBox(height: 2),
                  Row(children: [
                    Icon(Icons.star_rounded,
                        color: isComic
                            ? Colors.black
                            : (isHud ? C.accent : C.primaryHi),
                        size: 10),
                    const SizedBox(width: 4),
                    Text('114 SURAH · 30 JUZ',
                        style: TextStyle(
                          color: isComic
                              ? Colors.black.withValues(alpha: 0.5)
                              : (isHud
                                  ? C.hudTextDim()
                                  : C.text.withValues(alpha: 0.55)),
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                          fontSize: 8,
                          letterSpacing: 1.2)),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: isComic
            ? BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.black, width: 3))
            : (isHud
                ? BoxDecoration(
                    color: C.bgDeep.withOpacity(0.6),
                    border: Border.all(
                        color: C.accent.withOpacity(0.5), width: 1.2))
                : BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                        colors: [C.bgDeep, C.bgDark]),
                    border: Border.all(color: C.bgDark, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withValues(alpha: 0.6),
                          offset: const Offset(0, 1),
                          blurRadius: 2),
                    ])),
        child: TextField(
          controller: _searchCtrl,
          onChanged: _onSearch,
          style: TextStyle(
            color: isComic
                ? Colors.black
                : (isHud ? C.hudText() : C.text),
            fontFamily: isComic
                ? 'ComicNeue'
                : (isHud ? 'Orbitron' : 'ShareTechMono'),
            fontWeight: FontWeight.w700,
            fontSize: isComic ? 14 : 13,
            letterSpacing: isHud ? 1 : 0),
          cursorColor:
              isComic ? Colors.black : (isHud ? C.accent : C.accent),
          decoration: InputDecoration(
            hintText: 'Cari surah...',
            hintStyle: TextStyle(
              color: isComic
                  ? Colors.black.withValues(alpha: 0.4)
                  : (isHud
                      ? C.hudTextDim()
                      : C.text.withValues(alpha: 0.4)),
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: isComic ? 13 : 12,
              letterSpacing: isHud ? 1 : 0),
            prefixIcon: Icon(Icons.search_rounded,
                color: isComic
                    ? Colors.black
                    : (isHud ? C.accent : C.accent),
                size: 18),
            suffixIcon: _searchCtrl.text.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchCtrl.clear();
                      _onSearch('');
                    },
                    child: Icon(Icons.close_rounded,
                        color: isComic
                            ? Colors.black
                            : (isHud ? C.accent : C.textSub),
                        size: 16))
                : null,
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 14)),
        ),
      ),
    );
  }

  Widget _buildSurahTile(
      AppPalette C, bool isComic, bool isHud, QuranSurah surah) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GestureDetector(
        onTap: () {
          HapticFeedback.lightImpact();
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => QuranDetailPage(surah: surah),
            ),
          );
        },
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 48, height: 48,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border: Border.all(color: C.accent, width: 1.2),
                        boxShadow: [
                          BoxShadow(
                              color: C.accent.withOpacity(0.4),
                              blurRadius: 8),
                        ],
                      )
                    : BoxDecoration(
                        shape: isComic
                            ? BoxShape.rectangle
                            : BoxShape.circle,
                        borderRadius:
                            isComic ? BorderRadius.circular(10) : null,
                        gradient: isComic ? null
                            : RadialGradient(
                                center:
                                    const Alignment(-0.3, -0.3),
                                colors: [
                                    C.accentHi,
                                    C.accent,
                                    C.primaryLo
                                  ]),
                        color: isComic ? C.primaryHi : null,
                        border: Border.all(
                            color:
                                isComic ? Colors.black : C.accentShine,
                            width: isComic ? 3 : 1.5)),
                child: Center(
                  child: Text('${surah.nomor}',
                      style: TextStyle(
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : (isHud ? C.hudNeon() : C.bgDeep),
                        fontSize: isComic ? 18 : 16,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isHud ? 1 : 0)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(surah.namaLatin,
                        style: TextStyle(
                          color: isComic
                              ? Colors.black
                              : (isHud ? C.hudText() : C.text),
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: isComic ? 16 : 13,
                          letterSpacing:
                              isComic ? 0.5 : (isHud ? 1 : 0.5))),
                    const SizedBox(height: 3),
                    Text('${surah.arti} · ${surah.jumlahAyat} ayat',
                        style: TextStyle(
                          color: isComic
                              ? Colors.black.withValues(alpha: 0.6)
                              : (isHud
                                  ? C.hudTextDim()
                                  : C.text.withValues(alpha: 0.55)),
                          fontSize: isComic ? 12 : 10,
                          fontFamily: isComic
                              ? 'ComicNeue'
                              : 'ShareTechMono',
                          letterSpacing: isHud ? 1 : 0)),
                  ],
                ),
              ),
              Text(surah.nama,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudNeon() : C.accentShine),
                    fontSize: isComic ? 18 : 16,
                    fontWeight: FontWeight.w900,
                    shadows: isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 6),
                          ]
                        : null)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmpty(AppPalette C, bool isComic, bool isHud) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.search_off_rounded,
                  color: isComic
                      ? Colors.black
                      : (isHud ? C.hudTextDim() : C.textSub),
                  size: 48),
              const SizedBox(height: 12),
              Text('TIDAK DITEMUKAN',
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: isComic ? 18 : (isHud ? 13 : 13),
                    fontWeight: FontWeight.w900,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2,
                    shadows: isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 8),
                          ]
                        : null)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildError(AppPalette C, bool isComic, bool isHud) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline_rounded,
                  color: isComic
                      ? Colors.black
                      : (isHud ? C.hudWarning() : C.primaryHi),
                  size: 40),
              const SizedBox(height: 12),
              Text(_error,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudText() : C.text),
                    fontSize: isComic ? 13 : 12,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    letterSpacing: isHud ? 1 : 0)),
              const SizedBox(height: 14),
              GestureDetector(
                onTap: _loadData,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 12),
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border: Border.all(
                              color: C.accent, width: 1.4),
                          boxShadow: [
                            BoxShadow(
                                color: C.accent.withOpacity(0.4),
                                blurRadius: 10),
                          ],
                        )
                      : BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(isComic ? 12 : 8),
                          gradient: isComic ? null
                              : LinearGradient(colors: [
                                  C.primaryHi,
                                  C.primary,
                                  C.primaryLo
                                ]),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                              color: isComic
                                  ? Colors.black
                                  : C.primaryLo,
                              width: isComic ? 3 : 1.5)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.refresh_rounded,
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : (isHud ? C.hudNeon() : C.text),
                          size: 16),
                      const SizedBox(width: 8),
                      Text('COBA LAGI',
                          style: TextStyle(
                            color: isComic
                                ? C.contrastTextOn(C.primaryHi)
                                : (isHud ? C.hudNeon() : C.text),
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2,
                            fontSize: isComic ? 15 : 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE (3 STYLE)
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(5, 5),
                blurRadius: 0),
          ]),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
                color: C.accent.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withValues(alpha: 0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12,
        height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(
              color: C.accent.withOpacity(0.8)),
        ),
      );
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}