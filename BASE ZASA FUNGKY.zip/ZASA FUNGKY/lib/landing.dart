// lib/landing.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'smart_widgets.dart';
import 'login_page.dart';

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {

  late AnimationController _welcomeCtrl;

  late Animation<double> _welcomeSlide;
  late Animation<double> _welcomeFade;

  final PageController _carouselCtrl = PageController(viewportFraction: 0.88);
  int _carouselIndex = 0;

  final PageController _infoCardsCtrl =
      PageController(viewportFraction: 0.88);
  int _infoCardIndex = 0;

  @override
  void initState() {
    super.initState();

    _welcomeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..forward();

    _welcomeSlide = Tween<double>(begin: -1.0, end: 1.0).animate(
      CurvedAnimation(parent: _welcomeCtrl, curve: Curves.easeOutCubic),
    );

    _welcomeFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _welcomeCtrl,
        curve: const Interval(0.3, 1.0, curve: Curves.easeOut),
      ),
    );
  }

  @override
  void dispose() {
    _welcomeCtrl.dispose();
    _carouselCtrl.dispose();
    _infoCardsCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StyleBuilder(
      builder: (context, C, kit) {
        final isComic = kit.style == ThemeStyle.comic3d;
        final isHud = kit.style == ThemeStyle.hudTactical;

        return Scaffold(
          backgroundColor: isHud ? C.hudBg() : C.bgDeep,
          body: Stack(
            children: [
              Positioned.fill(
                child: isComic
                    ? CustomPaint(
                        painter: _HalftonePainter(
                            color: C.primaryLo.withValues(alpha: 0.12)),
                      )
                    : (isHud
                        ? CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()),
                          )
                        : Container(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(-0.4, -0.4),
                                radius: 1.5,
                                colors: [C.bg, C.bgDark, C.bgDeep],
                                stops: const [0.0, 0.6, 1.0],
                              ),
                            ),
                          )),
              ),
              _buildContentPhase(C, isComic, isHud),
            ],
          ),
        );
      },
    );
  }

  Widget _buildContentPhase(AppPalette C, bool isComic, bool isHud) {
    return SafeArea(
      key: const ValueKey('content-phase'),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),

            AnimatedBuilder(
              animation: _welcomeCtrl,
              builder: (_, __) {
                return ClipRect(
                  child: Transform.translate(
                    offset: Offset(
                      _welcomeSlide.value *
                          -MediaQuery.of(context).size.width,
                      0,
                    ),
                    child: Opacity(
                      opacity: _welcomeFade.value,
                      child: _buildWelcome(C, isComic, isHud),
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 30),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                '// KENAPA CRYLIX DEATH?',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 16 : 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: isComic ? 2 : 3,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            const SizedBox(height: 14),

            SizedBox(
              height: 260,
              child: PageView.builder(
                controller: _infoCardsCtrl,
                itemCount: _infoCards.length,
                onPageChanged: (i) =>
                    setState(() => _infoCardIndex = i),
                itemBuilder: (context, i) {
                  final card = _infoCards[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: _buildInfoCard(
                      C,
                      isComic,
                      isHud,
                      icon: card['icon'] as IconData,
                      title: card['title'] as String,
                      body: card['body'] as String,
                      color: card['color'] as Color,
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_infoCards.length, (i) {
                final active = i == _infoCardIndex;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: active ? 24 : 8,
                  height: 8,
                  decoration: isHud
                      ? BoxDecoration(
                          color: active
                              ? C.accent.withValues(alpha: 0.2)
                              : Colors.transparent,
                          border: Border.all(
                            color: active
                                ? C.accent
                                : C.accent.withValues(alpha: 0.3),
                            width: active ? 1.4 : 1,
                          ),
                          boxShadow: active
                              ? [
                                  BoxShadow(
                                    color: C.accent.withValues(alpha: 0.5),
                                    blurRadius: 8,
                                  ),
                                ]
                              : null,
                        )
                      : BoxDecoration(
                          color: active
                              ? (isComic ? C.primaryHi : C.accent)
                              : (isComic
                                  ? C.bgDark
                                  : C.textSub.withValues(alpha: 0.3)),
                          borderRadius: BorderRadius.circular(4),
                          border: isComic
                              ? Border.all(color: Colors.black, width: 2)
                              : null,
                        ),
                );
              }),
            ),

            const SizedBox(height: 30),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                '// CRYLIX CARDS',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 16 : 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: isComic ? 2 : 3,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            const SizedBox(height: 14),

            SizedBox(
              height: 240,
              child: PageView.builder(
                controller: _carouselCtrl,
                itemCount: _cards.length,
                onPageChanged: (i) =>
                    setState(() => _carouselIndex = i),
                itemBuilder: (context, i) {
                  final card = _cards[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: _buildComicCard(C, isComic, isHud, card),
                  );
                },
              ),
            ),

            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_cards.length, (i) {
                final active = i == _carouselIndex;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: active ? 24 : 8,
                  height: 8,
                  decoration: isHud
                      ? BoxDecoration(
                          color: active
                              ? C.accent.withValues(alpha: 0.2)
                              : Colors.transparent,
                          border: Border.all(
                            color: active
                                ? C.accent
                                : C.accent.withValues(alpha: 0.3),
                            width: active ? 1.4 : 1,
                          ),
                          boxShadow: active
                              ? [
                                  BoxShadow(
                                    color: C.accent.withValues(alpha: 0.5),
                                    blurRadius: 8,
                                  ),
                                ]
                              : null,
                        )
                      : BoxDecoration(
                          color: active
                              ? (isComic ? C.primaryHi : C.accent)
                              : (isComic
                                  ? C.bgDark
                                  : C.textSub.withValues(alpha: 0.3)),
                          borderRadius: BorderRadius.circular(4),
                          border: isComic
                              ? Border.all(color: Colors.black, width: 2)
                              : null,
                        ),
                );
              }),
            ),

            const SizedBox(height: 40),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _buildLoginButton(C, isComic, isHud),
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcome(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Text(
            'WELCOME TO',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isComic
                  ? C.comicTextSub
                  : (isHud ? C.hudTextDim() : C.textSub),
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: isComic ? 16 : 12,
              fontWeight: FontWeight.w700,
              letterSpacing: isComic ? 4 : 6,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'CRYLIX DEATH',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.hudNeon() : C.text),
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              fontSize: isComic ? 42 : 32,
              fontWeight: FontWeight.w900,
              letterSpacing: isComic ? 4 : 8,
              height: 1,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      Shadow(
                        color: (isHud ? C.accent : C.accent)
                            .withValues(alpha: 0.8),
                        blurRadius: 20,
                      ),
                    ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 30,
                height: 2,
                color: isComic
                    ? C.comicText
                    : (isHud ? C.accent : C.accent),
              ),
              const SizedBox(width: 12),
              Text(
                'WHATSAPP CRASHER & TOOLS',
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud ? C.hudTextDim() : C.textSub),
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontSize: isComic ? 11 : 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(width: 12),
              Container(
                width: 30,
                height: 2,
                color: isComic
                    ? C.comicText
                    : (isHud ? C.accent : C.accent),
              ),
            ],
          ),
        ],
      ),
    );
  }

  final List<Map<String, dynamic>> _infoCards = [
    {
      'icon': Icons.workspace_premium_rounded,
      'title': 'KENAPA PILIH CRYLIX DEATH?',
      'body':
          'Crylix Death adalah aplikasi WhatsApp crasher & tools yang stabil, cepat, dan update rutin. Dibuat dengan fokus ke performa dan keamanan user, semua fitur bisa diakses dengan mudah tanpa ribet.',
      'color': Color(0xFF2196F3),
    },
    {
      'icon': Icons.system_update_alt_rounded,
      'title': 'SEBERAPA SERING UPDATE?',
      'body':
          'Kami update aplikasi ini secara berkala — minimal 2 kali seminggu, dan update bug fix darurat kapanpun dibutuhkan. Semua update otomatis tersedia tanpa perlu install ulang.',
      'color': Color(0xFF9C27B0),
    },
    {
      'icon': Icons.groups_rounded,
      'title': 'JOIN COMMUNITY',
      'body':
          'Gabung grup Telegram kami untuk update, support, dan info terbaru.\n\n@testizasa',
      'color': Color(0xFF9C27B0),
    },
  ];

  Widget _buildInfoCard(
    AppPalette C,
    bool isComic,
    bool isHud, {
    required IconData icon,
    required String title,
    required String body,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(
                  color: color.withValues(alpha: 0.6), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: color.withValues(alpha: 0.2),
                  blurRadius: 14,
                ),
              ],
            )
          : BoxDecoration(
              color: isComic ? C.bgDark : Colors.black.withValues(alpha: 0.4),
              borderRadius: BorderRadius.circular(isComic ? 20 : 16),
              border: Border.all(
                color: isComic ? Colors.black : color.withValues(alpha: 0.4),
                width: isComic ? 4 : 1.5,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(6, 6),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: color.withValues(alpha: 0.15),
                        blurRadius: 20,
                      ),
                    ],
            ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: isHud
                    ? BoxDecoration(
                        color: color.withValues(alpha: 0.15),
                        border: Border.all(color: color, width: 1.2),
                        boxShadow: [
                          BoxShadow(
                            color: color.withValues(alpha: 0.35),
                            blurRadius: 8,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: isComic ? color : color.withValues(alpha: 0.2),
                        border: Border.all(
                          color: isComic ? Colors.black : color,
                          width: isComic ? 3 : 1.2,
                        ),
                      ),
                child: Icon(
                  icon,
                  color: isComic
                      ? C.contrastTextOn(color)
                      : color,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : color),
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontSize: isComic ? 14 : 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: isComic ? 1.2 : 1.5,
                    height: 1.3,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Text(
                body,
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud
                          ? C.hudText()
                          : C.text.withValues(alpha: 0.8)),
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontSize: isComic ? 13 : 11,
                  height: 1.6,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  final List<Map<String, dynamic>> _cards = [
    {
      'title': 'SELAMAT DATANG',
      'subtitle': 'Di Crylix Death',
      'body':
          'Terima kasih sudah menggunakan aplikasi ini, Nikmati fitur fitur keren nya',
      'icon': Icons.celebration_rounded,
      'emoji': '🎉',
    },
    {
      'title': 'PESAN PENTING',
      'subtitle': '"Jangan terlalu meninggi,\nnanti jatuhnya sakit"',
      'body': 'Tetap rendah hati, tetap santuy, tetap asik.',
      'icon': Icons.psychology_alt_rounded,
      'emoji': '💭',
    },
    {
      'title': 'DEVELOPER',
      'subtitle': '@zasaco',
      'body': 'Dibuat dengan senang hati dan dedikasi tinggi oleh Zasa',
      'icon': Icons.code_rounded,
      'emoji': '👀',
    },
    {
      'title': 'CRYLIX DEATH',
      'subtitle': 'By Zasa',
      'body':
          'Aplikasi WhatsApp Crasher & Tools paling stabil dan update rutin.',
      'icon': Icons.workspace_premium_rounded,
      'emoji': '👑',
    },
  ];

  Widget _buildComicCard(
      AppPalette C, bool isComic, bool isHud, Map<String, dynamic> card) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(
                  color: C.accent.withValues(alpha: 0.6), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: C.accent.withValues(alpha: 0.25),
                  blurRadius: 16,
                ),
              ],
            )
          : BoxDecoration(
              color: isComic ? C.bgDark : Colors.black.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(isComic ? 20 : 16),
              border: Border.all(
                color: isComic ? Colors.black : C.accent.withValues(alpha: 0.4),
                width: isComic ? 5 : 1.5,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(8, 8),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: C.accent.withValues(alpha: 0.25),
                        blurRadius: 20,
                      ),
                    ],
            ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            card['emoji'] as String,
            style: const TextStyle(fontSize: 40),
          ),
          const SizedBox(height: 12),

          Text(
            card['title'] as String,
            style: TextStyle(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.hudNeon() : C.accent),
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              fontSize: isComic ? 18 : 13,
              fontWeight: FontWeight.w900,
              letterSpacing: isComic ? 1.5 : 2,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
          ),
          const SizedBox(height: 4),

          Text(
            card['subtitle'] as String,
            style: TextStyle(
              color: isComic
                  ? C.comicTextSub
                  : (isHud
                      ? C.hudText()
                      : C.text.withValues(alpha: 0.85)),
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: isComic ? 14 : 12,
              fontWeight: FontWeight.w700,
              height: 1.4,
            ),
          ),
          const Spacer(),

          Container(
            height: isComic ? 3 : 1,
            color: isComic
                ? Colors.black
                : (isHud
                    ? C.accent.withValues(alpha: 0.3)
                    : C.accent.withValues(alpha: 0.3)),
          ),
          const SizedBox(height: 10),

          Text(
            card['body'] as String,
            style: TextStyle(
              color: isComic
                  ? C.comicTextMuted
                  : (isHud ? C.hudTextDim() : C.textSub),
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: isComic ? 12 : 10,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoginButton(AppPalette C, bool isComic, bool isHud) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        Navigator.of(context).push(
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => const LoginPage(),
            transitionDuration: const Duration(milliseconds: 400),
            transitionsBuilder: (_, anim, __, child) {
              return FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.08),
                    end: Offset.zero,
                  ).animate(CurvedAnimation(
                    parent: anim,
                    curve: Curves.easeOutCubic,
                  )),
                  child: child,
                ),
              );
            },
          ),
        );
      },
      child: Container(
        height: isComic ? 62 : 58,
        decoration: isHud
            ? BoxDecoration(
                color: C.primaryHi.withValues(alpha: 0.15),
                border: Border.all(color: C.primaryHi, width: 1.4),
                boxShadow: [
                  BoxShadow(
                    color: C.primaryHi.withValues(alpha: 0.5),
                    blurRadius: 16,
                  ),
                ],
              )
            : BoxDecoration(
                color: isComic ? C.primaryHi : null,
                gradient: isComic
                    ? null
                    : LinearGradient(
                        colors: [C.primaryHi, C.primary],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                borderRadius: BorderRadius.circular(isComic ? 14 : 12),
                border: Border.all(
                  color: isComic ? Colors.black : C.accent,
                  width: isComic ? 4 : 1.5,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(6, 6),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: C.primaryHi.withValues(alpha: 0.5),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.arrow_forward_rounded,
              color: isComic
                  ? C.contrastTextOn(C.primaryHi)
                  : (isHud ? C.hudNeon() : Colors.white),
              size: 22,
            ),
            const SizedBox(width: 12),
            Text(
              'LOGIN KE CRYLIX DEATH',
              style: TextStyle(
                color: isComic
                    ? C.contrastTextOn(C.primaryHi)
                    : (isHud ? C.hudNeon() : Colors.white),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontSize: isComic ? 18 : 13,
                fontWeight: FontWeight.w900,
                letterSpacing: isComic ? 2 : 3,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.contrastTextOn(C.primaryHi) ==
                                  Colors.white
                              ? Colors.black
                              : Colors.white,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _HalftonePainter extends CustomPainter {
  final Color color;
  _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}