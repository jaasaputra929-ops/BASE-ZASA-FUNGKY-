// market_detail_page.dart — Detail produk (FINAL FIXED)
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import 'app_theme.dart';
import 'market_api.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class MarketDetailPage extends StatefulWidget {
  final MarketProduct product;
  final String sessionKey;
  final String username;

  const MarketDetailPage({
    super.key,
    required this.product,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<MarketDetailPage> createState() => _MarketDetailPageState();
}

class _MarketDetailPageState extends State<MarketDetailPage> {
  bool _deleting = false;

  Future<void> _openWA(AppPalette C) async {
    final wa = widget.product.wa.replaceAll(RegExp(r'[^\d]'), '');
    if (wa.isEmpty) {
      _showSnack(C, 'Penjual nggak nyantumin WA', isError: true);
      return;
    }
    try {
      final uri = Uri.parse('https://wa.me/$wa');
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      _showSnack(C, 'Gagal buka WA: $e', isError: true);
    }
  }

  Future<void> _openTelegram(AppPalette C) async {
    final tg = widget.product.telegram.replaceAll('@', '').trim();
    if (tg.isEmpty) {
      _showSnack(C, 'Penjual nggak nyantumin Telegram', isError: true);
      return;
    }
    try {
      final uri = Uri.parse('https://t.me/$tg');
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      _showSnack(C, 'Gagal buka Telegram: $e', isError: true);
    }
  }

  void _copyInfo(AppPalette C) {
    final info = '''
PRODUK: ${widget.product.nama}
HARGA: ${widget.product.hargaFormatted}
PENJUAL: ${widget.product.penjual}
${widget.product.deskripsi.isNotEmpty ? 'DESKRIPSI: ${widget.product.deskripsi}' : ''}
''';
    Clipboard.setData(ClipboardData(text: info));
    _showSnack(C, 'Info produk di-copy!', isError: false);
  }

  Future<void> _deleteProduct(
      AppPalette C, bool isComic, bool isHud) async {
    final confirm = await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          accent: C.primaryHi,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.delete_forever_rounded,
                  color: isComic
                      ? Colors.black
                      : (isHud ? C.hudNeon() : C.primaryHi),
                  size: 40),
              const SizedBox(height: 12),
              Text(
                'HAPUS PRODUK?',
                style: TextStyle(
                  color: isComic
                      ? Colors.black
                      : (isHud ? C.hudNeon() : C.primaryHi),
                  fontSize: isComic ? 20 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Produk ini bakal ilang dari Pasar Online.\nYakin mau hapus?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? Colors.black.withOpacity(0.7)
                      : (isHud
                          ? C.hudText()
                          : C.text.withOpacity(0.7)),
                  fontSize: isComic ? 13 : 11,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _IndustrialButton(
                      C: C,
                      color: C.bg,
                      height: 44,
                      onTap: () => Navigator.pop(ctx, false),
                      child: Text(
                        'BATAL',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                          fontSize: isComic ? 15 : 11,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _IndustrialButton(
                      C: C,
                      color: C.primary,
                      height: 44,
                      onTap: () => Navigator.pop(ctx, true),
                      child: Text(
                        'HAPUS',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                          fontSize: isComic ? 15 : 11,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (confirm != true) return;
    setState(() => _deleting = true);
    final result = await MarketApi.deleteProduct(
        sessionKey: widget.sessionKey, productId: widget.product.id);
    if (!mounted) return;
    setState(() => _deleting = false);
    if (result['valid'] == true) {
      _showSnack(C, 'Produk berhasil dihapus', isError: false);
      Navigator.pop(context, true);
    } else {
      _showSnack(C, result['message'] ?? 'Gagal hapus', isError: true);
    }
  }

  void _showSnack(AppPalette C, String msg, {bool isError = false}) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(
              color: isError ? C.primaryHi : C.primaryHi,
              size: 8,
              blink: !isComic,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  color: isHud ? C.hudText() : C.text,
                  fontSize: isComic ? 13 : 12,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isHud ? C.hudPanel() : C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(
              isHud ? 4 : (isComic ? 12 : 8)),
          side: BorderSide(
              color: isError ? C.primaryHi : C.primaryHi,
              width: isComic ? 3 : 1.5),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;
            final product = widget.product;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              radius: 1.2,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                              stops: const [0.0, 0.6, 1.0],
                            ),
                          )),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildAppBar(C, isComic, isHud),
                          const SizedBox(height: 10),
                          Expanded(
                            child: SingleChildScrollView(
                              padding: const EdgeInsets.fromLTRB(
                                  14, 4, 14, 32),
                              physics:
                                  const BouncingScrollPhysics(),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  _MetalPlate(
                                    C: C,
                                    padding: EdgeInsets.zero,
                                    child: ClipRRect(
                                      borderRadius:
                                          BorderRadius.circular(
                                              isHud ? 0 : 9),
                                      child: AspectRatio(
                                        aspectRatio: 1 / 1,
                                        child: Image.network(
                                          MarketApi.getFotoUrl(
                                              product.fotoUrl),
                                          fit: BoxFit.cover,
                                          loadingBuilder: (_,
                                                  child,
                                                  progress) =>
                                              progress == null
                                                  ? child
                                                  : Container(
                                                      color: C.bgDark,
                                                      child: Center(
                                                        child:
                                                            CircularProgressIndicator(
                                                          color: isComic
                                                              ? Colors.black
                                                              : (isHud
                                                                  ? C.accent
                                                                  : C.accent),
                                                          strokeWidth: 3,
                                                        ),
                                                      ),
                                                    ),
                                          errorBuilder: (_, __, ___) =>
                                              Container(
                                            color: C.bgDark,
                                            child: Icon(
                                              Icons
                                                  .broken_image_outlined,
                                              color: isComic
                                                  ? Colors.white
                                                  : (isHud
                                                      ? C.hudTextDim()
                                                      : C.text),
                                              size: 60,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 16),

                                  // ═══ INFO PRODUK ═══
                                  _MetalPlate(
                                    C: C,
                                    padding: const EdgeInsets.all(14),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          padding:
                                              const EdgeInsets.symmetric(
                                                  horizontal: 10,
                                                  vertical: 4),
                                          decoration: isHud
                                              ? BoxDecoration(
                                                  color: C.accentHi
                                                      .withOpacity(
                                                          0.15),
                                                  border: Border.all(
                                                      color:
                                                          C.accentHi,
                                                      width: 1),
                                                )
                                              : BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          isComic
                                                              ? 8
                                                              : 8),
                                                  color: isComic
                                                      ? C.primaryHi
                                                      : C.accentHi
                                                          .withOpacity(
                                                              0.2),
                                                  border: Border.all(
                                                    color: isComic
                                                        ? Colors.black
                                                        : C.accentHi,
                                                    width: isComic
                                                        ? 2.5
                                                        : 1.5,
                                                  ),
                                                ),
                                          child: Text(
                                            product.kategori
                                                .toUpperCase(),
                                            style: TextStyle(
                                              color: isComic
                                                  ? Colors.white
                                                  : (isHud
                                                      ? C.hudNeon()
                                                      : C.accentHi),
                                              fontSize:
                                                  isComic ? 12 : 10,
                                              fontWeight:
                                                  FontWeight.w900,
                                              fontFamily: isComic
                                                  ? 'Bangers'
                                                  : 'Orbitron',
                                              letterSpacing: 1.2,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 10),
                                        Text(
                                          product.nama,
                                          style: TextStyle(
                                            color: isComic
                                                ? Colors.black
                                                : (isHud
                                                    ? C.hudText()
                                                    : C.text),
                                            fontSize:
                                                isComic ? 18 : 16,
                                            fontWeight:
                                                FontWeight.w900,
                                            fontFamily: isComic
                                                ? 'Bangers'
                                                : 'Orbitron',
                                            letterSpacing: 0.5,
                                            height: 1.3,
                                          ),
                                        ),
                                        const SizedBox(height: 12),
                                        Container(
                                          padding:
                                              const EdgeInsets.symmetric(
                                                  horizontal: 14,
                                                  vertical: 8),
                                          decoration: isHud
                                              ? BoxDecoration(
                                                  color: C.primaryHi
                                                      .withOpacity(
                                                          0.15),
                                                  border: Border.all(
                                                      color:
                                                          C.primaryHi,
                                                      width: 1.4),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: C
                                                          .primaryHi
                                                          .withOpacity(
                                                              0.35),
                                                      blurRadius: 10,
                                                    ),
                                                  ],
                                                )
                                              : BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          isComic
                                                              ? 12
                                                              : 10),
                                                  gradient: isComic
                                                      ? null
                                                      : LinearGradient(
                                                          colors: [
                                                            C.primaryHi,
                                                            C.primaryLo,
                                                          ],
                                                        ),
                                                  color: isComic
                                                      ? C.primaryHi
                                                      : null,
                                                  border: Border.all(
                                                    color: isComic
                                                        ? Colors.black
                                                        : Colors.black,
                                                    width: isComic
                                                        ? 3
                                                        : 2,
                                                  ),
                                                ),
                                          child: Text(
                                            product.hargaFormatted,
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize:
                                                  isComic ? 20 : 18,
                                              fontWeight:
                                                  FontWeight.w900,
                                              fontFamily: isComic
                                                  ? 'Bangers'
                                                  : 'Orbitron',
                                              letterSpacing: 0.5,
                                              shadows: isComic
                                                  ? const [
                                                      Shadow(
                                                        color: Colors
                                                            .black,
                                                        offset: Offset(
                                                            1, 1),
                                                        blurRadius: 0,
                                                      ),
                                                    ]
                                                  : null,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 12),

                                  // ═══ PENJUAL ═══
                                  _MetalPlate(
                                    C: C,
                                    padding: const EdgeInsets.all(14),
                                    child: Row(
                                      children: [
                                        Stack(
                                          alignment:
                                              Alignment.center,
                                          children: [
                                            Container(
                                              width: 46,
                                              height: 46,
                                              decoration: isHud
                                                  ? BoxDecoration(
                                                      color: C.accentHi
                                                          .withOpacity(
                                                              0.15),
                                                      border: Border.all(
                                                          color: C
                                                              .accentHi,
                                                          width: 1.4),
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: C
                                                              .accentHi
                                                              .withOpacity(
                                                                  0.35),
                                                          blurRadius:
                                                              10,
                                                        ),
                                                      ],
                                                    )
                                                  : BoxDecoration(
                                                      shape: BoxShape
                                                          .circle,
                                                      gradient: isComic
                                                          ? null
                                                          : RadialGradient(
                                                              colors: [
                                                                C.text,
                                                                C.bg,
                                                                C.bgDark,
                                                              ],
                                                            ),
                                                      color: isComic
                                                          ? C.primaryHi
                                                          : null,
                                                      border: Border.all(
                                                        color: isComic
                                                            ? Colors
                                                                .black
                                                            : C
                                                                .accentHi,
                                                        width: isComic
                                                            ? 3
                                                            : 2,
                                                      ),
                                                    ),
                                              child: Icon(
                                                Icons.person_rounded,
                                                color: isComic
                                                    ? Colors.white
                                                    : (isHud
                                                        ? C.accentHi
                                                        : C.accentHi),
                                                size: 22,
                                              ),
                                            ),
                                            if (!isComic)
                                              Positioned(
                                                top: -1,
                                                right: -1,
                                                child: _Led(
                                                  color:
                                                      C.primaryHi,
                                                  size: 6,
                                                  blink: true,
                                                ),
                                              ),
                                          ],
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .start,
                                            children: [
                                              Text(
                                                'PENJUAL',
                                                style: TextStyle(
                                                  color: isComic
                                                      ? Colors.black
                                                          .withOpacity(
                                                              0.6)
                                                      : (isHud
                                                          ? C.hudTextDim()
                                                          : C.accent),
                                                  fontSize:
                                                      isComic ? 12 : 9,
                                                  fontWeight:
                                                      FontWeight.w800,
                                                  fontFamily: isComic
                                                      ? 'Bangers'
                                                      : 'Orbitron',
                                                  letterSpacing: 1.5,
                                                ),
                                              ),
                                              const SizedBox(
                                                  height: 3),
                                              Text(
                                                product.penjual,
                                                style: TextStyle(
                                                  color: isComic
                                                      ? Colors.black
                                                      : (isHud
                                                          ? C.hudText()
                                                          : C.text),
                                                  fontSize:
                                                      isComic ? 16 : 13,
                                                  fontWeight:
                                                      FontWeight.w900,
                                                  fontFamily: isComic
                                                      ? 'Bangers'
                                                      : 'Orbitron',
                                                  letterSpacing: 0.5,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        if (product.isMine)
                                          Container(
                                            padding:
                                                const EdgeInsets
                                                    .symmetric(
                                                    horizontal: 8,
                                                    vertical: 4),
                                            decoration: isHud
                                                ? BoxDecoration(
                                                    color: C.accent
                                                        .withOpacity(
                                                            0.15),
                                                    border: Border.all(
                                                        color:
                                                            C.accent,
                                                        width: 1),
                                                  )
                                                : BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            isComic
                                                                ? 8
                                                                : 6),
                                                    color: isComic
                                                        ? C.accent
                                                        : C.accentHi
                                                            .withOpacity(
                                                                0.2),
                                                    border: Border.all(
                                                      color: isComic
                                                          ? Colors
                                                              .black
                                                          : C
                                                              .accentHi,
                                                      width: isComic
                                                          ? 2
                                                          : 1.5,
                                                    ),
                                                  ),
                                            child: Text(
                                              'INI PRODUK LU',
                                              style: TextStyle(
                                                color: isComic
                                                    ? Colors.white
                                                    : (isHud
                                                        ? C.hudNeon()
                                                        : C.accentHi),
                                                fontSize:
                                                    isComic ? 10 : 8,
                                                fontWeight:
                                                    FontWeight.w900,
                                                fontFamily: isComic
                                                    ? 'Bangers'
                                                    : 'Orbitron',
                                                letterSpacing: 0.8,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),

                                  // ═══ DESKRIPSI ═══
                                  if (product.deskripsi.isNotEmpty) ...[
                                    const SizedBox(height: 12),
                                    _MetalPlate(
                                      C: C,
                                      padding: const EdgeInsets.all(14),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                        children: [
                                          Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .description_rounded,
                                                color: isComic
                                                    ? Colors.black
                                                    : (isHud
                                                        ? C.hudNeon()
                                                        : C.accent),
                                                size: 16,
                                              ),
                                              const SizedBox(width: 6),
                                              Text(
                                                'DESKRIPSI',
                                                style: TextStyle(
                                                  color: isComic
                                                      ? Colors.black
                                                      : (isHud
                                                          ? C.hudNeon()
                                                          : C.accent),
                                                  fontSize:
                                                      isComic ? 14 : 11,
                                                  fontWeight:
                                                      FontWeight.w900,
                                                  fontFamily: isComic
                                                      ? 'Bangers'
                                                      : 'Orbitron',
                                                  letterSpacing: 1.5,
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 10),
                                          Text(
                                            product.deskripsi,
                                            style: TextStyle(
                                              color: isComic
                                                  ? Colors.black
                                                      .withOpacity(
                                                          0.8)
                                                  : (isHud
                                                      ? C.hudText()
                                                      : C.text
                                                          .withOpacity(
                                                              0.85)),
                                              fontSize:
                                                  isComic ? 14 : 12,
                                              fontFamily: isComic
                                                  ? 'ComicNeue'
                                                  : 'ShareTechMono',
                                              height: 1.6,
                                              fontWeight:
                                                  FontWeight.w600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],

                                  const SizedBox(height: 20),

                                  // ═══ KONTAK PENJUAL ═══
                                  if (!product.isMine) ...[
                                    Row(
                                      children: [
                                        if (product.wa.isNotEmpty)
                                          Expanded(
                                            child: _IndustrialButton(
                                              C: C,
                                              color: C.primaryHi,
                                              height: 50,
                                              onTap: () => _openWA(C),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                children: [
                                                  const Icon(
                                                    Icons
                                                        .phone_rounded,
                                                    color:
                                                        Colors.white,
                                                    size: 16,
                                                  ),
                                                  const SizedBox(
                                                      width: 6),
                                                  Text(
                                                    'WHATSAPP',
                                                    style: TextStyle(
                                                      color:
                                                          Colors.white,
                                                      fontWeight:
                                                          FontWeight
                                                              .w900,
                                                      fontFamily:
                                                          isComic
                                                              ? 'Bangers'
                                                              : 'Orbitron',
                                                      letterSpacing:
                                                          1.5,
                                                      fontSize:
                                                          isComic
                                                              ? 15
                                                              : 11,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        if (product.wa.isNotEmpty &&
                                            product
                                                .telegram.isNotEmpty)
                                          const SizedBox(width: 10),
                                        if (product.telegram.isNotEmpty)
                                          Expanded(
                                            child: _IndustrialButton(
                                              C: C,
                                              color: C.accentHi,
                                              height: 50,
                                              onTap: () =>
                                                  _openTelegram(C),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                children: [
                                                  const Icon(
                                                    Icons
                                                        .send_rounded,
                                                    color:
                                                        Colors.white,
                                                    size: 16,
                                                  ),
                                                  const SizedBox(
                                                      width: 6),
                                                  Text(
                                                    'TELEGRAM',
                                                    style: TextStyle(
                                                      color:
                                                          Colors.white,
                                                      fontWeight:
                                                          FontWeight
                                                              .w900,
                                                      fontFamily:
                                                          isComic
                                                              ? 'Bangers'
                                                              : 'Orbitron',
                                                      letterSpacing:
                                                          1.5,
                                                      fontSize:
                                                          isComic
                                                              ? 15
                                                              : 11,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                    const SizedBox(height: 10),
                                    _InsetPanel(
                                      C: C,
                                      isComic: isComic,
                                      isHud: isHud,
                                      padding:
                                          const EdgeInsets.all(12),
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons
                                                .info_outline_rounded,
                                            color: isComic
                                                ? Colors.black
                                                : (isHud
                                                    ? C.hudNeon()
                                                    : C.accent),
                                            size: 16,
                                          ),
                                          const SizedBox(width: 8),
                                          Expanded(
                                            child: Text(
                                              'Chat langsung ke penjual buat nego harga & info lebih lanjut.',
                                              style: TextStyle(
                                                color: isComic
                                                    ? Colors.black
                                                        .withOpacity(
                                                            0.7)
                                                    : (isHud
                                                        ? C.hudText()
                                                        : C.text
                                                            .withOpacity(
                                                                0.75)),
                                                fontSize:
                                                    isComic ? 12 : 10,
                                                fontFamily: isComic
                                                    ? 'ComicNeue'
                                                    : 'ShareTechMono',
                                                height: 1.5,
                                                fontWeight:
                                                    FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],

                                  // ═══ TOMBOL HAPUS ═══
                                  if (product.isMine) ...[
                                    const SizedBox(height: 10),
                                    _IndustrialButton(
                                      C: C,
                                      color: _deleting
                                          ? C.bg
                                          : C.primaryHi,
                                      height: 50,
                                      onTap: _deleting
                                          ? null
                                          : () => _deleteProduct(
                                              C, isComic, isHud),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                        children: [
                                          if (_deleting)
                                            SizedBox(
                                              width: 18,
                                              height: 18,
                                              child:
                                                  CircularProgressIndicator(
                                                strokeWidth: 2.5,
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                        Color>(C.accent),
                                              ),
                                            )
                                          else
                                            const Icon(
                                              Icons.delete_rounded,
                                              color: Colors.white,
                                              size: 16,
                                            ),
                                          const SizedBox(width: 10),
                                          Text(
                                            _deleting
                                                ? 'MENGHAPUS...'
                                                : 'HAPUS PRODUK',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight:
                                                  FontWeight.w900,
                                              fontFamily: isComic
                                                  ? 'Bangers'
                                                  : 'Orbitron',
                                              letterSpacing: 2,
                                              fontSize:
                                                  isComic ? 16 : 12,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: _MetalPlate(
        C: C,
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            _IconButton(
              C: C,
              isComic: isComic,
              isHud: isHud,
              icon: Icons.arrow_back_rounded,
              color: C.accent,
              onTap: () => Navigator.pop(context),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accentHi.withOpacity(0.15),
                          border: Border.all(
                              color: C.accentHi, width: 1.4),
                          boxShadow: [
                            BoxShadow(
                              color: C.accentHi.withOpacity(0.35),
                              blurRadius: 10,
                            ),
                          ],
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic
                              ? null
                              : RadialGradient(
                                  colors: [C.text, C.bg, C.bgDark]),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                              color: isComic
                                  ? Colors.black
                                  : C.accentHi,
                              width: isComic ? 3 : 2),
                        ),
                  child: Icon(
                    Icons.receipt_long_rounded,
                    color: isComic
                        ? Colors.white
                        : (isHud ? C.accentHi : C.accentHi),
                    size: 20,
                  ),
                ),
                if (!isComic)
                  Positioned(
                    top: -2,
                    right: -2,
                    child: _Led(
                      color: C.primaryHi,
                      size: 6,
                      blink: true,
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'DETAIL PRODUK',
                    style: TextStyle(
                      color: isComic
                          ? Colors.black
                          : (isHud ? C.hudNeon() : C.accentHi),
                      fontSize: isComic ? 18 : 13,
                      fontWeight: FontWeight.w900,
                      fontFamily:
                          isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: isComic ? 1.5 : 2,
                      height: 1,
                      shadows: isComic
                          ? null
                          : [
                              Shadow(
                                color: C.primaryLo,
                                offset: const Offset(0, 1),
                                blurRadius: 1,
                              ),
                              const Shadow(
                                color: Colors.black,
                                offset: Offset(0, 2),
                                blurRadius: 3,
                              ),
                            ],
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(
                        color: C.accentHi,
                        size: 4,
                        blink: !isComic,
                      ),
                      const SizedBox(width: 5),
                      Text(
                        'PASAR ONLINE',
                        style: TextStyle(
                          color: isComic
                              ? Colors.black.withOpacity(0.5)
                              : (isHud
                                  ? C.hudTextDim()
                                  : C.text.withOpacity(0.55)),
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          fontFamily: isComic
                              ? 'ComicNeue'
                              : 'ShareTechMono',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            _IconButton(
              C: C,
              isComic: isComic,
              isHud: isHud,
              icon: Icons.copy_rounded,
              color: C.accent,
              onTap: () => _copyInfo(C),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HELPER WIDGETS
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(
              color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.9),
              blurRadius: size * 1.8,
              spreadRadius: size * 0.3,
            ),
          ],
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [
            Colors.white.withOpacity(0.85),
            color.withOpacity(0.9),
            color.withOpacity(0.55),
          ],
          stops: const [0.0, 0.4, 1.0],
        ),
        border: Border.all(
            color: Colors.black.withOpacity(0.85),
            width: size * 0.1),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.75),
            blurRadius: size * 1.4,
            spreadRadius: size * 0.2,
          ),
        ],
      ),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  final Color? accent;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
    this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border:
              Border.all(color: accent ?? Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(
              color: accent ?? C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: C.accent.withOpacity(0.15),
              blurRadius: 12,
            ),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(
              top: 0,
              left: 0,
              child: SizedBox(
                width: 12,
                height: 12,
                child: CustomPaint(
                  painter: _HudCornerPainter(
                      color: C.accent.withOpacity(0.7)),
                ),
              ),
            ),
            Positioned(
              top: 0,
              right: 0,
              child: SizedBox(
                width: 12,
                height: 12,
                child: CustomPaint(
                  painter: _HudCornerPainter(
                      color: C.accent.withOpacity(0.7)),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              child: SizedBox(
                width: 12,
                height: 12,
                child: CustomPaint(
                  painter: _HudCornerPainter(
                      color: C.accent.withOpacity(0.7)),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              right: 0,
              child: SizedBox(
                width: 12,
                height: 12,
                child: CustomPaint(
                  painter: _HudCornerPainter(
                      color: C.accent.withOpacity(0.7)),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
          if (accent != null)
            BoxShadow(
              color: accent!.withOpacity(0.5),
              blurRadius: 14,
              spreadRadius: 1,
            ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(
              color: accent ?? Colors.black.withOpacity(0.5),
              width: accent != null ? 1.5 : 1),
        ),
        child: child,
      ),
    );
  }
}

class _InsetPanel extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final bool isHud;
  final Widget child;
  final EdgeInsets padding;
  const _InsetPanel({
    required this.C,
    required this.isComic,
    required this.isHud,
    required this.child,
    this.padding = const EdgeInsets.all(12),
  });

  @override
  Widget build(BuildContext context) {
    if (isHud) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDeep.withOpacity(0.7),
          border: Border.all(
              color: C.accent.withOpacity(0.4), width: 1),
        ),
        child: child,
      );
    }
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(colors: [C.bgDeep, C.bgDark]),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.95),
            offset: const Offset(0, 2),
            blurRadius: 4,
          ),
        ],
        border: Border.all(color: C.bgDark, width: 1.5),
      ),
      child: child,
    );
  }
}

class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final enabled = widget.onTap != null;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);

    return GestureDetector(
      onTapDown:
          enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            }
          : null,
      onTapCancel:
          enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(
                _pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: isHud
            ? BoxDecoration(
                color: enabled
                    ? (_pressed
                        ? widget.color.withOpacity(0.25)
                        : widget.color.withOpacity(0.15))
                    : C.bgDeep.withOpacity(0.5),
                border: Border.all(
                  color: enabled
                      ? widget.color
                      : C.hudTextDim().withOpacity(0.4),
                  width: 1.4,
                ),
                boxShadow: enabled && !_pressed
                    ? [
                        BoxShadow(
                          color: widget.color.withOpacity(0.35),
                          blurRadius: 10,
                        ),
                      ]
                    : null,
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: isComic
                    ? null
                    : LinearGradient(
                        begin: _pressed
                            ? Alignment.bottomCenter
                            : Alignment.topCenter,
                        end: _pressed
                            ? Alignment.topCenter
                            : Alignment.bottomCenter,
                        colors: _pressed
                            ? [dark, dark, widget.color]
                            : [light, widget.color, dark],
                        stops: const [0.0, 0.5, 1.0],
                      ),
                color: isComic ? widget.color : null,
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : dark.withOpacity(0.9),
                    width: isComic ? 3.5 : 1.5),
                boxShadow: isComic
                    ? (_pressed
                        ? []
                        : const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ])
                    : null,
              ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Center(
            child: Opacity(
              opacity: enabled ? 1 : 0.5,
              child: widget.child,
            ),
          ),
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(
        c.alpha,
        (c.red + 40).clamp(0, 255),
        (c.green + 40).clamp(0, 255),
        (c.blue + 30).clamp(0, 255),
      );
  static Color _darken(Color c) => Color.fromARGB(
        c.alpha,
        (c.red - 60).clamp(0, 255),
        (c.green - 50).clamp(0, 255),
        (c.blue - 40).clamp(0, 255),
      );
}

class _IconButton extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  final bool isHud;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final double size;
  const _IconButton({
    required this.C,
    required this.isComic,
    required this.isHud,
    required this.icon,
    required this.onTap,
    required this.color,
    this.size = 40,
  });

  @override
  State<_IconButton> createState() => _IconButtonState();
}

class _IconButtonState extends State<_IconButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size,
        height: widget.size,
        transform: widget.isComic
            ? Matrix4.translationValues(
                _pressed ? 2 : 0, _pressed ? 2 : 0, 0)
            : null,
        decoration: widget.isHud
            ? BoxDecoration(
                color: _pressed
                    ? C.accent.withOpacity(0.25)
                    : C.accent.withOpacity(0.1),
                border: Border.all(color: C.accent, width: 1.2),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: C.accent.withOpacity(0.35),
                          blurRadius: 8,
                        ),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: widget.isComic
                    ? null
                    : LinearGradient(
                        begin: _pressed
                            ? Alignment.bottomCenter
                            : Alignment.topCenter,
                        end: _pressed
                            ? Alignment.topCenter
                            : Alignment.bottomCenter,
                        colors: _pressed
                            ? [C.bgDark, C.bg]
                            : [C.textSub, C.bg, C.bgDark],
                      ),
                color: widget.isComic ? C.accent : null,
                border: Border.all(
                    color: widget.isComic
                        ? Colors.black
                        : Colors.black.withOpacity(0.7),
                    width: widget.isComic ? 3 : 1.2),
                boxShadow: widget.isComic
                    ? (_pressed
                        ? []
                        : const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(3, 3),
                              blurRadius: 0,
                            ),
                          ])
                    : null,
              ),
        child: Icon(
          widget.icon,
          color: widget.isComic
              ? Colors.white
              : (widget.isHud ? C.accent : widget.color),
          size: widget.size * 0.5,
        ),
      ),
    );
  }
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0;
          y < size.height + spacing;
          y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) =>
      old.color != color;
}