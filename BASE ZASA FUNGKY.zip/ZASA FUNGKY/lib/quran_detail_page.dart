// quran_detail_page.dart — Full 3 Style Support
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'quran_api.dart';

// ═══════════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE (3 STYLE)
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(5, 5),
                blurRadius: 0),
          ]),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withValues(alpha: 0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12, height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.8)),
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// QURAN DETAIL PAGE
// ═══════════════════════════════════════════════════════════
class QuranDetailPage extends StatefulWidget {
  final QuranSurah surah;
  const QuranDetailPage({super.key, required this.surah});

  @override
  State<QuranDetailPage> createState() => _QuranDetailPageState();
}

class _QuranDetailPageState extends State<QuranDetailPage> {
  QuranSurahDetail? _detail;
  bool _loading = true;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _loadDetail();
  }

  Future<void> _loadDetail() async {
    setState(() {
      _loading = true;
      _error = '';
    });
    final result = await QuranApi.getSurahDetail(widget.surah.nomor);
    if (!mounted) return;
    setState(() {
      _detail = result;
      _loading = false;
      if (result == null) {
        _error = 'Gagal memuat surah. Cek koneksi internet.';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              radius: 1.2,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                              stops: const [0.0, 0.6, 1.0]))),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withValues(
                                    alpha: 0.12))))),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine())))),
                    SafeArea(
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _buildTopBar(C, isComic, isHud),
                          const SizedBox(height: 10),
                          Expanded(
                            child: _loading
                                ? Center(
                                    child: CircularProgressIndicator(
                                        color: isComic
                                            ? Colors.black
                                            : (isHud
                                                ? C.hudNeon()
                                                : C.accent),
                                        strokeWidth: 2))
                                : _error.isNotEmpty
                                    ? _buildError(C, isComic, isHud)
                                    : _buildContent(C, isComic, isHud),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36, height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: isComic
                            ? null
                            : LinearGradient(
                                colors: [C.text, C.bg, C.bgDark]),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : C.primaryLo,
                            width: isComic ? 3 : 1.5)),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : (isHud ? C.hudNeon() : C.accent),
                    size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36, height: 36,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border: Border.all(color: C.accent, width: 1.2),
                      boxShadow: [
                        BoxShadow(
                            color: C.accent.withOpacity(0.5),
                            blurRadius: 8),
                      ],
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(colors: [
                              C.accentHi, C.accent, C.primaryLo]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.accentShine,
                          width: isComic ? 3 : 1.5)),
              child: Icon(Icons.book_rounded,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : C.bgDeep),
                  size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.surah.namaLatin.toUpperCase(),
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 16 : 13,
                        letterSpacing: isComic ? 1 : 1.5,
                        shadows: isHud
                            ? [
                                Shadow(
                                    color: C.accent.withOpacity(0.5),
                                    blurRadius: 6),
                              ]
                            : null),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Text(
                      'SURAH ${widget.surah.nomor} · ${widget.surah.jumlahAyat} AYAT',
                      style: TextStyle(
                        color: isComic
                            ? Colors.black.withValues(alpha: 0.5)
                            : (isHud
                                ? C.hudTextDim()
                                : C.text.withValues(alpha: 0.55)),
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        fontSize: 8,
                        letterSpacing: 1.2)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(AppPalette C, bool isComic, bool isHud) {
    final detail = _detail!;
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 24),
      physics: const BouncingScrollPhysics(),
      itemCount: detail.ayat.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) return _buildHeader(C, isComic, isHud, detail);
        return _buildAyatTile(
            C, isComic, isHud, detail.ayat[i - 1]);
      },
    );
  }

  Widget _buildHeader(
      AppPalette C, bool isComic, bool isHud, QuranSurahDetail detail) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: _MetalPlate(
        C: C,
        brass: !isComic && !isHud,
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(detail.nama,
                style: TextStyle(
                  color: isComic ? Colors.black : C.bgDeep,
                  fontSize: 36,
                  fontWeight: FontWeight.w900,
                  height: 1.2),
                textDirection: TextDirection.rtl),
            const SizedBox(height: 8),
            Text(detail.namaLatin,
                style: TextStyle(
                  color: isComic ? Colors.black : C.bgDeep,
                  fontSize: isComic ? 20 : 18,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 1)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 10 : 20),
                color: isComic
                    ? Colors.white
                    : C.bgDeep.withValues(alpha: 0.15),
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : C.bgDeep.withValues(alpha: 0.4),
                    width: isComic ? 2.5 : 1)),
              child: Text(
                  '${detail.arti} · ${detail.jumlahAyat} AYAT · ${detail.tempatTurun.toUpperCase()}',
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : C.bgDeep.withValues(alpha: 0.9),
                    fontSize: isComic ? 10 : 9,
                    fontFamily:
                        isComic ? 'Bangers' : 'ShareTechMono',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAyatTile(
      AppPalette C, bool isComic, bool isHud, QuranAyat ayat) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 4),
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border: Border.all(
                              color: C.accent, width: 1.2),
                          boxShadow: [
                            BoxShadow(
                                color: C.accent.withOpacity(0.4),
                                blurRadius: 6),
                          ],
                        )
                      : BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(isComic ? 10 : 6),
                          gradient: isComic
                              ? null
                              : LinearGradient(colors: [
                                  C.accentHi,
                                  C.accent,
                                  C.primaryLo
                                ]),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                              color: isComic
                                  ? Colors.black
                                  : C.accentShine,
                              width: isComic ? 2.5 : 1)),
                  child: Text('AYAT ${ayat.nomorAyat}',
                      style: TextStyle(
                        color: isComic
                            ? Colors.white
                            : (isHud ? C.hudNeon() : C.bgDeep),
                        fontSize: isComic ? 12 : 9,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 1.5,
                        shadows: isHud
                            ? [
                                Shadow(
                                    color:
                                        C.accent.withOpacity(0.5),
                                    blurRadius: 4),
                              ]
                            : null)),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 14),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.bgDeep.withOpacity(0.6),
                      border: Border.all(
                          color: C.accent.withOpacity(0.4),
                          width: 1),
                    )
                  : BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(isComic ? 10 : 10),
                      color: isComic
                          ? Colors.white
                          : Colors.black.withValues(alpha: 0.4),
                      border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.accent.withValues(alpha: 0.25),
                          width: isComic ? 3 : 1)),
              child: Text(ayat.teksArab,
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudText() : C.accentShine),
                    fontSize: isComic ? 26 : 24,
                    height: 1.9,
                    fontWeight: FontWeight.w500,
                    shadows: isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.3),
                                blurRadius: 6),
                          ]
                        : null)),
            ),
            const SizedBox(height: 12),
            Text(ayat.teksLatin,
                style: TextStyle(
                  color: isComic
                      ? Colors.black.withValues(alpha: 0.7)
                      : (isHud
                          ? C.hudTextDim()
                          : C.text.withValues(alpha: 0.7)),
                  fontSize: isComic ? 13 : 11.5,
                  fontStyle: FontStyle.italic,
                  height: 1.6,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Text(ayat.teksIndonesia,
                style: TextStyle(
                  color: isComic
                      ? Colors.black
                      : (isHud ? C.hudText() : C.text),
                  fontSize: isComic ? 14 : 12.5,
                  height: 1.65,
                  fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildError(AppPalette C, bool isComic, bool isHud) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline_rounded,
                  color: isComic
                      ? Colors.black
                      : (isHud ? C.hudWarning() : C.primaryHi),
                  size: 42),
              const SizedBox(height: 12),
              Text(_error,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudText() : C.text),
                    fontSize: isComic ? 13 : 12,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w700)),
              const SizedBox(height: 18),
              GestureDetector(
                onTap: _loadDetail,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 10),
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border: Border.all(
                              color: C.accent, width: 1.4),
                          boxShadow: [
                            BoxShadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 10),
                          ],
                        )
                      : BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(isComic ? 12 : 8),
                          gradient: isComic
                              ? null
                              : LinearGradient(colors: [
                                  C.primaryHi,
                                  C.primary,
                                  C.primaryLo
                                ]),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                              color: isComic
                                  ? Colors.black
                                  : C.primaryLo,
                              width: isComic ? 3 : 1.5)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.refresh_rounded,
                          color: isComic
                              ? Colors.white
                              : (isHud ? C.hudNeon() : C.text),
                          size: 16),
                      const SizedBox(width: 8),
                      Text('COBA LAGI',
                          style: TextStyle(
                            color: isComic
                                ? Colors.white
                                : (isHud ? C.hudNeon() : C.text),
                            fontSize: isComic ? 15 : 11,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) =>
      old.color != color;
}