// spam_ngl.dart — NGL Auto Sender (3 Style Support)
import 'dart:convert';
import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';

class NglPage extends StatefulWidget {
  const NglPage({super.key});

  @override
  State<NglPage> createState() => _NglPageState();
}

class _NglPageState extends State<NglPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  bool isRunning = false;
  int counter = 0;
  String statusLog = "";
  Timer? timer;

  String generateDeviceId(int length) {
    final random = Random.secure();
    return List.generate(
        length, (_) => random.nextInt(16).toRadixString(16)).join();
  }

  Future<void> sendMessage(String username, String message) async {
    final deviceId = generateDeviceId(42);
    final url = Uri.parse("https://ngl.link/api/submit");

    final headers = {
      "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
      "Accept": "*/*",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      "Referer": "https://ngl.link/$username",
      "Origin": "https://ngl.link"
    };

    final body =
        "username=$username&question=$message&deviceId=$deviceId&gameSlug=&referrer=";

    try {
      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        setState(() {
          counter++;
          statusLog = "✅ [$counter] Pesan terkirim";
        });
      } else {
        setState(() {
          statusLog =
              "❌ Ratelimit (${response.statusCode}), tunggu 5 detik...";
        });
        await Future.delayed(const Duration(seconds: 5));
      }
    } catch (e) {
      setState(() {
        statusLog = "⚠️ Error: $e";
      });
      await Future.delayed(const Duration(seconds: 2));
    }
  }

  void startLoop() {
    final username = usernameController.text.trim();
    final message = messageController.text.trim();

    if (username.isEmpty || message.isEmpty) {
      setState(() {
        statusLog = "⚠️ Harap isi username & pesan!";
      });
      return;
    }

    setState(() {
      isRunning = true;
      counter = 0;
      statusLog = "▶️ Mulai mengirim...";
    });

    timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (isRunning) {
        sendMessage(username, message);
      }
    });
  }

  void stopLoop() {
    setState(() {
      isRunning = false;
      statusLog = "⏹️ Dihentikan.";
    });
    timer?.cancel();
  }

  @override
  void dispose() {
    timer?.cancel();
    usernameController.dispose();
    messageController.dispose();
    super.dispose();
  }

  // ═══ PANEL DECORATION (3 STYLE) ═══
  BoxDecoration _panel(AppPalette C, bool isComic, bool isHud, {double r = 16}) {
    if (isComic) {
      return BoxDecoration(
        color: C.bgDark,
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: Colors.black, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
        ],
      );
    }
    if (isHud) {
      return BoxDecoration(
        color: C.hudPanel(),
        border: Border.all(color: C.hudBorder(), width: 1.2),
        boxShadow: [
          BoxShadow(color: C.accent.withOpacity(0.2), blurRadius: 12),
        ],
      );
    }
    return BoxDecoration(
      color: C.bgDark,
      borderRadius: BorderRadius.circular(r),
      border: Border.all(color: C.accent.withOpacity(0.35), width: 1.2),
      boxShadow: [
        BoxShadow(
            color: Colors.black.withOpacity(0.6),
            offset: const Offset(0, 4),
            blurRadius: 10),
      ],
    );
  }

  Widget _buildInput({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required TextEditingController controller,
    required String label,
    required IconData icon,
    int maxLines = 1,
  }) {
    return Container(
      decoration: _panel(C, isComic, isHud, r: isHud ? 4 : 16),
      padding: EdgeInsets.symmetric(
          horizontal: isComic ? 8 : 12, vertical: isComic ? 4 : 0),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        style: TextStyle(
          color: isComic
              ? Colors.black
              : (isHud ? C.hudText() : C.text),
          fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
          fontWeight: FontWeight.w700,
          fontSize: 14,
          letterSpacing: isHud ? 1 : 0,
        ),
        cursorColor: isComic ? Colors.black : C.accent,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            color: isComic
                ? Colors.black.withOpacity(0.6)
                : (isHud ? C.hudTextDim() : C.accent),
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontWeight: FontWeight.w700,
          ),
          prefixIcon: Icon(icon,
              color: isComic ? Colors.black : C.accent, size: 18),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 4),
        ),
      ),
    );
  }

  Widget _buildBigButton({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback? onTap,
  }) {
    final disabled = onTap == null;
    final textColor = isComic ? C.contrastTextOn(color) : Colors.white;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 54,
        decoration: isHud
            ? BoxDecoration(
                color: color.withOpacity(disabled ? 0.05 : 0.15),
                border: Border.all(
                    color: color.withOpacity(disabled ? 0.4 : 1),
                    width: 1.4),
                boxShadow: disabled
                    ? []
                    : [
                        BoxShadow(
                            color: color.withOpacity(0.35),
                            blurRadius: 10),
                      ],
              )
            : BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(isComic ? 12 : 12),
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : color.withOpacity(0.9),
                    width: isComic ? 3.5 : 1.5),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                            color: Colors.black,
                            offset: Offset(4, 4),
                            blurRadius: 0),
                      ]
                    : [
                        BoxShadow(
                            color: color.withOpacity(0.35),
                            blurRadius: 12),
                      ],
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color:
                    disabled ? textColor.withOpacity(0.5) : textColor,
                size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color:
                    disabled ? textColor.withOpacity(0.5) : textColor,
                fontWeight: FontWeight.w900,
                fontSize: 15,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 1.5 : (isHud ? 2 : 1),
                shadows: isComic
                    ? [
                        Shadow(
                            color: textColor == Colors.white
                                ? Colors.black
                                : Colors.white,
                            offset: const Offset(2, 2),
                            blurRadius: 0),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Stack(
                children: [
                  if (isComic)
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _ComicHalftonePainter(
                            color: C.primaryLo.withOpacity(0.12)),
                      ),
                    ),
                  if (isHud)
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _HudGridPainter(
                            color: C.hudGridLine()),
                      ),
                    ),
                  SafeArea(
                    child: Column(
                      children: [
                        _buildTopBar(C, isComic, isHud),
                        Expanded(
                          child: SingleChildScrollView(
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  isHud: isHud,
                                  controller: usernameController,
                                  label: "Username NGL",
                                  icon: Icons.alternate_email_rounded,
                                ),
                                const SizedBox(height: 12),
                                _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  isHud: isHud,
                                  controller: messageController,
                                  label: "Pesan",
                                  icon: Icons.message_rounded,
                                  maxLines: 3,
                                ),
                                const SizedBox(height: 20),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _buildBigButton(
                                        C: C,
                                        isComic: isComic,
                                        isHud: isHud,
                                        label: "START",
                                        icon: Icons.play_arrow_rounded,
                                        color: C.primaryHi,
                                        onTap: isRunning ? null : startLoop,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: _buildBigButton(
                                        C: C,
                                        isComic: isComic,
                                        isHud: isHud,
                                        label: "STOP",
                                        icon: Icons.stop_rounded,
                                        color: C.accent,
                                        onTap: isRunning ? stopLoop : null,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 20),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(16),
                                  decoration: _panel(C, isComic, isHud),
                                  child: Column(
                                    children: [
                                      Text(
                                        statusLog,
                                        style: TextStyle(
                                          fontSize: isComic ? 15 : 14,
                                          color: isComic
                                              ? C.comicText
                                              : (isHud
                                                  ? C.hudText()
                                                  : C.text),
                                          fontFamily: isComic
                                              ? 'ComicNeue'
                                              : 'ShareTechMono',
                                          fontWeight: FontWeight.w700,
                                          letterSpacing: isHud ? 1 : 0,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                      if (counter > 0)
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 10),
                                          child: Text(
                                            "Total terkirim: $counter",
                                            style: TextStyle(
                                              fontSize: isComic ? 15 : 13,
                                              color: isComic
                                                  ? C.comicTextSub
                                                  : (isHud
                                                      ? C.hudTextDim()
                                                      : C.textSub),
                                              fontFamily: isComic
                                                  ? 'ComicNeue'
                                                  : 'ShareTechMono',
                                              fontWeight: FontWeight.w700,
                                              letterSpacing:
                                                  isHud ? 1 : 0,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: _panel(C, isComic, isHud, r: isHud ? 4 : 12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36,
                height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border: Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: isComic
                            ? null
                            : LinearGradient(
                                colors: [C.text, C.bg, C.bgDark]),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color:
                                isComic ? Colors.black : C.primaryLo,
                            width: isComic ? 2.5 : 1.5),
                      ),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : C.accent,
                    size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36,
              height: 36,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border: Border.all(color: C.accent, width: 1.2),
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(colors: [
                              C.accentHi,
                              C.accent,
                              C.primaryLo
                            ]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color:
                              isComic ? Colors.black : C.accentShine,
                          width: isComic ? 3 : 1.5),
                    ),
              child: Icon(Icons.send_rounded,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : C.bgDeep),
                  size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('NGL AUTO SENDER',
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 18 : 13,
                        letterSpacing: isComic ? 2 : 2.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0),
                              ]
                            : (isHud
                                ? [
                                    Shadow(
                                        color: C.accent
                                            .withOpacity(0.5),
                                        blurRadius: 8),
                                  ]
                                : null),
                      )),
                  const SizedBox(height: 2),
                  Text('AUTO SPAM ANONYMOUS',
                      style: TextStyle(
                        color: isComic
                            ? C.comicTextSub
                            : (isHud
                                ? C.hudTextDim()
                                : C.text.withOpacity(0.55)),
                        fontFamily: isComic
                            ? 'ComicNeue'
                            : 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        fontSize: 8,
                        letterSpacing: 1.2),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}