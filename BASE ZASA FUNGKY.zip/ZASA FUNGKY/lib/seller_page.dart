// seller_page.dart — Seller Dashboard (Full 3 Style Support)
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'app_theme.dart';

class SellerPage extends StatefulWidget {
  final String keyToken;
  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['full up'];
  String selectedRole = 'full up';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;

  static const String _baseUrl = 'http://angelacantik.zone.id:3631';

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
          Uri.parse('$_baseUrl/listUsers?key=${widget.keyToken}'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "$_baseUrl/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "✅ Akun berhasil dibuat!");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _fetchUsers();
      } else {
        String msg = data['message'] ?? 'Gagal membuat akun.';
        if (data['invalidDay'] == true) msg += " (Max 30 hari untuk Reseller)";
        _alert("Gagal", "❌ $msg");
      }
    } catch (e) {
      _alert("Error", "❌ Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "$_baseUrl/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "✅ Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", "❌ ${data['message'] ?? 'Gagal mengubah durasi.'}");
      }
    } catch (e) {
      _alert("Error", "❌ Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  // ═══ SHADOW HELPER ═══
  List<BoxShadow> _shadow(double s) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    if (style == ThemeStyle.comic3d) {
      return [
        BoxShadow(color: Colors.black, offset: Offset(s, s), blurRadius: 0),
      ];
    }
    if (style == ThemeStyle.hudTactical) {
      return [
        BoxShadow(color: C.accent.withOpacity(0.2), blurRadius: 12),
      ];
    }
    return [
      BoxShadow(
          color: Colors.black.withOpacity(0.6),
          offset: const Offset(0, 4),
          blurRadius: 10),
    ];
  }

  // ═══ PANEL DECORATION ═══
  BoxDecoration _panel(AppPalette C, bool isComic, bool isHud,
      {double r = 20, Color? color}) {
    final base = color ?? C.bgDark;
    if (isComic) {
      return BoxDecoration(
        color: base,
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: Colors.black, width: 4),
        boxShadow: _shadow(6),
      );
    }
    if (isHud) {
      return BoxDecoration(
        color: C.hudPanel(),
        border: Border.all(color: C.hudBorder(), width: 1.2),
        boxShadow: _shadow(0),
      );
    }
    return BoxDecoration(
      color: base,
      borderRadius: BorderRadius.circular(r),
      border: Border.all(color: C.accent.withOpacity(0.3), width: 1.2),
      boxShadow: _shadow(0),
    );
  }

  void _alert(String title, String message) {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: isComic
            ? Container(
                decoration: BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(6, 6),
                        blurRadius: 0),
                  ],
                ),
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: C.primaryHi,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.black, width: 3),
                          ),
                          child: Icon(Icons.info_outline,
                              color: C.contrastTextOn(C.primaryHi), size: 18),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(title.toUpperCase(),
                              style: TextStyle(
                                color: C.comicText,
                                fontFamily: 'Bangers',
                                fontSize: 18,
                                letterSpacing: 2,
                              )),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(message,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: C.comicTextSub,
                            fontFamily: 'ComicNeue',
                            fontSize: 13,
                            height: 1.5)),
                    const SizedBox(height: 20),
                    _ComicDialogButton(
                        C: C, label: 'OK', onTap: () => Navigator.pop(context)),
                  ],
                ),
              )
            : Container(
                padding: const EdgeInsets.all(20),
                decoration: _panel(C, isComic, isHud, r: 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.info_outline,
                            color: isHud ? C.hudNeon() : C.accent),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(title,
                              style: TextStyle(
                                  color: isHud ? C.hudNeon() : C.text,
                                  fontFamily: 'Orbitron',
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.5)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text(message,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: isHud ? C.hudText() : C.textSub,
                            fontFamily: 'ShareTechMono',
                            fontSize: 12,
                            height: 1.5)),
                    const SizedBox(height: 20),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 24, vertical: 10),
                        decoration: isHud
                            ? BoxDecoration(
                                color: C.accent.withOpacity(0.15),
                                border: Border.all(
                                    color: C.accent, width: 1.2),
                              )
                            : BoxDecoration(
                                gradient: LinearGradient(
                                    colors: [C.accent, C.accentHi]),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                      color: C.accentHi.withOpacity(0.3),
                                      blurRadius: 10),
                                ],
                              ),
                        child: Text('OK',
                            style: TextStyle(
                                color: isHud ? C.hudNeon() : C.bgDeep,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.5)),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildInput({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required String label,
    required TextEditingController controller,
    required dynamic icon,
    TextInputType type = TextInputType.text,
    String hint = "",
  }) {
    if (isComic) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Text(label.toUpperCase(),
                  style: TextStyle(
                    color: C.comicText,
                    fontFamily: 'Bangers',
                    fontSize: 13,
                    letterSpacing: 1.5,
                  )),
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
                boxShadow: _shadow(3),
              ),
              child: TextField(
                controller: controller,
                keyboardType: type,
                style: const TextStyle(
                    color: Colors.black,
                    fontFamily: 'ComicNeue',
                    fontWeight: FontWeight.w700,
                    fontSize: 14),
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: TextStyle(
                      color: Colors.black.withOpacity(0.4),
                      fontFamily: 'ComicNeue',
                      fontSize: 12),
                  prefixIcon:
                      _DynamicIcon(icon, color: C.primaryHi, size: 18),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                ),
              ),
            ),
          ],
        ),
      );
    }

    if (isHud) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Text(label.toUpperCase(),
                  style: TextStyle(
                    color: C.accent,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 10,
                    letterSpacing: 2,
                  )),
            ),
            Container(
              decoration: BoxDecoration(
                color: C.bgDeep.withOpacity(0.6),
                border: Border.all(
                    color: C.accent.withOpacity(0.5), width: 1.2),
              ),
              child: TextField(
                controller: controller,
                keyboardType: type,
                style: TextStyle(
                    color: C.hudText(),
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    letterSpacing: 1),
                cursorColor: C.accent,
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: TextStyle(
                      color: C.hudTextDim(),
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      letterSpacing: 1),
                  prefixIcon:
                      _DynamicIcon(icon, color: C.accent, size: 16),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: C.text, fontFamily: 'ShareTechMono'),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: C.text.withOpacity(0.3)),
          labelStyle: TextStyle(color: C.accentHi),
          prefixIcon:
              _DynamicIcon(icon, color: C.accentHi.withOpacity(0.7), size: 18),
          filled: true,
          fillColor: C.bgDeep,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.bg),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.bg),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.accentHi, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required String title,
    required dynamic icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: EdgeInsets.all(isComic ? 18 : 20),
      decoration: _panel(C, isComic, isHud, r: isComic ? 18 : (isHud ? 4 : 20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border: Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        color: isComic ? C.primaryHi : C.accent.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                        border: isComic
                            ? Border.all(color: Colors.black, width: 3)
                            : null,
                      ),
                child: _DynamicIcon(icon,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.hudNeon() : C.accentHi),
                    size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(title,
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudNeon() : C.text),
                      fontSize: isComic ? 18 : (isHud ? 13 : 18),
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: isComic ? 2 : (isHud ? 2.5 : 1),
                      shadows: isComic
                          ? [
                              Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0),
                            ]
                          : null,
                    )),
              ),
            ],
          ),
          const SizedBox(height: 18),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(
      AppPalette C, bool isComic, bool isHud, Map user) {
    if (isComic) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3),
          boxShadow: _shadow(3),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: C.primaryHi,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 2.5),
              ),
              child: Icon(Icons.person,
                  color: C.contrastTextOn(C.primaryHi), size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user['username'],
                      style: const TextStyle(
                        color: Colors.black,
                        fontFamily: 'Bangers',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        letterSpacing: 1,
                      )),
                  const SizedBox(height: 2),
                  Text(
                      "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                      style: TextStyle(
                        color: Colors.black.withOpacity(0.6),
                        fontFamily: 'ComicNeue',
                        fontWeight: FontWeight.w700,
                        fontSize: 11,
                      )),
                ],
              ),
            ),
          ],
        ),
      );
    }

    if (isHud) {
      return Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: C.bgDeep.withOpacity(0.6),
          border: Border.all(
              color: C.accent.withOpacity(0.35), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: C.accent.withOpacity(0.15),
                border: Border.all(
                    color: C.accent.withOpacity(0.6), width: 1),
              ),
              child: Icon(Icons.person, color: C.accent, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user['username'],
                      style: TextStyle(
                          color: C.hudText(),
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                          letterSpacing: 1)),
                  const SizedBox(height: 4),
                  Text(
                      "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                      style: TextStyle(
                          color: C.hudTextDim(),
                          fontSize: 10,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 0.5)),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.accentHi.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: C.accent.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: C.accentHi),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'],
                    style: TextStyle(
                        color: C.text,
                        fontWeight: FontWeight.bold,
                        fontSize: 16)),
                const SizedBox(height: 4),
                Text(
                    "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                    style: TextStyle(color: C.textSub, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination(AppPalette C, bool isComic, bool isHud) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isActive = currentPage == page;

        if (isHud) {
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: isActive
                    ? C.accent.withOpacity(0.25)
                    : C.accent.withOpacity(0.05),
                border: Border.all(
                  color:
                      isActive ? C.accent : C.accent.withOpacity(0.3),
                  width: 1,
                ),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                            color: C.accent.withOpacity(0.5),
                            blurRadius: 8),
                      ]
                    : null,
              ),
              child: Text('$page',
                  style: TextStyle(
                    color: isActive ? C.hudNeon() : C.hudTextDim(),
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    fontSize: 11,
                    letterSpacing: 1,
                  )),
            ),
          );
        }

        if (isComic) {
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: isActive ? C.primaryHi : C.bg,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
                boxShadow: _shadow(2),
              ),
              child: Text('$page',
                  style: TextStyle(
                    color: isActive
                        ? C.contrastTextOn(C.primaryHi)
                        : C.comicText,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Bangers',
                    fontSize: 14,
                  )),
            ),
          );
        }

        return ElevatedButton(
          onPressed: () => setState(() => currentPage = page),
          style: ElevatedButton.styleFrom(
            backgroundColor:
                isActive ? C.accentHi : Colors.transparent,
            foregroundColor:
                isActive ? C.bgDeep : C.text.withOpacity(0.5),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: C.accentHi.withOpacity(0.15)),
            ),
          ),
          child: Text("$page",
              style:
                  const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        );
      }),
    );
  }

  Widget _buildActionButton({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required String label,
    required VoidCallback onTap,
  }) {
    if (isHud) {
      return GestureDetector(
        onTap: isLoading ? null : onTap,
        child: Container(
          height: 50,
          decoration: BoxDecoration(
            color: C.accent.withOpacity(isLoading ? 0.05 : 0.15),
            border: Border.all(
                color: C.accent.withOpacity(isLoading ? 0.4 : 1),
                width: 1.4),
            boxShadow: isLoading
                ? []
                : [
                    BoxShadow(
                        color: C.accent.withOpacity(0.35),
                        blurRadius: 10),
                  ],
          ),
          child: Center(
            child: isLoading
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: C.hudNeon()),
                  )
                : Text(label,
                    style: TextStyle(
                      color: C.hudNeon(),
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                      letterSpacing: 2,
                    )),
          ),
        ),
      );
    }

    if (isComic) {
      return GestureDetector(
        onTap: isLoading ? null : onTap,
        child: Container(
          height: 50,
          decoration: BoxDecoration(
            color: C.primaryHi,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.black, width: 3.5),
            boxShadow: _shadow(4),
          ),
          child: Center(
            child: isLoading
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: C.contrastTextOn(C.primaryHi)),
                  )
                : Text(label,
                    style: TextStyle(
                      color: C.contrastTextOn(C.primaryHi),
                      fontFamily: 'Bangers',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      letterSpacing: 1.5,
                    )),
          ),
        ),
      );
    }

    return Container(
      height: 50,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [C.accent, C.accentHi]),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
              color: C.accentHi.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4)),
        ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        child: isLoading
            ? SizedBox(
                width: 20,
                height: 20,
                child:
                    CircularProgressIndicator(strokeWidth: 2, color: C.bgDeep))
            : Text(label,
                style: TextStyle(
                    color: C.bgDeep, fontWeight: FontWeight.bold)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withOpacity(0.12)),
                            ),
                          )
                        : (isHud
                            ? Container(
                                color: C.hudBg(),
                                child: CustomPaint(
                                  painter: _HudGridPainter(
                                      color: C.hudGridLine()),
                                ),
                              )
                            : Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      C.bgDeep,
                                      C.accent.withOpacity(0.12),
                                      C.bgDeep
                                    ],
                                  ),
                                ),
                              )),
                  ),
                  SafeArea(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Header Icon
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: isHud
                                ? BoxDecoration(
                                    color: C.accent.withOpacity(0.15),
                                    border: Border.all(
                                        color: C.accent, width: 1.5),
                                    boxShadow: [
                                      BoxShadow(
                                          color: C.accent.withOpacity(0.4),
                                          blurRadius: 15),
                                    ],
                                  )
                                : BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: isComic ? C.primaryHi : null,
                                    border: isComic
                                        ? Border.all(
                                            color: Colors.black, width: 4)
                                        : null,
                                    boxShadow: isComic ? _shadow(5) : null,
                                  ),
                            child: _DynamicIcon(FontAwesomeIcons.store,
                                color: isComic
                                    ? C.contrastTextOn(C.primaryHi)
                                    : (isHud ? C.hudNeon() : C.accentHi),
                                size: 40),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "SELLER DASHBOARD",
                            style: TextStyle(
                              color: isComic
                                  ? C.comicText
                                  : (isHud ? C.hudNeon() : C.text),
                              fontSize:
                                  isComic ? 28 : (isHud ? 22 : 24),
                              fontWeight: FontWeight.bold,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: isComic ? 3 : 2.5,
                              shadows: isComic
                                  ? [
                                      Shadow(
                                          color: C.comicTextOutline
                                              .withOpacity(0.7),
                                          offset: const Offset(2, 2),
                                          blurRadius: 0),
                                    ]
                                  : (isHud
                                      ? [
                                          Shadow(
                                              color: C.accent
                                                  .withOpacity(0.6),
                                              blurRadius: 12),
                                        ]
                                      : [
                                          Shadow(
                                              color: C.accentHi
                                                  .withOpacity(0.8),
                                              blurRadius: 10),
                                        ]),
                            ),
                          ),
                          const SizedBox(height: 30),

                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            isHud: isHud,
                            title: "CREATE FULL UP",
                            icon: FontAwesomeIcons.userPlus,
                            children: [
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  isHud: isHud,
                                  label: "Username Baru",
                                  controller: createUsernameController,
                                  icon: FontAwesomeIcons.user),
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  isHud: isHud,
                                  label: "Password",
                                  controller: createPasswordController,
                                  icon: FontAwesomeIcons.lock),
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  isHud: isHud,
                                  label: "Durasi (Hari)",
                                  controller: createDayController,
                                  icon: FontAwesomeIcons.calendarDay,
                                  type: TextInputType.number,
                                  hint: "Maksimal 30 hari"),
                              const SizedBox(height: 6),
                              _buildActionButton(
                                C: C,
                                isComic: isComic,
                                isHud: isHud,
                                label: "CREATE ACCOUNT",
                                onTap: _createAccount,
                              ),
                            ],
                          ),

                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            isHud: isHud,
                            title: "EXTEND DURATION",
                            icon: FontAwesomeIcons.clock,
                            children: [
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  isHud: isHud,
                                  label: "Username Target",
                                  controller: editUsernameController,
                                  icon: FontAwesomeIcons.userEdit,
                                  hint: "Username member"),
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  isHud: isHud,
                                  label: "Tambah Hari",
                                  controller: editDayController,
                                  icon: FontAwesomeIcons.calendarPlus,
                                  type: TextInputType.number,
                                  hint: "Maksimal 30 hari"),
                              const SizedBox(height: 6),
                              _buildActionButton(
                                C: C,
                                isComic: isComic,
                                isHud: isHud,
                                label: "ADD DAYS",
                                onTap: _editUser,
                              ),
                            ],
                          ),

                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            isHud: isHud,
                            title: "FULL UP LIST",
                            icon: FontAwesomeIcons.users,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 4),
                                decoration: isHud
                                    ? BoxDecoration(
                                        color: C.bgDeep.withOpacity(0.6),
                                        border: Border.all(
                                            color: C.accent
                                                .withOpacity(0.5),
                                            width: 1.2),
                                      )
                                    : BoxDecoration(
                                        color: isComic
                                            ? Colors.white
                                            : C.bgDeep,
                                        borderRadius:
                                            BorderRadius.circular(12),
                                        border: Border.all(
                                            color: isComic
                                                ? Colors.black
                                                : C.bg,
                                            width: isComic ? 3 : 1),
                                      ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    value: selectedRole,
                                    dropdownColor: isHud
                                        ? C.hudPanel()
                                        : (isComic
                                            ? Colors.white
                                            : C.bgDark),
                                    style: TextStyle(
                                        color: isHud
                                            ? C.hudText()
                                            : (isComic
                                                ? Colors.black
                                                : C.text),
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : (isHud
                                                ? 'Orbitron'
                                                : 'ShareTechMono'),
                                        letterSpacing: isHud ? 1 : 0),
                                    items: roleOptions
                                        .map((role) => DropdownMenuItem(
                                            value: role,
                                            child:
                                                Text(role.toUpperCase())))
                                        .toList(),
                                    onChanged: (val) {
                                      if (val != null) {
                                        selectedRole = val;
                                        _filterAndPaginate();
                                      }
                                    },
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              isLoading
                                  ? Center(
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.all(20),
                                        child: CircularProgressIndicator(
                                            color: isComic
                                                ? Colors.black
                                                : (isHud
                                                    ? C.hudNeon()
                                                    : C.accentHi)),
                                      ),
                                    )
                                  : Column(
                                      children: [
                                        ..._getCurrentPageData().map((u) =>
                                            _buildUserItem(
                                                C, isComic, isHud, u)),
                                        const SizedBox(height: 16),
                                        _buildPagination(
                                            C, isComic, isHud),
                                      ],
                                    ),
                            ],
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC DIALOG BUTTON
// ═══════════════════════════════════════════════════════════
class _ComicDialogButton extends StatelessWidget {
  final AppPalette C;
  final String label;
  final VoidCallback onTap;
  const _ComicDialogButton(
      {required this.C, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final bg = C.primaryHi;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
          ],
        ),
        child: Center(
          child: Text(label,
              style: TextStyle(
                color: C.contrastTextOn(bg),
                fontFamily: 'Bangers',
                fontSize: 16,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              )),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// DYNAMIC ICON
// ═══════════════════════════════════════════════════════════
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  const _DynamicIcon(this.icon, {this.size, this.color});

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox.shrink();
    if (icon is IconData && icon.fontPackage == 'font_awesome_flutter') {
      return FaIcon(icon, size: size, color: color);
    } else if (icon is IconData) {
      return Icon(icon, size: size, color: color);
    }
    return const SizedBox.shrink();
  }
}