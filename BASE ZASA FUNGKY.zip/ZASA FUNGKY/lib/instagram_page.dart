// lib/instagram_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:ui';
import 'api_config.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class InstagramDownloaderPage extends StatefulWidget {
  const InstagramDownloaderPage({super.key});

  @override
  State<InstagramDownloaderPage> createState() => _InstagramDownloaderPageState();
}

class _InstagramDownloaderPageState extends State<InstagramDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  bool _isSharing = false;
  int _sharingIndex = -1;
  String? _errorMessage;
  Map<String, dynamic>? _mediaData;
  List<Map<String, dynamic>> _medias = [];

  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  final Color bloodRed = const Color(0xFFE53935);
  final Color darkRed = const Color(0xFFB71C1C);
  final Color lightRed = const Color(0xFFFF5252);
  final Color deepBlack = const Color(0xFF0A0A0A);
  final Color cardDark = const Color(0xFF1A1A1A);

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _downloadInstagram() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _errorMessage = "URL Instagram tidak boleh kosong.";
        _mediaData = null;
        _medias = [];
      });
      return;
    }

    if (!url.contains('instagram.com') && !url.contains('instagr.am')) {
      setState(() {
        _errorMessage = "Link harus dari Instagram (instagram.com / instagr.am)";
        _mediaData = null;
        _medias = [];
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _mediaData = null;
      _medias = [];
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });

    try {
      final apiUrl = '$baseUrl/instagram/download?url=${Uri.encodeComponent(url)}';
      print('[IG] Fetch: $apiUrl');

      final res = await http.get(
        Uri.parse(apiUrl),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 45));

      if (res.statusCode != 200) {
        setState(() {
          _errorMessage = 'Server error (${res.statusCode}). Coba lagi nanti.';
        });
        return;
      }

      final json = jsonDecode(res.body) as Map<String, dynamic>;

      if (json['valid'] != true) {
        setState(() {
          _errorMessage = json['message'] ?? 'Gagal ambil data Instagram';
        });
        return;
      }

      final medias = List<Map<String, dynamic>>.from(json['medias'] ?? []);

      if (medias.isEmpty) {
        setState(() {
          _errorMessage = 'Media Instagram kosong / tidak valid';
        });
        return;
      }

      setState(() {
        _mediaData = {
          'source': json['source'] ?? 'unknown',
          'title': json['title'] ?? 'Instagram Post',
          'author': json['author'] ?? 'Unknown',
          'thumbnail': json['thumbnail'] ?? '',
          'total': json['total'] ?? medias.length,
        };
        _medias = medias;
      });

      final firstVideo = medias.firstWhere(
        (m) => m['type'] == 'video',
        orElse: () => {},
      );
      if (firstVideo.isNotEmpty && (firstVideo['url'] as String).isNotEmpty) {
        _initializeVideoPlayer(videoUrl: firstVideo['url']);
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Terjadi kesalahan: $e';
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _initializeVideoPlayer({required String videoUrl}) {
    _videoController = VideoPlayerController.networkUrl(
      Uri.parse(videoUrl),
      httpHeaders: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
        'Accept': '*/*',
      },
    );

    Future.delayed(const Duration(seconds: 20), () {
      if (!mounted) return;
      if (_videoController?.value.isInitialized != true) {
        setState(() {
          _errorMessage = 'Video loading timeout. Koneksi lambat / URL ga valid.';
        });
        _videoController?.dispose();
      }
    });

    _videoController!.initialize().then((_) {
      if (!mounted) return;
      setState(() {
        _chewieController = ChewieController(
          videoPlayerController: _videoController!,
          autoPlay: true,
          looping: false,
          showControls: true,
          materialProgressColors: ChewieProgressColors(
            playedColor: bloodRed,
            handleColor: lightRed,
            backgroundColor: Colors.grey[300]!,
            bufferedColor: Colors.grey[400]!,
          ),
        );
      });
    }).catchError((e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Gagal load video player: $e';
        });
      }
    });
  }

  Future<void> _shareMedia(int index) async {
    if (index < 0 || index >= _medias.length) return;

    setState(() {
      _isSharing = true;
      _sharingIndex = index;
    });

    try {
      final media = _medias[index];
      final mediaUrl = media['url'] as String?;
      final type = media['type'] as String? ?? 'video';

      if (mediaUrl == null || mediaUrl.isEmpty) {
        _showSnack('URL media tidak tersedia', isError: true);
        return;
      }

      final res = await http.get(
        Uri.parse(mediaUrl),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
          'Accept': '*/*',
        },
      ).timeout(const Duration(seconds: 60));

      if (res.statusCode != 200) {
        _showSnack('Gagal download media: ${res.statusCode}', isError: true);
        return;
      }

      final tempDir = await getTemporaryDirectory();
      final ext = type == 'video' ? 'mp4' : 'jpg';
      final fileName = 'instagram_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsBytes(res.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Media Instagram dari: ${_mediaData?['author'] ?? 'Unknown'}',
      );
    } catch (e) {
      _showSnack('Error sharing: $e', isError: true);
    } finally {
      if (mounted) {
        setState(() {
          _isSharing = false;
          _sharingIndex = -1;
        });
      }
    }
  }

  void _pasteFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data != null && data.text != null && data.text!.isNotEmpty) {
      setState(() {
        _urlController.text = data.text!.trim();
      });
      HapticFeedback.lightImpact();
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final C = AppTheme.current.value;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            fontWeight: FontWeight.w700,
            color: isHud ? C.hudText() : Colors.white,
          ),
        ),
        backgroundColor: isError
            ? (isHud ? C.hudPanel() : darkRed)
            : (isHud ? C.hudPanel() : Colors.green[700]),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isHud ? 4 : 16),
          side: BorderSide(
              color: isHud
                  ? C.hudBorder()
                  : bloodRed.withValues(alpha: 0.3)),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // BUILD HELPERS
  // ═══════════════════════════════════════════════════════
  Widget _buildGlassCard({
    required Widget child,
    EdgeInsetsGeometry? padding,
    AppPalette? C,
    bool? isHud,
  }) {
    final palette = C ?? AppTheme.current.value;
    final hud = isHud ?? (AppTheme.currentStyle.value == ThemeStyle.hudTactical);

    if (hud) {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: padding ?? const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: palette.hudPanel(),
          border: Border.all(color: palette.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: palette.accent.withValues(alpha: 0.15),
              blurRadius: 12,
            ),
          ],
        ),
        child: child,
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: padding ?? const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [cardDark, cardDark.withValues(alpha: 0.8)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: bloodRed.withValues(alpha: 0.3), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: bloodRed.withValues(alpha: 0.15),
            blurRadius: 25,
            spreadRadius: 2,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _buildGlassInputField(AppPalette C, bool isHud) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isHud ? 2 : 16),
        gradient: isHud
            ? null
            : LinearGradient(
                colors: [cardDark, cardDark.withValues(alpha: 0.8)],
              ),
        color: isHud ? C.bgDeep.withValues(alpha: 0.7) : null,
        border: isHud
            ? Border.all(color: C.accent.withValues(alpha: 0.4), width: 1)
            : null,
      ),
      child: TextField(
        controller: _urlController,
        style: TextStyle(
          color: isHud ? C.hudText() : Colors.white,
          fontSize: 16,
        ),
        cursorColor: isHud ? C.accent : bloodRed,
        decoration: InputDecoration(
          labelText: 'Masukkan URL Instagram',
          labelStyle: TextStyle(
              color: isHud ? C.hudTextDim() : Colors.white70),
          hintText: 'Contoh: https://www.instagram.com/reel/xxx/',
          hintStyle: TextStyle(
              color: isHud
                  ? C.hudTextDim()
                  : Colors.white54),
          prefixIcon:
              Icon(Icons.link, color: isHud ? C.accent : bloodRed),
          suffixIcon: GestureDetector(
            onTap: _pasteFromClipboard,
            child: Container(
              margin: const EdgeInsets.all(8),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withValues(alpha: 0.15),
                      border:
                          Border.all(color: C.accent, width: 1),
                    )
                  : BoxDecoration(
                      color: bloodRed.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: bloodRed.withValues(alpha: 0.3)),
                    ),
              child: Center(
                widthFactor: 1,
                child: Text(
                  'PASTE',
                  style: TextStyle(
                    color: isHud ? C.hudNeon() : lightRed,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ),
          filled: isHud,
          fillColor: isHud ? C.bgDeep.withValues(alpha: 0.7) : null,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isHud ? 2 : 16),
            borderSide: BorderSide(
                color: isHud
                    ? C.accent.withValues(alpha: 0.4)
                    : bloodRed.withValues(alpha: 0.3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isHud ? 2 : 16),
            borderSide: BorderSide(
                color: isHud ? C.accent : bloodRed,
                width: isHud ? 1.4 : 2),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isHud ? 2 : 16),
            borderSide: BorderSide(
                color: isHud
                    ? C.accent.withValues(alpha: 0.4)
                    : bloodRed.withValues(alpha: 0.3)),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
    required Color color,
    bool isLoading = false,
    AppPalette? C,
    bool? isHud,
  }) {
    final palette = C ?? AppTheme.current.value;
    final hud = isHud ?? (AppTheme.currentStyle.value == ThemeStyle.hudTactical);

    if (hud) {
      return Container(
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.15),
          border: Border.all(color: color, width: 1.4),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.35),
              blurRadius: 12,
            ),
          ],
        ),
        child: ElevatedButton(
          onPressed: isLoading ? null : onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          child: isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: color,
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: color, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      text,
                      style: TextStyle(
                        color: palette.hudText(),
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          colors: [color.withValues(alpha: 0.8), color.withValues(alpha: 0.6)],
        ),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.3),
            blurRadius: 15,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: isLoading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    text,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor: isHud ? C.hudBg() : deepBlack,
              body: Stack(
                children: [
                  if (!isHud) ...[
                    Positioned(
                      top: -100,
                      right: -100,
                      child: Container(
                        width: 300,
                        height: 300,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              bloodRed.withValues(alpha: 0.1),
                              Colors.transparent
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: -150,
                      left: -100,
                      child: Container(
                        width: 400,
                        height: 400,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              darkRed.withValues(alpha: 0.08),
                              Colors.transparent
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                  if (isHud)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(
                          painter: _HudGridPainter(
                              color: C.hudGridLine()),
                        ),
                      ),
                    ),
                  BackdropFilter(
                    filter: ImageFilter.blur(
                        sigmaX: isHud ? 0 : 20,
                        sigmaY: isHud ? 0 : 20),
                    child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            // ── HEADER ──
                            _buildGlassCard(
                              C: C,
                              isHud: isHud,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.camera_alt,
                                      color:
                                          isHud ? C.hudNeon() : bloodRed,
                                      size: 32),
                                  const SizedBox(width: 12),
                                  Text(
                                    "INSTAGRAM DL",
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.2,
                                      color: isHud
                                          ? C.hudNeon()
                                          : Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 24),

                            // ── INPUT + BUTTON ──
                            _buildGlassCard(
                              C: C,
                              isHud: isHud,
                              child: Column(
                                children: [
                                  _buildGlassInputField(C, isHud),
                                  const SizedBox(height: 16),
                                  _buildActionButton(
                                    text: "DOWNLOAD",
                                    icon: Icons.download,
                                    onPressed: _downloadInstagram,
                                    color: isHud ? C.accent : bloodRed,
                                    isLoading: _isLoading,
                                    C: C,
                                    isHud: isHud,
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 20),

                            // ── ERROR ──
                            if (_errorMessage != null)
                              _buildGlassCard(
                                C: C,
                                isHud: isHud,
                                child: Row(
                                  children: [
                                    Icon(Icons.error_outline,
                                        color: isHud
                                            ? C.accent
                                            : lightRed),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Text(
                                        _errorMessage!,
                                        style: TextStyle(
                                          color: isHud
                                              ? C.hudText()
                                              : Colors.white70,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                            const SizedBox(height: 20),

                            // ── RESULT ──
                            if (_mediaData != null)
                              Expanded(
                                child: SingleChildScrollView(
                                  child: Column(
                                    children: [
                                      _buildGlassCard(
                                        C: C,
                                        isHud: isHud,
                                        padding:
                                            const EdgeInsets.all(16),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                Icon(Icons.person,
                                                    color: isHud
                                                        ? C.hudNeon()
                                                        : bloodRed,
                                                    size: 16),
                                                const SizedBox(width: 8),
                                                Expanded(
                                                  child: Text(
                                                    _mediaData!['author'] ??
                                                        'Unknown',
                                                    style: TextStyle(
                                                      color: isHud
                                                          ? C.hudText()
                                                          : Colors.white,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                      horizontal: 8,
                                                      vertical: 2),
                                                  decoration: isHud
                                                      ? BoxDecoration(
                                                          color: C.accent
                                                              .withValues(
                                                                  alpha: 0.15),
                                                          border: Border.all(
                                                              color: C.accent,
                                                              width: 1),
                                                        )
                                                      : BoxDecoration(
                                                          color: bloodRed
                                                              .withValues(
                                                                  alpha: 0.15),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(6),
                                                          border: Border.all(
                                                              color: bloodRed
                                                                  .withValues(
                                                                      alpha:
                                                                          0.4)),
                                                        ),
                                                  child: Text(
                                                    (_mediaData!['source'] ??
                                                            'N/A')
                                                        .toString()
                                                        .toUpperCase(),
                                                    style: TextStyle(
                                                      color: isHud
                                                          ? C.hudNeon()
                                                          : lightRed,
                                                      fontSize: 9,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      letterSpacing: 1,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 6),
                                            Text(
                                              _mediaData!['title'] ?? '',
                                              style: TextStyle(
                                                color: isHud
                                                    ? C.hudText()
                                                    : Colors.white
                                                        .withValues(
                                                            alpha: 0.75),
                                                fontSize: 12,
                                                height: 1.4,
                                              ),
                                              maxLines: 2,
                                              overflow:
                                                  TextOverflow.ellipsis,
                                            ),
                                            const SizedBox(height: 8),
                                            Row(
                                              children: [
                                                Icon(Icons.collections,
                                                    color: isHud
                                                        ? C.hudTextDim()
                                                        : Colors.white54,
                                                    size: 14),
                                                const SizedBox(width: 6),
                                                Text(
                                                  '${_mediaData!['total']} media ditemukan',
                                                  style: TextStyle(
                                                    color: isHud
                                                        ? C.hudTextDim()
                                                        : Colors.white54,
                                                    fontSize: 11,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),

                                      const SizedBox(height: 12),

                                      if (_chewieController != null)
                                        _buildGlassCard(
                                          C: C,
                                          isHud: isHud,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      isHud ? 2 : 16),
                                              border: Border.all(
                                                  color: isHud
                                                      ? C.accent
                                                      : bloodRed
                                                          .withValues(
                                                              alpha: 0.3)),
                                            ),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      isHud ? 2 : 16),
                                              child: AspectRatio(
                                                aspectRatio: _videoController!
                                                            .value
                                                            .isInitialized ==
                                                        true
                                                    ? _videoController!
                                                        .value.aspectRatio
                                                    : 9 / 16,
                                                child: Chewie(
                                                    controller:
                                                        _chewieController!),
                                              ),
                                            ),
                                          ),
                                        )
                                      else if (_medias
                                          .any((m) => m['type'] == 'video'))
                                        _buildGlassCard(
                                          C: C,
                                          isHud: isHud,
                                          child: Container(
                                            height: 200,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      isHud ? 2 : 16),
                                              color: isHud
                                                  ? C.hudPanel()
                                                  : cardDark,
                                            ),
                                            child: Center(
                                              child:
                                                  CircularProgressIndicator(
                                                      color: isHud
                                                          ? C.accent
                                                          : Colors.white),
                                            ),
                                          ),
                                        ),

                                      const SizedBox(height: 12),

                                      ...List.generate(_medias.length, (i) {
                                        final media = _medias[i];
                                        final isVideo =
                                            media['type'] == 'video';
                                        final isSharingThis =
                                            _isSharing && _sharingIndex == i;

                                        return _buildGlassCard(
                                          C: C,
                                          isHud: isHud,
                                          padding:
                                              const EdgeInsets.all(12),
                                          child: Row(
                                            children: [
                                              Container(
                                                width: 60,
                                                height: 60,
                                                decoration: isHud
                                                    ? BoxDecoration(
                                                        color: C.bgDeep
                                                            .withValues(
                                                                alpha: 0.7),
                                                        border: Border.all(
                                                            color: C.accent,
                                                            width: 1),
                                                        image: (media[
                                                                        'thumbnail'] ??
                                                                    '')
                                                                .toString()
                                                                .isNotEmpty
                                                            ? DecorationImage(
                                                                image: NetworkImage(
                                                                    media[
                                                                        'thumbnail']),
                                                                fit: BoxFit
                                                                    .cover,
                                                              )
                                                            : null,
                                                      )
                                                    : BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        border: Border.all(
                                                          color: bloodRed
                                                              .withValues(
                                                                  alpha: 0.4),
                                                          width: 1.5,
                                                        ),
                                                        image: (media[
                                                                        'thumbnail'] ??
                                                                    '')
                                                                .toString()
                                                                .isNotEmpty
                                                            ? DecorationImage(
                                                                image: NetworkImage(
                                                                    media[
                                                                        'thumbnail']),
                                                                fit: BoxFit
                                                                    .cover,
                                                              )
                                                            : null,
                                                        color: cardDark,
                                                      ),
                                                child: (media['thumbnail'] ??
                                                                '')
                                                            .toString()
                                                            .isEmpty
                                                    ? Icon(
                                                        isVideo
                                                            ? Icons.videocam
                                                            : Icons.image,
                                                        color: isHud
                                                            ? C.accent
                                                            : bloodRed,
                                                        size: 24,
                                                      )
                                                    : null,
                                              ),
                                              const SizedBox(width: 12),
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .start,
                                                  children: [
                                                    Text(
                                                      isVideo
                                                          ? 'VIDEO ${i + 1}'
                                                          : 'FOTO ${i + 1}',
                                                      style: TextStyle(
                                                        color: isHud
                                                            ? C.hudText()
                                                            : Colors.white,
                                                        fontWeight:
                                                            FontWeight.w900,
                                                        fontSize: 13,
                                                        letterSpacing: 1,
                                                      ),
                                                    ),
                                                    const SizedBox(height: 4),
                                                    Text(
                                                      isVideo
                                                          ? 'Video MP4'
                                                          : 'Gambar JPG',
                                                      style: TextStyle(
                                                        color: isHud
                                                            ? C.hudTextDim()
                                                            : Colors.white54,
                                                        fontSize: 11,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              GestureDetector(
                                                onTap: isSharingThis
                                                    ? null
                                                    : () => _shareMedia(i),
                                                child: Container(
                                                  width: 44,
                                                  height: 44,
                                                  decoration: isHud
                                                      ? BoxDecoration(
                                                          color: isSharingThis
                                                              ? C.hudTextDim()
                                                                  .withValues(
                                                                      alpha:
                                                                          0.2)
                                                              : C.accent
                                                                  .withValues(
                                                                      alpha:
                                                                          0.15),
                                                          border: Border.all(
                                                              color:
                                                                  isSharingThis
                                                                      ? C.hudTextDim()
                                                                      : C
                                                                          .accent,
                                                              width: 1.2),
                                                          boxShadow:
                                                              isSharingThis
                                                                  ? null
                                                                  : [
                                                                      BoxShadow(
                                                                        color: C.accent
                                                                            .withValues(
                                                                                alpha: 0.35),
                                                                        blurRadius:
                                                                            8,
                                                                      ),
                                                                    ],
                                                        )
                                                      : BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          gradient:
                                                              LinearGradient(
                                                            colors: isSharingThis
                                                                ? [
                                                                    Colors
                                                                        .grey,
                                                                    Colors.grey[
                                                                        700]!
                                                                  ]
                                                                : [
                                                                    bloodRed,
                                                                    darkRed
                                                                  ],
                                                          ),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: isSharingThis
                                                                  ? Colors
                                                                      .transparent
                                                                  : bloodRed
                                                                      .withValues(
                                                                          alpha:
                                                                              0.4),
                                                              blurRadius: 10,
                                                              spreadRadius: 1,
                                                            ),
                                                          ],
                                                        ),
                                                  child: isSharingThis
                                                      ? Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(12),
                                                          child:
                                                              CircularProgressIndicator(
                                                            strokeWidth: 2,
                                                            color: isHud
                                                                ? C.accent
                                                                : Colors
                                                                    .white,
                                                          ),
                                                        )
                                                      : Icon(
                                                          Icons.download,
                                                          color: isHud
                                                              ? C.accent
                                                              : Colors.white,
                                                          size: 20,
                                                        ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      }),

                                      const SizedBox(height: 16),

                                      _buildGlassCard(
                                        C: C,
                                        isHud: isHud,
                                        padding:
                                            const EdgeInsets.all(16),
                                        child: Row(
                                          children: [
                                            Icon(Icons.info,
                                                color: isHud
                                                    ? C.hudNeon()
                                                    : bloodRed,
                                                size: 20),
                                            const SizedBox(width: 12),
                                            Expanded(
                                              child: Text(
                                                "Tiap media bisa di-share / save terpisah. Tap tombol download di tiap item.",
                                                style: TextStyle(
                                                  color: isHud
                                                      ? C.hudText()
                                                      : Colors.white70,
                                                  fontSize: 11,
                                                  height: 1.5,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}