// lib/call_crylix_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:video_player/video_player.dart';
import 'package:web_socket_channel/io.dart';

import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          color: color,
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.9),
              blurRadius: size * 1.8,
              spreadRadius: size * 0.3,
            ),
          ],
        ),
      );
    }

    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withValues(alpha: 0.85 * opacity),
              color.withValues(alpha: opacity),
              color.withValues(alpha: 0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(color: Colors.black.withValues(alpha: 0.85), width: size * 0.1),
          boxShadow: [
            BoxShadow(color: color.withValues(alpha: 0.75 * opacity), blurRadius: size * 1.4, spreadRadius: size * 0.2),
            BoxShadow(color: color.withValues(alpha: 0.35 * opacity), blurRadius: size * 2.6, spreadRadius: size * 0.4),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});
  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return SizedBox(
        width: size, height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withValues(alpha: 0.7)),
        ),
      );
    }

    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7, height: size * 0.11,
            color: Colors.black.withValues(alpha: 0.9),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withValues(alpha: 0.6), width: 1),
        ),
      );
    }

    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: C.accent.withValues(alpha: 0.15),
              blurRadius: 12,
            ),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _Screw(C: C, size: 12)),
            Positioned(top: 0, right: 0, child: _Screw(C: C, size: 12)),
            Positioned(bottom: 0, left: 0, child: _Screw(C: C, size: 12)),
            Positioned(bottom: 0, right: 0, child: _Screw(C: C, size: 12)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.75), offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withValues(alpha: 0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// INSET PANEL
// ═══════════════════════════════════════════════════════════
class _InsetPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  const _InsetPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 12),
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDeep.withValues(alpha: 0.7),
          border: Border.all(color: C.accent.withValues(alpha: 0.4), width: 1),
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.bgDeep, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.95),
            offset: const Offset(0, 2),
            blurRadius: 4,
          ),
          const BoxShadow(
            color: Colors.white10,
            offset: Offset(0, -1),
            blurRadius: 1,
          ),
        ],
        border: Border.all(color: C.bgDark, width: 1.5),
      ),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ═══════════════════════════════════════════════════════════
class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final enabled = widget.onTap != null;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);

    final textColor = isComic
        ? C.contrastTextOn(widget.color)
        : (isHud ? C.hudText() : Colors.white);
    final textOutline = textColor == Colors.white ? Colors.black : Colors.white;

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            }
          : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: isHud
            ? BoxDecoration(
                color: enabled
                    ? (_pressed
                        ? widget.color.withValues(alpha: 0.25)
                        : widget.color.withValues(alpha: 0.15))
                    : C.bgDeep.withValues(alpha: 0.5),
                border: Border.all(
                  color: enabled
                      ? widget.color
                      : C.hudTextDim().withValues(alpha: 0.4),
                  width: 1.4,
                ),
                boxShadow: enabled && !_pressed
                    ? [
                        BoxShadow(
                          color: widget.color.withValues(alpha: 0.35),
                          blurRadius: 10,
                        ),
                      ]
                    : null,
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 14 : 12),
                gradient: isComic
                    ? null
                    : LinearGradient(
                        begin: _pressed ? Alignment.bottomCenter : Alignment.topCenter,
                        end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
                        colors: _pressed
                            ? [dark, dark, widget.color]
                            : [light, widget.color, dark],
                        stops: const [0.0, 0.5, 1.0],
                      ),
                color: isComic ? widget.color : null,
                boxShadow: isComic
                    ? (_pressed ? [] : const [
                        BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
                      ])
                    : (_pressed
                        ? [BoxShadow(color: Colors.black.withValues(alpha: 0.9), offset: const Offset(0, 1), blurRadius: 3)]
                        : [
                            BoxShadow(color: widget.color.withValues(alpha: 0.45), offset: const Offset(0, 5), blurRadius: 10, spreadRadius: -2),
                            BoxShadow(color: Colors.black.withValues(alpha: 0.75), offset: const Offset(0, 4), blurRadius: 6),
                          ]),
                border: Border.all(
                  color: isComic ? Colors.black : dark.withValues(alpha: 0.9),
                  width: isComic ? 3.5 : 1.5,
                ),
              ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic && !isHud)
              Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 6)),
            if (!isComic && !isHud)
              Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 6)),
            if (!isComic && !isHud)
              Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 6)),
            if (!isComic && !isHud)
              Positioned(bottom: 5, right: 5, child: _Rivet(C: C, size: 6)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Opacity(
                opacity: enabled ? 1 : 0.5,
                child: DefaultTextStyle(
                  style: TextStyle(
                    color: textColor,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    shadows: isComic
                        ? [Shadow(color: textOutline, offset: const Offset(2, 2), blurRadius: 0)]
                        : null,
                  ),
                  child: IconTheme(
                    data: IconThemeData(color: textColor),
                    child: widget.child,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(c.alpha,
      (c.red + 40).clamp(0, 255),
      (c.green + 40).clamp(0, 255),
      (c.blue + 30).clamp(0, 255));
  static Color _darken(Color c) => Color.fromARGB(c.alpha,
      (c.red - 60).clamp(0, 255),
      (c.green - 50).clamp(0, 255),
      (c.blue - 40).clamp(0, 255));
}

// ═══════════════════════════════════════════════════════════
// ICON BUTTON
// ═══════════════════════════════════════════════════════════
class _IconButton extends StatefulWidget {
  final AppPalette C;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final double size;
  const _IconButton({
    required this.C,
    required this.icon,
    required this.onTap,
    required this.color,
    this.size = 40,
  });

  @override
  State<_IconButton> createState() => _IconButtonState();
}

class _IconButtonState extends State<_IconButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isHud) {
      return GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) {
          setState(() => _pressed = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            color: _pressed
                ? C.accent.withValues(alpha: 0.25)
                : C.accent.withValues(alpha: 0.1),
            border: Border.all(color: C.accent, width: 1.2),
            boxShadow: _pressed
                ? []
                : [
                    BoxShadow(
                      color: C.accent.withValues(alpha: 0.35),
                      blurRadius: 8,
                    ),
                  ],
          ),
          child: Icon(widget.icon,
              color: C.accent, size: widget.size * 0.5),
        ),
      );
    }

    if (isComic) {
      return GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) {
          setState(() => _pressed = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          width: widget.size,
          height: widget.size,
          transform: Matrix4.translationValues(
              _pressed ? 3 : 0, _pressed ? 3 : 0, 0),
          decoration: BoxDecoration(
            color: C.bgDark,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.black, width: 3),
            boxShadow: _pressed
                ? []
                : const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(3, 3),
                      blurRadius: 0,
                    ),
                  ],
          ),
          child: Icon(widget.icon,
              color: widget.color, size: widget.size * 0.5),
        ),
      );
    }

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(
            begin: _pressed ? Alignment.bottomCenter : Alignment.topCenter,
            end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
            colors: _pressed
                ? [C.bgDark, C.bg]
                : [C.textSub, C.bg, C.bgDark],
          ),
          border: Border.all(
              color: Colors.black.withValues(alpha: 0.7), width: 1.2),
          boxShadow: _pressed
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.9),
                    offset: const Offset(0, 1),
                    blurRadius: 2,
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.7),
                    offset: const Offset(0, 3),
                    blurRadius: 5,
                  ),
                  const BoxShadow(
                    color: Colors.white24,
                    offset: Offset(0, -1),
                    blurRadius: 1,
                  ),
                ],
        ),
        child: Icon(widget.icon,
            color: widget.color, size: widget.size * 0.5),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════
class CallCrylixPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String baseUrl;
  const CallCrylixPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.baseUrl,
  });
  @override
  State<CallCrylixPage> createState() => _CallCrylixPageState();
}

class _CallCrylixPageState extends State<CallCrylixPage> {
  int _tab = 0;
  final _search = TextEditingController();
  final _contactSearch = TextEditingController();
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _groups = [];
  bool _loading = true;
  IOWebSocketChannel? _socket;
  StreamSubscription? _sub;

  String get _wsUrl => widget.baseUrl.replaceFirst(
        RegExp(r'^https?://'),
        widget.baseUrl.startsWith('https://') ? 'wss://' : 'ws://',
      );

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _connect();
    _refresh();
  }

  void _connect() {
    try {
      _socket = IOWebSocketChannel.connect(Uri.parse(_wsUrl));
      _socket!.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
      _sub = _socket!.stream.listen((raw) {
        try {
          final d = jsonDecode(raw.toString());
          if (d['type'] == 'call_invite') {
            _incomingVoice('${d['from']}', '${d['callId']}');
          }
          if (d['type'] == 'video_call_invite') {
            _incomingVideo('${d['from']}', '${d['callId']}');
          }
          if (d['type'] == 'group_call_invite') _incomingGroup(d);
          if (d['type'] == 'group_created' && d['group'] is Map) {
            final group = Map<String, dynamic>.from(d['group']);
            if (mounted) {
              setState(() {
                _groups.removeWhere((g) => g['id'] == group['id']);
                _groups.insert(0, group);
              });
            }
          }
        } catch (_) {}
      });
    } catch (_) {}
  }

  Future<http.Response?> _getWithRetry(Uri uri) async {
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final response = await http.get(uri);
        if (response.statusCode != 429 || attempt == 2) return response;
        await Future<void>.delayed(Duration(milliseconds: 700 * (attempt + 1)));
      } catch (_) {
        if (attempt == 2) return null;
        await Future<void>.delayed(Duration(milliseconds: 500 * (attempt + 1)));
      }
    }
    return null;
  }

  Future<void> _refresh() async {
    if (mounted) setState(() => _loading = true);
    final key = Uri.encodeQueryComponent(widget.sessionKey);
    try {
      final u = await _getWithRetry(
          Uri.parse('${widget.baseUrl}/api/cal/users?key=$key'));
      if (u?.statusCode == 200) {
        final data = jsonDecode(u!.body);
        if (data['success'] == true) {
          _users = List<Map<String, dynamic>>.from(data['users'] ?? []);
        }
      }
      await Future<void>.delayed(const Duration(milliseconds: 250));
      final g = await _getWithRetry(
          Uri.parse('${widget.baseUrl}/api/cal/groups?key=$key'));
      if (g?.statusCode == 200) {
        final data = jsonDecode(g!.body);
        if (data['success'] == true) {
          _groups = List<Map<String, dynamic>>.from(data['groups'] ?? []);
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  void _incomingVoice(String from, String callId) => _incomingDialog(
        'Panggilan Suara',
        '$from sedang menelepon.',
        Icons.call_rounded,
        () => VoiceCallPage(
          username: widget.username,
          peer: from,
          callId: callId,
          sessionKey: widget.sessionKey,
          baseUrl: widget.baseUrl,
          incoming: true,
        ),
      );

  void _incomingVideo(String from, String callId) => _incomingDialog(
        'Panggilan Video',
        '$from mengajak video call.',
        Icons.videocam_rounded,
        () => VideoCallPage(
          username: widget.username,
          peer: from,
          callId: callId,
          sessionKey: widget.sessionKey,
          baseUrl: widget.baseUrl,
          incoming: true,
        ),
      );

  void _incomingGroup(Map<String, dynamic> d) => _incomingDialog(
        'Panggilan Grup',
        '${d['from']} memulai panggilan di ${d['groupName'] ?? 'grup'}.',
        Icons.groups_rounded,
        () => GroupCallPage(
          username: widget.username,
          groupId: '${d['groupId']}',
          groupName: '${d['groupName'] ?? 'Grup'}',
          members: List<String>.from(d['members'] ?? []),
          sessionKey: widget.sessionKey,
          baseUrl: widget.baseUrl,
        ),
      );

  void _incomingDialog(
      String title, String body, IconData icon, Widget Function() page) {
    if (!mounted) return;
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black.withValues(alpha: 0.85),
      transitionDuration: const Duration(milliseconds: 250),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: child,
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: isHud
                        ? BoxDecoration(
                            color: C.accent.withValues(alpha: 0.15),
                            border: Border.all(color: C.accent, width: 1.4),
                            boxShadow: [
                              BoxShadow(
                                color: C.accent.withValues(alpha: 0.4),
                                blurRadius: 14,
                              ),
                            ],
                          )
                        : BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: isComic
                                ? null
                                : RadialGradient(colors: [
                                    C.accent.withValues(alpha: 0.4),
                                    C.accent.withValues(alpha: 0.15),
                                    Colors.black
                                  ]),
                            color: isComic ? C.accent : null,
                            border: Border.all(
                                color: isComic ? Colors.black : C.accent,
                                width: isComic ? 4 : 2),
                            boxShadow: isComic
                                ? null
                                : [
                                    BoxShadow(
                                        color: C.accent.withValues(alpha: 0.5),
                                        blurRadius: 15,
                                        spreadRadius: 1)
                                  ],
                          ),
                    child: Icon(icon,
                        color: isComic
                            ? C.contrastTextOn(C.accent)
                            : (isHud ? C.accent : C.accent),
                        size: 28),
                  ),
                  Positioned(
                    top: 0,
                    right: 0,
                    child: _Led(color: C.primaryHi, size: 8, blink: true),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                title.toUpperCase(),
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                body,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicText.withValues(alpha: 0.85)
                      : (isHud
                          ? C.hudText()
                          : C.text.withValues(alpha: 0.75)),
                  fontSize: 11,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: _IndustrialButton(
                      C: C,
                      color: C.primaryHi,
                      height: 48,
                      onTap: () => Navigator.pop(ctx),
                      child: Text(
                        'TOLAK',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _IndustrialButton(
                      C: C,
                      color: C.accent,
                      height: 48,
                      onTap: () {
                        Navigator.pop(ctx);
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => page()));
                      },
                      child: Text(
                        'TERIMA',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openChat(String peer) => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CalChatPage(
            username: widget.username,
            peer: peer,
            sessionKey: widget.sessionKey,
            baseUrl: widget.baseUrl,
          ),
        ),
      );

  void _startVoice(String peer) {
    final id =
        'voice-${widget.username}-${DateTime.now().millisecondsSinceEpoch}';
    _socket?.sink
        .add(jsonEncode({'type': 'call_invite', 'to': peer, 'callId': id}));
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => VoiceCallPage(
          username: widget.username,
          peer: peer,
          callId: id,
          sessionKey: widget.sessionKey,
          baseUrl: widget.baseUrl,
          incoming: false,
        ),
      ),
    );
  }

  void _startVideo(String peer) {
    final id =
        'video-${widget.username}-${DateTime.now().millisecondsSinceEpoch}';
    _socket?.sink.add(
        jsonEncode({'type': 'video_call_invite', 'to': peer, 'callId': id}));
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => VideoCallPage(
          username: widget.username,
          peer: peer,
          callId: id,
          sessionKey: widget.sessionKey,
          baseUrl: widget.baseUrl,
          incoming: false,
        ),
      ),
    );
  }

  Future<void> _createGroup() async {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final name = TextEditingController();
    final selected = <String>{};
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (c, set) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(20),
          child: _MetalPlate(
            C: C,
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'BUAT GRUP CRYLIX',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
                const SizedBox(height: 16),
                _InsetPanel(
                  C: C,
                  child: TextField(
                    controller: name,
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudText() : C.text),
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                    decoration: InputDecoration(
                      hintText: 'Nama grup',
                      hintStyle: TextStyle(
                          color: isComic
                              ? C.comicTextMuted
                              : (isHud
                                  ? C.hudTextDim()
                                  : C.text.withValues(alpha: 0.4))),
                      border: InputBorder.none,
                      contentPadding:
                          const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 250),
                  child: SingleChildScrollView(
                    child: Column(
                      children: _users
                          .map((u) => CheckboxListTile(
                                value:
                                    selected.contains(u['username']),
                                title: Text(
                                  '${u['username']}',
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicText
                                        : (isHud ? C.hudText() : C.text),
                                    fontFamily: isComic
                                        ? 'ComicNeue'
                                        : 'ShareTechMono',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                activeColor: C.accentHi,
                                checkColor: isComic
                                    ? C.contrastTextOn(C.accentHi)
                                    : Colors.white,
                                onChanged: (v) {
                                  set(() {
                                    v == true
                                        ? selected.add(
                                            '${u['username']}')
                                        : selected.remove(
                                            '${u['username']}');
                                  });
                                },
                              ))
                          .toList(),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _IndustrialButton(
                        C: C,
                        color: C.bg,
                        height: 46,
                        onTap: () => Navigator.pop(c, false),
                        child: Text(
                          'BATAL',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _IndustrialButton(
                        C: C,
                        color: C.accentHi,
                        height: 46,
                        onTap: () => Navigator.pop(c, true),
                        child: Text(
                          'BUAT',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (ok != true || name.text.trim().isEmpty) return;
    try {
      final uri = Uri.parse('${widget.baseUrl}/api/cal/groups');
      final payload = jsonEncode({
        'key': widget.sessionKey,
        'name': name.text.trim(),
        'members': selected.toList()
      });
      var r = await http.post(uri,
          headers: {'Content-Type': 'application/json'},
          body: payload);
      if (r.statusCode == 429) {
        await Future<void>.delayed(const Duration(milliseconds: 1100));
        r = await http.post(uri,
            headers: {'Content-Type': 'application/json'},
            body: payload);
      }
      if (r.statusCode >= 200 && r.statusCode < 300) {
        final data = jsonDecode(r.body);
        final created = Map<String, dynamic>.from(data['group'] ?? {});
        if (created.isNotEmpty && mounted) {
          setState(() {
            _groups.removeWhere((g) => g['id'] == created['id']);
            _groups.insert(0, created);
          });
        }
        await Future<void>.delayed(const Duration(milliseconds: 800));
        if (mounted) await _refresh();
      } else if (mounted) {
        _snack(C, 'Gagal membuat grup (${r.statusCode})', C.primaryHi);
      }
    } catch (e) {
      if (mounted) _snack(C, 'Gagal terhubung ke server', C.primaryHi);
    }
    name.dispose();
  }

  void _snack(AppPalette C, String msg, Color color) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
        msg,
        style: TextStyle(
            fontWeight: FontWeight.w700,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            color: isComic
                ? C.contrastTextOn(color)
                : (isHud ? C.hudText() : Colors.white)),
      ),
      backgroundColor: isHud ? C.hudPanel() : color,
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  void dispose() {
    _sub?.cancel();
    _socket?.sink.close();
    _search.dispose();
    _contactSearch.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? Container(color: C.bg)
                        : (isHud
                            ? Container(color: C.hudBg())
                            : Container(
                                decoration: BoxDecoration(
                                  gradient: RadialGradient(
                                    center: const Alignment(-0.3, -0.3),
                                    radius: 1.2,
                                    colors: [C.bg, C.bgDark, C.bgDeep],
                                    stops: const [0.0, 0.6, 1.0],
                                  ),
                                ),
                              )),
                  ),
                  if (isComic)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(
                          painter: _HalftonePainter(
                              color: C.primaryLo.withValues(alpha: 0.12)),
                        ),
                      ),
                    ),
                  if (isHud)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(
                          painter: _HudGridPainter(color: C.hudGridLine()),
                        ),
                      ),
                    ),
                  SafeArea(
                    child: Column(
                      children: [
                        _buildAppBar(C, isComic),
                        const SizedBox(height: 8),
                        _buildTabBar(C, isComic),
                        const SizedBox(height: 8),
                        Expanded(
                          child: IndexedStack(
                            index: _tab,
                            children: [
                              _homeTab(C, isComic),
                              _groupsTab(C, isComic),
                              CallCrylixStoriesPage(
                                username: widget.username,
                                sessionKey: widget.sessionKey,
                                baseUrl: widget.baseUrl,
                              ),
                              _contactsTab(C, isComic),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              floatingActionButton: _tab == 1
                  ? FloatingActionButton.extended(
                      onPressed: _createGroup,
                      backgroundColor:
                          isHud ? C.accent.withValues(alpha: 0.2) : C.accentHi,
                      foregroundColor: isComic
                          ? C.contrastTextOn(C.accentHi)
                          : (isHud ? C.hudNeon() : Colors.white),
                      shape: isHud
                          ? RoundedRectangleBorder(
                              side: BorderSide(color: C.accent, width: 1.4),
                            )
                          : RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(isComic ? 16 : 14),
                              side: BorderSide(
                                color: Colors.black,
                                width: isComic ? 4 : 3,
                              ),
                            ),
                      icon: const Icon(Icons.group_add_rounded),
                      label: Text(
                        'GRUP BARU',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    )
                  : null,
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            _IconButton(
              C: C,
              icon: Icons.arrow_back_rounded,
              color: C.accent,
              onTap: () => Navigator.pop(context),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accentHi.withValues(alpha: 0.15),
                          border: Border.all(
                              color: C.accentHi, width: 1.4),
                          boxShadow: [
                            BoxShadow(
                              color: C.accentHi.withValues(alpha: 0.35),
                              blurRadius: 10,
                            ),
                          ],
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic
                              ? null
                              : RadialGradient(
                                  colors: [C.text, C.bg, C.bgDark]),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                            color:
                                isComic ? Colors.black : C.accentHi,
                            width: isComic ? 3 : 2,
                          ),
                          boxShadow: isComic
                              ? null
                              : [
                                  BoxShadow(
                                    color:
                                        C.accentHi.withValues(alpha: 0.5),
                                    blurRadius: 10,
                                    spreadRadius: 1,
                                  )
                                ],
                        ),
                  child: Icon(
                    Icons.call_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.accentHi : C.accentHi),
                    size: 20,
                  ),
                ),
                if (!isComic)
                  Positioned(
                    top: -2,
                    right: -2,
                    child: _Led(
                        color: C.primaryHi, size: 6, blink: true),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'CALL CRYLIX',
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudNeon() : C.accentHi),
                      fontSize: isComic ? 15 : 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2,
                      height: 1,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : [
                              Shadow(
                                color: C.primaryLo,
                                offset: const Offset(0, 1),
                                blurRadius: 1,
                              ),
                              const Shadow(
                                color: Colors.black,
                                offset: Offset(0, 2),
                                blurRadius: 3,
                              ),
                            ],
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(color: C.accentHi, size: 4, blink: true),
                      const SizedBox(width: 5),
                      Text(
                        'VOICE · VIDEO · GROUP',
                        style: TextStyle(
                          color: isComic
                              ? C.comicTextSub
                              : (isHud
                                  ? C.hudTextDim()
                                  : C.text.withValues(alpha: 0.55)),
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          fontFamily: isComic
                              ? 'ComicNeue'
                              : 'ShareTechMono',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            _IconButton(
              C: C,
              icon: Icons.refresh_rounded,
              color: C.accent,
              onTap: _refresh,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabBar(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    final tabs = [
      {
        'icon': Icons.chat_bubble_rounded,
        'label': 'CHAT',
        'color': C.accentHi
      },
      {
        'icon': Icons.groups_rounded,
        'label': 'GRUP',
        'color': C.accentHi
      },
      {
        'icon': Icons.auto_awesome_rounded,
        'label': 'STORY',
        'color': C.primaryHi
      },
      {
        'icon': Icons.contacts_rounded,
        'label': 'KONTAK',
        'color': C.accent
      },
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(6),
        radius: 12,
        child: Row(
          children: tabs.asMap().entries.map((e) {
            final i = e.key;
            final t = e.value;
            final active = _tab == i;
            final color = t['color'] as Color;
            final activeTextColor = isComic
                ? C.contrastTextOn(color)
                : (isHud ? C.hudNeon() : Colors.white);

            return Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _tab = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: isHud
                      ? BoxDecoration(
                          color: active
                              ? C.accent.withValues(alpha: 0.15)
                              : null,
                          border: Border.all(
                            color: active
                                ? C.accent
                                : C.accent.withValues(alpha: 0.2),
                            width: 1,
                          ),
                          boxShadow: active
                              ? [
                                  BoxShadow(
                                    color: C.accent.withValues(alpha: 0.4),
                                    blurRadius: 8,
                                  ),
                                ]
                              : null,
                        )
                      : BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          gradient: active && !isComic
                              ? LinearGradient(colors: [
                                  color.withValues(alpha: 0.9),
                                  color.withValues(alpha: 0.6)
                                ])
                              : null,
                          color: isComic && active ? color : null,
                          border: isComic && active
                              ? Border.all(color: Colors.black, width: 2.5)
                              : (active
                                  ? Border.all(
                                      color: Colors.black, width: 1.5)
                                  : null),
                          boxShadow: isComic && active
                              ? const [
                                  BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(2, 2),
                                    blurRadius: 0,
                                  ),
                                ]
                              : (!isComic && active
                                  ? [
                                      BoxShadow(
                                        color: color.withValues(alpha: 0.5),
                                        blurRadius: 8,
                                      )
                                    ]
                                  : null),
                        ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        t['icon'] as IconData,
                        color: active
                            ? activeTextColor
                            : (isComic
                                ? C.comicTextSub
                                : (isHud
                                    ? C.hudTextDim()
                                    : C.text.withValues(alpha: 0.6))),
                        size: 16,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        t['label'] as String,
                        style: TextStyle(
                          color: active
                              ? activeTextColor
                              : (isComic
                                  ? C.comicTextSub
                                  : (isHud
                                      ? C.hudTextDim()
                                      : C.text.withValues(alpha: 0.6))),
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _homeTab(AppPalette C, bool isComic) {
    final q = _search.text.toLowerCase();
    final users = _users
        .where((u) => '${u['username']}'.toLowerCase().contains(q))
        .toList();

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _searchField(C,
              controller: _search,
              hint: 'Cari percakapan atau user...',
              isComic: isComic),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _quickAction(C, 'Panggilan', Icons.call_rounded,
                    C.accentHi, () => setState(() => _tab = 3), isComic),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _quickAction(C, 'Video', Icons.videocam_rounded,
                    C.accentHi, () => setState(() => _tab = 3), isComic),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _quickAction(C, 'Story',
                    Icons.auto_awesome_rounded, C.primaryHi,
                    () => setState(() => _tab = 2), isComic),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _sectionHeader(C, 'Percakapan', '${users.length} user',
              Icons.chat_bubble_rounded, C.accentHi, isComic),
          const SizedBox(height: 12),
          if (_loading)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: CircularProgressIndicator(
                    color: C.accent, strokeWidth: 2),
              ),
            )
          else if (users.isEmpty)
            Padding(
              padding: const EdgeInsets.all(32),
              child: Center(
                child: Text(
                  'Belum ada user.',
                  style: TextStyle(
                    color: isComic ? C.comicTextSub : C.textSub,
                    fontWeight: FontWeight.w700,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                  ),
                ),
              ),
            )
          else
            ...users.map((u) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: _userCard(C, u, isComic),
                )),
        ],
      ),
    );
  }

  Widget _searchField(AppPalette C,
      {required TextEditingController controller,
      required String hint,
      bool isComic = false}) {
    return _InsetPanel(
      C: C,
      child: TextField(
        controller: controller,
        onChanged: (_) => setState(() {}),
        style: TextStyle(
          color: isComic ? C.comicText : C.text,
          fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
          fontWeight: FontWeight.w700,
        ),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
            color: isComic
                ? C.comicTextMuted
                : C.text.withValues(alpha: 0.35),
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 12,
          ),
          prefixIcon:
              Icon(Icons.search_rounded, color: C.accent, size: 18),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }

  Widget _quickAction(AppPalette C, String label, IconData icon, Color color,
      VoidCallback onTap, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final textColor = isComic
        ? C.contrastTextOn(color)
        : (isHud ? C.hudText() : Colors.white);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: isHud
            ? BoxDecoration(
                color: color.withValues(alpha: 0.15),
                border: Border.all(color: color, width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: color.withValues(alpha: 0.35),
                    blurRadius: 8,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                gradient: isComic
                    ? null
                    : LinearGradient(colors: [
                        color.withValues(alpha: 0.85),
                        color.withValues(alpha: 0.55)
                      ]),
                color: isComic ? color : null,
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : Colors.black.withValues(alpha: 0.7),
                    width: isComic ? 3 : 1.5),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        BoxShadow(
                            color: color.withValues(alpha: 0.4),
                            blurRadius: 8,
                            offset: const Offset(0, 3))
                      ],
              ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: textColor, size: 18),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: textColor,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(AppPalette C, String title, String subtitle,
      IconData icon, Color color, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Row(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: isHud
                  ? BoxDecoration(
                      color: color.withValues(alpha: 0.15),
                      border: Border.all(color: color, width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: color.withValues(alpha: 0.35),
                          blurRadius: 10,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(
                              colors: [C.text, C.bg, C.bgDark]),
                      color: isComic ? color : null,
                      border: Border.all(
                          color: isComic ? Colors.black : color,
                          width: isComic ? 2.5 : 1.8),
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                  color: color.withValues(alpha: 0.4),
                                  blurRadius: 8)
                            ],
                    ),
              child: Icon(icon,
                  color: isComic
                      ? C.contrastTextOn(color)
                      : (isHud ? color : color),
                  size: 16),
            ),
            if (!isComic && !isHud)
              Positioned(
                top: -1,
                right: -1,
                child: _Led(
                    color: C.primaryHi, size: 5, blink: true),
              ),
          ],
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title.toUpperCase(),
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accentHi),
                  fontSize: isComic ? 14 : 12,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                  height: 1,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud
                          ? C.hudTextDim()
                          : C.text.withValues(alpha: 0.5)),
                  fontSize: 9,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _userCard(AppPalette C, Map<String, dynamic> u, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final username = '${u['username']}';
    final role = '${u['role'] ?? 'member'}';

    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      radius: 12,
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: isHud
                ? BoxDecoration(
                    color: C.accentHi.withValues(alpha: 0.15),
                    border: Border.all(color: C.accentHi, width: 1.2),
                    boxShadow: [
                      BoxShadow(
                        color: C.accentHi.withValues(alpha: 0.35),
                        blurRadius: 8,
                      ),
                    ],
                  )
                : BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic
                        ? null
                        : RadialGradient(
                            colors: [C.text, C.bg, C.bgDark]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(color: C.accentHi, width: 2),
                    boxShadow: isComic
                        ? null
                        : [
                            BoxShadow(
                                color: C.accentHi.withValues(alpha: 0.4),
                                blurRadius: 8)
                          ],
                  ),
            child: Center(
              child: Text(
                username.isEmpty ? '?' : username[0].toUpperCase(),
                style: TextStyle(
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.accentHi : C.text),
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudText() : C.text),
                    fontSize: isComic ? 15 : 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 1 : 0.5,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  role.toUpperCase(),
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : (isHud
                            ? C.hudTextDim()
                            : C.accent.withValues(alpha: 0.7)),
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          _iconAction(C, Icons.call_rounded, C.accentHi,
              () => _startVoice(username), isComic),
          const SizedBox(width: 5),
          _iconAction(C, Icons.videocam_rounded, C.accentHi,
              () => _startVideo(username), isComic),
          const SizedBox(width: 5),
          _iconAction(C, Icons.chat_bubble_rounded, C.accent,
              () => _openChat(username), isComic),
        ],
      ),
    );
  }

  Widget _iconAction(AppPalette C, IconData icon, Color color,
      VoidCallback onTap, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final textColor = isComic
        ? C.contrastTextOn(color)
        : (isHud ? color : Colors.white);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: isHud
            ? BoxDecoration(
                color: color.withValues(alpha: 0.15),
                border: Border.all(color: color, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: color.withValues(alpha: 0.3),
                    blurRadius: 6,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: isComic
                    ? null
                    : LinearGradient(colors: [
                        color.withValues(alpha: 0.9),
                        color.withValues(alpha: 0.6)
                      ]),
                color: isComic ? color : null,
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : Colors.black.withValues(alpha: 0.7),
                    width: isComic ? 2.5 : 1.2),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        BoxShadow(
                            color: color.withValues(alpha: 0.4),
                            blurRadius: 6,
                            offset: const Offset(0, 2))
                      ],
              ),
        child: Icon(icon, color: textColor, size: 15),
      ),
    );
  }

  Widget _groupsTab(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    if (_groups.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accentHi.withValues(alpha: 0.15),
                      border: Border.all(color: C.accentHi, width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: C.accentHi.withValues(alpha: 0.35),
                          blurRadius: 15,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(
                              colors: [C.text, C.bg, C.bgDark]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(color: C.accentHi, width: 2),
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                  color:
                                      C.accentHi.withValues(alpha: 0.5),
                                  blurRadius: 15,
                                  spreadRadius: 2)
                            ],
                    ),
              child: Icon(Icons.groups_rounded,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.accentHi : C.accentHi),
                  size: 36),
            ),
            const SizedBox(height: 16),
            Text(
              'BELUM ADA GRUP',
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudNeon() : C.accent),
                fontSize: isComic ? 16 : 14,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 2,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Tap tombol GRUP BARU di bawah',
              style: TextStyle(
                color: isComic
                    ? C.comicTextSub
                    : (isHud
                        ? C.hudTextDim()
                        : C.text.withValues(alpha: 0.5)),
                fontSize: 11,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              ),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionHeader(C, 'Grup Crylix', '${_groups.length} grup',
              Icons.groups_rounded, C.accentHi, isComic),
          const SizedBox(height: 12),
          ..._groups.map((g) {
            final members = List<String>.from(g['members'] ?? []);
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _MetalPlate(
                C: C,
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 12),
                radius: 12,
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: isHud
                          ? BoxDecoration(
                              color:
                                  C.accentHi.withValues(alpha: 0.15),
                              border: Border.all(
                                  color: C.accentHi, width: 1.2),
                              boxShadow: [
                                BoxShadow(
                                  color:
                                      C.accentHi.withValues(alpha: 0.35),
                                  blurRadius: 8,
                                ),
                              ],
                            )
                          : BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: isComic
                                  ? null
                                  : RadialGradient(
                                      colors: [C.text, C.bg, C.bgDark]),
                              color: isComic ? C.primaryHi : null,
                              border: Border.all(
                                  color: C.accentHi, width: 2),
                              boxShadow: isComic
                                  ? null
                                  : [
                                      BoxShadow(
                                          color: C.accentHi
                                              .withValues(alpha: 0.4),
                                          blurRadius: 8)
                                    ],
                            ),
                      child: Icon(Icons.groups_rounded,
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : (isHud ? C.accentHi : C.accentHi),
                          size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${g['name']}',
                            style: TextStyle(
                              color: isComic
                                  ? C.comicText
                                  : (isHud ? C.hudText() : C.text),
                              fontSize: isComic ? 15 : 13,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: isComic ? 1 : 0.5,
                              shadows: isComic
                                  ? [
                                      Shadow(
                                        color: C.comicTextOutline,
                                        offset: const Offset(1, 1),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : null,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            '${members.length} anggota',
                            style: TextStyle(
                              color: isComic
                                  ? C.comicTextSub
                                  : (isHud
                                      ? C.hudTextDim()
                                      : C.text.withValues(alpha: 0.5)),
                              fontSize: 9,
                              fontFamily: isComic
                                  ? 'ComicNeue'
                                  : 'ShareTechMono',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _iconAction(C, Icons.videocam_rounded, C.accentHi,
                        () => _startGroup(g), isComic),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  void _startGroup(Map<String, dynamic> g) {
    final id = 'group-${g['id']}-${DateTime.now().millisecondsSinceEpoch}';
    final m = List<String>.from(g['members'] ?? []);
    _socket?.sink.add(jsonEncode({
      'type': 'group_call_invite',
      'groupId': g['id'],
      'groupName': g['name'],
      'members': m,
      'callId': id
    }));
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GroupCallPage(
          username: widget.username,
          groupId: '${g['id']}',
          groupName: '${g['name']}',
          members: m,
          sessionKey: widget.sessionKey,
          baseUrl: widget.baseUrl,
        ),
      ),
    );
  }

  Widget _contactsTab(AppPalette C, bool isComic) {
    final q = _contactSearch.text.trim().toLowerCase();
    final filtered = _users
        .where((u) => '${u['username'] ?? ''}'.toLowerCase().contains(q))
        .toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
          child: _sectionHeader(C, 'Kontak Crylix',
              '${filtered.length} kontak', Icons.contacts_rounded,
              C.accent, isComic),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: _searchField(C,
              controller: _contactSearch,
              hint: 'Cari username...',
              isComic: isComic),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: filtered.isEmpty
              ? Center(
                  child: Text(
                    'Kontak tidak ditemukan.',
                    style: TextStyle(
                      color: isComic ? C.comicTextSub : C.textSub,
                      fontWeight: FontWeight.w700,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 32),
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) =>
                      _userCard(C, filtered[i], isComic),
                ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _HalftonePainter extends CustomPainter {
  final Color color;
  const _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// CHAT PAGE
// ═══════════════════════════════════════════════════════════
class CalChatPage extends StatefulWidget {
  final String username, peer, sessionKey, baseUrl;
  const CalChatPage({
    super.key,
    required this.username,
    required this.peer,
    required this.sessionKey,
    required this.baseUrl,
  });
  @override
  State<CalChatPage> createState() => _CalChatPageState();
}

class _CalChatPageState extends State<CalChatPage> {
  final _msg = TextEditingController();
  final _rec = AudioRecorder();
  final _messages = <Map<String, dynamic>>[];
  IOWebSocketChannel? _s;
  StreamSubscription? _sub;
  bool _recording = false;

  String get ws => widget.baseUrl.replaceFirst(
        RegExp(r'^https?://'),
        widget.baseUrl.startsWith('https://') ? 'wss://' : 'ws://',
      );

  @override
  void initState() {
    super.initState();
    _connect();
    _history();
  }

  void _connect() {
    try {
      _s = IOWebSocketChannel.connect(Uri.parse(ws));
      _s!.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
      _sub = _s!.stream.listen((raw) {
        final d = jsonDecode(raw.toString());
        if ((d['type'] == 'chat' || d['type'] == 'voice_message') &&
            d['message'] != null) {
          final m = Map<String, dynamic>.from(d['message']);
          if ((m['from'] == widget.peer && m['to'] == widget.username) ||
              (m['from'] == widget.username && m['to'] == widget.peer)) {
            setState(() => _messages.add(m));
          }
        }
      });
    } catch (_) {}
  }

  Future<void> _history() async {
    try {
      final r = await http.get(Uri.parse(
          '${widget.baseUrl}/api/chat/history/${Uri.encodeComponent(widget.peer)}?key=${Uri.encodeQueryComponent(widget.sessionKey)}'));
      if (r.statusCode == 200) {
        final d = jsonDecode(r.body);
        if (d['success'] == true) {
          setState(() {
            _messages
              ..clear()
              ..addAll(List<Map<String, dynamic>>.from(d['messages'] ?? []));
          });
        }
      }
    } catch (_) {}
  }

  void _send() {
    final t = _msg.text.trim();
    if (t.isEmpty) return;
    _s?.sink
        .add(jsonEncode({'type': 'chat', 'to': widget.peer, 'message': t}));
    _msg.clear();
  }

  Future<void> _voice() async {
    if (_recording) {
      final p = await _rec.stop();
      setState(() => _recording = false);
      if (p != null) {
        final req = http.MultipartRequest(
            'POST', Uri.parse('${widget.baseUrl}/api/cal/voice'));
        req.fields..['key'] = widget.sessionKey..['to'] = widget.peer;
        req.files.add(await http.MultipartFile.fromPath('audio', p));
        await req.send();
      }
      return;
    }
    if (!await _rec.hasPermission()) return;
    final d = await getTemporaryDirectory();
    await _rec.start(
        const RecordConfig(
            encoder: AudioEncoder.aacLc,
            bitRate: 64000,
            sampleRate: 44100),
        path: '${d.path}/cal_${DateTime.now().millisecondsSinceEpoch}.m4a');
    setState(() => _recording = true);
  }

  void _call(AppPalette C, bool video, bool isComic) {
    final id =
        '${video ? 'video' : 'voice'}-${DateTime.now().millisecondsSinceEpoch}';
    _s?.sink.add(jsonEncode({
      'type': video ? 'video_call_invite' : 'call_invite',
      'to': widget.peer,
      'callId': id
    }));
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => video
            ? VideoCallPage(
                username: widget.username,
                peer: widget.peer,
                callId: id,
                sessionKey: widget.sessionKey,
                baseUrl: widget.baseUrl,
                incoming: false,
              )
            : VoiceCallPage(
                username: widget.username,
                peer: widget.peer,
                callId: id,
                sessionKey: widget.sessionKey,
                baseUrl: widget.baseUrl,
                incoming: false,
              ),
      ),
    );
  }

  @override
  void dispose() {
    _sub?.cancel();
    _s?.sink.close();
    _msg.dispose();
    _rec.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              radius: 1.2,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                              stops: const [0.0, 0.6, 1.0],
                            ),
                          )),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HalftonePainter(
                                color: C.primaryLo.withValues(alpha: 0.12)),
                          ),
                        ),
                      ),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(color: C.hudGridLine()),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildAppBar(c, C, isComic),
                          Expanded(
                            child: ListView.builder(
                              reverse: true,
                              padding: const EdgeInsets.all(14),
                              itemCount: _messages.length,
                              itemBuilder: (_, i) {
                                final m =
                                    _messages[_messages.length - 1 - i];
                                final mine = m['from'] == widget.username;
                                final bubbleColor = mine
                                    ? (isComic
                                        ? C.primaryHi
                                        : C.accentHi)
                                    : (isComic
                                        ? C.bgDark
                                        : C.bgDark);
                                final textColor = isComic
                                    ? C.contrastTextOn(bubbleColor)
                                    : (isHud
                                        ? C.hudText()
                                        : (mine ? C.bgDeep : C.text));

                                return Align(
                                  alignment: mine
                                      ? Alignment.centerRight
                                      : Alignment.centerLeft,
                                  child: Container(
                                    margin: const EdgeInsets.all(4),
                                    padding: const EdgeInsets.all(12),
                                    constraints: BoxConstraints(
                                      maxWidth: MediaQuery.of(c)
                                              .size
                                              .width *
                                          0.75,
                                    ),
                                    decoration: isHud
                                        ? BoxDecoration(
                                            color: mine
                                                ? C.accent
                                                    .withValues(alpha: 0.2)
                                                : C.bgDeep
                                                    .withValues(alpha: 0.7),
                                            border: Border.all(
                                              color: mine
                                                  ? C.accent
                                                  : C.accent
                                                      .withValues(alpha: 0.4),
                                              width: mine ? 1.4 : 1,
                                            ),
                                            boxShadow: mine
                                                ? [
                                                    BoxShadow(
                                                      color: C.accent
                                                          .withValues(
                                                              alpha: 0.4),
                                                      blurRadius: 10,
                                                    ),
                                                  ]
                                                : null,
                                          )
                                        : BoxDecoration(
                                            color: isComic
                                                ? bubbleColor
                                                : null,
                                            gradient: isComic
                                                ? null
                                                : (mine
                                                    ? LinearGradient(colors: [
                                                        C.accentHi,
                                                        C.accent,
                                                        C.primaryLo
                                                      ])
                                                    : LinearGradient(colors: [
                                                        C.textSub,
                                                        C.bg,
                                                        C.bgDark
                                                      ])),
                                            borderRadius:
                                                BorderRadius.circular(
                                                    isComic ? 14 : 12),
                                            border: Border.all(
                                                color: Colors.black
                                                    .withValues(alpha: 0.7),
                                                width: 1.2),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Colors.black
                                                    .withValues(alpha: 0.5),
                                                offset:
                                                    const Offset(0, 2),
                                                blurRadius: 4,
                                              ),
                                            ],
                                          ),
                                    child: Text(
                                      m['voiceUrl'] != null
                                          ? '🎙 Voice note'
                                          : '${m['message'] ?? ''}',
                                      style: TextStyle(
                                        color: textColor,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono',
                                        fontWeight: FontWeight.w700,
                                        shadows: isComic
                                            ? [
                                                Shadow(
                                                  color: textColor ==
                                                          Colors.white
                                                      ? Colors.black
                                                      : Colors.white,
                                                  offset:
                                                      const Offset(1, 1),
                                                  blurRadius: 0,
                                                ),
                                              ]
                                            : null,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          SafeArea(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  12, 8, 12, 12),
                              child: Row(
                                children: [
                                  _chatBtn(
                                    C: C,
                                    icon: _recording
                                        ? Icons.stop_rounded
                                        : Icons.mic_rounded,
                                    color: _recording
                                        ? C.primaryHi
                                        : C.accent,
                                    isComic: isComic,
                                    isHud: isHud,
                                    onTap: _voice,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: _InsetPanel(
                                      C: C,
                                      child: TextField(
                                        controller: _msg,
                                        onSubmitted: (_) => _send(),
                                        style: TextStyle(
                                          color: isComic
                                              ? C.comicText
                                              : (isHud
                                                  ? C.hudText()
                                                  : C.text),
                                          fontFamily: isComic
                                              ? 'ComicNeue'
                                              : 'ShareTechMono',
                                          fontWeight: FontWeight.w700,
                                        ),
                                        decoration: InputDecoration(
                                          hintText: 'Tulis pesan...',
                                          hintStyle: TextStyle(
                                            color: isComic
                                                ? C.comicTextMuted
                                                : (isHud
                                                    ? C.hudTextDim()
                                                    : C.text
                                                        .withValues(
                                                            alpha: 0.4)),
                                            fontFamily: isComic
                                                ? 'ComicNeue'
                                                : 'ShareTechMono',
                                            fontSize: 12,
                                          ),
                                          border: InputBorder.none,
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                  vertical: 14),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  _chatBtn(
                                    C: C,
                                    icon: Icons.send_rounded,
                                    color: C.primaryHi,
                                    isComic: isComic,
                                    isHud: isHud,
                                    onTap: _send,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _chatBtn({
    required AppPalette C,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    required bool isComic,
    required bool isHud,
  }) {
    if (isHud) {
      return GestureDetector(
        onTap: onTap,
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            border: Border.all(color: color, width: 1.2),
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.3),
                blurRadius: 8,
              ),
            ],
          ),
          child: Icon(icon, color: color, size: 18),
        ),
      );
    }
    if (isComic) {
      return GestureDetector(
        onTap: onTap,
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: C.bgDark,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.black, width: 3),
            boxShadow: const [
              BoxShadow(
                color: Colors.black,
                offset: Offset(3, 3),
                blurRadius: 0,
              ),
            ],
          ),
          child: Icon(icon, color: color, size: 18),
        ),
      );
    }
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(colors: [
            C.textSub,
            C.bg,
            C.bgDark,
          ]),
          border: Border.all(
              color: Colors.black.withValues(alpha: 0.7), width: 1.2),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.7),
                offset: const Offset(0, 3),
                blurRadius: 5),
          ],
        ),
        child: Icon(icon, color: color, size: 18),
      ),
    );
  }

  Widget _buildAppBar(BuildContext c, AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        child: Row(
          children: [
            _chatBtn(
              C: C,
              icon: Icons.arrow_back_rounded,
              color: C.accent,
              isComic: isComic,
              isHud: isHud,
              onTap: () => Navigator.pop(c),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36,
              height: 36,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accentHi.withValues(alpha: 0.15),
                      border: Border.all(color: C.accentHi, width: 1.2),
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(
                              colors: [C.text, C.bg, C.bgDark]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(color: C.accentHi, width: 1.5),
                    ),
              child: Center(
                child: Text(
                  widget.peer.isEmpty
                      ? '?'
                      : widget.peer[0].toUpperCase(),
                  style: TextStyle(
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.accentHi : C.text),
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                widget.peer,
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accentHi),
                  fontSize: isComic ? 15 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 1,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            _chatBtn(
              C: C,
              icon: Icons.call_rounded,
              color: C.accentHi,
              isComic: isComic,
              isHud: isHud,
              onTap: () => _call(C, false, isComic),
            ),
            const SizedBox(width: 6),
            _chatBtn(
              C: C,
              icon: Icons.videocam_rounded,
              color: C.accentHi,
              isComic: isComic,
              isHud: isHud,
              onTap: () => _call(C, true, isComic),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// VOICE CALL PAGE
// ═══════════════════════════════════════════════════════════
class VoiceCallPage extends StatefulWidget {
  final String username, peer, callId, sessionKey, baseUrl;
  final bool incoming;
  const VoiceCallPage({
    super.key,
    required this.username,
    required this.peer,
    required this.callId,
    required this.sessionKey,
    required this.baseUrl,
    required this.incoming,
  });
  @override
  State<VoiceCallPage> createState() => _VoiceCallPageState();
}

class _VoiceCallPageState extends State<VoiceCallPage> {
  RTCPeerConnection? pc;
  MediaStream? local;
  IOWebSocketChannel? s;
  StreamSubscription? sub;
  bool muted = false;
  String status = 'Menghubungkan...';

  String get ws => widget.baseUrl.replaceFirst(
        RegExp(r'^https?://'),
        widget.baseUrl.startsWith('https://') ? 'wss://' : 'ws://',
      );

  @override
  void initState() {
    super.initState();
    _connect();
  }

  void _connect() {
    s = IOWebSocketChannel.connect(Uri.parse(ws));
    s!.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
    sub = s!.stream.listen(_signal);
    _setup();
  }

  void send(Map d) => s?.sink.add(jsonEncode(d));

  Future<void> _setup() async {
    try {
      pc = await createPeerConnection({
        'iceServers': [
          {'urls': ['stun:stun.l.google.com:19302']}
        ]
      });
      pc!.onIceCandidate = (c) {
        if (c.candidate != null) {
          send({
            'type': 'call_ice',
            'to': widget.peer,
            'callId': widget.callId,
            'candidate': c.toMap()
          });
        }
      };
      pc!.onConnectionState = (x) {
        if (mounted)
          setState(() => status = x.toString().split('.').last);
      };
      local = await navigator.mediaDevices
          .getUserMedia({'audio': true, 'video': false});
      for (final t in local!.getTracks()) {
        await pc!.addTrack(t, local!);
      }
      if (widget.incoming) {
        send({
          'type': 'call_accept',
          'to': widget.peer,
          'callId': widget.callId
        });
      } else {
        final o = await pc!.createOffer({'offerToReceiveAudio': 1});
        await pc!.setLocalDescription(o);
        send({
          'type': 'call_offer',
          'to': widget.peer,
          'callId': widget.callId,
          'sdp': o.sdp
        });
        setState(() => status = 'Memanggil...');
      }
    } catch (e) {
      if (mounted) setState(() => status = 'WebRTC gagal');
    }
  }

  Future<void> _signal(raw) async {
    try {
      final d = jsonDecode(raw.toString());
      if (d['callId'] != widget.callId) return;
      switch (d['type']) {
        case 'call_offer':
          if (widget.incoming) {
            await pc?.setRemoteDescription(
                RTCSessionDescription(d['sdp'], 'offer'));
            final a = await pc!.createAnswer({'offerToReceiveAudio': 1});
            await pc!.setLocalDescription(a);
            send({
              'type': 'call_answer',
              'to': widget.peer,
              'callId': widget.callId,
              'sdp': a.sdp
            });
          }
          break;
        case 'call_answer':
          if (!widget.incoming) {
            await pc?.setRemoteDescription(
                RTCSessionDescription(d['sdp'], 'answer'));
          }
          break;
        case 'call_ice':
          final c = Map<String, dynamic>.from(d['candidate'] ?? {});
          await pc?.addCandidate(RTCIceCandidate(
              c['candidate'], c['sdpMid'], c['sdpMLineIndex']));
          break;
        case 'call_reject':
        case 'call_end':
          if (mounted) Navigator.pop(context);
          break;
      }
    } catch (_) {}
  }

  void end() {
    send({'type': 'call_end', 'to': widget.peer, 'callId': widget.callId});
    Navigator.pop(context);
  }

  @override
  void dispose() {
    sub?.cancel();
    s?.sink.close();
    for (final t in local?.getTracks() ?? <MediaStreamTrack>[]) {
      t.stop();
    }
    local?.dispose();
    pc?.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;
            return _CallScaffold(
              C: C,
              title: widget.peer,
              subtitle: 'Voice Call',
              status: status,
              accent: C.accentHi,
              icon: Icons.person_rounded,
              muted: muted,
              isComic: isComic,
              isHud: isHud,
              onMute: () {
                setState(() => muted = !muted);
                for (final t
                    in local?.getAudioTracks() ?? <MediaStreamTrack>[]) {
                  t.enabled = !muted;
                }
              },
              onEnd: end,
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// VIDEO CALL PAGE
// ═══════════════════════════════════════════════════════════
class VideoCallPage extends StatefulWidget {
  final String username, peer, callId, sessionKey, baseUrl;
  final bool incoming;
  const VideoCallPage({
    super.key,
    required this.username,
    required this.peer,
    required this.callId,
    required this.sessionKey,
    required this.baseUrl,
    required this.incoming,
  });
  @override
  State<VideoCallPage> createState() => _VideoCallPageState();
}

class _VideoCallPageState extends State<VideoCallPage> {
  RTCPeerConnection? pc;
  MediaStream? local, remote;
  RTCVideoRenderer lr = RTCVideoRenderer(), rr = RTCVideoRenderer();
  IOWebSocketChannel? s;
  StreamSubscription? sub;
  bool muted = false, cam = true;
  String status = 'Menghubungkan...';

  String get ws => widget.baseUrl.replaceFirst(
        RegExp(r'^https?://'),
        widget.baseUrl.startsWith('https://') ? 'wss://' : 'ws://',
      );

  @override
  void initState() {
    super.initState();
    lr.initialize();
    rr.initialize();
    _connect();
  }

  void send(Map d) => s?.sink.add(jsonEncode(d));

  void _connect() {
    s = IOWebSocketChannel.connect(Uri.parse(ws));
    s!.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
    sub = s!.stream.listen(_signal);
    _setup();
  }

  Future<void> _setup() async {
    try {
      pc = await createPeerConnection({
        'iceServers': [
          {'urls': ['stun:stun.l.google.com:19302']}
        ]
      });
      pc!.onIceCandidate = (c) {
        if (c.candidate != null) {
          send({
            'type': 'call_ice',
            'to': widget.peer,
            'callId': widget.callId,
            'candidate': c.toMap()
          });
        }
      };
      pc!.onTrack = (e) {
        if (e.streams.isNotEmpty) {
          remote = e.streams.first;
          rr.srcObject = remote;
          setState(() {});
        }
      };
      pc!.onConnectionState = (x) {
        if (mounted)
          setState(() => status = x.toString().split('.').last);
      };
      local = await navigator.mediaDevices
          .getUserMedia({'audio': true, 'video': true});
      lr.srcObject = local;
      for (final t in local!.getTracks()) {
        await pc!.addTrack(t, local!);
      }
      if (widget.incoming) {
        send({
          'type': 'call_accept',
          'to': widget.peer,
          'callId': widget.callId
        });
      } else {
        final o = await pc!.createOffer(
            {'offerToReceiveAudio': 1, 'offerToReceiveVideo': 1});
        await pc!.setLocalDescription(o);
        send({
          'type': 'call_offer',
          'to': widget.peer,
          'callId': widget.callId,
          'sdp': o.sdp
        });
        setState(() => status = 'Memanggil...');
      }
    } catch (_) {
      if (mounted) setState(() => status = 'Kamera/mikrofon gagal');
    }
  }

  Future<void> _signal(raw) async {
    try {
      final d = jsonDecode(raw.toString());
      if (d['callId'] != widget.callId) return;
      switch (d['type']) {
        case 'call_offer':
          if (widget.incoming) {
            await pc?.setRemoteDescription(
                RTCSessionDescription(d['sdp'], 'offer'));
            final a = await pc!.createAnswer(
                {'offerToReceiveAudio': 1, 'offerToReceiveVideo': 1});
            await pc!.setLocalDescription(a);
            send({
              'type': 'call_answer',
              'to': widget.peer,
              'callId': widget.callId,
              'sdp': a.sdp
            });
          }
          break;
        case 'call_answer':
          if (!widget.incoming) {
            await pc?.setRemoteDescription(
                RTCSessionDescription(d['sdp'], 'answer'));
          }
          break;
        case 'call_ice':
          final c = Map<String, dynamic>.from(d['candidate'] ?? {});
          await pc?.addCandidate(RTCIceCandidate(
              c['candidate'], c['sdpMid'], c['sdpMLineIndex']));
          break;
        case 'call_reject':
        case 'call_end':
          if (mounted) Navigator.pop(context);
          break;
      }
    } catch (_) {}
  }

  void end() {
    send({'type': 'call_end', 'to': widget.peer, 'callId': widget.callId});
    Navigator.pop(context);
  }

  @override
  void dispose() {
    sub?.cancel();
    s?.sink.close();
    lr.dispose();
    rr.dispose();
    for (final t in local?.getTracks() ?? <MediaStreamTrack>[]) {
      t.stop();
    }
    local?.dispose();
    pc?.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor: Colors.black,
              body: Stack(
                children: [
                  Positioned.fill(
                    child: RTCVideoView(rr,
                        objectFit: RTCVideoViewObjectFit
                            .RTCVideoViewObjectFitCover),
                  ),
                  Positioned(
                    top: 50,
                    right: 16,
                    width: 110,
                    height: 160,
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: isComic
                              ? C.accent
                              : (isHud ? C.accent : C.accentHi),
                          width: isComic ? 4 : (isHud ? 1.4 : 3),
                        ),
                        borderRadius: isHud
                            ? BorderRadius.circular(2)
                            : BorderRadius.circular(isComic ? 12 : 16),
                        boxShadow: isComic
                            ? const [
                                BoxShadow(
                                  color: Colors.black,
                                  offset: Offset(5, 5),
                                  blurRadius: 0,
                                ),
                              ]
                            : [
                                BoxShadow(
                                  color: (isHud
                                          ? C.accent
                                          : C.accentHi)
                                      .withValues(alpha: 0.5),
                                  blurRadius: 15,
                                ),
                              ],
                      ),
                      child: ClipRRect(
                        borderRadius: isHud
                            ? BorderRadius.circular(2)
                            : BorderRadius.circular(isComic ? 8 : 13),
                        child: RTCVideoView(lr, mirror: true),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 60,
                    left: 18,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.hudPanel(),
                              border: Border.all(
                                  color: C.accent, width: 1.2),
                              boxShadow: [
                                BoxShadow(
                                  color: C.accent.withValues(alpha: 0.4),
                                  blurRadius: 10,
                                ),
                              ],
                            )
                          : BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.7),
                              borderRadius:
                                  BorderRadius.circular(isComic ? 12 : 20),
                              border: Border.all(
                                  color: isComic
                                      ? Colors.black
                                      : C.accentHi,
                                  width: isComic ? 3 : 2),
                              boxShadow: isComic
                                  ? const [
                                      BoxShadow(
                                        color: Colors.black,
                                        offset: Offset(3, 3),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : null,
                            ),
                      child: Text(
                        status,
                        style: TextStyle(
                          color: isComic
                              ? C.comicText
                              : (isHud ? C.hudText() : C.text),
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          fontFamily:
                              isComic ? 'Bangers' : 'ShareTechMono',
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 35,
                    left: 0,
                    right: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _callBtn(
                          C,
                          icon: muted ? Icons.mic_off : Icons.mic,
                          color: muted ? C.primaryHi : C.bg,
                          isComic: isComic,
                          isHud: isHud,
                          onTap: () {
                            setState(() => muted = !muted);
                            for (final t
                                in local?.getAudioTracks() ??
                                    <MediaStreamTrack>[]) {
                              t.enabled = !muted;
                            }
                          },
                        ),
                        const SizedBox(width: 20),
                        _callBtn(
                          C,
                          icon: Icons.call_end,
                          color: C.primaryHi,
                          isComic: isComic,
                          isHud: isHud,
                          onTap: end,
                          size: 56,
                        ),
                        const SizedBox(width: 20),
                        _callBtn(
                          C,
                          icon: cam
                              ? Icons.videocam
                              : Icons.videocam_off,
                          color: cam ? C.bg : C.primaryHi,
                          isComic: isComic,
                          isHud: isHud,
                          onTap: () {
                            setState(() => cam = !cam);
                            for (final t
                                in local?.getVideoTracks() ??
                                    <MediaStreamTrack>[]) {
                              t.enabled = cam;
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _callBtn(
    AppPalette C, {
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    required bool isComic,
    required bool isHud,
    double size = 50,
  }) {
    final iconColor =
        isComic ? C.contrastTextOn(color) : Colors.white;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: isHud
            ? BoxDecoration(
                color: color.withValues(alpha: 0.15),
                border: Border.all(color: color, width: 1.4),
                boxShadow: [
                  BoxShadow(
                    color: color.withValues(alpha: 0.4),
                    blurRadius: 10,
                  ),
                ],
              )
            : BoxDecoration(
                color: color,
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.black,
                  width: isComic ? 3.5 : 2.5,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        BoxShadow(
                            color: color.withValues(alpha: 0.5),
                            blurRadius: 10)
                      ],
              ),
        child: Icon(
          icon,
          color: isHud ? color : iconColor,
          size: size * 0.45,
          shadows: isComic
              ? [
                  Shadow(
                    color: iconColor == Colors.white
                        ? Colors.black
                        : Colors.white,
                    offset: const Offset(1, 1),
                    blurRadius: 0,
                  ),
                ]
              : null,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// GROUP CALL PAGE
// ═══════════════════════════════════════════════════════════
class GroupCallPage extends StatefulWidget {
  final String username, groupId, groupName, sessionKey, baseUrl;
  final List<String> members;
  const GroupCallPage({
    super.key,
    required this.username,
    required this.groupId,
    required this.groupName,
    required this.members,
    required this.sessionKey,
    required this.baseUrl,
  });
  @override
  State<GroupCallPage> createState() => _GroupCallPageState();
}

class _GroupCallPageState extends State<GroupCallPage> {
  IOWebSocketChannel? s;
  StreamSubscription? sub;
  final Map<String, RTCPeerConnection> pcs = {};
  final Map<String, RTCVideoRenderer> renders = {};
  MediaStream? local;
  String status = 'Menghubungkan...';

  String get ws => widget.baseUrl.replaceFirst(
        RegExp(r'^https?://'),
        widget.baseUrl.startsWith('https://') ? 'wss://' : 'ws://',
      );
  List<String> get peers =>
      widget.members.where((x) => x != widget.username).toList();

  @override
  void initState() {
    super.initState();
    _connect();
    _media();
  }

  void send(Map<String, dynamic> data) => s?.sink.add(jsonEncode(data));

  void _connect() {
    try {
      s = IOWebSocketChannel.connect(Uri.parse(ws));
      s!.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
      sub = s!.stream.listen(_signal);
    } catch (_) {
      if (mounted) setState(() => status = 'WebSocket gagal');
    }
  }

  Future<void> _media() async {
    try {
      local = await navigator.mediaDevices
          .getUserMedia({'audio': true, 'video': true});
      for (final peer in peers) {
        if (widget.username.compareTo(peer) < 0) {
          await _makePeer(peer, true);
        } else {
          await _makePeer(peer, false);
        }
      }
      send({
        'type': 'group_call_join',
        'groupId': widget.groupId,
        'members': widget.members
      });
      if (mounted) setState(() => status = 'Menunggu peserta...');
    } catch (_) {
      if (mounted) setState(() => status = 'Kamera/mikrofon gagal');
    }
  }

  Future<RTCPeerConnection> _makePeer(String peer, bool offer) async {
    final existing = pcs[peer];
    if (existing != null) return existing;
    final pc = await createPeerConnection({
      'iceServers': [
        {'urls': ['stun:stun.l.google.com:19302']}
      ]
    });
    pcs[peer] = pc;
    for (final track in local?.getTracks() ?? <MediaStreamTrack>[]) {
      await pc.addTrack(track, local!);
    }
    pc.onIceCandidate = (candidate) {
      if (candidate.candidate != null) {
        send({
          'type': 'group_call_ice',
          'to': peer,
          'groupId': widget.groupId,
          'candidate': candidate.toMap()
        });
      }
    };
    pc.onTrack = (event) {
      if (event.streams.isNotEmpty) {
        _renderer(peer).srcObject = event.streams.first;
        if (mounted) setState(() {});
      }
    };
    if (offer) {
      final offerDescription = await pc.createOffer(
          {'offerToReceiveAudio': 1, 'offerToReceiveVideo': 1});
      await pc.setLocalDescription(offerDescription);
      send({
        'type': 'group_call_offer',
        'to': peer,
        'groupId': widget.groupId,
        'sdp': offerDescription.sdp
      });
    }
    return pc;
  }

  RTCVideoRenderer _renderer(String peer) {
    return renders.putIfAbsent(peer, () {
      final renderer = RTCVideoRenderer();
      renderer.initialize();
      return renderer;
    });
  }

  Future<void> _signal(dynamic raw) async {
    try {
      final data = jsonDecode(raw.toString()) as Map<String, dynamic>;
      if (data['groupId']?.toString() != widget.groupId) return;
      if (data['from']?.toString() == widget.username) return;
      final from = '${data['from']}';
      switch (data['type']) {
        case 'group_call_join':
          if (widget.username.compareTo(from) < 0) {
            await _makePeer(from, true);
          } else {
            await _makePeer(from, false);
          }
          break;
        case 'group_call_offer':
          final pc = await _makePeer(from, false);
          await pc.setRemoteDescription(
              RTCSessionDescription(data['sdp'], 'offer'));
          final answer = await pc.createAnswer(
              {'offerToReceiveAudio': 1, 'offerToReceiveVideo': 1});
          await pc.setLocalDescription(answer);
          send({
            'type': 'group_call_answer',
            'to': from,
            'groupId': widget.groupId,
            'sdp': answer.sdp
          });
          break;
        case 'group_call_answer':
          final pc = pcs[from];
          if (pc != null) {
            await pc.setRemoteDescription(
                RTCSessionDescription(data['sdp'], 'answer'));
          }
          break;
        case 'group_call_ice':
          final candidate =
              Map<String, dynamic>.from(data['candidate'] ?? {});
          await pcs[from]?.addCandidate(RTCIceCandidate(
              candidate['candidate'],
              candidate['sdpMid'],
              candidate['sdpMLineIndex']));
          break;
        case 'group_call_leave':
          _removePeer(from);
          break;
      }
    } catch (_) {}
  }

  void _removePeer(String peer) {
    pcs[peer]?.close();
    pcs.remove(peer);
    renders[peer]?.dispose();
    renders.remove(peer);
    if (mounted) setState(() {});
  }

  void end() {
    send({
      'type': 'group_call_leave',
      'groupId': widget.groupId,
      'members': widget.members
    });
    Navigator.pop(context);
  }

  @override
  void dispose() {
    sub?.cancel();
    s?.sink.close();
    for (final pc in pcs.values) {
      pc.close();
    }
    for (final renderer in renders.values) {
      renderer.dispose();
    }
    for (final track in local?.getTracks() ?? <MediaStreamTrack>[]) {
      track.stop();
    }
    local?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            final tiles = <Widget>[];
            for (final peer in renders.keys) {
              tiles.add(Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: isComic
                        ? C.accent
                        : (isHud ? C.accent : C.accentHi),
                    width: isComic ? 3.5 : (isHud ? 1.4 : 2.5),
                  ),
                  borderRadius: isHud
                      ? BorderRadius.circular(2)
                      : BorderRadius.circular(isComic ? 12 : 14),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(4, 4),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: (isHud ? C.accent : C.accentHi)
                                .withValues(alpha: 0.4),
                            blurRadius: 10,
                          ),
                        ],
                ),
                child: ClipRRect(
                  borderRadius: isHud
                      ? BorderRadius.circular(2)
                      : BorderRadius.circular(isComic ? 8 : 11),
                  child: RTCVideoView(
                    _renderer(peer),
                    objectFit: RTCVideoViewObjectFit
                        .RTCVideoViewObjectFitCover,
                  ),
                ),
              ));
            }
            if (tiles.isEmpty) {
              tiles.add(Center(
                child: Text(
                  'Menunggu peserta...',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudText() : C.text),
                    fontWeight: FontWeight.w800,
                    fontFamily:
                        isComic ? 'Bangers' : 'ShareTechMono',
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ));
            }

            return Scaffold(
              backgroundColor: isComic
                  ? C.bg
                  : (isHud ? C.hudBg() : Colors.black),
              body: Stack(
                children: [
                  if (isComic)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(
                          painter: _HalftonePainter(
                              color: C.primaryLo.withValues(alpha: 0.12)),
                        ),
                      ),
                    ),
                  if (isHud)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(
                          painter: _HudGridPainter(
                              color: C.hudGridLine()),
                        ),
                      ),
                    ),
                  SafeArea(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: _MetalPlate(
                            C: C,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 10),
                            child: Row(
                              children: [
                                _IconButton(
                                  C: C,
                                  icon: Icons.arrow_back_rounded,
                                  color: C.accent,
                                  onTap: () =>
                                      Navigator.pop(context),
                                ),
                                const SizedBox(width: 12),
                                Icon(
                                  Icons.groups_rounded,
                                  color: isComic
                                      ? C.comicText
                                      : (isHud
                                          ? C.hudNeon()
                                          : C.accentHi),
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    widget.groupName,
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicText
                                          : (isHud
                                              ? C.hudNeon()
                                              : C.accentHi),
                                      fontSize: isComic ? 15 : 13,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: isComic
                                          ? 'Bangers'
                                          : 'Orbitron',
                                      letterSpacing: 1,
                                      shadows: isComic
                                          ? [
                                              Shadow(
                                                color:
                                                    C.comicTextOutline,
                                                offset:
                                                    const Offset(1, 1),
                                                blurRadius: 0,
                                              ),
                                            ]
                                          : null,
                                    ),
                                  ),
                                ),
                                _Led(
                                    color: C.primaryHi,
                                    size: 6,
                                    blink: true),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: GridView.count(
                            crossAxisCount: tiles.length <= 1 ? 1 : 2,
                            padding: const EdgeInsets.all(8),
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                            children: tiles,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _IconButton(
                                C: C,
                                icon: Icons.mic_rounded,
                                color: C.accent,
                                size: 50,
                                onTap: () {
                                  for (final track
                                      in local?.getAudioTracks() ??
                                          <MediaStreamTrack>[]) {
                                    track.enabled = !track.enabled;
                                  }
                                },
                              ),
                              const SizedBox(width: 20),
                              _IconButton(
                                C: C,
                                icon: Icons.call_end,
                                color: C.primaryHi,
                                size: 56,
                                onTap: end,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CALL SCAFFOLD (Voice)
// ═══════════════════════════════════════════════════════════
class _CallScaffold extends StatelessWidget {
  final AppPalette C;
  final String title, subtitle, status;
  final bool muted;
  final Color accent;
  final IconData icon;
  final VoidCallback onMute, onEnd;
  final bool isComic;
  final bool isHud;
  const _CallScaffold({
    required this.C,
    required this.title,
    required this.subtitle,
    required this.status,
    required this.muted,
    required this.accent,
    required this.icon,
    required this.onMute,
    required this.onEnd,
    required this.isComic,
    required this.isHud,
  });

  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor:
            isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
        body: Stack(
          children: [
            Positioned.fill(
              child: isComic
                  ? Container(color: C.bg)
                  : (isHud
                      ? Container(color: C.hudBg())
                      : Container(
                          decoration: BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              radius: 1.2,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                              stops: const [0.0, 0.6, 1.0],
                            ),
                          ),
                        )),
            ),
            if (isComic)
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _HalftonePainter(
                        color: C.primaryLo.withValues(alpha: 0.12)),
                  ),
                ),
              ),
            if (isHud)
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _HudGridPainter(color: C.hudGridLine()),
                  ),
                ),
              ),
            SafeArea(
              child: Column(
                children: [
                  const Spacer(),
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 130,
                        height: 130,
                        decoration: isHud
                            ? BoxDecoration(
                                color: accent.withValues(alpha: 0.15),
                                border: Border.all(
                                    color: accent, width: 1.4),
                                boxShadow: [
                                  BoxShadow(
                                    color: accent.withValues(alpha: 0.5),
                                    blurRadius: 20,
                                    spreadRadius: 2,
                                  ),
                                ],
                              )
                            : BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: isComic
                                    ? null
                                    : RadialGradient(colors: [
                                        accent.withValues(alpha: 0.4),
                                        accent.withValues(alpha: 0.15),
                                        Colors.black
                                      ]),
                                color: isComic ? accent : null,
                                border: Border.all(
                                    color: isComic
                                        ? Colors.black
                                        : accent,
                                    width: isComic ? 5 : 3),
                                boxShadow: isComic
                                    ? const [
                                        BoxShadow(
                                          color: Colors.black,
                                          offset: Offset(6, 6),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : [
                                        BoxShadow(
                                            color: accent
                                                .withValues(alpha: 0.6),
                                            blurRadius: 25,
                                            spreadRadius: 3)
                                      ],
                              ),
                        child: Icon(
                          icon,
                          size: 60,
                          color: isComic
                              ? C.contrastTextOn(accent)
                              : (isHud ? accent : accent),
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.contrastTextOn(accent) ==
                                            Colors.white
                                        ? Colors.black
                                        : Colors.white,
                                    offset: const Offset(2, 2),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                      if (!isComic)
                        Positioned(
                          top: 8,
                          right: 8,
                          child: _Led(
                              color: C.primaryHi,
                              size: 12,
                              blink: true),
                        ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Text(
                    title,
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudText() : C.text),
                      fontSize: isComic ? 26 : 24,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(2, 2),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    subtitle.toUpperCase(),
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudNeon() : accent),
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 3,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: isHud
                        ? BoxDecoration(
                            color: C.bgDeep.withValues(alpha: 0.7),
                            border: Border.all(
                                color: C.accent.withValues(alpha: 0.4),
                                width: 1),
                          )
                        : BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(isComic ? 12 : 20),
                            color: isComic
                                ? C.bgDark
                                : Colors.black.withValues(alpha: 0.5),
                            border: Border.all(
                                color: isComic
                                    ? Colors.black
                                    : C.bgDark,
                                width: isComic ? 3 : 1.5),
                            boxShadow: isComic
                                ? const [
                                    BoxShadow(
                                      color: Colors.black,
                                      offset: Offset(3, 3),
                                      blurRadius: 0,
                                    ),
                                  ]
                                : null,
                          ),
                    child: Text(
                      status,
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudText() : C.text),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                      ),
                    ),
                  ),
                  const Spacer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: onMute,
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: isHud
                              ? BoxDecoration(
                                  color: muted
                                      ? C.primaryHi
                                          .withValues(alpha: 0.25)
                                      : C.accent.withValues(alpha: 0.15),
                                  border: Border.all(
                                    color: muted
                                        ? C.primaryHi
                                        : C.accent,
                                    width: 1.4,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: (muted
                                              ? C.primaryHi
                                              : C.accent)
                                          .withValues(alpha: 0.4),
                                      blurRadius: 10,
                                    ),
                                  ],
                                )
                              : BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: isComic
                                      ? null
                                      : LinearGradient(colors: [
                                          C.textSub,
                                          C.bg,
                                          C.bgDark,
                                        ]),
                                  color: isComic ? C.bgDark : null,
                                  border: Border.all(
                                      color: isComic
                                          ? Colors.black
                                          : (muted
                                              ? C.primaryHi
                                              : C.accent),
                                      width: isComic ? 3.5 : 2),
                                ),
                          child: Icon(
                            muted ? Icons.mic_off : Icons.mic,
                            color: isComic
                                ? (muted
                                    ? C.contrastTextOn(C.primaryHi)
                                    : C.comicText)
                                : (isHud
                                    ? (muted ? C.primaryHi : C.accent)
                                    : (muted ? C.primaryHi : C.accent)),
                            size: 24,
                          ),
                        ),
                      ),
                      const SizedBox(width: 22),
                      GestureDetector(
                        onTap: onEnd,
                        child: Container(
                          width: 64,
                          height: 64,
                          decoration: isHud
                              ? BoxDecoration(
                                  color:
                                      C.primaryHi.withValues(alpha: 0.2),
                                  border: Border.all(
                                      color: C.primaryHi, width: 1.4),
                                  boxShadow: [
                                    BoxShadow(
                                      color: C.primaryHi
                                          .withValues(alpha: 0.5),
                                      blurRadius: 14,
                                    ),
                                  ],
                                )
                              : BoxDecoration(
                                  color: C.primaryHi,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.black,
                                    width: isComic ? 4 : 2.5,
                                  ),
                                  boxShadow: isComic
                                      ? const [
                                          BoxShadow(
                                            color: Colors.black,
                                            offset: Offset(4, 4),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : [
                                          BoxShadow(
                                              color: C.primaryHi
                                                  .withValues(alpha: 0.5),
                                              blurRadius: 12)
                                        ],
                                ),
                          child: Icon(
                            Icons.call_end,
                            color: isComic
                                ? C.contrastTextOn(C.primaryHi)
                                : (isHud ? C.primaryHi : Colors.white),
                            size: 28,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// STORIES PAGE
// ═══════════════════════════════════════════════════════════
class CallCrylixStoriesPage extends StatefulWidget {
  final String username, sessionKey, baseUrl;
  const CallCrylixStoriesPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.baseUrl,
  });
  @override
  State<CallCrylixStoriesPage> createState() =>
      _CallCrylixStoriesPageState();
}

class _CallCrylixStoriesPageState extends State<CallCrylixStoriesPage> {
  final picker = ImagePicker();
  List<Map<String, dynamic>> groups = [];
  bool loading = true;

  String mediaUrl(String value) {
    if (value.startsWith('http://') || value.startsWith('https://')) {
      return value;
    }
    return '${widget.baseUrl}${value.startsWith('/') ? '' : '/'}$value';
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (mounted) setState(() => loading = true);
    try {
      http.Response? r;
      for (var attempt = 0; attempt < 3; attempt++) {
        r = await http.get(Uri.parse(
            '${widget.baseUrl}/api/cal/stories?key=${Uri.encodeQueryComponent(widget.sessionKey)}'));
        if (r.statusCode != 429 || attempt == 2) break;
        await Future<void>.delayed(
            Duration(milliseconds: 700 * (attempt + 1)));
      }
      if (r?.statusCode == 200) {
        final data = jsonDecode(r!.body);
        if (data['success'] == true && mounted) {
          setState(() =>
              groups = List<Map<String, dynamic>>.from(data['users'] ?? []));
        }
      }
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  Future<void> createStory(AppPalette C, bool isComic, bool isHud) async {
    final kind = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.image_rounded, color: C.primaryHi),
              title: Text(
                'Foto',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudText() : C.text),
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w800,
                ),
              ),
              onTap: () => Navigator.pop(context, 'image'),
            ),
            ListTile(
              leading:
                  Icon(Icons.video_library_rounded, color: C.primaryHi),
              title: Text(
                'Video',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudText() : C.text),
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w800,
                ),
              ),
              onTap: () => Navigator.pop(context, 'video'),
            ),
          ],
        ),
      ),
    );
    if (kind == null) return;
    final x = kind == 'video'
        ? await picker.pickVideo(source: ImageSource.gallery)
        : await picker.pickImage(source: ImageSource.gallery);
    if (x == null) return;

    final cap = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'CAPTION STORY',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.primaryHi),
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
              const SizedBox(height: 16),
              _InsetPanel(
                C: C,
                child: TextField(
                  controller: cap,
                  maxLength: 120,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudText() : C.text),
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                  ),
                  decoration: InputDecoration(
                    hintText: 'Tulis sesuatu...',
                    hintStyle: TextStyle(
                        color: isComic
                            ? C.comicTextMuted
                            : (isHud
                                ? C.hudTextDim()
                                : C.text.withValues(alpha: 0.4))),
                    border: InputBorder.none,
                    counterStyle: TextStyle(
                        color: isComic
                            ? C.comicTextSub
                            : (isHud ? C.hudTextDim() : C.accent),
                        fontFamily: isComic
                            ? 'ComicNeue'
                            : 'ShareTechMono'),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _IndustrialButton(
                      C: C,
                      color: C.bg,
                      height: 46,
                      onTap: () => Navigator.pop(context, false),
                      child: Text(
                        'BATAL',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _IndustrialButton(
                      C: C,
                      color: C.primaryHi,
                      height: 46,
                      onTap: () => Navigator.pop(context, true),
                      child: Text(
                        'POSTING',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (ok != true) {
      cap.dispose();
      return;
    }

    try {
      final req = http.MultipartRequest(
          'POST', Uri.parse('${widget.baseUrl}/api/cal/stories'));
      req.fields['key'] = widget.sessionKey;
      req.fields['caption'] = cap.text.trim();
      req.files.add(await http.MultipartFile.fromPath('media', x.path));
      final response = await req.send();
      if (response.statusCode >= 200 && response.statusCode < 300) {
        if (mounted) await load();
      }
    } catch (_) {}
    cap.dispose();
  }

  @override
  Widget build(BuildContext c) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            if (loading) {
              return Center(
                child: CircularProgressIndicator(
                    color: C.accent, strokeWidth: 2),
              );
            }
            return SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            Stack(
                              alignment: Alignment.center,
                              children: [
                                Container(
                                  width: 36,
                                  height: 36,
                                  decoration: isHud
                                      ? BoxDecoration(
                                          color: C.primaryHi
                                              .withValues(alpha: 0.15),
                                          border: Border.all(
                                              color: C.primaryHi,
                                              width: 1.4),
                                          boxShadow: [
                                            BoxShadow(
                                              color: C.primaryHi
                                                  .withValues(alpha: 0.35),
                                              blurRadius: 10,
                                            ),
                                          ],
                                        )
                                      : BoxDecoration(
                                          shape: BoxShape.circle,
                                          gradient: isComic
                                              ? null
                                              : RadialGradient(
                                                  colors: [
                                                    C.text,
                                                    C.bg,
                                                    C.bgDark
                                                  ]),
                                          color: isComic
                                              ? C.primaryHi
                                              : null,
                                          border: Border.all(
                                              color: isComic
                                                  ? Colors.black
                                                  : C.primaryHi,
                                              width:
                                                  isComic ? 3 : 1.8),
                                          boxShadow: isComic
                                              ? null
                                              : [
                                                  BoxShadow(
                                                      color: C.primaryHi
                                                          .withValues(
                                                              alpha: 0.4),
                                                      blurRadius: 8)
                                                ],
                                        ),
                                  child: Icon(
                                      Icons.auto_awesome_rounded,
                                      color: isComic
                                          ? C.contrastTextOn(C.primaryHi)
                                          : (isHud
                                              ? C.primaryHi
                                              : C.primaryHi),
                                      size: 16),
                                ),
                                if (!isComic && !isHud)
                                  Positioned(
                                    top: -1,
                                    right: -1,
                                    child: _Led(
                                        color: C.primaryHi,
                                        size: 5,
                                        blink: true),
                                  ),
                              ],
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'STORY CRYLIX',
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicText
                                        : (isHud
                                            ? C.hudNeon()
                                            : C.accentHi),
                                    fontSize: isComic ? 14 : 12,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: isComic
                                        ? 'Bangers'
                                        : 'Orbitron',
                                    letterSpacing: 2,
                                    height: 1,
                                    shadows: isComic
                                        ? [
                                            Shadow(
                                              color:
                                                  C.comicTextOutline,
                                              offset:
                                                  const Offset(1, 1),
                                              blurRadius: 0,
                                            ),
                                          ]
                                        : null,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  '24 jam',
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicTextSub
                                        : (isHud
                                            ? C.hudTextDim()
                                            : C.textSub),
                                    fontSize: 9,
                                    fontFamily: isComic
                                        ? 'ComicNeue'
                                        : 'ShareTechMono',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () => createStory(C, isComic, isHud),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          decoration: isHud
                              ? BoxDecoration(
                                  color: C.primaryHi
                                      .withValues(alpha: 0.15),
                                  border: Border.all(
                                      color: C.primaryHi, width: 1.4),
                                  boxShadow: [
                                    BoxShadow(
                                      color: C.primaryHi
                                          .withValues(alpha: 0.35),
                                      blurRadius: 10,
                                    ),
                                  ],
                                )
                              : BoxDecoration(
                                  borderRadius:
                                      BorderRadius.circular(10),
                                  gradient: isComic
                                      ? null
                                      : LinearGradient(colors: [
                                          C.primaryHi
                                              .withValues(alpha: 0.9),
                                          C.primaryHi
                                              .withValues(alpha: 0.6)
                                        ]),
                                  color: isComic ? C.primaryHi : null,
                                  border: Border.all(
                                      color: isComic
                                          ? Colors.black
                                          : Colors.black
                                              .withValues(alpha: 0.7),
                                      width: isComic ? 3 : 1.5),
                                  boxShadow: isComic
                                      ? const [
                                          BoxShadow(
                                            color: Colors.black,
                                            offset: Offset(3, 3),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : [
                                          BoxShadow(
                                              color: C.primaryHi
                                                  .withValues(alpha: 0.4),
                                              blurRadius: 8)
                                        ],
                                ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.add_rounded,
                                color: isComic
                                    ? C.contrastTextOn(C.primaryHi)
                                    : (isHud
                                        ? C.hudNeon()
                                        : Colors.white),
                                size: 14,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'BUAT',
                                style: TextStyle(
                                  color: isComic
                                      ? C.contrastTextOn(C.primaryHi)
                                      : (isHud
                                          ? C.hudNeon()
                                          : Colors.white),
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                  fontFamily: isComic
                                      ? 'Bangers'
                                      : 'Orbitron',
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  if (groups.isEmpty)
                    Padding(
                      padding: const EdgeInsets.all(32),
                      child: Center(
                        child: Text(
                          'Belum ada story.',
                          style: TextStyle(
                            color: isComic
                                ? C.comicTextSub
                                : (isHud
                                    ? C.hudTextDim()
                                    : C.textSub),
                            fontWeight: FontWeight.w700,
                            fontFamily: isComic
                                ? 'ComicNeue'
                                : 'ShareTechMono',
                          ),
                        ),
                      ),
                    )
                  else
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        childAspectRatio: 0.78,
                      ),
                      itemCount: groups.length,
                      itemBuilder: (_, i) {
                        final g = groups[i];
                        final stories = List<Map<String, dynamic>>.from(
                            g['stories'] ?? []);
                        final first = stories.isNotEmpty
                            ? stories.first
                            : <String, dynamic>{};
                        final media = '${first['mediaUrl'] ?? ''}';
                        return GestureDetector(
                          onTap: stories.isEmpty
                              ? null
                              : () => Navigator.push(
                                    c,
                                    MaterialPageRoute(
                                      builder: (_) => CalStoryViewer(
                                        stories: stories,
                                        baseUrl: widget.baseUrl,
                                        sessionKey: widget.sessionKey,
                                      ),
                                    ),
                                  ),
                          child: Container(
                            decoration: isHud
                                ? BoxDecoration(
                                    border: Border.all(
                                        color: C.accent, width: 1.4),
                                    boxShadow: [
                                      BoxShadow(
                                        color: C.accent
                                            .withValues(alpha: 0.3),
                                        blurRadius: 10,
                                      ),
                                    ],
                                    image: media.isNotEmpty
                                        ? DecorationImage(
                                            image: NetworkImage(
                                                mediaUrl(media)),
                                            fit: BoxFit.cover)
                                        : null,
                                    color:
                                        media.isEmpty ? C.bg : null,
                                  )
                                : BoxDecoration(
                                    color: isComic
                                        ? (media.isEmpty
                                            ? C.bgDark
                                            : null)
                                        : null,
                                    borderRadius:
                                        BorderRadius.circular(14),
                                    border: Border.all(
                                        color: isComic
                                            ? Colors.black
                                            : C.primaryHi
                                                .withValues(alpha: 0.6),
                                        width: isComic ? 4 : 2),
                                    boxShadow: isComic
                                        ? const [
                                            BoxShadow(
                                              color: Colors.black,
                                              offset: Offset(4, 4),
                                              blurRadius: 0,
                                            ),
                                          ]
                                        : [
                                            BoxShadow(
                                                color: C.primaryHi
                                                    .withValues(
                                                        alpha: 0.3),
                                                blurRadius: 10)
                                          ],
                                    image: media.isNotEmpty
                                        ? DecorationImage(
                                            image: NetworkImage(
                                                mediaUrl(media)),
                                            fit: BoxFit.cover)
                                        : null,
                                  ),
                            child: Align(
                              alignment: Alignment.bottomLeft,
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color:
                                      Colors.black.withValues(alpha: 0.8),
                                  borderRadius:
                                      const BorderRadius.vertical(
                                          bottom:
                                              Radius.circular(12)),
                                ),
                                child: Text(
                                  '${g['username']}',
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicText
                                        : (isHud
                                            ? C.hudText()
                                            : C.text),
                                    fontWeight: FontWeight.w900,
                                    fontSize: 11,
                                    fontFamily: isComic
                                        ? 'Bangers'
                                        : 'Orbitron',
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// STORY VIEWER
// ═══════════════════════════════════════════════════════════
class CalStoryViewer extends StatefulWidget {
  final List<Map<String, dynamic>> stories;
  final String baseUrl, sessionKey;
  const CalStoryViewer({
    super.key,
    required this.stories,
    required this.baseUrl,
    required this.sessionKey,
  });
  @override
  State<CalStoryViewer> createState() => _CalStoryViewerState();
}

class _CalStoryViewerState extends State<CalStoryViewer> {
  int i = 0;
  VideoPlayerController? vc;

  String mediaUrl(String value) => value.startsWith('http://') ||
          value.startsWith('https://')
      ? value
      : '${widget.baseUrl}${value.startsWith('/') ? '' : '/'}$value';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await vc?.dispose();
    vc = null;
    if (widget.stories.isEmpty) return;
    final s = widget.stories[i];
    if (s['mediaType'] == 'video') {
      final controller = VideoPlayerController.networkUrl(
          Uri.parse(mediaUrl('${s['mediaUrl'] ?? ''}')));
      vc = controller;
      try {
        await controller.initialize();
        if (!mounted || vc != controller) return;
        setState(() {});
        await controller.play();
      } catch (_) {}
    }
    try {
      await http.post(
        Uri.parse('${widget.baseUrl}/api/cal/stories/view'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'storyId': s['id']}),
      );
    } catch (_) {}
  }

  @override
  void dispose() {
    vc?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            if (widget.stories.isEmpty) {
              return Scaffold(
                backgroundColor:
                    isComic ? C.bg : (isHud ? C.hudBg() : Colors.black),
                body: Center(
                  child: Text(
                    'Story kosong',
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudText() : C.text),
                    ),
                  ),
                ),
              );
            }
            final s = widget.stories[i];
            final isVideo = s['mediaType'] == 'video';

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : Colors.black),
              body: GestureDetector(
                onTap: () {
                  if (i + 1 < widget.stories.length) {
                    setState(() => i++);
                    _load();
                  } else {
                    Navigator.pop(c);
                  }
                },
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (isVideo && vc?.value.isInitialized == true)
                      Center(
                        child: AspectRatio(
                          aspectRatio: vc!.value.aspectRatio,
                          child: VideoPlayer(vc!),
                        ),
                      )
                    else
                      Center(
                        child: Image.network(
                          mediaUrl('${s['mediaUrl'] ?? ''}'),
                          fit: BoxFit.contain,
                        ),
                      ),
                    Positioned(
                      top: 30,
                      left: 0,
                      right: 0,
                      child: Padding(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 18),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                              isHud ? 2 : 10),
                          child: LinearProgressIndicator(
                            value: (i + 1) / widget.stories.length,
                            backgroundColor: isHud
                                ? C.hudTextDim().withValues(alpha: 0.3)
                                : C.text.withValues(alpha: 0.3),
                            valueColor:
                                AlwaysStoppedAnimation(C.accentHi),
                            minHeight: 6,
                          ),
                        ),
                      ),
                    ),
                    if ((s['caption'] ?? '').toString().isNotEmpty)
                      Positioned(
                        bottom: 60,
                        left: 18,
                        right: 18,
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: isHud
                              ? BoxDecoration(
                                  color: C.hudPanel(),
                                  border: Border.all(
                                      color: C.accent, width: 1.4),
                                  boxShadow: [
                                    BoxShadow(
                                      color: C.accent
                                          .withValues(alpha: 0.4),
                                      blurRadius: 12,
                                    ),
                                  ],
                                )
                              : BoxDecoration(
                                  color: isComic
                                      ? C.bgDark
                                      : Colors.black
                                          .withValues(alpha: 0.7),
                                  borderRadius:
                                      BorderRadius.circular(14),
                                  border: Border.all(
                                      color: isComic
                                          ? Colors.black
                                          : C.accentHi,
                                      width: isComic ? 4 : 2),
                                  boxShadow: isComic
                                      ? const [
                                          BoxShadow(
                                            color: Colors.black,
                                            offset: Offset(4, 4),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : null,
                                ),
                          child: Text(
                            '${s['caption']}',
                            style: TextStyle(
                              color: isComic
                                  ? C.comicText
                                  : (isHud ? C.hudText() : C.text),
                              fontSize: isComic ? 16 : 14,
                              fontWeight: FontWeight.w800,
                              fontFamily: isComic
                                  ? 'Bangers'
                                  : 'ShareTechMono',
                              shadows: isComic
                                  ? [
                                      Shadow(
                                        color: C.comicTextOutline,
                                        offset: const Offset(1, 1),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : null,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}