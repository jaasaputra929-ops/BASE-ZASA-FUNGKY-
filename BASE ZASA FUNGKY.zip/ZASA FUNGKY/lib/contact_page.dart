// lib/contact_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage>
    with TickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _entryCtrl;
  late Animation<double> _entryFade;
  late Animation<Offset> _entrySlide;

  final List<Map<String, dynamic>> _contacts = [
    {
      "label": "Telegram",
      "subtitle": "@NtedPakeE",
      "icon": FontAwesomeIcons.telegram,
      "brandColor": const Color(0xFF2AABEE),
      "url": "https://t.me/NtedPakeE",
    },
    {
      "label": "TikTok",
      "subtitle": "@nted.exec",
      "icon": FontAwesomeIcons.tiktok,
      "brandColor": Colors.white,
      "url":
          "https://www.tiktok.com/@nted.exec?_r=1&_t=ZS-97tKcZwgjWn",
    },
  ];

  int? _pressedIndex;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    _entryFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
          parent: _entryCtrl,
          curve: const Interval(0.0, 0.8, curve: Curves.easeOut)),
    );
    _entrySlide = Tween<Offset>(
      begin: const Offset(0, 0.12),
      end: Offset.zero,
    ).animate(CurvedAnimation(
        parent: _entryCtrl, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _entryCtrl.dispose();
    super.dispose();
  }

  Future<void> _launchUrl(String url) async {
    HapticFeedback.lightImpact();
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              extendBodyBehindAppBar: true,
              appBar: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0,
                systemOverlayStyle: SystemUiOverlayStyle.light,
                leading: IconButton(
                  icon: Icon(
                    Icons.arrow_back_ios_new,
                    color: isComic ? Colors.black : C.accent,
                    size: 18,
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
                centerTitle: true,
                title: Text(
                  "CUSTOMER SERVICE",
                  style: TextStyle(
                    color: isComic ? Colors.black : C.text,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w700,
                    fontSize: isComic ? 18 : 13,
                    letterSpacing: isComic ? 1.5 : 2,
                  ),
                ),
              ),
              body: Stack(
                children: [
                  // Background
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color:
                                      C.primaryLo.withOpacity(0.12)),
                            ),
                          )
                        : Container(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(0, -0.5),
                                radius: 0.9,
                                colors: [
                                  C.primary.withOpacity(0.08),
                                  C.bg,
                                  C.bgDeep,
                                ],
                              ),
                            ),
                          ),
                  ),
                  // Grid accent (original only)
                  if (!isComic)
                    Positioned.fill(
                      child: Opacity(
                        opacity: 0.025,
                        child: CustomPaint(
                          size: MediaQuery.of(context).size,
                          painter: _GridPainter(C: C),
                        ),
                      ),
                    ),
                  // Corner accents
                  Positioned(top: 8, left: 8,
                      child: _CornerAccent(
                          C: C,
                          isTop: true,
                          isLeft: true,
                          isComic: isComic)),
                  Positioned(top: 8, right: 8,
                      child: _CornerAccent(
                          C: C,
                          isTop: true,
                          isLeft: false,
                          isComic: isComic)),
                  Positioned(bottom: 8, left: 8,
                      child: _CornerAccent(
                          C: C,
                          isTop: false,
                          isLeft: true,
                          isComic: isComic)),
                  Positioned(bottom: 8, right: 8,
                      child: _CornerAccent(
                          C: C,
                          isTop: false,
                          isLeft: false,
                          isComic: isComic)),
                  // Main content
                  SafeArea(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 22, vertical: 24),
                      child: FadeTransition(
                        opacity: _entryFade,
                        child: SlideTransition(
                          position: _entrySlide,
                          child: Column(
                            children: [
                              _buildHeaderIcon(C, isComic),
                              const SizedBox(height: 20),
                              _buildTitle(C, isComic),
                              const SizedBox(height: 10),
                              _buildDivider(C, isComic),
                              const SizedBox(height: 12),
                              _buildSubtitle(C, isComic),
                              const SizedBox(height: 40),
                              _buildSectionLabel(C, isComic),
                              const SizedBox(height: 14),
                              ..._contacts.asMap().entries.map((e) {
                                final i = e.key;
                                final c = e.value;
                                return Padding(
                                  padding:
                                      const EdgeInsets.only(bottom: 12),
                                  child: _buildContactCard(
                                    C: C,
                                    isComic: isComic,
                                    index: i,
                                    label: c['label'],
                                    subtitle: c['subtitle'],
                                    icon: c['icon'] as IconData,
                                    brandColor: c['brandColor'],
                                    url: c['url'],
                                  ),
                                );
                              }),
                              const SizedBox(height: 40),
                              _buildDivider(C, isComic),
                              const SizedBox(height: 16),
                              _buildFooter(C, isComic),
                              const SizedBox(height: 8),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildHeaderIcon(AppPalette C, bool isComic) {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, child) => Container(
        width: 90,
        height: 90,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isComic ? C.primaryHi : C.bgDark,
          border: Border.all(
            color: isComic
                ? Colors.black
                : C.primary.withValues(
                    alpha: _pulseAnim.value * 0.5),
            width: isComic ? 5 : 1.5,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: C.primary.withValues(
                        alpha: _pulseAnim.value * 0.15),
                    blurRadius: 28,
                  ),
                ],
        ),
        child: Icon(
          Icons.support_agent_rounded,
          color: isComic ? Colors.white : C.primary,
          size: 38,
        ),
      ),
    );
  }

  Widget _buildTitle(AppPalette C, bool isComic) {
    return Text(
      "NEED HELP?",
      style: TextStyle(
        color: isComic ? Colors.black : C.text,
        fontFamily: isComic ? 'Bangers' : 'Orbitron',
        fontWeight: FontWeight.w700,
        fontSize: isComic ? 26 : 20,
        letterSpacing: isComic ? 2 : 3,
        shadows: isComic
            ? const [
                Shadow(
                  color: Colors.black26,
                  offset: Offset(2, 2),
                  blurRadius: 0,
                ),
              ]
            : null,
      ),
    );
  }

  Widget _buildSubtitle(AppPalette C, bool isComic) {
    return Text(
      "Hubungi kami melalui platform\nmedia sosial di bawah ini.",
      textAlign: TextAlign.center,
      style: TextStyle(
        color: isComic
            ? Colors.black.withValues(alpha: 0.6)
            : C.textSub,
        fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
        fontSize: isComic ? 13 : 11,
        letterSpacing: 1,
        height: 1.7,
        fontWeight: isComic ? FontWeight.w700 : null,
      ),
    );
  }

  Widget _buildSectionLabel(AppPalette C, bool isComic) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        isComic ? "CONTACT CHANNELS" : "// CONTACT CHANNELS",
        style: TextStyle(
          color: isComic
              ? Colors.black
              : C.primary.withValues(alpha: 0.6),
          fontFamily: isComic ? 'Bangers' : 'ShareTechMono',
          fontSize: isComic ? 16 : 10,
          letterSpacing: 2,
          fontWeight: isComic ? FontWeight.w900 : null,
        ),
      ),
    );
  }

  Widget _buildDivider(AppPalette C, bool isComic) {
    if (isComic) {
      return Container(width: 60, height: 3, color: Colors.black);
    }
    return Container(
      width: 48,
      height: 1,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            C.primary.withValues(alpha: 0.0),
            C.primary.withValues(alpha: 0.9),
            C.primary.withValues(alpha: 0.0),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter(AppPalette C, bool isComic) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Container(
            width: isComic ? 8 : 5,
            height: isComic ? 8 : 5,
            decoration: BoxDecoration(
              color: isComic
                  ? C.primary
                  : C.primary.withValues(
                      alpha: _pulseAnim.value * 0.6),
              shape: BoxShape.circle,
              border: isComic
                  ? Border.all(color: Colors.black, width: 2)
                  : null,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          "NTED SUPPORT",
          style: TextStyle(
            color: isComic
                ? Colors.black.withValues(alpha: 0.6)
                : C.textSub,
            fontFamily: isComic ? 'Bangers' : 'ShareTechMono',
            fontSize: isComic ? 13 : 10,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(width: 10),
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Container(
            width: isComic ? 8 : 5,
            height: isComic ? 8 : 5,
            decoration: BoxDecoration(
              color: isComic
                  ? C.primary
                  : C.primary.withValues(
                      alpha: _pulseAnim.value * 0.6),
              shape: BoxShape.circle,
              border: isComic
                  ? Border.all(color: Colors.black, width: 2)
                  : null,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildContactCard({
    required AppPalette C,
    required bool isComic,
    required int index,
    required String label,
    required String subtitle,
    required IconData icon,
    required Color brandColor,
    required String url,
  }) {
    final isPressed = _pressedIndex == index;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressedIndex = index),
      onTapUp: (_) {
        setState(() => _pressedIndex = null);
        _launchUrl(url);
      },
      onTapCancel: () => setState(() => _pressedIndex = null),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 18),
        transform: isComic
            ? Matrix4.translationValues(
                isPressed ? 4 : 0, isPressed ? 4 : 0, 0)
            : null,
        decoration: isComic
            ? BoxDecoration(
                color: isPressed ? brandColor : C.bgDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: isPressed
                    ? []
                    : const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(5, 5),
                          blurRadius: 0,
                        ),
                      ],
              )
            : BoxDecoration(
                color: isPressed
                    ? C.primary.withValues(alpha: 0.08)
                    : C.bgDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isPressed
                      ? C.primary.withValues(alpha: 0.5)
                      : C.textSub.withValues(alpha: 0.2),
                  width: 1,
                ),
                boxShadow: isPressed
                    ? [
                        BoxShadow(
                          color: C.primary.withValues(alpha: 0.12),
                          blurRadius: 20,
                        ),
                      ]
                    : [],
              ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: isComic
                    ? Colors.white
                    : brandColor.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : brandColor.withValues(alpha: 0.2),
                  width: isComic ? 3 : 1,
                ),
              ),
              child: Center(
                child: Icon(
                  icon,
                  color: isComic ? Colors.black : brandColor,
                  size: 20,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: isComic ? Colors.black : C.text,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w700,
                      fontSize: isComic ? 17 : 12,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withValues(alpha: 0.7)
                          : C.textSub,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontSize: isComic ? 13 : 11,
                      letterSpacing: 0.5,
                      fontWeight:
                          isComic ? FontWeight.w700 : null,
                    ),
                  ),
                ],
              ),
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 120),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: isComic
                    ? Colors.white
                    : (isPressed
                        ? C.primary.withValues(alpha: 0.15)
                        : Colors.black),
                borderRadius: BorderRadius.circular(isComic ? 10 : 8),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (isPressed
                          ? C.primary.withValues(alpha: 0.4)
                          : C.textSub.withValues(alpha: 0.15)),
                  width: isComic ? 3 : 1,
                ),
              ),
              child: Icon(
                Icons.arrow_forward_ios_rounded,
                color: isComic
                    ? Colors.black
                    : (isPressed ? C.primary : C.textSub),
                size: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CORNER ACCENT
// ═══════════════════════════════════════════════════════════
class _CornerAccent extends StatelessWidget {
  final AppPalette C;
  final bool isTop, isLeft, isComic;
  const _CornerAccent({
    required this.C,
    required this.isTop,
    required this.isLeft,
    required this.isComic,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(20, 20),
      painter: _CornerPainter(
        isTop: isTop,
        isLeft: isLeft,
        color: isComic
            ? Colors.black.withValues(alpha: 0.8)
            : C.primary.withValues(alpha: 0.2),
        thickness: isComic ? 3 : 1.5,
      ),
    );
  }
}

class _CornerPainter extends CustomPainter {
  final bool isTop, isLeft;
  final Color color;
  final double thickness;
  _CornerPainter({
    required this.isTop,
    required this.isLeft,
    required this.color,
    required this.thickness,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = thickness
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final x = isLeft ? 0.0 : size.width;
    final y = isTop ? 0.0 : size.height;
    final dx = isLeft ? size.width * 0.5 : -size.width * 0.5;
    final dy = isTop ? size.height * 0.5 : -size.height * 0.5;
    canvas.drawLine(Offset(x, y), Offset(x + dx, y), paint);
    canvas.drawLine(Offset(x, y), Offset(x, y + dy), paint);
  }

  @override
  bool shouldRepaint(_CornerPainter old) => false;
}

// ═══════════════════════════════════════════════════════════
// GRID PAINTER (original only)
// ═══════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final AppPalette C;
  _GridPainter({required this.C});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = C.textSub.withValues(alpha: 0.5)
      ..strokeWidth = 0.5;
    const spacing = 40.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_GridPainter old) => false;
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) =>
      old.color != color;
}