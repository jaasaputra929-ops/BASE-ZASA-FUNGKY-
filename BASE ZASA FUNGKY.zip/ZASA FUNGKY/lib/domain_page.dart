import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class DomainOsintPage extends StatefulWidget {
  const DomainOsintPage({super.key});

  @override
  State<DomainOsintPage> createState() => _DomainOsintPageState();
}

class _DomainOsintPageState extends State<DomainOsintPage>
    with TickerProviderStateMixin {
  final TextEditingController _domainController = TextEditingController();

  bool _isLoading = false;
  Map<String, dynamic>? _dnsData;
  List<Map<String, dynamic>> _certRecords = [];
  List<String> _uniqueSubdomains = [];
  String? _errorMessage;
  String? _scannedDomain;

  late final AnimationController _pulseAnim;
  late final AnimationController _scanAnim;
  late final AnimationController _resultAnim;

  late final Animation<double> _pulse;
  late final Animation<double> _scan;
  late final Animation<double> _fadeIn;
  late final Animation<Offset> _slideUp;

  @override
  void initState() {
    super.initState();
    _pulseAnim = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1400))
      ..repeat(reverse: true);
    _scanAnim = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800));
    _resultAnim = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 750));

    _pulse = Tween<double>(begin: 0.6, end: 1.0).animate(
        CurvedAnimation(parent: _pulseAnim, curve: Curves.easeInOut));
    _scan = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _scanAnim, curve: Curves.easeInOut));
    _fadeIn = CurvedAnimation(
        parent: _resultAnim, curve: Curves.easeOutQuint);
    _slideUp = Tween<Offset>(
            begin: const Offset(0, 0.16), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _resultAnim, curve: Curves.easeOutExpo));
  }

  @override
  void dispose() {
    _domainController.dispose();
    _pulseAnim.dispose();
    _scanAnim.dispose();
    _resultAnim.dispose();
    super.dispose();
  }

  Future<void> _checkDomain() async {
    final domain = _domainController.text.trim().toLowerCase();
    if (domain.isEmpty) {
      _setError('Masukkan nama domain terlebih dahulu.');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _dnsData = null;
      _certRecords = [];
      _uniqueSubdomains = [];
      _scannedDomain = domain;
    });
    _scanAnim.repeat();

    try {
      final results = await Future.wait([
        _fetchDns(domain),
        _fetchSubdomains(domain),
      ]);

      final dns = results[0] as Map<String, dynamic>?;
      final certs = results[1] as List<Map<String, dynamic>>;

      final Set<String> subSet = {};
      for (final c in certs) {
        final nm = c['name_value']?.toString() ?? '';
        final cn = c['common_name']?.toString() ?? '';
        for (final s in [nm, cn]) {
          if (s.isNotEmpty) {
            for (final part in s.split('\n')) {
              final t = part.trim();
              if (t.isNotEmpty) subSet.add(t);
            }
          }
        }
      }
      final subList = subSet.toList()..sort();

      if (dns != null || certs.isNotEmpty) {
        setState(() {
          _dnsData = dns;
          _certRecords = certs;
          _uniqueSubdomains = subList;
        });
        _resultAnim.forward(from: 0);
      } else {
        _setError('Tidak ada data ditemukan untuk domain ini.');
      }
    } catch (e) {
      _setError('Koneksi gagal. Periksa jaringan Anda.');
    } finally {
      _scanAnim.stop();
      _scanAnim.reset();
      setState(() => _isLoading = false);
    }
  }

  Future<Map<String, dynamic>?> _fetchDns(String domain) async {
    try {
      final url = Uri.parse(
          'https://api.siputzx.my.id/api/tools/dns?domain=$domain');
      final resp =
          await http.get(url).timeout(const Duration(seconds: 12));
      if (resp.statusCode == 200) {
        final j = jsonDecode(resp.body);
        return j['status'] == true ? j['data'] as Map<String, dynamic>? : null;
      }
    } catch (_) {}
    return null;
  }

  Future<List<Map<String, dynamic>>> _fetchSubdomains(String domain) async {
    try {
      final url = Uri.parse(
          'https://rynekoo-api.hf.space/tools/finder/subdomain-finder?domain=$domain');
      final resp =
          await http.get(url).timeout(const Duration(seconds: 20));
      if (resp.statusCode == 200) {
        final j = jsonDecode(resp.body);
        if (j['success'] == true && j['result'] is List) {
          return (j['result'] as List)
              .whereType<Map<String, dynamic>>()
              .toList();
        }
      }
    } catch (_) {}
    return [];
  }

  void _setError(String msg) {
    setState(() {
      _errorMessage = msg;
      _dnsData = null;
      _certRecords = [];
      _uniqueSubdomains = [];
      _isLoading = false;
    });
    _scanAnim.stop();
    _scanAnim.reset();
  }

  void _copy(AppPalette C, String text, String label) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: const Duration(milliseconds: 1400),
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: Center(
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
            decoration: BoxDecoration(
              color: isHud ? C.hudPanel() : C.bgDark,
              borderRadius: BorderRadius.circular(isHud ? 4 : 30),
              border: Border.all(
                  color: isHud
                      ? C.accent.withValues(alpha: 0.6)
                      : C.primaryHi.withValues(alpha: 0.4)),
              boxShadow: [
                BoxShadow(
                    color: C.primaryHi.withValues(alpha: 0.2),
                    blurRadius: 12)
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle_rounded,
                    color: C.primaryHi, size: 15),
                const SizedBox(width: 8),
                Text(
                  '$label disalin',
                  style: TextStyle(
                    color: isHud ? C.hudText() : C.text,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputCard(AppPalette C, bool isHud) {
    return Container(
      decoration: BoxDecoration(
        color: isHud ? C.hudPanel() : C.bgDark,
        borderRadius: isHud ? null : BorderRadius.circular(20),
        border: Border.all(
            color: isHud
                ? C.hudBorder()
                : C.primaryHi.withValues(alpha: 0.18),
            width: isHud ? 1.2 : 1.2),
        boxShadow: [
          BoxShadow(
              color: C.primaryHi.withValues(alpha: isHud ? 0.15 : 0.08),
              blurRadius: isHud ? 15 : 24,
              spreadRadius: 2),
          if (!isHud)
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.5),
                blurRadius: 20,
                offset: const Offset(0, 8)),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  C.primaryHi.withValues(alpha: 0.12),
                  C.primaryHi.withValues(alpha: 0.04)
                ],
              ),
              borderRadius:
                  isHud ? null : const BorderRadius.vertical(top: Radius.circular(20)),
              border: Border(
                  bottom: BorderSide(
                      color: C.primaryHi.withValues(alpha: 0.12),
                      width: 1)),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withValues(alpha: 0.15),
                          border: Border.all(color: C.accent, width: 1.2),
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          color: C.primaryHi.withValues(alpha: 0.1),
                          border: Border.all(
                              color: C.primaryHi.withValues(alpha: 0.3),
                              width: 1),
                        ),
                  child: Icon(Icons.travel_explore,
                      color: isHud ? C.accent : C.primaryHi, size: 18),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'DOMAIN OSINT',
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        letterSpacing: 2.5,
                        color: isHud ? C.hudNeon() : C.text,
                      ),
                    ),
                    Text(
                      'Subdomain & Certificate Scanner',
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontSize: 11,
                        color: isHud ? C.hudTextDim() : C.textSub,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                AnimatedBuilder(
                  animation: _pulse,
                  builder: (_, __) => Opacity(
                    opacity: _pulse.value,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.accent,
                              boxShadow: [
                                BoxShadow(
                                    color:
                                        C.accent.withValues(alpha: 0.9),
                                    blurRadius: 8)
                              ],
                            )
                          : BoxDecoration(
                              shape: BoxShape.circle,
                              color: C.primaryHi,
                              boxShadow: [
                                BoxShadow(
                                    color: C.primaryHi
                                        .withValues(alpha: 0.6),
                                    blurRadius: 6)
                              ],
                            ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
            child: Column(
              children: [
                Stack(
                  children: [
                    TextField(
                      controller: _domainController,
                      keyboardType: TextInputType.url,
                      style: TextStyle(
                        color: isHud ? C.hudText() : C.text,
                        fontSize: 17,
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                      decoration: InputDecoration(
                        hintText: 'contoh: example.com',
                        hintStyle: TextStyle(
                          color: isHud
                              ? C.hudTextDim()
                              : C.textSub.withValues(alpha: 0.5),
                          fontFamily: 'Rajdhani',
                          fontSize: 16,
                        ),
                        filled: true,
                        fillColor: isHud
                            ? C.bgDeep.withValues(alpha: 0.7)
                            : C.bgDeep.withValues(alpha: 0.6),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 17),
                        prefixIcon: Icon(Icons.dns_rounded,
                            color: isHud
                                ? C.accent
                                : C.primaryHi.withValues(alpha: 0.55),
                            size: 20),
                        enabledBorder: isHud
                            ? OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: C.accent.withValues(alpha: 0.4),
                                    width: 1),
                                borderRadius: BorderRadius.circular(2),
                              )
                            : OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: C.primaryHi
                                        .withValues(alpha: 0.2),
                                    width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                        focusedBorder: isHud
                            ? OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: C.accent, width: 1.4),
                                borderRadius: BorderRadius.circular(2),
                              )
                            : OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: C.primaryHi, width: 1.8),
                                borderRadius: BorderRadius.circular(14),
                              ),
                      ),
                      onSubmitted: (_) => _checkDomain(),
                    ),
                    if (_isLoading)
                      Positioned.fill(
                        child: ClipRRect(
                          borderRadius:
                              BorderRadius.circular(isHud ? 2 : 14),
                          child: AnimatedBuilder(
                            animation: _scan,
                            builder: (_, __) => CustomPaint(
                              painter: _ScanPainter(
                                  progress: _scan.value, color: C.primaryHi),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: _isLoading ? null : _checkDomain,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: isHud
                        ? BoxDecoration(
                            color: _isLoading
                                ? C.bgDeep.withValues(alpha: 0.5)
                                : C.primaryHi.withValues(alpha: 0.15),
                            border: Border.all(
                              color: _isLoading
                                  ? C.hudTextDim().withValues(alpha: 0.3)
                                  : C.primaryHi,
                              width: 1.4,
                            ),
                            boxShadow: _isLoading
                                ? null
                                : [
                                    BoxShadow(
                                      color: C.primaryHi
                                          .withValues(alpha: 0.5),
                                      blurRadius: 14,
                                    ),
                                  ],
                          )
                        : BoxDecoration(
                            gradient: _isLoading
                                ? LinearGradient(colors: [
                                    C.bg,
                                    C.bg.withValues(alpha: 0.7)
                                  ])
                                : LinearGradient(
                                    colors: [
                                      C.primary,
                                      C.primaryHi,
                                      C.primaryHi
                                    ],
                                    begin: Alignment.centerLeft,
                                    end: Alignment.centerRight,
                                  ),
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: _isLoading
                                ? []
                                : [
                                    BoxShadow(
                                        color: C.primaryHi
                                            .withValues(alpha: 0.35),
                                        blurRadius: 14,
                                        offset: const Offset(0, 5)),
                                  ],
                          ),
                    child: _isLoading
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 17,
                                height: 17,
                                child: CircularProgressIndicator(
                                    color: isHud
                                        ? C.accent
                                        : C.primaryHi
                                            .withValues(alpha: 0.6),
                                    strokeWidth: 2),
                              ),
                              const SizedBox(width: 12),
                              Text(
                                'MEMINDAI...',
                                style: TextStyle(
                                  fontFamily: 'Rajdhani',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14,
                                  letterSpacing: 2,
                                  color: isHud ? C.hudTextDim() : C.textSub,
                                ),
                              ),
                            ],
                          )
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.radar_rounded,
                                  color: isHud ? C.hudNeon() : Colors.white,
                                  size: 20),
                              const SizedBox(width: 10),
                              Text(
                                'SCAN DOMAIN',
                                style: TextStyle(
                                  fontFamily: 'Rajdhani',
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                  letterSpacing: 2.5,
                                  color:
                                      isHud ? C.hudNeon() : Colors.white,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildError(AppPalette C, bool isHud) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: isHud
          ? BoxDecoration(
              color: Colors.red.withValues(alpha: 0.1),
              border: Border.all(color: Colors.red, width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: Colors.red.withValues(alpha: 0.3),
                  blurRadius: 10,
                ),
              ],
            )
          : BoxDecoration(
              color: C.primaryHi.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: C.primaryHi.withValues(alpha: 0.25)),
            ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: isHud
                ? BoxDecoration(
                    color: Colors.red.withValues(alpha: 0.2),
                    border: Border.all(color: Colors.red, width: 1.2),
                  )
                : BoxDecoration(
                    color: C.primaryHi.withValues(alpha: 0.12),
                    shape: BoxShape.circle,
                  ),
            child: Icon(Icons.error_outline_rounded,
                color: isHud ? Colors.red : C.primaryHi, size: 19),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: TextStyle(
                color: isHud ? C.hudText() : C.text,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w500,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(AppPalette C,
      {required String title,
      required IconData icon,
      required Color accent,
      required List<Widget> children,
      String? badge,
      required bool isHud}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: accent.withValues(alpha: 0.15),
                  blurRadius: 12,
                ),
              ],
            )
          : BoxDecoration(
              color: C.bgDark,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: accent.withValues(alpha: 0.13), width: 1),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 5)),
              ],
            ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(18, 13, 18, 11),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  accent.withValues(alpha: 0.1),
                  accent.withValues(alpha: 0.03),
                ],
              ),
              borderRadius:
                  isHud ? null : const BorderRadius.vertical(top: Radius.circular(18)),
              border: Border(
                  bottom: BorderSide(
                      color: accent.withValues(alpha: 0.1), width: 1)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: isHud
                      ? BoxDecoration(
                          color: accent.withValues(alpha: 0.15),
                          border:
                              Border.all(color: accent, width: 1.2),
                        )
                      : BoxDecoration(
                          color: accent.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                  child: Icon(icon, color: accent, size: 15),
                ),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: TextStyle(
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                    letterSpacing: 2,
                    color: accent,
                  ),
                ),
                if (badge != null) ...[
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.12),
                      borderRadius:
                          BorderRadius.circular(isHud ? 2 : 20),
                      border:
                          Border.all(color: accent.withValues(alpha: 0.3)),
                    ),
                    child: Text(
                      badge,
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                        color: accent,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }

  Widget _buildRow(AppPalette C, String label, String? value,
      {bool copy = false, Color? valueColor, bool isHud = false}) {
    if (value == null || value.trim().isEmpty) return const SizedBox.shrink();
    return InkWell(
      onTap: copy ? () => _copy(C, value, label) : null,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 9),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 110,
              child: Text(
                label,
                style: TextStyle(
                  fontFamily: 'Rajdhani',
                  fontSize: 12,
                  color: isHud ? C.hudTextDim() : C.textSub,
                  letterSpacing: 0.3,
                ),
              ),
            ),
            Expanded(
              child: Text(
                value,
                style: TextStyle(
                  fontFamily: 'Rajdhani',
                  fontSize: 14.5,
                  fontWeight: FontWeight.w600,
                  color: valueColor ??
                      (isHud ? C.hudText() : C.text),
                  height: 1.35,
                ),
              ),
            ),
            if (copy)
              Padding(
                padding: const EdgeInsets.only(left: 6),
                child: Icon(Icons.copy_all_rounded,
                    size: 13,
                    color: isHud
                        ? C.accent.withValues(alpha: 0.5)
                        : C.primaryHi.withValues(alpha: 0.35)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _rowDivider(AppPalette C, bool isHud) => Container(
      height: 1,
      color: isHud ? C.accent.withValues(alpha: 0.2) : C.bg,
      margin: EdgeInsets.zero);

  Widget _buildDnsSection(AppPalette C, bool isHud) {
    if (_dnsData == null) return const SizedBox.shrink();
    final dns = _dnsData!;
    final records = dns['records'] as Map<String, dynamic>? ?? {};

    final List<Widget> rows = [
      _buildRow(C, 'Domain', dns['unicodeDomain']?.toString(),
          copy: true, isHud: isHud),
      _rowDivider(C, isHud),
      _buildRow(C, 'Punycode', dns['punycodeDomain']?.toString(),
          copy: true, isHud: isHud),
    ];

    final nsAnswers =
        records['ns']?['response']?['answer'] as List? ?? [];
    if (nsAnswers.isNotEmpty) {
      rows.add(_rowDivider(C, isHud));
      rows.add(_sectionLabel(C, 'Name Servers', isHud));
      for (final ns in nsAnswers) {
        final t = ns['record']?['target']?.toString();
        if (t != null && t.isNotEmpty) {
          rows.add(_buildRow(C, 'NS', t, copy: true, isHud: isHud));
        }
      }
    }

    final aAnswers =
        records['a']?['response']?['answer'] as List? ?? [];
    if (aAnswers.isNotEmpty) {
      rows.add(_rowDivider(C, isHud));
      rows.add(_sectionLabel(C, 'A Records', isHud));
      for (final a in aAnswers) {
        final d = a['record']?['data']?.toString();
        if (d != null && d.isNotEmpty) {
          rows.add(_buildRow(C, 'IP', d,
              copy: true, valueColor: C.accentHi, isHud: isHud));
        }
      }
    }

    final soaAnswers =
        records['soa']?['response']?['answer'] as List? ?? [];
    if (soaAnswers.isNotEmpty) {
      final soa = soaAnswers.first['record'];
      rows.add(_rowDivider(C, isHud));
      rows.add(_sectionLabel(C, 'SOA Record', isHud));
      rows.add(_buildRow(C, 'Primary NS', soa?['host']?.toString(),
          copy: true, isHud: isHud));
      rows.add(_buildRow(C, 'Admin', soa?['admin']?.toString(),
          copy: true, isHud: isHud));
      rows.add(_buildRow(C, 'Serial', soa?['serial']?.toString(),
          isHud: isHud));
      rows.add(_buildRow(C, 'Refresh', soa?['refresh']?.toString(),
          isHud: isHud));
      rows.add(_buildRow(C, 'Retry', soa?['retry']?.toString(),
          isHud: isHud));
      rows.add(_buildRow(C, 'Expire', soa?['expire']?.toString(),
          isHud: isHud));
      rows.add(_buildRow(C, 'Min TTL', soa?['minimum']?.toString(),
          isHud: isHud));
    }

    return _buildSection(
      C,
      title: 'DNS INFORMATION',
      icon: Icons.dns_rounded,
      accent: C.primaryHi,
      children: rows,
      isHud: isHud,
    );
  }

  Widget _sectionLabel(AppPalette C, String text, bool isHud) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 2),
      child: Text(
        text,
        style: TextStyle(
          fontFamily: 'Rajdhani',
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.5,
          color: isHud ? C.hudTextDim() : C.textSub,
        ),
      ),
    );
  }

  Widget _buildSubdomainSection(AppPalette C, bool isHud) {
    if (_uniqueSubdomains.isEmpty) return const SizedBox.shrink();
    return _buildSection(
      C,
      title: 'SUBDOMAINS',
      icon: Icons.language_rounded,
      accent: C.accent,
      badge: '${_uniqueSubdomains.length} found',
      isHud: isHud,
      children: [
        const SizedBox(height: 4),
        ..._uniqueSubdomains.map((s) => _buildSubItem(C, s, isHud)).toList(),
      ],
    );
  }

  Widget _buildSubItem(AppPalette C, String sub, bool isHud) {
    return InkWell(
      onTap: () => _copy(C, sub, sub),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        margin: const EdgeInsets.only(bottom: 7),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: isHud
            ? BoxDecoration(
                color: C.bgDeep.withValues(alpha: 0.6),
                border: Border.all(
                    color: C.accent.withValues(alpha: 0.3), width: 1),
              )
            : BoxDecoration(
                color: C.bgDeep.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: C.accent.withValues(alpha: 0.08)),
              ),
        child: Row(
          children: [
            Container(
              width: 5,
              height: 5,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent,
                      boxShadow: [
                        BoxShadow(
                            color: C.accent.withValues(alpha: 0.9),
                            blurRadius: 6)
                      ],
                    )
                  : BoxDecoration(
                      color: C.accent, shape: BoxShape.circle),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                sub,
                style: TextStyle(
                  fontFamily: 'Rajdhani',
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: isHud ? C.hudText() : C.text,
                  letterSpacing: 0.3,
                ),
              ),
            ),
            Icon(Icons.copy_all_rounded,
                size: 13,
                color: C.accent.withValues(alpha: isHud ? 0.6 : 0.35)),
          ],
        ),
      ),
    );
  }

  Widget _buildCertSection(AppPalette C, bool isHud) {
    if (_certRecords.isEmpty) return const SizedBox.shrink();

    final Map<String, Map<String, dynamic>> bySerial = {};
    for (final c in _certRecords) {
      final serial = c['serial_number']?.toString() ?? c['id'].toString();
      bySerial.putIfAbsent(serial, () => c);
    }
    final unique = bySerial.values.toList();

    return _buildSection(
      C,
      title: 'SSL CERTIFICATES',
      icon: Icons.verified_rounded,
      accent: C.accentHi,
      badge: '${unique.length} certs',
      isHud: isHud,
      children: [
        const SizedBox(height: 4),
        ...unique.map((c) => _buildCertCard(C, c, isHud)).toList(),
      ],
    );
  }

  Widget _buildCertCard(AppPalette C, Map<String, dynamic> cert, bool isHud) {
    final cn          = cert['common_name']?.toString() ?? '';
    final issuer      = cert['issuer_name']?.toString() ?? '';
    final notBefore   = _fmtDate(cert['not_before']?.toString());
    final notAfter    = _fmtDate(cert['not_after']?.toString());
    final serial      = cert['serial_number']?.toString() ?? '';
    final timestamp   = _fmtDate(cert['entry_timestamp']?.toString());

    final expiry = cert['not_after']?.toString();
    bool isExpired = false;
    if (expiry != null) {
      try {
        isExpired = DateTime.parse(expiry).isBefore(DateTime.now());
      } catch (_) {}
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: isHud
          ? BoxDecoration(
              color: C.bgDeep.withValues(alpha: 0.7),
              border: Border.all(
                color: isExpired
                    ? C.primaryHi.withValues(alpha: 0.5)
                    : C.accentHi.withValues(alpha: 0.4),
                width: 1,
              ),
            )
          : BoxDecoration(
              color: C.bgDeep.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isExpired
                    ? C.primaryHi.withValues(alpha: 0.2)
                    : C.accentHi.withValues(alpha: 0.12),
                width: 1,
              ),
            ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  cn,
                  style: TextStyle(
                    fontFamily: 'Rajdhani',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: isHud ? C.hudText() : C.text,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: isExpired
                      ? C.primaryHi.withValues(alpha: 0.12)
                      : C.accentHi.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(isHud ? 2 : 6),
                  border: Border.all(
                    color: isExpired
                        ? C.primaryHi.withValues(alpha: 0.3)
                        : C.accentHi.withValues(alpha: 0.3),
                  ),
                ),
                child: Text(
                  isExpired ? 'EXPIRED' : 'VALID',
                  style: TextStyle(
                    fontFamily: 'Rajdhani',
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                    color: isExpired ? C.primaryHi : C.accentHi,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
              height: 1,
              color: isHud ? C.accent.withValues(alpha: 0.2) : C.bg),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.account_balance_rounded,
                  size: 12,
                  color: isHud ? C.hudTextDim() : C.textSub),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  _shortIssuer(issuer),
                  style: TextStyle(
                    fontFamily: 'Rajdhani',
                    fontSize: 12,
                    color: isHud ? C.hudTextDim() : C.textSub,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(Icons.date_range_rounded,
                  size: 12,
                  color: isHud ? C.hudTextDim() : C.textSub),
              const SizedBox(width: 6),
              Text(
                '$notBefore  →  $notAfter',
                style: TextStyle(
                  fontFamily: 'Rajdhani',
                  fontSize: 12,
                  color: isExpired
                      ? C.primaryHi.withValues(alpha: 0.7)
                      : C.accentHi.withValues(alpha: 0.8),
                ),
              ),
            ],
          ),
          if (serial.isNotEmpty) ...[
            const SizedBox(height: 6),
            InkWell(
              onTap: () => _copy(C, serial, 'Serial'),
              child: Row(
                children: [
                  Icon(Icons.fingerprint,
                      size: 12,
                      color: isHud ? C.hudTextDim() : C.textSub),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      serial,
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontSize: 11,
                        color: isHud ? C.hudTextDim() : C.textSub,
                        letterSpacing: 0.3,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ],
          if (timestamp.isNotEmpty) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.access_time_rounded,
                    size: 12,
                    color: (isHud ? C.hudTextDim() : C.textSub)
                        .withValues(alpha: 0.6)),
                const SizedBox(width: 6),
                Text(
                  'Logged: $timestamp',
                  style: TextStyle(
                    fontFamily: 'Rajdhani',
                    fontSize: 11,
                    color: (isHud ? C.hudTextDim() : C.textSub)
                        .withValues(alpha: 0.6),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  String _shortIssuer(String issuer) {
    final cnMatch = RegExp(r'CN=([^,]+)').firstMatch(issuer);
    final oMatch = RegExp(r'O=([^,]+)').firstMatch(issuer);
    if (cnMatch != null && oMatch != null) {
      return '${oMatch.group(1)} — ${cnMatch.group(1)}';
    }
    return issuer;
  }

  String _fmtDate(String? raw) {
    if (raw == null || raw.isEmpty) return '';
    try {
      final dt = DateTime.parse(raw);
      final months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
        'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
      ];
      return '${dt.day} ${months[dt.month - 1]} ${dt.year}';
    } catch (_) {
      return raw.split('T').first;
    }
  }

  Widget _buildSummaryBanner(AppPalette C, bool isHud) {
    final subCount = _uniqueSubdomains.length;
    final certCount = (() {
      final Map<String, bool> seen = {};
      for (final c in _certRecords) {
        seen[c['serial_number']?.toString() ?? c['id'].toString()] = true;
      }
      return seen.length;
    })();
    final hasDns = _dnsData != null;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: C.accent.withValues(alpha: 0.2),
                  blurRadius: 12,
                ),
              ],
            )
          : BoxDecoration(
              gradient: LinearGradient(
                colors: [C.bgDark, C.bg],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: C.primaryHi.withValues(alpha: 0.2), width: 1),
              boxShadow: [
                BoxShadow(
                    color: C.primaryHi.withValues(alpha: 0.1),
                    blurRadius: 16,
                    offset: const Offset(0, 5)),
              ],
            ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withValues(alpha: 0.15),
                        border: Border.all(color: C.accent, width: 1),
                      )
                    : BoxDecoration(
                        color: C.primaryHi.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: C.primaryHi.withValues(alpha: 0.3)),
                      ),
                child: Row(
                  children: [
                    Container(
                      width: 6, height: 6,
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.accent,
                              boxShadow: [
                                BoxShadow(
                                    color: C.accent.withValues(alpha: 0.9),
                                    blurRadius: 6)
                              ],
                            )
                          : BoxDecoration(
                              color: C.primaryHi, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'SCAN SELESAI',
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.5,
                        color: isHud ? C.hudNeon() : C.primaryHi,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Icon(Icons.language_rounded,
                  size: 14,
                  color: (isHud ? C.hudTextDim() : C.textSub)
                      .withValues(alpha: 0.6)),
              const SizedBox(width: 5),
              Text(
                _scannedDomain ?? '',
                style: TextStyle(
                  fontFamily: 'Rajdhani',
                  fontSize: 13,
                  color: isHud ? C.hudTextDim() : C.textSub,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _statChip(C,
                  icon: Icons.language_rounded,
                  label: 'Subdomains',
                  value: subCount.toString(),
                  color: C.accent,
                  isHud: isHud),
              const SizedBox(width: 10),
              _statChip(C,
                  icon: Icons.verified_rounded,
                  label: 'Sertifikat',
                  value: certCount.toString(),
                  color: C.accentHi,
                  isHud: isHud),
              const SizedBox(width: 10),
              _statChip(C,
                  icon: Icons.dns_rounded,
                  label: 'DNS',
                  value: hasDns ? 'OK' : '-',
                  color: C.primaryHi,
                  isHud: isHud),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statChip(AppPalette C,
      {required IconData icon,
      required String label,
      required String value,
      required Color color,
      required bool isHud}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: isHud
            ? BoxDecoration(
                color: color.withValues(alpha: 0.1),
                border: Border.all(color: color.withValues(alpha: 0.4), width: 1),
              )
            : BoxDecoration(
                color: color.withValues(alpha: 0.07),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: color.withValues(alpha: 0.18)),
              ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(height: 5),
            Text(
              value,
              style: TextStyle(
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w800,
                fontSize: 16,
                color: color,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Rajdhani',
                fontSize: 10,
                color: isHud ? C.hudTextDim() : C.textSub,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;
            final hasResult = _dnsData != null ||
                _certRecords.isNotEmpty ||
                _uniqueSubdomains.isNotEmpty;

            return Scaffold(
              backgroundColor: isHud ? C.hudBg() : C.bgDeep,
              extendBodyBehindAppBar: true,
              appBar: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0,
                centerTitle: true,
                systemOverlayStyle: SystemUiOverlayStyle.light,
                leading: Padding(
                  padding: const EdgeInsets.all(10),
                  child: GestureDetector(
                    onTap: () => Navigator.maybePop(context),
                    child: Container(
                      decoration: BoxDecoration(
                        color: isHud ? C.hudPanel() : C.bgDark,
                        borderRadius:
                            BorderRadius.circular(isHud ? 2 : 10),
                        border: Border.all(
                            color: isHud
                                ? C.hudBorder()
                                : C.primaryHi.withValues(alpha: 0.2)),
                      ),
                      child: Icon(Icons.arrow_back_ios_rounded,
                          color: isHud ? C.hudNeon() : C.text, size: 15),
                    ),
                  ),
                ),
                title: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.radar_rounded,
                        color: isHud ? C.hudNeon() : C.primaryHi, size: 16),
                    const SizedBox(width: 8),
                    Text(
                      'DOMAIN OSINT',
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w800,
                        color: isHud ? C.hudNeon() : C.text,
                        fontSize: 15,
                        letterSpacing: 3,
                      ),
                    ),
                  ],
                ),
              ),
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isHud
                        ? CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()))
                        : CustomPaint(painter: _BgPainter(C: C)),
                  ),
                  if (!isHud) ...[
                    Positioned(
                      top: -100, left: -60,
                      child: _glowOrb(300, C.primaryHi, 0.06),
                    ),
                    Positioned(
                      bottom: -80, right: -80,
                      child: _glowOrb(220, C.primary, 0.04),
                    ),
                  ],
                  SafeArea(
                    child: CustomScrollView(
                      physics: const BouncingScrollPhysics(),
                      slivers: [
                        SliverPadding(
                          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                          sliver: SliverToBoxAdapter(
                              child: _buildInputCard(C, isHud)),
                        ),
                        if (_errorMessage != null)
                          SliverPadding(
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                            sliver: SliverToBoxAdapter(
                                child: _buildError(C, isHud)),
                          ),
                        if (hasResult)
                          SliverPadding(
                            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                            sliver: SliverToBoxAdapter(
                              child: FadeTransition(
                                opacity: _fadeIn,
                                child: SlideTransition(
                                  position: _slideUp,
                                  child: Column(
                                    children: [
                                      _buildSummaryBanner(C, isHud),
                                      _buildDnsSection(C, isHud),
                                      _buildSubdomainSection(C, isHud),
                                      _buildCertSection(C, isHud),
                                      const SizedBox(height: 28),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _glowOrb(double size, Color color, double opacity) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withValues(alpha: opacity), Colors.transparent],
        ),
      ),
    );
  }
}

class _ScanPainter extends CustomPainter {
  final double progress;
  final Color color;
  const _ScanPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final y = size.height * progress;
    final paint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          color.withValues(alpha: 0),
          color.withValues(alpha: 0.5),
          color.withValues(alpha: 0),
        ],
        stops: const [0, 0.5, 1],
      ).createShader(Rect.fromLTWH(0, y - 22, size.width, 44));
    canvas.drawRect(Rect.fromLTWH(0, y - 22, size.width, 44), paint);
  }

  @override
  bool shouldRepaint(_ScanPainter o) => o.progress != progress;
}

class _BgPainter extends CustomPainter {
  final AppPalette C;
  _BgPainter({required this.C});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = C.primaryHi.withValues(alpha: 0.022)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_BgPainter o) => o.C != C;
}