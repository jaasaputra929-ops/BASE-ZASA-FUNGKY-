// lib/manage_server.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HELPER WIDGETS
// ═══════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 12});
  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 8});
  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withOpacity(0.6), width: 1),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: C.accent.withOpacity(0.15),
              blurRadius: 12,
            ),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _Screw(C: C, size: 12)),
            Positioned(top: 0, right: 0, child: _Screw(C: C, size: 12)),
            Positioned(bottom: 0, left: 0, child: _Screw(C: C, size: 12)),
            Positioned(bottom: 0, right: 0, child: _Screw(C: C, size: 12)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6),
              blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 48,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final enabled = widget.onTap != null;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            }
          : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: isHud
            ? BoxDecoration(
                color: enabled
                    ? (_pressed
                        ? widget.color.withOpacity(0.25)
                        : widget.color.withOpacity(0.15))
                    : C.bgDeep.withOpacity(0.5),
                border: Border.all(
                  color: enabled
                      ? widget.color
                      : C.hudTextDim().withOpacity(0.4),
                  width: 1.4,
                ),
                boxShadow: enabled && !_pressed
                    ? [
                        BoxShadow(
                          color: widget.color.withOpacity(0.35),
                          blurRadius: 10,
                        ),
                      ]
                    : null,
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                gradient: isComic
                    ? null
                    : LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: _pressed
                            ? [
                                widget.color.withOpacity(0.4),
                                widget.color.withOpacity(0.2)
                              ]
                            : [
                                widget.color,
                                widget.color.withOpacity(0.7)
                              ],
                      ),
                color: isComic ? widget.color : null,
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : widget.color.withOpacity(0.9),
                  width: isComic ? 3.5 : 1.5,
                ),
                boxShadow: isComic
                    ? (_pressed
                        ? []
                        : const [
                            BoxShadow(
                                color: Colors.black,
                                offset: Offset(4, 4),
                                blurRadius: 0),
                          ])
                    : null,
              ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic && !isHud) ...[
              Positioned(top: 3, left: 3, child: _Rivet(C: C, size: 5)),
              Positioned(top: 3, right: 3, child: _Rivet(C: C, size: 5)),
              Positioned(bottom: 3, left: 3, child: _Rivet(C: C, size: 5)),
              Positioned(bottom: 3, right: 3, child: _Rivet(C: C, size: 5)),
            ],
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child:
                  Opacity(opacity: enabled ? 1 : 0.5, child: widget.child),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// MANAGE SERVER PAGE
// ═══════════════════════════════════════════════════════════
class ManageServerPage extends StatefulWidget {
  final String keyToken;
  const ManageServerPage({super.key, required this.keyToken});

  @override
  State<ManageServerPage> createState() => _ManageServerPageState();
}

class _ManageServerPageState extends State<ManageServerPage> {
  List<Map<String, dynamic>> vpsList = [];
  bool isLoading = false;

  final _hostController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchVpsList();
  }

  @override
  void dispose() {
    _hostController.dispose();
    _userController.dispose();
    _passController.dispose();
    super.dispose();
  }

  Future<void> _fetchVpsList() async {
    final C = AppTheme.current.value;
    setState(() => isLoading = true);
    final uri = Uri.parse(
        'http://angelacantik.zone.id:3631/myServer?key=${widget.keyToken}');
    try {
      final res = await http.get(uri);
      final data = jsonDecode(res.body);
      setState(() {
        vpsList = List<Map<String, dynamic>>.from(data);
      });
    } catch (_) {
      _showError(C, "Gagal mengambil data VPS.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _addVps() async {
    final C = AppTheme.current.value;
    final host = _hostController.text.trim();
    final user = _userController.text.trim();
    final pass = _passController.text.trim();

    if (host.isEmpty || user.isEmpty || pass.isEmpty) {
      _showError(C, "Isi semua field terlebih dahulu.");
      return;
    }

    final uri = Uri.parse('http://angelacantik.zone.id:3631/addServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
        'username': user,
        'password': pass,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _hostController.clear();
        _userController.clear();
        _passController.clear();
        _fetchVpsList();
      } else {
        _showError(C, data['error'] ?? 'Gagal menambah VPS');
      }
    } catch (_) {
      _showError(C, "Gagal terhubung ke server.");
    }
  }

  Future<void> _deleteVps(String host) async {
    final C = AppTheme.current.value;
    final uri = Uri.parse('http://angelacantik.zone.id:3631/delServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _fetchVpsList();
      } else {
        _showError(C, "Gagal menghapus VPS.");
      }
    } catch (_) {
      _showError(C, "Gagal menghubungi server.");
    }
  }

  void _showError(AppPalette C, String msg) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Icon(Icons.error_outline,
                      color: isComic
                          ? Colors.black
                          : (isHud ? C.primaryHi : C.primaryHi),
                      size: 20),
                  const SizedBox(width: 10),
                  Text("Error",
                      style: TextStyle(
                        color: isComic
                            ? Colors.black
                            : (isHud ? C.hudNeon() : C.primaryHi),
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontSize: isComic ? 18 : 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      )),
                ],
              ),
              const SizedBox(height: 12),
              Text(msg,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withOpacity(0.7)
                        : (isHud ? C.hudText() : C.text.withOpacity(0.7)),
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontSize: isComic ? 13 : 11,
                    height: 1.5,
                  )),
              const SizedBox(height: 20),
              _IndustrialButton(
                C: C,
                color: C.primaryHi,
                height: 44,
                onTap: () => Navigator.pop(context),
                child: Center(
                    child: Text('OK',
                        style: TextStyle(
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : (isHud ? C.hudText() : Colors.white),
                          fontSize: isComic ? 15 : 11,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                        ))),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddDialog(AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Tambah VPS",
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudNeon() : C.primaryHi),
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontSize: isComic ? 20 : 13,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  )),
              const SizedBox(height: 16),
              _buildInput(C, isComic, isHud, "IP VPS", _hostController),
              _buildInput(C, isComic, isHud, "Username", _userController),
              _buildInput(C, isComic, isHud, "Password", _passController),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _IndustrialButton(
                      C: C,
                      color: C.bg,
                      height: 44,
                      onTap: () => Navigator.pop(context),
                      child: Center(
                          child: Text('BATAL',
                              style: TextStyle(
                                color: isComic
                                    ? C.comicText
                                    : (isHud ? C.hudText() : Colors.white),
                                fontSize: isComic ? 15 : 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                letterSpacing: 2,
                              ))),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _IndustrialButton(
                      C: C,
                      color: C.primaryHi,
                      height: 44,
                      onTap: () {
                        Navigator.pop(context);
                        _addVps();
                      },
                      child: Center(
                          child: Text('TAMBAH',
                              style: TextStyle(
                                color: isComic
                                    ? C.contrastTextOn(C.primaryHi)
                                    : (isHud ? C.hudText() : Colors.white),
                                fontSize: isComic ? 15 : 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                letterSpacing: 2,
                              ))),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInput(AppPalette C, bool isComic, bool isHud,
      String label, TextEditingController controller) {
    if (isHud) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Container(
          decoration: BoxDecoration(
            color: C.bgDeep.withOpacity(0.7),
            border: Border.all(
                color: C.accent.withOpacity(0.4), width: 1),
          ),
          child: TextField(
            controller: controller,
            style: TextStyle(color: C.hudText()),
            decoration: InputDecoration(
              labelText: label,
              labelStyle: TextStyle(color: C.hudTextDim()),
              prefixIcon: Icon(Icons.dns_rounded,
                  color: C.accent, size: 18),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 14),
            ),
          ),
        ),
      );
    }

    if (isComic) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.black, width: 3),
          ),
          child: TextField(
            controller: controller,
            style: const TextStyle(
                color: Colors.black,
                fontFamily: 'ComicNeue',
                fontWeight: FontWeight.w700),
            cursorColor: Colors.black,
            decoration: InputDecoration(
              labelText: label,
              labelStyle: TextStyle(
                  color: Colors.black.withOpacity(0.5),
                  fontFamily: 'ComicNeue'),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 14),
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        style: TextStyle(color: C.text),
        cursorColor: C.accent,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: C.text.withOpacity(0.7)),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: C.primaryHi.withOpacity(0.5)),
            borderRadius: BorderRadius.circular(12),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: C.primaryHi, width: 2),
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return SafeArea(
              child: Scaffold(
                backgroundColor:
                    isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
                body: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: Container(color: C.bg),
                      ),
                    if (isHud)
                      Positioned.fill(
                        child: CustomPaint(
                          painter: _HudGridPainter(
                              color: C.hudGridLine()),
                        ),
                      ),
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("My VPS List",
                                  style: TextStyle(
                                      fontSize: isComic ? 22 : 18,
                                      color: isComic
                                          ? C.comicText
                                          : (isHud
                                              ? C.hudNeon()
                                              : C.text),
                                      fontWeight: FontWeight.w900,
                                      fontFamily: isComic
                                          ? 'Bangers'
                                          : 'Orbitron',
                                      letterSpacing: 2)),
                              GestureDetector(
                                onTap: () => _showAddDialog(C),
                                child: Container(
                                  width: 40,
                                  height: 40,
                                  decoration: isHud
                                      ? BoxDecoration(
                                          color: C.accent
                                              .withOpacity(0.15),
                                          border: Border.all(
                                              color: C.accent,
                                              width: 1.2),
                                          boxShadow: [
                                            BoxShadow(
                                              color: C.accent
                                                  .withOpacity(0.35),
                                              blurRadius: 8,
                                            ),
                                          ],
                                        )
                                      : BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          gradient: isComic
                                              ? null
                                              : LinearGradient(
                                                  colors: [
                                                    C.accentHi,
                                                    C.accent,
                                                    C.primaryLo
                                                  ]),
                                          color:
                                              isComic ? C.primaryHi : null,
                                          border: Border.all(
                                              color: isComic
                                                  ? Colors.black
                                                  : C.accentShine,
                                              width: isComic ? 3 : 1.5)),
                                  child: Icon(Icons.add,
                                      color: isComic
                                          ? Colors.white
                                          : (isHud
                                              ? C.hudNeon()
                                              : C.bgDeep),
                                      size: 20),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Container(
                            height: 2,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  C.primaryHi.withOpacity(0.5),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Expanded(
                            child: isLoading
                                ? Center(
                                    child: CircularProgressIndicator(
                                        color: isComic
                                            ? Colors.black
                                            : (isHud
                                                ? C.accent
                                                : C.accent)))
                                : vpsList.isEmpty
                                    ? Center(
                                        child: Text(
                                            "Belum ada VPS terdaftar",
                                            style: TextStyle(
                                                color: isComic
                                                    ? C.comicTextSub
                                                    : (isHud
                                                        ? C.hudTextDim()
                                                        : C.textSub),
                                                fontFamily: isComic
                                                    ? 'ComicNeue'
                                                    : 'ShareTechMono',
                                                fontSize: 13)),
                                      )
                                    : ListView.builder(
                                        itemCount: vpsList.length,
                                        itemBuilder: (context, index) {
                                          final vps = vpsList[index];
                                          return Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 10),
                                            child: _MetalPlate(
                                              C: C,
                                              padding:
                                                  const EdgeInsets.all(12),
                                              child: Row(
                                                children: [
                                                  Stack(
                                                    alignment:
                                                        Alignment.center,
                                                    children: [
                                                      Container(
                                                        width: 40,
                                                        height: 40,
                                                        decoration: isHud
                                                            ? BoxDecoration(
                                                                color: C
                                                                    .accent
                                                                    .withOpacity(
                                                                        0.15),
                                                                border: Border.all(
                                                                    color: C
                                                                        .accent,
                                                                    width:
                                                                        1.2),
                                                              )
                                                            : BoxDecoration(
                                                                shape: BoxShape
                                                                    .circle,
                                                                gradient: isComic
                                                                    ? null
                                                                    : RadialGradient(
                                                                        colors: [
                                                                          C.text,
                                                                          C.bg,
                                                                          C.bgDark
                                                                        ]),
                                                                color: isComic
                                                                    ? C
                                                                        .primaryHi
                                                                    : null,
                                                                border: Border.all(
                                                                    color: isComic
                                                                        ? Colors
                                                                            .black
                                                                        : C
                                                                            .primaryHi,
                                                                    width: isComic
                                                                        ? 3
                                                                        : 1.5),
                                                              ),
                                                        child: Icon(
                                                            Icons
                                                                .dns_rounded,
                                                            color: isComic
                                                                ? Colors.white
                                                                : (isHud
                                                                    ? C.accent
                                                                    : C
                                                                        .primaryHi),
                                                            size: 18),
                                                      ),
                                                    ],
                                                  ),
                                                  const SizedBox(width: 12),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                            "${vps['host']}",
                                                            style: TextStyle(
                                                              color: isComic
                                                                  ? Colors
                                                                      .black
                                                                  : (isHud
                                                                      ? C.hudText()
                                                                      : C.text),
                                                              fontFamily: isComic
                                                                  ? 'Bangers'
                                                                  : 'Orbitron',
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w900,
                                                              fontSize:
                                                                  isComic
                                                                      ? 16
                                                                      : 13,
                                                              letterSpacing:
                                                                  0.5,
                                                            )),
                                                        const SizedBox(
                                                            height: 3),
                                                        Text(
                                                            "User: ${vps['username']}",
                                                            style: TextStyle(
                                                              color: isComic
                                                                  ? Colors.black
                                                                      .withOpacity(
                                                                          0.6)
                                                                  : (isHud
                                                                      ? C.hudTextDim()
                                                                      : C.textSub),
                                                              fontFamily: isComic
                                                                  ? 'ComicNeue'
                                                                  : 'ShareTechMono',
                                                              fontSize:
                                                                  isComic
                                                                      ? 12
                                                                      : 10,
                                                            )),
                                                      ],
                                                    ),
                                                  ),
                                                  GestureDetector(
                                                    onTap: () => _deleteVps(
                                                        vps['host']),
                                                    child: Container(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              8),
                                                      decoration: isHud
                                                          ? BoxDecoration(
                                                              color: C.primaryHi
                                                                  .withOpacity(
                                                                      0.15),
                                                              border: Border.all(
                                                                  color: C
                                                                      .primaryHi,
                                                                  width: 1),
                                                            )
                                                          : BoxDecoration(
                                                              shape: BoxShape
                                                                  .circle,
                                                              color: isComic
                                                                  ? C.accent
                                                                  : C.primaryHi
                                                                      .withOpacity(
                                                                          0.2),
                                                              border: Border.all(
                                                                  color: isComic
                                                                      ? Colors
                                                                          .black
                                                                      : C
                                                                          .primaryHi
                                                                          .withOpacity(
                                                                              0.6),
                                                                  width:
                                                                      isComic
                                                                          ? 2.5
                                                                          : 1),
                                                            ),
                                                      child: Icon(
                                                          Icons
                                                              .delete_outline,
                                                          color: isComic
                                                              ? C.contrastTextOn(
                                                                  C.accent)
                                                              : (isHud
                                                                  ? C
                                                                      .primaryHi
                                                                  : Colors
                                                                      .white),
                                                          size: 16),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}