// lib/app_theme.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum ThemeStyle { original, comic3d, hudTactical }

class ThemeStyleInfo {
  final ThemeStyle style;
  final String name;
  final String id;
  final String description;
  final IconData icon;

  const ThemeStyleInfo({
    required this.style,
    required this.name,
    required this.id,
    required this.description,
    required this.icon,
  });

  static const List<ThemeStyleInfo> all = [
    ThemeStyleInfo(
      style: ThemeStyle.original,
      name: 'ORIGINAL',
      id: 'original',
      description: 'Industrial metal · tactical · dark',
      icon: Icons.bolt_rounded,
    ),
    ThemeStyleInfo(
      style: ThemeStyle.comic3d,
      name: '3D COMIC',
      id: 'comic3d',
      description: 'Pop art · bold outline · playful',
      icon: Icons.bubble_chart_rounded,
    ),
    ThemeStyleInfo(
      style: ThemeStyle.hudTactical,
      name: 'HUD TACTICAL',
      id: 'hud_tactical',
      description: 'Sci-fi HUD · neon grid · cyber tactical',
      icon: Icons.radar_rounded,
    ),
  ];

  static ThemeStyleInfo getById(String id) {
    return all.firstWhere((s) => s.id == id, orElse: () => all.first);
  }
}

class AppPalette {
  final String name;
  final String id;
  final Color primary;
  final Color primaryHi;
  final Color primaryLo;
  final Color accent;
  final Color accentHi;
  final Color accentShine;
  final Color bg;
  final Color bgDark;
  final Color bgDeep;
  final Color text;
  final Color textSub;

  const AppPalette({
    required this.name,
    required this.id,
    required this.primary,
    required this.primaryHi,
    required this.primaryLo,
    required this.accent,
    required this.accentHi,
    required this.accentShine,
    required this.bg,
    required this.bgDark,
    required this.bgDeep,
    required this.text,
    required this.textSub,
  });
}

class AppPalettes {
  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 1: DARK & BOLD (10) ═══
  // ══════════════════════════════════════════════════════════

  static const bloodRed = AppPalette(
    name: 'Blood Red', id: 'blood_red',
    primary: Color(0xFFCC1010), primaryHi: Color(0xFFFF3030),
    primaryLo: Color(0xFF4A0000), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF0A0A0A), bgDark: Color(0xFF1A0A0A),
    bgDeep: Color(0xFF000000), text: Color(0xFFF5F0E8),
    textSub: Color(0xFF8A8A8A),
  );

  static const cyberBlue = AppPalette(
    name: 'Cyber Blue', id: 'cyber_blue',
    primary: Color(0xFF1976D2), primaryHi: Color(0xFF42A5F5),
    primaryLo: Color(0xFF0D47A1), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80DEEA), accentShine: Color(0xFFE0F7FA),
    bg: Color(0xFF0A0A14), bgDark: Color(0xFF0A1420),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0F8FF),
    textSub: Color(0xFF78909C),
  );

  static const neonGreen = AppPalette(
    name: 'Neon Green', id: 'neon_green',
    primary: Color(0xFF00C853), primaryHi: Color(0xFF00E676),
    primaryLo: Color(0xFF1B5E20), accent: Color(0xFF76FF03),
    accentHi: Color(0xFFB2FF59), accentShine: Color(0xFFCCFF90),
    bg: Color(0xFF0A1408), bgDark: Color(0xFF0D2010),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8F5E9),
    textSub: Color(0xFF66BB6A),
  );

  static const purpleMystic = AppPalette(
    name: 'Purple Mystic', id: 'purple_mystic',
    primary: Color(0xFF9C27B0), primaryHi: Color(0xFFCE93D8),
    primaryLo: Color(0xFF4A148C), accent: Color(0xFFE040FB),
    accentHi: Color(0xFFEA80FC), accentShine: Color(0xFFF3E5F5),
    bg: Color(0xFF0F0A14), bgDark: Color(0xFF1A0F20),
    bgDeep: Color(0xFF000000), text: Color(0xFFF3E5F5),
    textSub: Color(0xFF9575CD),
  );

  static const goldRoyal = AppPalette(
    name: 'Gold Royal', id: 'gold_royal',
    primary: Color(0xFFD4AF37), primaryHi: Color(0xFFF5DEB3),
    primaryLo: Color(0xFF6B5015), accent: Color(0xFFFFD700),
    accentHi: Color(0xFFFFF3B0), accentShine: Color(0xFFFFFDE7),
    bg: Color(0xFF141008), bgDark: Color(0xFF201808),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF8E1),
    textSub: Color(0xFFBCAAA4),
  );

  static const pinkNeon = AppPalette(
    name: 'Pink Neon', id: 'pink_neon',
    primary: Color(0xFFE91E63), primaryHi: Color(0xFFFF4081),
    primaryLo: Color(0xFF880E4F), accent: Color(0xFFFF80AB),
    accentHi: Color(0xFFFFB1C1), accentShine: Color(0xFFFFE4EC),
    bg: Color(0xFF140A10), bgDark: Color(0xFF200F18),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0F5),
    textSub: Color(0xFFF48FB1),
  );

  static const orangeFire = AppPalette(
    name: 'Orange Fire', id: 'orange_fire',
    primary: Color(0xFFE65100), primaryHi: Color(0xFFFF9800),
    primaryLo: Color(0xFFBF360C), accent: Color(0xFFFFC107),
    accentHi: Color(0xFFFFE082), accentShine: Color(0xFFFFF8E1),
    bg: Color(0xFF140A00), bgDark: Color(0xFF201000),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF3E0),
    textSub: Color(0xFFFFB74D),
  );

  static const obsidianBlack = AppPalette(
    name: 'Obsidian Black', id: 'obsidian_black',
    primary: Color(0xFF1C1C1E), primaryHi: Color(0xFF2C2C2E),
    primaryLo: Color(0xFF0A0A0C), accent: Color(0xFFBFBFBF),
    accentHi: Color(0xFFDFDFDF), accentShine: Color(0xFFF5F5F5),
    bg: Color(0xFF000000), bgDark: Color(0xFF0A0A0A),
    bgDeep: Color(0xFF000000), text: Color(0xFFEDEDED),
    textSub: Color(0xFF8E8E93),
  );

  static const carbonFiber = AppPalette(
    name: 'Carbon Fiber', id: 'carbon_fiber',
    primary: Color(0xFF212121), primaryHi: Color(0xFF3A3A3A),
    primaryLo: Color(0xFF0F0F0F), accent: Color(0xFFFF5722),
    accentHi: Color(0xFFFF8A65), accentShine: Color(0xFFFFBBA0),
    bg: Color(0xFF0A0A0A), bgDark: Color(0xFF141414),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8E8E8),
    textSub: Color(0xFF9E9E9E),
  );

  static const ravenDark = AppPalette(
    name: 'Raven Dark', id: 'raven_dark',
    primary: Color(0xFF1F1F2E), primaryHi: Color(0xFF35354A),
    primaryLo: Color(0xFF0F0F1A), accent: Color(0xFF00BCD4),
    accentHi: Color(0xFF4DD0E1), accentShine: Color(0xFFB2EBF2),
    bg: Color(0xFF080810), bgDark: Color(0xFF101018),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8E8F0),
    textSub: Color(0xFF8585A0),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 2: COOL & FRESH (10) ═══
  // ══════════════════════════════════════════════════════════

  static const cyanIce = AppPalette(
    name: 'Cyan Ice', id: 'cyan_ice',
    primary: Color(0xFF00ACC1), primaryHi: Color(0xFF4DD0E1),
    primaryLo: Color(0xFF006064), accent: Color(0xFF80DEEA),
    accentHi: Color(0xFFB2EBF2), accentShine: Color(0xFFE0F7FA),
    bg: Color(0xFF08141A), bgDark: Color(0xFF0D2028),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0F7FA),
    textSub: Color(0xFF4DD0E1),
  );

  static const matrixGreen = AppPalette(
    name: 'Matrix', id: 'matrix',
    primary: Color(0xFF00FF41), primaryHi: Color(0xFF69FF77),
    primaryLo: Color(0xFF003B00), accent: Color(0xFF39FF14),
    accentHi: Color(0xFF7FFF00), accentShine: Color(0xFFADFF2F),
    bg: Color(0xFF000000), bgDark: Color(0xFF001100),
    bgDeep: Color(0xFF000000), text: Color(0xFF00FF41),
    textSub: Color(0xFF00AA22),
  );

  static const oceanBlue = AppPalette(
    name: 'Ocean Blue', id: 'ocean_blue',
    primary: Color(0xFF0277BD), primaryHi: Color(0xFF039BE5),
    primaryLo: Color(0xFF01579B), accent: Color(0xFF4FC3F7),
    accentHi: Color(0xFF81D4FA), accentShine: Color(0xFFB3E5FC),
    bg: Color(0xFF0A1419), bgDark: Color(0xFF0F1F2A),
    bgDeep: Color(0xFF000000), text: Color(0xFFE1F5FE),
    textSub: Color(0xFF64B5F6),
  );

  static const mintFresh = AppPalette(
    name: 'Mint Fresh', id: 'mint_fresh',
    primary: Color(0xFF00897B), primaryHi: Color(0xFF26A69A),
    primaryLo: Color(0xFF004D40), accent: Color(0xFF4DB6AC),
    accentHi: Color(0xFF80CBC4), accentShine: Color(0xFFB2DFDB),
    bg: Color(0xFF0A1410), bgDark: Color(0xFF0F1F1A),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0F2F1),
    textSub: Color(0xFF80CBC4),
  );

  static const auroraTeal = AppPalette(
    name: 'Aurora Teal', id: 'aurora_teal',
    primary: Color(0xFF14B8A6), primaryHi: Color(0xFF2DD4BF),
    primaryLo: Color(0xFF0F766E), accent: Color(0xFF67E8F9),
    accentHi: Color(0xFFA5F3FC), accentShine: Color(0xFFCFFAFE),
    bg: Color(0xFF051010), bgDark: Color(0xFF0A1A1A),
    bgDeep: Color(0xFF000000), text: Color(0xFFCCFBF1),
    textSub: Color(0xFF5EEAD4),
  );

  static const electricBlue = AppPalette(
    name: 'Electric Blue', id: 'electric_blue',
    primary: Color(0xFF00A8FF), primaryHi: Color(0xFF4DC8FF),
    primaryLo: Color(0xFF0060B0), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80F0FF), accentShine: Color(0xFFD0F8FF),
    bg: Color(0xFF000814), bgDark: Color(0xFF001020),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0F5FF),
    textSub: Color(0xFF60B0E0),
  );

  static const aquamarine = AppPalette(
    name: 'Aquamarine', id: 'aquamarine',
    primary: Color(0xFF7FFFD4), primaryHi: Color(0xFFB0FFE5),
    primaryLo: Color(0xFF40B090), accent: Color(0xFF00BCD4),
    accentHi: Color(0xFF4DD0E1), accentShine: Color(0xFFB2EBF2),
    bg: Color(0xFF001A18), bgDark: Color(0xFF002824),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0FFF8),
    textSub: Color(0xFF80E8D0),
  );

  static const crystalCyan = AppPalette(
    name: 'Crystal Cyan', id: 'crystal_cyan',
    primary: Color(0xFF00FFD9), primaryHi: Color(0xFF4DFFE8),
    primaryLo: Color(0xFF00B090), accent: Color(0xFF007AFF),
    accentHi: Color(0xFF4D9FFF), accentShine: Color(0xFFB0D0FF),
    bg: Color(0xFF001A18), bgDark: Color(0xFF002824),
    bgDeep: Color(0xFF000000), text: Color(0xFFD0FFF8),
    textSub: Color(0xFF60E8D0),
  );

  static const iceBlue = AppPalette(
    name: 'Ice Blue', id: 'ice_blue',
    primary: Color(0xFF7FE8FF), primaryHi: Color(0xFFB0F0FF),
    primaryLo: Color(0xFF40A0C0), accent: Color(0xFF0066FF),
    accentHi: Color(0xFF4D90FF), accentShine: Color(0xFFB0D0FF),
    bg: Color(0xFF001420), bgDark: Color(0xFF001F30),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0F8FF),
    textSub: Color(0xFF80C8E0),
  );

  static const seabreeze = AppPalette(
    name: 'Sea Breeze', id: 'seabreeze',
    primary: Color(0xFF87CEEB), primaryHi: Color(0xFFB0E0F0),
    primaryLo: Color(0xFF5090B0), accent: Color(0xFF00CED1),
    accentHi: Color(0xFF40E0E0), accentShine: Color(0xFFB0F5F5),
    bg: Color(0xFF0A1420), bgDark: Color(0xFF101F30),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0F5FF),
    textSub: Color(0xFF90C0E0),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 3: SOFT & ELEGANT (10) ═══
  // ══════════════════════════════════════════════════════════

  static const blackGold = AppPalette(
    name: 'Black Gold', id: 'black_gold',
    primary: Color(0xFF1A1A1A), primaryHi: Color(0xFF2C2C2C),
    primaryLo: Color(0xFF0A0A0A), accent: Color(0xFFFFD700),
    accentHi: Color(0xFFFFF176), accentShine: Color(0xFFFFFDE7),
    bg: Color(0xFF0A0A0A), bgDark: Color(0xFF141414),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF8E1),
    textSub: Color(0xFFB0A070),
  );

  static const lavenderDream = AppPalette(
    name: 'Lavender Dream', id: 'lavender_dream',
    primary: Color(0xFF7E57C2), primaryHi: Color(0xFF9575CD),
    primaryLo: Color(0xFF4527A0), accent: Color(0xFFB39DDB),
    accentHi: Color(0xFFD1C4E9), accentShine: Color(0xFFEDE7F6),
    bg: Color(0xFF0F0A1A), bgDark: Color(0xFF1A0F2A),
    bgDeep: Color(0xFF000000), text: Color(0xFFEDE7F6),
    textSub: Color(0xFFB39DDB),
  );

  static const roseGold = AppPalette(
    name: 'Rose Gold', id: 'rose_gold',
    primary: Color(0xFFB76E79), primaryHi: Color(0xFFD48A96),
    primaryLo: Color(0xFF7A4449), accent: Color(0xFFE8B4B8),
    accentHi: Color(0xFFF5D5D8), accentShine: Color(0xFFFFF0F1),
    bg: Color(0xFF140A0C), bgDark: Color(0xFF1F0F13),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF5F5),
    textSub: Color(0xFFBCAAA4),
  );

  static const whiteSilver = AppPalette(
    name: 'White Silver', id: 'white_silver',
    primary: Color(0xFFB0BEC5), primaryHi: Color(0xFFECEFF1),
    primaryLo: Color(0xFF546E7A), accent: Color(0xFFCFD8DC),
    accentHi: Color(0xFFECEFF1), accentShine: Color(0xFFFFFFFF),
    bg: Color(0xFF0F1214), bgDark: Color(0xFF1A1F22),
    bgDeep: Color(0xFF000000), text: Color(0xFFECEFF1),
    textSub: Color(0xFF90A4AE),
  );

  static const pearlWhite = AppPalette(
    name: 'Pearl White', id: 'pearl_white',
    primary: Color(0xFF9E9E9E), primaryHi: Color(0xFFE0E0E0),
    primaryLo: Color(0xFF424242), accent: Color(0xFFF5F5F5),
    accentHi: Color(0xFFFFFFFF), accentShine: Color(0xFFFFFFFF),
    bg: Color(0xFFF5F5F5), bgDark: Color(0xFFE8E8E8),
    bgDeep: Color(0xFFD5D5D5), text: Color(0xFF1A1A1A),
    textSub: Color(0xFF616161),
  );

  static const champagneGold = AppPalette(
    name: 'Champagne Gold', id: 'champagne_gold',
    primary: Color(0xFFF7E7CE), primaryHi: Color(0xFFFFF5E0),
    primaryLo: Color(0xFFB0A080), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF141008), bgDark: Color(0xFF201808),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF8E8),
    textSub: Color(0xFFC0B090),
  );

  static const platinumElite = AppPalette(
    name: 'Platinum Elite', id: 'platinum_elite',
    primary: Color(0xFFE5E4E2), primaryHi: Color(0xFFF5F5F3),
    primaryLo: Color(0xFFA0A09F), accent: Color(0xFF00BCD4),
    accentHi: Color(0xFF4DD0E1), accentShine: Color(0xFFB2EBF2),
    bg: Color(0xFF141416), bgDark: Color(0xFF1F1F22),
    bgDeep: Color(0xFF000000), text: Color(0xFFF5F5F5),
    textSub: Color(0xFFB0B0B5),
  );

  static const roseQuartz = AppPalette(
    name: 'Rose Quartz', id: 'rose_quartz',
    primary: Color(0xFFF7CAC9), primaryHi: Color(0xFFFFE0DF),
    primaryLo: Color(0xFFB09090), accent: Color(0xFFE8B4B8),
    accentHi: Color(0xFFF5D5D8), accentShine: Color(0xFFFFF0F1),
    bg: Color(0xFF1A0F14), bgDark: Color(0xFF2A1820),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0F5),
    textSub: Color(0xFFD0A8B0),
  );

  static const jasmineWhite = AppPalette(
    name: 'Jasmine White', id: 'jasmine_white',
    primary: Color(0xFFFFF8DC), primaryHi: Color(0xFFFFFFF0),
    primaryLo: Color(0xFFB0A880), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF141410), bgDark: Color(0xFF201F18),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF8E8),
    textSub: Color(0xFFC0B898),
  );

  static const copperRose = AppPalette(
    name: 'Copper Rose', id: 'copper_rose',
    primary: Color(0xFFC0806A), primaryHi: Color(0xFFD8A090),
    primaryLo: Color(0xFF805040), accent: Color(0xFF00BCD4),
    accentHi: Color(0xFF4DD0E1), accentShine: Color(0xFFB2EBF2),
    bg: Color(0xFF140A08), bgDark: Color(0xFF201008),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0E8),
    textSub: Color(0xFFD0B0A0),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 4: VIBRANT (10) ═══
  // ══════════════════════════════════════════════════════════

  static const cherryRed = AppPalette(
    name: 'Cherry Red', id: 'cherry_red',
    primary: Color(0xFFC62828), primaryHi: Color(0xFFE53935),
    primaryLo: Color(0xFF7F0000), accent: Color(0xFFFF8A80),
    accentHi: Color(0xFFFFAB91), accentShine: Color(0xFFFFCCBC),
    bg: Color(0xFF140A0A), bgDark: Color(0xFF200F0F),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFEBEE),
    textSub: Color(0xFFEF9A9A),
  );

  static const midnightPurple = AppPalette(
    name: 'Midnight Purple', id: 'midnight_purple',
    primary: Color(0xFF4A148C), primaryHi: Color(0xFF6A1B9A),
    primaryLo: Color(0xFF1A0033), accent: Color(0xFFE040FB),
    accentHi: Color(0xFFEA80FC), accentShine: Color(0xFFF3E5F5),
    bg: Color(0xFF0A0510), bgDark: Color(0xFF14081F),
    bgDeep: Color(0xFF000000), text: Color(0xFFF3E5F5),
    textSub: Color(0xFF9575CD),
  );

  static const sunsetOrange = AppPalette(
    name: 'Sunset Orange', id: 'sunset_orange',
    primary: Color(0xFFD84315), primaryHi: Color(0xFFFF5722),
    primaryLo: Color(0xFF7A1E00), accent: Color(0xFFFFB74D),
    accentHi: Color(0xFFFFCC80), accentShine: Color(0xFFFFE0B2),
    bg: Color(0xFF1A0F0A), bgDark: Color(0xFF2A1810),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF3E0),
    textSub: Color(0xFFBCAAA4),
  );

  static const hotMagenta = AppPalette(
    name: 'Hot Magenta', id: 'hot_magenta',
    primary: Color(0xFFD500F9), primaryHi: Color(0xFFE040FB),
    primaryLo: Color(0xFF6A0080), accent: Color(0xFFFF80AB),
    accentHi: Color(0xFFFFB1C1), accentShine: Color(0xFFFFE4EC),
    bg: Color(0xFF14051A), bgDark: Color(0xFF20082A),
    bgDeep: Color(0xFF000000), text: Color(0xFFFCE4EC),
    textSub: Color(0xFFF48FB1),
  );

  static const royalBlue = AppPalette(
    name: 'Royal Blue', id: 'royal_blue',
    primary: Color(0xFF283593), primaryHi: Color(0xFF3949AB),
    primaryLo: Color(0xFF0D1240), accent: Color(0xFF64B5F6),
    accentHi: Color(0xFF90CAF9), accentShine: Color(0xFFBBDEFB),
    bg: Color(0xFF0A0A1A), bgDark: Color(0xFF101228),
    bgDeep: Color(0xFF000000), text: Color(0xFFE3F2FD),
    textSub: Color(0xFF7986CB),
  );

  static const toxicGreen = AppPalette(
    name: 'Toxic Green', id: 'toxic_green',
    primary: Color(0xFF39FF14), primaryHi: Color(0xFF7FFF00),
    primaryLo: Color(0xFF1F8F0A), accent: Color(0xFFCCFF00),
    accentHi: Color(0xFFE8FF56), accentShine: Color(0xFFF5FFB0),
    bg: Color(0xFF001400), bgDark: Color(0xFF002000),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0FFE0),
    textSub: Color(0xFF90FF60),
  );

  static const laserPink = AppPalette(
    name: 'Laser Pink', id: 'laser_pink',
    primary: Color(0xFFFF0090), primaryHi: Color(0xFFFF4DB0),
    primaryLo: Color(0xFFB00060), accent: Color(0xFF00FFFF),
    accentHi: Color(0xFF80FFFF), accentShine: Color(0xFFD0FFFF),
    bg: Color(0xFF14000A), bgDark: Color(0xFF20000F),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0F0),
    textSub: Color(0xFFFF80C0),
  );

  static const plasmaPurple = AppPalette(
    name: 'Plasma Purple', id: 'plasma_purple',
    primary: Color(0xFFBF00FF), primaryHi: Color(0xFFD44DFF),
    primaryLo: Color(0xFF8A00B0), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80F0FF), accentShine: Color(0xFFD0F8FF),
    bg: Color(0xFF0A0014), bgDark: Color(0xFF14001F),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0E0FF),
    textSub: Color(0xFFC080FF),
  );

  static const solarFlare = AppPalette(
    name: 'Solar Flare', id: 'solar_flare',
    primary: Color(0xFFFF6B00), primaryHi: Color(0xFFFFA040),
    primaryLo: Color(0xFFB04000), accent: Color(0xFFFFEA00),
    accentHi: Color(0xFFFFFF56), accentShine: Color(0xFFFFFFB0),
    bg: Color(0xFF140800), bgDark: Color(0xFF200F00),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0E0),
    textSub: Color(0xFFFFB080),
  );

  static const lavaRed = AppPalette(
    name: 'Lava Red', id: 'lava_red',
    primary: Color(0xFFE53935), primaryHi: Color(0xFFFF5252),
    primaryLo: Color(0xFF9F0A0A), accent: Color(0xFFFFAB00),
    accentHi: Color(0xFFFFC140), accentShine: Color(0xFFFFE0A0),
    bg: Color(0xFF140000), bgDark: Color(0xFF200000),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0E0),
    textSub: Color(0xFFFF8080),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 5: POPULAR THEMES (10) ═══
  // ══════════════════════════════════════════════════════════

  static const dracula = AppPalette(
    name: 'Dracula', id: 'dracula',
    primary: Color(0xFFBD93F9), primaryHi: Color(0xFFD6ACFF),
    primaryLo: Color(0xFF6272A4), accent: Color(0xFFFF79C6),
    accentHi: Color(0xFFFFB8D9), accentShine: Color(0xFFFFD6F0),
    bg: Color(0xFF282A36), bgDark: Color(0xFF21222C),
    bgDeep: Color(0xFF191A21), text: Color(0xFFF8F8F2),
    textSub: Color(0xFF8BE9FD),
  );

  static const nord = AppPalette(
    name: 'Nord', id: 'nord',
    primary: Color(0xFF5E81AC), primaryHi: Color(0xFF81A1C1),
    primaryLo: Color(0xFF3B4252), accent: Color(0xFF88C0D0),
    accentHi: Color(0xFFA3D4E0), accentShine: Color(0xFFBFE3EA),
    bg: Color(0xFF2E3440), bgDark: Color(0xFF3B4252),
    bgDeep: Color(0xFF242933), text: Color(0xFFECEFF4),
    textSub: Color(0xFF81A1C1),
  );

  static const tokyoNight = AppPalette(
    name: 'Tokyo Night', id: 'tokyo_night',
    primary: Color(0xFF7AA2F7), primaryHi: Color(0xFF9EB8FF),
    primaryLo: Color(0xFF3D59A1), accent: Color(0xFFBB9AF7),
    accentHi: Color(0xFFD4BFFF), accentShine: Color(0xFFE8DBFF),
    bg: Color(0xFF1A1B26), bgDark: Color(0xFF16161E),
    bgDeep: Color(0xFF0F0F14), text: Color(0xFFC0CAF5),
    textSub: Color(0xFF565F89),
  );

  static const synthwave = AppPalette(
    name: 'Synthwave', id: 'synthwave',
    primary: Color(0xFFFF2E97), primaryHi: Color(0xFFFF6FB5),
    primaryLo: Color(0xFF8B0045), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80DEEA), accentShine: Color(0xFFE0F7FA),
    bg: Color(0xFF1A0033), bgDark: Color(0xFF260048),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0F0),
    textSub: Color(0xFFFF80AB),
  );

  static const gruvbox = AppPalette(
    name: 'Gruvbox', id: 'gruvbox',
    primary: Color(0xFFD79921), primaryHi: Color(0xFFFABD2F),
    primaryLo: Color(0xFF8B6914), accent: Color(0xFFB8BB26),
    accentHi: Color(0xFFD5D86A), accentShine: Color(0xFFE8EAA0),
    bg: Color(0xFF282828), bgDark: Color(0xFF1D2021),
    bgDeep: Color(0xFF141414), text: Color(0xFFEBDBB2),
    textSub: Color(0xFFA89984),
  );

  static const catppuccin = AppPalette(
    name: 'Catppuccin', id: 'catppuccin',
    primary: Color(0xFFCBA6F7), primaryHi: Color(0xFFDDB8FF),
    primaryLo: Color(0xFF8839EF), accent: Color(0xFFF5C2E7),
    accentHi: Color(0xFFFFD4EE), accentShine: Color(0xFFFFE5F5),
    bg: Color(0xFF1E1E2E), bgDark: Color(0xFF181825),
    bgDeep: Color(0xFF11111B), text: Color(0xFFCDD6F4),
    textSub: Color(0xFFA6ADC8),
  );

  static const hololive = AppPalette(
    name: 'Hololive', id: 'hololive',
    primary: Color(0xFF42A5F5), primaryHi: Color(0xFF64B5F6),
    primaryLo: Color(0xFF1565C0), accent: Color(0xFFFF80AB),
    accentHi: Color(0xFFFFB1C1), accentShine: Color(0xFFFFE4EC),
    bg: Color(0xFF0A1428), bgDark: Color(0xFF14203A),
    bgDeep: Color(0xFF000000), text: Color(0xFFE3F2FD),
    textSub: Color(0xFF90CAF9),
  );

  static const cyberpunkYellow = AppPalette(
    name: 'Cyberpunk Yellow', id: 'cyberpunk_yellow',
    primary: Color(0xFFFCEE0A), primaryHi: Color(0xFFFFF56B),
    primaryLo: Color(0xFFB0A000), accent: Color(0xFFFF0088),
    accentHi: Color(0xFFFF4DB0), accentShine: Color(0xFFFFB0D8),
    bg: Color(0xFF0A0A00), bgDark: Color(0xFF141400),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFFFE0),
    textSub: Color(0xFFC0C080),
  );

  static const vaporwave = AppPalette(
    name: 'Vaporwave', id: 'vaporwave',
    primary: Color(0xFFFF6EC7), primaryHi: Color(0xFFFF9DD8),
    primaryLo: Color(0xFFB03A88), accent: Color(0xFF01CDFE),
    accentHi: Color(0xFF6EE0FF), accentShine: Color(0xFFC0F0FF),
    bg: Color(0xFF1A0F2E), bgDark: Color(0xFF2A1A45),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0F5),
    textSub: Color(0xFFD890C0),
  );

  static const ayuDark = AppPalette(
    name: 'Ayu Dark', id: 'ayu_dark',
    primary: Color(0xFFFFB454), primaryHi: Color(0xFFFFC97A),
    primaryLo: Color(0xFFB07820), accent: Color(0xFF36A3D9),
    accentHi: Color(0xFF6BBEE8), accentShine: Color(0xFFB0DCF5),
    bg: Color(0xFF0F1419), bgDark: Color(0xFF1A1F26),
    bgDeep: Color(0xFF000000), text: Color(0xFFE6E1CF),
    textSub: Color(0xFFB8CCD6),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 6: LIGHT MODE (10) ═══
  // ══════════════════════════════════════════════════════════

  static const whiteLight = AppPalette(
    name: 'White Light', id: 'white_light',
    primary: Color(0xFF1976D2), primaryHi: Color(0xFF42A5F5),
    primaryLo: Color(0xFF0D47A1), accent: Color(0xFF7B1FA2),
    accentHi: Color(0xFF9C27B0), accentShine: Color(0xFFE1BEE7),
    bg: Color(0xFFFAFAFA), bgDark: Color(0xFFF0F0F0),
    bgDeep: Color(0xFFE0E0E0), text: Color(0xFF212121),
    textSub: Color(0xFF616161),
  );

  static const creamVanilla = AppPalette(
    name: 'Cream Vanilla', id: 'cream_vanilla',
    primary: Color(0xFFEF6C00), primaryHi: Color(0xFFFF9800),
    primaryLo: Color(0xFFB53D00), accent: Color(0xFF8D6E63),
    accentHi: Color(0xFFA1887F), accentShine: Color(0xFFD7CCC8),
    bg: Color(0xFFFFF8E1), bgDark: Color(0xFFFFECB3),
    bgDeep: Color(0xFFFFE082), text: Color(0xFF3E2723),
    textSub: Color(0xFF6D4C41),
  );

  static const solarizedLight = AppPalette(
    name: 'Solarized Light', id: 'solarized_light',
    primary: Color(0xFF268BD2), primaryHi: Color(0xFF4DA6E0),
    primaryLo: Color(0xFF1A6098), accent: Color(0xFFCB4B16),
    accentHi: Color(0xFFE07050), accentShine: Color(0xFFF5B0A0),
    bg: Color(0xFFFDF6E3), bgDark: Color(0xFFEEE8D5),
    bgDeep: Color(0xFFD8D0B8), text: Color(0xFF073642),
    textSub: Color(0xFF586E75),
  );

  static const githubLight = AppPalette(
    name: 'GitHub Light', id: 'github_light',
    primary: Color(0xFF0969DA), primaryHi: Color(0xFF2F86E8),
    primaryLo: Color(0xFF054A9A), accent: Color(0xFF8250DF),
    accentHi: Color(0xFFA475F0), accentShine: Color(0xFFD5B8FF),
    bg: Color(0xFFFFFFFF), bgDark: Color(0xFFF6F8FA),
    bgDeep: Color(0xFFEAEEF2), text: Color(0xFF1F2328),
    textSub: Color(0xFF656D76),
  );

  static const latte = AppPalette(
    name: 'Latte', id: 'latte',
    primary: Color(0xFFB07A52), primaryHi: Color(0xFFD09A70),
    primaryLo: Color(0xFF805030), accent: Color(0xFF8D6E63),
    accentHi: Color(0xFFA1887F), accentShine: Color(0xFFD7CCC8),
    bg: Color(0xFFF5EBE0), bgDark: Color(0xFFE8D8C8),
    bgDeep: Color(0xFFD5C0A8), text: Color(0xFF3E2723),
    textSub: Color(0xFF6D4C41),
  );

  static const sakuraLight = AppPalette(
    name: 'Sakura Light', id: 'sakura_light',
    primary: Color(0xFFE91E63), primaryHi: Color(0xFFFF4081),
    primaryLo: Color(0xFF880E4F), accent: Color(0xFFFFB6C1),
    accentHi: Color(0xFFFFD0D8), accentShine: Color(0xFFFFE8F0),
    bg: Color(0xFFFFF5F7), bgDark: Color(0xFFFFE0E8),
    bgDeep: Color(0xFFFFC0D0), text: Color(0xFF4A1528),
    textSub: Color(0xFF8A4058),
  );

  static const skyLight = AppPalette(
    name: 'Sky Light', id: 'sky_light',
    primary: Color(0xFF0288D1), primaryHi: Color(0xFF29B6F6),
    primaryLo: Color(0xFF01579B), accent: Color(0xFF00BCD4),
    accentHi: Color(0xFF4DD0E1), accentShine: Color(0xFFB2EBF2),
    bg: Color(0xFFE1F5FE), bgDark: Color(0xFFB3E5FC),
    bgDeep: Color(0xFF81D4FA), text: Color(0xFF012E4A),
    textSub: Color(0xFF4A6B80),
  );

  static const mintLight = AppPalette(
    name: 'Mint Light', id: 'mint_light',
    primary: Color(0xFF00897B), primaryHi: Color(0xFF26A69A),
    primaryLo: Color(0xFF004D40), accent: Color(0xFF4DB6AC),
    accentHi: Color(0xFF80CBC4), accentShine: Color(0xFFB2DFDB),
    bg: Color(0xFFE0F2F1), bgDark: Color(0xFFB2DFDB),
    bgDeep: Color(0xFF80CBC4), text: Color(0xFF002A25),
    textSub: Color(0xFF4A7A72),
  );

  static const lemonLight = AppPalette(
    name: 'Lemon Light', id: 'lemon_light',
    primary: Color(0xFFF57F17), primaryHi: Color(0xFFFB8C00),
    primaryLo: Color(0xFFBF5F00), accent: Color(0xFFF9A825),
    accentHi: Color(0xFFFBC02D), accentShine: Color(0xFFFDD835),
    bg: Color(0xFFFFFDE7), bgDark: Color(0xFFFFF9C4),
    bgDeep: Color(0xFFFFF59D), text: Color(0xFF3E2723),
    textSub: Color(0xFF6D4C41),
  );

  static const cloudLight = AppPalette(
    name: 'Cloud Light', id: 'cloud_light',
    primary: Color(0xFF546E7A), primaryHi: Color(0xFF78909C),
    primaryLo: Color(0xFF37474F), accent: Color(0xFF26A69A),
    accentHi: Color(0xFF4DB6AC), accentShine: Color(0xFF80CBC4),
    bg: Color(0xFFECEFF1), bgDark: Color(0xFFCFD8DC),
    bgDeep: Color(0xFFB0BEC5), text: Color(0xFF263238),
    textSub: Color(0xFF546E7A),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 7: COSMIC & SPACE (10) ═══
  // ══════════════════════════════════════════════════════════

  static const galaxyPurple = AppPalette(
    name: 'Galaxy Purple', id: 'galaxy_purple',
    primary: Color(0xFF6A1B9A), primaryHi: Color(0xFF8E24AA),
    primaryLo: Color(0xFF4A148C), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80F0FF), accentShine: Color(0xFFD0F8FF),
    bg: Color(0xFF0A0518), bgDark: Color(0xFF150A28),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8D8FF),
    textSub: Color(0xFF9575CD),
  );

  static const nebulaPink = AppPalette(
    name: 'Nebula Pink', id: 'nebula_pink',
    primary: Color(0xFFE91E63), primaryHi: Color(0xFFFF4081),
    primaryLo: Color(0xFF880E4F), accent: Color(0xFF9C27B0),
    accentHi: Color(0xFFCE93D8), accentShine: Color(0xFFF3E5F5),
    bg: Color(0xFF14051A), bgDark: Color(0xFF20082A),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0F5),
    textSub: Color(0xFFF48FB1),
  );

  static const cosmosBlue = AppPalette(
    name: 'Cosmos Blue', id: 'cosmos_blue',
    primary: Color(0xFF1A237E), primaryHi: Color(0xFF283593),
    primaryLo: Color(0xFF0D1240), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80F0FF), accentShine: Color(0xFFD0F8FF),
    bg: Color(0xFF000018), bgDark: Color(0xFF000028),
    bgDeep: Color(0xFF000000), text: Color(0xFFD0D8FF),
    textSub: Color(0xFF6070A0),
  );

  static const starGold = AppPalette(
    name: 'Star Gold', id: 'star_gold',
    primary: Color(0xFFFFD700), primaryHi: Color(0xFFFFE44D),
    primaryLo: Color(0xFFB09000), accent: Color(0xFF9C27B0),
    accentHi: Color(0xFFCE93D8), accentShine: Color(0xFFF3E5F5),
    bg: Color(0xFF0F0A1A), bgDark: Color(0xFF1A1028),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF8E1),
    textSub: Color(0xFFC8B080),
  );

  static const auroraGreen = AppPalette(
    name: 'Aurora Green', id: 'aurora_green',
    primary: Color(0xFF00E676), primaryHi: Color(0xFF69F0AE),
    primaryLo: Color(0xFF00B248), accent: Color(0xFF7C4DFF),
    accentHi: Color(0xFFB388FF), accentShine: Color(0xFFE0D0FF),
    bg: Color(0xFF001A10), bgDark: Color(0xFF002820),
    bgDeep: Color(0xFF000000), text: Color(0xFFD0FFE8),
    textSub: Color(0xFF80E8B0),
  );

  static const cosmicOrange = AppPalette(
    name: 'Cosmic Orange', id: 'cosmic_orange',
    primary: Color(0xFFFF6D00), primaryHi: Color(0xFFFF9800),
    primaryLo: Color(0xFFBF4500), accent: Color(0xFF3D5AFE),
    accentHi: Color(0xFF7C8FFF), accentShine: Color(0xFFD0D8FF),
    bg: Color(0xFF140A00), bgDark: Color(0xFF201000),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0E0),
    textSub: Color(0xFFFFB880),
  );

  static const spaceGray = AppPalette(
    name: 'Space Gray', id: 'space_gray',
    primary: Color(0xFF424242), primaryHi: Color(0xFF616161),
    primaryLo: Color(0xFF212121), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80F0FF), accentShine: Color(0xFFD0F8FF),
    bg: Color(0xFF0A0A0A), bgDark: Color(0xFF141414),
    bgDeep: Color(0xFF000000), text: Color(0xFFEDEDED),
    textSub: Color(0xFF909090),
  );

  static const meteorRed = AppPalette(
    name: 'Meteor Red', id: 'meteor_red',
    primary: Color(0xFFD32F2F), primaryHi: Color(0xFFE53935),
    primaryLo: Color(0xFF8B1818), accent: Color(0xFFFFAB00),
    accentHi: Color(0xFFFFC140), accentShine: Color(0xFFFFE0A0),
    bg: Color(0xFF140808), bgDark: Color(0xFF200F0F),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0E0),
    textSub: Color(0xFFFF9090),
  );

  static const lunarSilver = AppPalette(
    name: 'Lunar Silver', id: 'lunar_silver',
    primary: Color(0xFFC0C0C0), primaryHi: Color(0xFFE0E0E0),
    primaryLo: Color(0xFF808080), accent: Color(0xFF6A1B9A),
    accentHi: Color(0xFF8E24AA), accentShine: Color(0xFFCE93D8),
    bg: Color(0xFF141416), bgDark: Color(0xFF1F1F22),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0F0F0),
    textSub: Color(0xFFB0B0B5),
  );

  static const blackHole = AppPalette(
    name: 'Black Hole', id: 'black_hole',
    primary: Color(0xFF1A1A1A), primaryHi: Color(0xFF2C2C2C),
    primaryLo: Color(0xFF000000), accent: Color(0xFF7C4DFF),
    accentHi: Color(0xFFB388FF), accentShine: Color(0xFFE0D0FF),
    bg: Color(0xFF000000), bgDark: Color(0xFF0A0A0A),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0E0E0),
    textSub: Color(0xFF808080),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 8: NATURE & EARTHY (10) ═══
  // ══════════════════════════════════════════════════════════

  static const forestGreen = AppPalette(
    name: 'Forest Green', id: 'forest_green',
    primary: Color(0xFF2E7D32), primaryHi: Color(0xFF43A047),
    primaryLo: Color(0xFF1B5E20), accent: Color(0xFF8BC34A),
    accentHi: Color(0xFFAED581), accentShine: Color(0xFFDCEDC8),
    bg: Color(0xFF0A1408), bgDark: Color(0xFF0F2010),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8F5E9),
    textSub: Color(0xFF81C784),
  );

  static const desertSand = AppPalette(
    name: 'Desert Sand', id: 'desert_sand',
    primary: Color(0xFFC19A6B), primaryHi: Color(0xFFD4B080),
    primaryLo: Color(0xFF8A6A40), accent: Color(0xFFE8B923),
    accentHi: Color(0xFFF5D060), accentShine: Color(0xFFFFE8B0),
    bg: Color(0xFF1A1208), bgDark: Color(0xFF2A1E10),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0D8),
    textSub: Color(0xFFC8A878),
  );

  static const mossGreen = AppPalette(
    name: 'Moss Green', id: 'moss_green',
    primary: Color(0xFF558B2F), primaryHi: Color(0xFF7CB342),
    primaryLo: Color(0xFF33691E), accent: Color(0xFF9E9D24),
    accentHi: Color(0xFFC0CA33), accentShine: Color(0xFFE6EE9C),
    bg: Color(0xFF0A1408), bgDark: Color(0xFF14200F),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8F5E0),
    textSub: Color(0xFF9CCC65),
  );

  static const terracotta = AppPalette(
    name: 'Terracotta', id: 'terracotta',
    primary: Color(0xFFBF5B3F), primaryHi: Color(0xFFD97A5F),
    primaryLo: Color(0xFF8A3E28), accent: Color(0xFFF4A460),
    accentHi: Color(0xFFFFC080), accentShine: Color(0xFFFFE0B8),
    bg: Color(0xFF140A06), bgDark: Color(0xFF201008),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0E8),
    textSub: Color(0xFFD0A090),
  );

  static const sageGreen = AppPalette(
    name: 'Sage Green', id: 'sage_green',
    primary: Color(0xFF9CAF88), primaryHi: Color(0xFFB8C8A8),
    primaryLo: Color(0xFF6F8058), accent: Color(0xFFA3B18A),
    accentHi: Color(0xFFC8D4B0), accentShine: Color(0xFFE5ECD8),
    bg: Color(0xFF141810), bgDark: Color(0xFF1F2418),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8EDE0),
    textSub: Color(0xFFB0B8A0),
  );

  static const coffeeBrown = AppPalette(
    name: 'Coffee Brown', id: 'coffee_brown',
    primary: Color(0xFF6F4E37), primaryHi: Color(0xFF8B6A50),
    primaryLo: Color(0xFF4A3325), accent: Color(0xFFC89F6C),
    accentHi: Color(0xFFE0B888), accentShine: Color(0xFFF5DCB8),
    bg: Color(0xFF140C08), bgDark: Color(0xFF20140F),
    bgDeep: Color(0xFF000000), text: Color(0xFFF5E8D8),
    textSub: Color(0xFFB09880),
  );

  static const bambooGreen = AppPalette(
    name: 'Bamboo Green', id: 'bamboo_green',
    primary: Color(0xFF7CB342), primaryHi: Color(0xFF9CCC65),
    primaryLo: Color(0xFF558B2F), accent: Color(0xFFAFB42B),
    accentHi: Color(0xFFCDDC39), accentShine: Color(0xFFE6EE9C),
    bg: Color(0xFF0F1808), bgDark: Color(0xFF1A2810),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0F8E0),
    textSub: Color(0xFFB0C878),
  );

  static const clayRed = AppPalette(
    name: 'Clay Red', id: 'clay_red',
    primary: Color(0xFFB73A2A), primaryHi: Color(0xFFD04F3C),
    primaryLo: Color(0xFF8A2018), accent: Color(0xFFD9A87C),
    accentHi: Color(0xFFE8C0A0), accentShine: Color(0xFFF5DCC8),
    bg: Color(0xFF140505), bgDark: Color(0xFF200808),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE8E0),
    textSub: Color(0xFFC89080),
  );

  static const oliveGrove = AppPalette(
    name: 'Olive Grove', id: 'olive_grove',
    primary: Color(0xFF6B7B3C), primaryHi: Color(0xFF8A9A4F),
    primaryLo: Color(0xFF4A5828), accent: Color(0xFFB8B040),
    accentHi: Color(0xFFD0C860), accentShine: Color(0xFFE8E0A0),
    bg: Color(0xFF101408), bgDark: Color(0xFF1A2010),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0F0D8),
    textSub: Color(0xFFA8B078),
  );

  static const autumnLeaf = AppPalette(
    name: 'Autumn Leaf', id: 'autumn_leaf',
    primary: Color(0xFFD2691E), primaryHi: Color(0xFFE88A3A),
    primaryLo: Color(0xFF9A4510), accent: Color(0xFFB8860B),
    accentHi: Color(0xFFD4A830), accentShine: Color(0xFFE8C860),
    bg: Color(0xFF1A0F04), bgDark: Color(0xFF2A1A08),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0D8),
    textSub: Color(0xFFC8A070),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 9: ROYAL & LUXURY (10) ═══
  // ══════════════════════════════════════════════════════════

  static const royalEmerald = AppPalette(
    name: 'Royal Emerald', id: 'royal_emerald',
    primary: Color(0xFF046307), primaryHi: Color(0xFF0A9F0F),
    primaryLo: Color(0xFF023A04), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF021408), bgDark: Color(0xFF051F0F),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8F5E0),
    textSub: Color(0xFF80B085),
  );

  static const royalSapphire = AppPalette(
    name: 'Royal Sapphire', id: 'royal_sapphire',
    primary: Color(0xFF0F2A8F), primaryHi: Color(0xFF1A3FB0),
    primaryLo: Color(0xFF081560), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF050A1F), bgDark: Color(0xFF0A102F),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0E8FF),
    textSub: Color(0xFF8090C8),
  );

  static const royalRuby = AppPalette(
    name: 'Royal Ruby', id: 'royal_ruby',
    primary: Color(0xFF8B0033), primaryHi: Color(0xFFB01050),
    primaryLo: Color(0xFF5A0020), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF0F0208), bgDark: Color(0xFF1F0510),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0E8),
    textSub: Color(0xFFC08090),
  );

  static const royalAmethyst = AppPalette(
    name: 'Royal Amethyst', id: 'royal_amethyst',
    primary: Color(0xFF5B0A8B), primaryHi: Color(0xFF8B1ABF),
    primaryLo: Color(0xFF3A055F), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF0A0214), bgDark: Color(0xFF150A1F),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0E0FF),
    textSub: Color(0xFFB080D0),
  );

  static const bronzeLuxury = AppPalette(
    name: 'Bronze Luxury', id: 'bronze_luxury',
    primary: Color(0xFFCD7F32), primaryHi: Color(0xFFE0A050),
    primaryLo: Color(0xFF8F5010), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF140A04), bgDark: Color(0xFF201008),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0E0),
    textSub: Color(0xFFD0A878),
  );

  static const royalVelvet = AppPalette(
    name: 'Royal Velvet', id: 'royal_velvet',
    primary: Color(0xFF4A0E4E), primaryHi: Color(0xFF6B156F),
    primaryLo: Color(0xFF2A052E), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF0A020F), bgDark: Color(0xFF150518),
    bgDeep: Color(0xFF000000), text: Color(0xFFF5E0F8),
    textSub: Color(0xFFB080C0),
  );

  static const imperialPurple = AppPalette(
    name: 'Imperial Purple', id: 'imperial_purple',
    primary: Color(0xFF66023C), primaryHi: Color(0xFF8B0A54),
    primaryLo: Color(0xFF400125), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF0F0208), bgDark: Color(0xFF1F0510),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0F0),
    textSub: Color(0xFFC090A8),
  );

  static const goldMetallic = AppPalette(
    name: 'Gold Metallic', id: 'gold_metallic',
    primary: Color(0xFFFFD700), primaryHi: Color(0xFFFFE44D),
    primaryLo: Color(0xFFB09000), accent: Color(0xFF8B4513),
    accentHi: Color(0xFFA0522D), accentShine: Color(0xFFD2B48C),
    bg: Color(0xFF1A1408), bgDark: Color(0xFF2A200F),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF8E0),
    textSub: Color(0xFFC8B080),
  );

  static const platinumMetallic = AppPalette(
    name: 'Platinum Metallic', id: 'platinum_metallic',
    primary: Color(0xFFE5E4E2), primaryHi: Color(0xFFF5F5F3),
    primaryLo: Color(0xFFA0A09F), accent: Color(0xFF7B68EE),
    accentHi: Color(0xFFA090F5), accentShine: Color(0xFFD0C8FF),
    bg: Color(0xFF141416), bgDark: Color(0xFF1F1F22),
    bgDeep: Color(0xFF000000), text: Color(0xFFF5F5F5),
    textSub: Color(0xFFB0B0B5),
  );

  static const roseGoldMetallic = AppPalette(
    name: 'Rose Gold Metallic', id: 'rose_gold_metallic',
    primary: Color(0xFFB76E79), primaryHi: Color(0xFFD48A96),
    primaryLo: Color(0xFF7A4449), accent: Color(0xFFFFD700),
    accentHi: Color(0xFFFFE44D), accentShine: Color(0xFFFFF3A8),
    bg: Color(0xFF140A0C), bgDark: Color(0xFF1F0F13),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF5F5),
    textSub: Color(0xFFC0A0A8),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 10: RETRO & VINTAGE (10) ═══
  // ══════════════════════════════════════════════════════════

  static const retroBrown = AppPalette(
    name: 'Retro Brown', id: 'retro_brown',
    primary: Color(0xFF8D6E63), primaryHi: Color(0xFFA1887F),
    primaryLo: Color(0xFF5D4037), accent: Color(0xFFD7A86E),
    accentHi: Color(0xFFE8C098), accentShine: Color(0xFFF5DCC0),
    bg: Color(0xFF1A1208), bgDark: Color(0xFF2A1E10),
    bgDeep: Color(0xFF000000), text: Color(0xFFF5E8D8),
    textSub: Color(0xFFBCAAA4),
  );

  static const retroTeal = AppPalette(
    name: 'Retro Teal', id: 'retro_teal',
    primary: Color(0xFF00796B), primaryHi: Color(0xFF00897B),
    primaryLo: Color(0xFF004D40), accent: Color(0xFFF9A825),
    accentHi: Color(0xFFFBC02D), accentShine: Color(0xFFFDD835),
    bg: Color(0xFF0A1410), bgDark: Color(0xFF0F1F1A),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0F2F1),
    textSub: Color(0xFF80CBC4),
  );

  static const retroRed = AppPalette(
    name: 'Retro Red', id: 'retro_red',
    primary: Color(0xFFB71C1C), primaryHi: Color(0xFFD32F2F),
    primaryLo: Color(0xFF7F0000), accent: Color(0xFFF9A825),
    accentHi: Color(0xFFFBC02D), accentShine: Color(0xFFFDD835),
    bg: Color(0xFF140808), bgDark: Color(0xFF200F0F),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0E0),
    textSub: Color(0xFFEF9A9A),
  );

  static const retroMustard = AppPalette(
    name: 'Retro Mustard', id: 'retro_mustard',
    primary: Color(0xFFD4A017), primaryHi: Color(0xFFE8B830),
    primaryLo: Color(0xFF9A7500), accent: Color(0xFF8B4513),
    accentHi: Color(0xFFA0522D), accentShine: Color(0xFFD2B48C),
    bg: Color(0xFF1A1208), bgDark: Color(0xFF2A1E10),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0D0),
    textSub: Color(0xFFC8B080),
  );

  static const retroOlive = AppPalette(
    name: 'Retro Olive', id: 'retro_olive',
    primary: Color(0xFF6B7B3C), primaryHi: Color(0xFF8A9A4F),
    primaryLo: Color(0xFF4A5828), accent: Color(0xFFD4A017),
    accentHi: Color(0xFFE8B830), accentShine: Color(0xFFFFE080),
    bg: Color(0xFF101408), bgDark: Color(0xFF1A2010),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0F0D8),
    textSub: Color(0xFFA8B078),
  );

  static const retroNavy = AppPalette(
    name: 'Retro Navy', id: 'retro_navy',
    primary: Color(0xFF1A237E), primaryHi: Color(0xFF283593),
    primaryLo: Color(0xFF0D1240), accent: Color(0xFFD4A017),
    accentHi: Color(0xFFE8B830), accentShine: Color(0xFFFFE080),
    bg: Color(0xFF050A1F), bgDark: Color(0xFF0A102F),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0E8FF),
    textSub: Color(0xFF8090C8),
  );

  static const retroMaroon = AppPalette(
    name: 'Retro Maroon', id: 'retro_maroon',
    primary: Color(0xFF800000), primaryHi: Color(0xFFA01010),
    primaryLo: Color(0xFF500000), accent: Color(0xFFD4A017),
    accentHi: Color(0xFFE8B830), accentShine: Color(0xFFFFE080),
    bg: Color(0xFF140404), bgDark: Color(0xFF200808),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0E0),
    textSub: Color(0xFFC89090),
  );

  static const retroCream = AppPalette(
    name: 'Retro Cream', id: 'retro_cream',
    primary: Color(0xFFD4A88A), primaryHi: Color(0xFFE8C0A0),
    primaryLo: Color(0xFF9A7860), accent: Color(0xFF8B4513),
    accentHi: Color(0xFFA0522D), accentShine: Color(0xFFD2B48C),
    bg: Color(0xFF1A1208), bgDark: Color(0xFF2A1E10),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0E0),
    textSub: Color(0xFFC8B090),
  );

  static const vinylBlack = AppPalette(
    name: 'Vinyl Black', id: 'vinyl_black',
    primary: Color(0xFF1A1A1A), primaryHi: Color(0xFF2C2C2C),
    primaryLo: Color(0xFF0A0A0A), accent: Color(0xFFD4A017),
    accentHi: Color(0xFFE8B830), accentShine: Color(0xFFFFE080),
    bg: Color(0xFF0A0A0A), bgDark: Color(0xFF141414),
    bgDeep: Color(0xFF000000), text: Color(0xFFEDEDED),
    textSub: Color(0xFF999999),
  );

  static const cassetteOrange = AppPalette(
    name: 'Cassette Orange', id: 'cassette_orange',
    primary: Color(0xFFFF6D00), primaryHi: Color(0xFFFF9800),
    primaryLo: Color(0xFFBF4500), accent: Color(0xFF8B4513),
    accentHi: Color(0xFFA0522D), accentShine: Color(0xFFD2B48C),
    bg: Color(0xFF1A0F04), bgDark: Color(0xFF2A1A08),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0E0),
    textSub: Color(0xFFFFB880),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ MASTER LIST — 100 PALETTE ═══
  // ══════════════════════════════════════════════════════════

  static const List<AppPalette> all = [
    bloodRed, cyberBlue, neonGreen, purpleMystic, goldRoyal,
    pinkNeon, orangeFire, obsidianBlack, carbonFiber, ravenDark,
    cyanIce, matrixGreen, oceanBlue, mintFresh, auroraTeal,
    electricBlue, aquamarine, crystalCyan, iceBlue, seabreeze,
    blackGold, lavenderDream, roseGold, whiteSilver, pearlWhite,
    champagneGold, platinumElite, roseQuartz, jasmineWhite, copperRose,
    cherryRed, midnightPurple, sunsetOrange, hotMagenta, royalBlue,
    toxicGreen, laserPink, plasmaPurple, solarFlare, lavaRed,
    dracula, nord, tokyoNight, synthwave, gruvbox,
    catppuccin, hololive, cyberpunkYellow, vaporwave, ayuDark,
    whiteLight, creamVanilla, solarizedLight, githubLight, latte,
    sakuraLight, skyLight, mintLight, lemonLight, cloudLight,
    galaxyPurple, nebulaPink, cosmosBlue, starGold, auroraGreen,
    cosmicOrange, spaceGray, meteorRed, lunarSilver, blackHole,
    forestGreen, desertSand, mossGreen, terracotta, sageGreen,
    coffeeBrown, bambooGreen, clayRed, oliveGrove, autumnLeaf,
    royalEmerald, royalSapphire, royalRuby, royalAmethyst, bronzeLuxury,
    royalVelvet, imperialPurple, goldMetallic, platinumMetallic, roseGoldMetallic,
    retroBrown, retroTeal, retroRed, retroMustard, retroOlive,
    retroNavy, retroMaroon, retroCream, vinylBlack, cassetteOrange,
  ];

  static AppPalette getById(String id) =>
      all.firstWhere((p) => p.id == id, orElse: () => bloodRed);
}

class AppTheme {
  static const String _paletteKey = 'app_theme_id';
  static const String _styleKey = 'app_style_id';

  static final ValueNotifier<AppPalette> current =
      ValueNotifier<AppPalette>(AppPalettes.bloodRed);
  static final ValueNotifier<ThemeStyle> currentStyle =
      ValueNotifier<ThemeStyle>(ThemeStyle.original);

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final paletteId = prefs.getString(_paletteKey) ?? 'blood_red';
    final styleId = prefs.getString(_styleKey) ?? 'original';
    current.value = AppPalettes.getById(paletteId);
    currentStyle.value = ThemeStyleInfo.getById(styleId).style;
  }

  static Future<void> setPalette(AppPalette palette) async {
    current.value = palette;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_paletteKey, palette.id);
  }

  static Future<void> setStyle(ThemeStyle style) async {
    currentStyle.value = style;
    final prefs = await SharedPreferences.getInstance();
    final info = ThemeStyleInfo.all.firstWhere(
      (s) => s.style == style,
      orElse: () => ThemeStyleInfo.all.first,
    );
    await prefs.setString(_styleKey, info.id);
  }

  static bool get isComic => currentStyle.value == ThemeStyle.comic3d;
  static bool get isOriginal => currentStyle.value == ThemeStyle.original;
  static bool get isHud => currentStyle.value == ThemeStyle.hudTactical;
}

class StyleKit {
  final AppPalette C;
  final ThemeStyle style;
  const StyleKit({required this.C, required this.style});

  double get radiusSm => style == ThemeStyle.comic3d ? 10 : 6;
  double get radiusMd => style == ThemeStyle.comic3d ? 16 : 10;
  double get radiusLg => style == ThemeStyle.comic3d ? 22 : 14;
  double get borderThin => style == ThemeStyle.comic3d ? 2.0 : 1.0;
  double get borderMd => style == ThemeStyle.comic3d ? 3.0 : 1.5;
  double get borderThick => style == ThemeStyle.comic3d ? 4.0 : 2.0;

  // ═══ STYLE HELPERS ═══
  bool get isComic3d => style == ThemeStyle.comic3d;
  bool get isHud => style == ThemeStyle.hudTactical;
  bool get isOriginalStyle => style == ThemeStyle.original;

  Color get outline => style == ThemeStyle.comic3d
      ? const Color(0xFF000000)
      : (style == ThemeStyle.hudTactical
          ? C.accent.withOpacity(0.65)
          : C.primaryLo.withOpacity(0.6));

  Offset get shadowOffset =>
      style == ThemeStyle.comic3d ? const Offset(4, 4) : const Offset(0, 4);
  double get shadowBlur => style == ThemeStyle.comic3d ? 0 : 8;
  String get fontFamily {
    if (style == ThemeStyle.comic3d) return 'Bangers';
    return 'Orbitron';
  }
  String get fontFamilySub {
    if (style == ThemeStyle.comic3d) return 'ComicNeue';
    return 'ShareTechMono';
  }

  // ═══ HUD HELPERS ═══
  Color get hudBg => const Color(0xFF02060A);
  Color get hudPanel => const Color(0xFF0A1218).withOpacity(0.85);
  Color get hudPanelHi => const Color(0xFF0F1A22).withOpacity(0.9);
  Color get hudBorder => C.accent.withOpacity(0.65);
  Color get hudBorderHi => C.accentHi.withOpacity(0.9);
  Color get hudGridLine => C.accent.withOpacity(0.08);
  Color get hudNeon => C.accentHi;
  Color get hudText => const Color(0xFFB8E6F0);
  Color get hudTextDim => const Color(0xFF5A7A85);
  Color get hudWarning => const Color(0xFFFF3B3B);
  Color get hudSuccess => const Color(0xFF00FF9C);
  Color get hudInfo => const Color(0xFF00D9FF);
  String get hudFont => 'Orbitron';
  String get hudMono => 'ShareTechMono';

  BoxDecoration panelDecor({Color? color, double? radius, bool elevated = true}) {
    final r = radius ?? radiusMd;
    final baseColor = color ?? C.bgDark;

    if (style == ThemeStyle.comic3d) {
      return BoxDecoration(
        color: baseColor,
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: Colors.black, width: borderMd),
        boxShadow: elevated
            ? const [
                BoxShadow(color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : null,
      );
    }

    if (style == ThemeStyle.hudTactical) {
      return BoxDecoration(
        color: hudPanel,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: hudBorder, width: 1.2),
        boxShadow: elevated
            ? [
                BoxShadow(color: C.accent.withOpacity(0.18), blurRadius: 12),
              ]
            : null,
      );
    }

    return BoxDecoration(
      borderRadius: BorderRadius.circular(r),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [C.bg, C.bgDark, C.bgDeep],
        stops: const [0.0, 0.5, 1.0],
      ),
      border: Border.all(color: outline, width: borderThin),
      boxShadow: elevated
          ? [
              BoxShadow(
                  color: Colors.black.withOpacity(0.75),
                  offset: const Offset(0, 6),
                  blurRadius: 12),
              BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 16),
            ]
          : null,
    );
  }

  BoxDecoration buttonDecor({Color? color, bool pressed = false}) {
    final baseColor = color ?? C.primaryHi;

    if (style == ThemeStyle.comic3d) {
      return BoxDecoration(
        color: baseColor,
        borderRadius: BorderRadius.circular(radiusMd),
        border: Border.all(color: Colors.black, width: borderThick),
        boxShadow: pressed
            ? null
            : const [
                BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
              ],
      );
    }

    if (style == ThemeStyle.hudTactical) {
      return BoxDecoration(
        color: pressed
            ? baseColor.withOpacity(0.25)
            : baseColor.withOpacity(0.12),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: baseColor, width: 1.4),
        boxShadow: pressed
            ? null
            : [
                BoxShadow(color: baseColor.withOpacity(0.35), blurRadius: 10),
              ],
      );
    }

    return BoxDecoration(
      borderRadius: BorderRadius.circular(radiusMd),
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          baseColor,
          baseColor.withOpacity(0.7),
          baseColor.withOpacity(0.4),
        ],
      ),
      border: Border.all(color: outline, width: borderMd),
      boxShadow: [
        BoxShadow(color: baseColor.withOpacity(0.4), blurRadius: 12),
        BoxShadow(
            color: Colors.black.withOpacity(0.6),
            offset: const Offset(0, 4),
            blurRadius: 6),
      ],
    );
  }
}

class StyleBuilder extends StatelessWidget {
  final Widget Function(BuildContext, AppPalette, StyleKit) builder;
  const StyleBuilder({super.key, required this.builder});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            return builder(context, C, StyleKit(C: C, style: style));
          },
        );
      },
    );
  }
}

class AppThemeScope extends InheritedWidget {
  final ThemeStyle style;
  final AppPalette palette;
  final StyleKit kit;
  const AppThemeScope({
    super.key,
    required this.style,
    required this.palette,
    required this.kit,
    required super.child,
  });

  static AppThemeScope? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppThemeScope>();

  static ThemeStyle styleOf(BuildContext context) =>
      maybeOf(context)?.style ?? AppTheme.currentStyle.value;
  static AppPalette paletteOf(BuildContext context) =>
      maybeOf(context)?.palette ?? AppTheme.current.value;
  static StyleKit kitOf(BuildContext context) =>
      maybeOf(context)?.kit ??
      StyleKit(C: AppTheme.current.value, style: AppTheme.currentStyle.value);
  static bool isComic(BuildContext context) =>
      styleOf(context) == ThemeStyle.comic3d;
  static bool isHud(BuildContext context) =>
      styleOf(context) == ThemeStyle.hudTactical;

  @override
  bool updateShouldNotify(AppThemeScope old) =>
      old.style != style || old.palette.id != palette.id;
}

// ═══════════════════════════════════════════════════════════
// AUTO CONTRAST
// ═══════════════════════════════════════════════════════════
extension AppPaletteContrast on AppPalette {
  double _lum(Color c) {
    final r = c.red / 255;
    final g = c.green / 255;
    final b = c.blue / 255;
    double toLinear(double v) =>
        v <= 0.03928 ? v / 12.92 : math.pow((v + 0.055) / 1.055, 2.4).toDouble();
    return 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
  }

  double get _bgLuminance => (_lum(bg) + _lum(bgDark) + _lum(bgDeep)) / 3;
  bool get isDarkPalette => _bgLuminance < 0.5;
  bool get isLightPalette => !isDarkPalette;

  Color get comicText =>
      isDarkPalette ? const Color(0xFFF5F5F5) : const Color(0xFF0A0A0A);
  Color get comicTextSub =>
      isDarkPalette ? const Color(0xFFB0B0B0) : const Color(0xFF333333);
  Color get comicTextMuted =>
      isDarkPalette ? const Color(0xFF808080) : const Color(0xFF666666);
  Color get comicTextOutline => isDarkPalette ? Colors.black : Colors.white;

  Color contrastTextOn(Color background) =>
      _lum(background) > 0.5 ? Colors.black : Colors.white;
}

// ═══════════════════════════════════════════════════════════
// ADAPTIVE HELPER
// ═══════════════════════════════════════════════════════════
extension AdaptiveStyle on AppPalette {
  Color txtMain(bool isComic) => isComic ? comicText : text;
  Color txtSub2(bool isComic) => isComic ? comicTextSub : textSub;
  Color txtMuted(bool isComic) => isComic ? comicTextMuted : textSub;
  Color txtOutline2(bool isComic) => isComic ? comicTextOutline : Colors.black;
  String font(bool isComic) => isComic ? 'Bangers' : 'Orbitron';
  String fontSub(bool isComic) => isComic ? 'ComicNeue' : 'ShareTechMono';
  Color txtOnInput(bool isComic) => isComic ? Colors.black : text;
  Color txtOnButton(bool isComic, Color btnColor) =>
      isComic ? contrastTextOn(btnColor) : Colors.white;
}

// ═══════════════════════════════════════════════════════════
// HUD TACTICAL HELPERS
// ═══════════════════════════════════════════════════════════
extension HudTacticalStyle on AppPalette {
  Color hudBg() => const Color(0xFF02060A);
  Color hudPanel() => const Color(0xFF0A1218).withOpacity(0.85);
  Color hudPanelHi() => const Color(0xFF0F1A22).withOpacity(0.9);
  Color hudBorder() => accent.withOpacity(0.65);
  Color hudBorderHi() => accentHi.withOpacity(0.9);
  Color hudGridLine() => accent.withOpacity(0.08);
  Color hudNeon() => accentHi;
  Color hudText() => const Color(0xFFB8E6F0);
  Color hudTextDim() => const Color(0xFF5A7A85);
  Color hudWarning() => const Color(0xFFFF3B3B);
  Color hudSuccess() => const Color(0xFF00FF9C);
  Color hudInfo() => const Color(0xFF00D9FF);
}