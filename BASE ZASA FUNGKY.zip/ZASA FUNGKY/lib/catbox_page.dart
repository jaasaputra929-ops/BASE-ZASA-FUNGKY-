// lib/catbox_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'app_theme.dart';
import 'catbox_service.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class CatboxPage extends StatefulWidget {
  const CatboxPage({super.key});

  @override
  State<CatboxPage> createState() => _CatboxPageState();
}

class _CatboxPageState extends State<CatboxPage> {
  File? _selectedFile;
  String? _uploadedUrl;
  bool _isUploading = false;
  String? _errorMsg;
  bool _isTemporary = false;
  String _expiry = '24h';

  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picked = await _picker.pickImage(
        source: source,
        imageQuality: 85,
        maxWidth: 1920,
      );
      if (picked != null) {
        setState(() {
          _selectedFile = File(picked.path);
          _uploadedUrl = null;
          _errorMsg = null;
        });
      }
    } catch (e) {
      setState(() => _errorMsg = 'Gagal pilih gambar: $e');
    }
  }

  Future<void> _upload() async {
    if (_selectedFile == null) {
      setState(() => _errorMsg = 'Pilih foto dulu bro!');
      return;
    }

    setState(() {
      _isUploading = true;
      _errorMsg = null;
      _uploadedUrl = null;
    });

    final CatboxResult result;
    if (_isTemporary) {
      result = await CatboxService.uploadTemporary(
        _selectedFile!,
        expiry: _expiry,
      );
    } else {
      result = await CatboxService.uploadFile(_selectedFile!);
    }

    if (!mounted) return;

    setState(() {
      _isUploading = false;
      if (result.success) {
        _uploadedUrl = result.url;
      } else {
        _errorMsg = result.error ?? 'Upload gagal';
      }
    });

    if (result.success) {
      HapticFeedback.mediumImpact();
    }
  }

  void _copyUrl() {
    if (_uploadedUrl == null) return;
    HapticFeedback.lightImpact();
    Clipboard.setData(ClipboardData(text: _uploadedUrl!));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('URL berhasil di-copy!'),
        backgroundColor: Colors.green[700],
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _reset() {
    setState(() {
      _selectedFile = null;
      _uploadedUrl = null;
      _errorMsg = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor: isComic
                  ? C.bg
                  : (isHud ? C.hudBg() : C.bgDeep),
              appBar: AppBar(
                backgroundColor: isHud ? C.hudPanel() : C.bgDark,
                elevation: 0,
                iconTheme: IconThemeData(color: C.accent),
                title: Text(
                  'CATBOX UPLOADER',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.accentHi),
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontSize: isComic ? 20 : 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: isComic ? 2 : 3,
                  ),
                ),
              ),
              body: Stack(
                children: [
                  if (isComic)
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _HalftonePainter(
                            color: C.primaryLo.withOpacity(0.12)),
                      ),
                    ),
                  if (isHud)
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _HudGridPainter(
                            color: C.hudGridLine()),
                      ),
                    ),
                  SafeArea(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _buildInfoCard(C, isComic, isHud),
                          const SizedBox(height: 16),
                          _buildModeSelector(C, isComic, isHud),
                          const SizedBox(height: 16),
                          _buildUploadArea(C, isComic, isHud),
                          const SizedBox(height: 16),
                          if (_errorMsg != null)
                            _buildErrorBox(C, isComic, isHud),
                          if (_uploadedUrl != null)
                            _buildResultBox(C, isComic, isHud),
                          const SizedBox(height: 16),
                          _buildActionButtons(C, isComic, isHud),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildInfoCard(AppPalette C, bool isComic, bool isHud) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: C.accent.withOpacity(0.15),
                  blurRadius: 10,
                ),
              ],
            )
          : BoxDecoration(
              color: isComic ? C.bgDark : Colors.black.withOpacity(0.35),
              borderRadius: BorderRadius.circular(isComic ? 16 : 12),
              border: Border.all(
                color:
                    isComic ? Colors.black : C.accent.withOpacity(0.35),
                width: isComic ? 4 : 1.2,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(5, 5),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: isHud
                ? BoxDecoration(
                    color: C.accent.withOpacity(0.15),
                    border: Border.all(color: C.accent, width: 1.4),
                    boxShadow: [
                      BoxShadow(
                        color: C.accent.withOpacity(0.4),
                        blurRadius: 10,
                      ),
                    ],
                  )
                : BoxDecoration(
                    shape: BoxShape.circle,
                    color: isComic
                        ? C.primaryHi
                        : C.accent.withOpacity(0.2),
                    border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 3 : 1.5,
                    ),
                  ),
            child: Icon(
              Icons.cloud_upload_rounded,
              color: isComic
                  ? C.contrastTextOn(C.primaryHi)
                  : (isHud ? C.hudNeon() : C.accent),
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'CATBOX.MOE UPLOADER',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: isComic ? 15 : 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 1.5 : 2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Upload foto & dapetin URL permanent gratis. Cocok buat bukti transfer, profile, dll.',
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : (isHud
                            ? C.hudTextDim()
                            : C.text.withOpacity(0.7)),
                    fontSize: isComic ? 12 : 10,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeSelector(
      AppPalette C, bool isComic, bool isHud) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '// MODE UPLOAD',
          style: TextStyle(
            color: isComic
                ? C.comicText
                : (isHud ? C.hudNeon() : C.accent),
            fontSize: isComic ? 13 : 10,
            fontWeight: FontWeight.w900,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _modeButton(
                C: C,
                isComic: isComic,
                isHud: isHud,
                label: 'PERMANENT',
                subtitle: 'catbox.moe',
                icon: Icons.all_inclusive_rounded,
                selected: !_isTemporary,
                onTap: () => setState(() {
                  _isTemporary = false;
                  _uploadedUrl = null;
                }),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _modeButton(
                C: C,
                isComic: isComic,
                isHud: isHud,
                label: 'TEMPORARY',
                subtitle: 'auto-hapus',
                icon: Icons.timer_rounded,
                selected: _isTemporary,
                onTap: () => setState(() {
                  _isTemporary = true;
                  _uploadedUrl = null;
                }),
              ),
            ),
          ],
        ),
        if (_isTemporary) ...[
          const SizedBox(height: 10),
          Text(
            '// EXPIRY',
            style: TextStyle(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.hudNeon() : C.accent),
              fontSize: isComic ? 13 : 10,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: ['1h', '12h', '24h', '72h'].map((e) {
              final sel = _expiry == e;
              return GestureDetector(
                onTap: () => setState(() => _expiry = e),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 8),
                  decoration: isHud
                      ? BoxDecoration(
                          color: sel
                              ? C.accent.withOpacity(0.2)
                              : C.bgDeep.withOpacity(0.6),
                          border: Border.all(
                            color: sel
                                ? C.accent
                                : C.accent.withOpacity(0.3),
                            width: sel ? 1.4 : 1,
                          ),
                          boxShadow: sel
                              ? [
                                  BoxShadow(
                                    color: C.accent.withOpacity(0.4),
                                    blurRadius: 8,
                                  ),
                                ]
                              : null,
                        )
                      : BoxDecoration(
                          color: sel
                              ? (isComic ? C.primaryHi : C.accent)
                              : (isComic ? C.bgDark : C.bg),
                          borderRadius: BorderRadius.circular(
                              isComic ? 10 : 8),
                          border: Border.all(
                            color: isComic
                                ? Colors.black
                                : (sel
                                    ? C.accent
                                    : C.textSub.withOpacity(0.3)),
                            width: isComic ? 3 : 1.2,
                          ),
                        ),
                  child: Text(
                    e,
                    style: TextStyle(
                      color: sel
                          ? (isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : (isHud ? C.hudNeon() : C.bgDeep))
                          : (isComic
                              ? C.comicText
                              : (isHud ? C.hudText() : C.text)),
                      fontWeight: FontWeight.w900,
                      fontFamily:
                          isComic ? 'Bangers' : 'ShareTechMono',
                      fontSize: 12,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ],
    );
  }

  Widget _modeButton({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required String label,
    required String subtitle,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: isHud
            ? BoxDecoration(
                color: selected
                    ? C.accent.withOpacity(0.15)
                    : C.bgDeep.withOpacity(0.6),
                border: Border.all(
                  color: selected
                      ? C.accent
                      : C.accent.withOpacity(0.3),
                  width: selected ? 1.4 : 1,
                ),
                boxShadow: selected
                    ? [
                        BoxShadow(
                          color: C.accent.withOpacity(0.4),
                          blurRadius: 10,
                        ),
                      ]
                    : null,
              )
            : BoxDecoration(
                color: selected
                    ? (isComic
                        ? C.primaryHi
                        : C.accent.withOpacity(0.15))
                    : (isComic ? C.bgDark : C.bg),
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (selected
                          ? C.accent
                          : C.textSub.withOpacity(0.25)),
                  width: isComic ? 3 : (selected ? 2 : 1),
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
        child: Row(
          children: [
            Icon(
              icon,
              color: selected
                  ? (isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : C.accent))
                  : (isComic
                      ? C.comicTextSub
                      : (isHud ? C.hudTextDim() : C.textSub)),
              size: 20,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: selected
                          ? (isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : (isHud ? C.hudNeon() : C.accent))
                          : (isComic
                              ? C.comicText
                              : (isHud ? C.hudText() : C.text)),
                      fontSize: isComic ? 13 : 10,
                      fontWeight: FontWeight.w900,
                      fontFamily:
                          isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: selected
                          ? (isComic
                              ? C.contrastTextOn(C.primaryHi)
                                  .withOpacity(0.85)
                              : C.accent.withOpacity(0.7))
                          : (isComic
                              ? C.comicTextSub
                              : (isHud
                                  ? C.hudTextDim()
                                  : C.textSub)),
                      fontSize: 9,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUploadArea(
      AppPalette C, bool isComic, bool isHud) {
    if (_selectedFile == null) {
      return GestureDetector(
        onTap: () => _showImageOptions(),
        child: Container(
          height: 200,
          decoration: isHud
              ? BoxDecoration(
                  color: C.bgDeep.withOpacity(0.6),
                  border: Border.all(
                    color: C.accent.withOpacity(0.5),
                    width: 1.4,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: C.accent.withOpacity(0.2),
                      blurRadius: 12,
                    ),
                  ],
                )
              : BoxDecoration(
                  color:
                      isComic ? C.bgDark : Colors.black.withOpacity(0.3),
                  borderRadius:
                      BorderRadius.circular(isComic ? 16 : 12),
                  border: Border.all(
                    color: isComic
                        ? Colors.black
                        : C.accent.withOpacity(0.4),
                    width: isComic ? 4 : 2,
                  ),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(5, 5),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.primaryHi.withOpacity(0.15),
                        border: Border.all(
                            color: C.primaryHi, width: 1.4),
                        boxShadow: [
                          BoxShadow(
                            color: C.primaryHi.withOpacity(0.4),
                            blurRadius: 12,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: isComic
                            ? C.primaryHi
                            : C.accent.withOpacity(0.15),
                        border: Border.all(
                          color: isComic ? Colors.black : C.accent,
                          width: isComic ? 4 : 2,
                        ),
                      ),
                child: Icon(
                  Icons.add_photo_alternate_rounded,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.primaryHi : C.accent),
                  size: 30,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                'TAP UNTUK PILIH FOTO',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontSize: isComic ? 16 : 12,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Kamera / Galeri · Max 200MB',
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud
                          ? C.hudTextDim()
                          : C.text.withOpacity(0.5)),
                  fontSize: isComic ? 11 : 10,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: C.accent.withOpacity(0.15),
                  blurRadius: 10,
                ),
              ],
            )
          : BoxDecoration(
              color: isComic ? C.bgDark : Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(isComic ? 16 : 12),
              border: Border.all(
                color: isComic ? Colors.black : C.accent.withOpacity(0.4),
                width: isComic ? 4 : 1.5,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(5, 5),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          ClipRRect(
            borderRadius:
                BorderRadius.circular(isComic ? 12 : (isHud ? 2 : 10)),
            child: Image.file(
              _selectedFile!,
              width: double.infinity,
              height: 220,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _smallButton(
                  C: C,
                  isComic: isComic,
                  isHud: isHud,
                  icon: Icons.refresh_rounded,
                  label: 'GANTI',
                  color: C.accent,
                  onTap: () => _showImageOptions(),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _smallButton(
                  C: C,
                  isComic: isComic,
                  isHud: isHud,
                  icon: Icons.close_rounded,
                  label: 'HAPUS',
                  color: C.primaryHi,
                  onTap: _reset,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _smallButton({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 42,
        decoration: isHud
            ? BoxDecoration(
                color: color.withOpacity(0.15),
                border: Border.all(color: color, width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.3),
                    blurRadius: 8,
                  ),
                ],
              )
            : BoxDecoration(
                color: isComic ? color : color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(isComic ? 10 : 8),
                border: Border.all(
                  color:
                      isComic ? Colors.black : color.withOpacity(0.5),
                  width: isComic ? 3 : 1,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isComic
                  ? C.contrastTextOn(color)
                  : (isHud ? C.hudText() : color),
              size: 14,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isComic
                    ? C.contrastTextOn(color)
                    : (isHud ? C.hudText() : color),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: isComic ? 13 : 10,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorBox(
      AppPalette C, bool isComic, bool isHud) {
    return Container(
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.only(bottom: 12),
      decoration: isHud
          ? BoxDecoration(
              color: Colors.red.withOpacity(0.1),
              border: Border.all(color: Colors.red, width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: Colors.red.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            )
          : BoxDecoration(
              color: isComic ? C.bgDark : Colors.red.withOpacity(0.15),
              borderRadius: BorderRadius.circular(isComic ? 12 : 10),
              border: Border.all(
                color: isComic ? Colors.black : Colors.red,
                width: isComic ? 3 : 1.5,
              ),
            ),
      child: Row(
        children: [
          Icon(
            Icons.error_outline_rounded,
            color:
                isComic ? C.primaryHi : (isHud ? Colors.red : Colors.red[400]),
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _errorMsg!,
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudText() : Colors.red[300]),
                fontSize: isComic ? 13 : 11,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultBox(
      AppPalette C, bool isComic, bool isHud) {
    return Container(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 12),
      decoration: isHud
          ? BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              border: Border.all(color: Colors.green, width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(0.3),
                  blurRadius: 10,
                ),
              ],
            )
          : BoxDecoration(
              color: isComic ? C.bgDark : Colors.green.withOpacity(0.12),
              borderRadius: BorderRadius.circular(isComic ? 16 : 12),
              border: Border.all(
                color: isComic ? Colors.black : Colors.green,
                width: isComic ? 4 : 1.5,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(4, 4),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: isHud
                    ? BoxDecoration(
                        color: Colors.green.withOpacity(0.2),
                        border: Border.all(
                            color: Colors.green, width: 1.4),
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: isComic
                            ? Colors.green
                            : Colors.green.withOpacity(0.2),
                        border: Border.all(
                          color: isComic ? Colors.black : Colors.green,
                          width: isComic ? 3 : 1.5,
                        ),
                      ),
                child: Icon(
                  Icons.check_rounded,
                  color: isComic
                      ? Colors.white
                      : (isHud ? Colors.green : Colors.green[400]),
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'UPLOAD SUKSES!',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : Colors.green[400]),
                    fontSize: isComic ? 16 : 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: isHud
                ? BoxDecoration(
                    color: C.bgDeep.withOpacity(0.7),
                    border: Border.all(
                        color: C.accent.withOpacity(0.4), width: 1),
                  )
                : BoxDecoration(
                    color:
                        isComic ? C.bg : Colors.black.withOpacity(0.4),
                    borderRadius:
                        BorderRadius.circular(isComic ? 10 : 8),
                    border: Border.all(
                      color: isComic
                          ? Colors.black
                          : C.accent.withOpacity(0.4),
                      width: isComic ? 2.5 : 1,
                    ),
                  ),
            child: SelectableText(
              _uploadedUrl!,
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudText() : C.accent),
                fontSize: 11,
                fontFamily:
                    isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _smallButton(
                  C: C,
                  isComic: isComic,
                  isHud: isHud,
                  icon: Icons.copy_rounded,
                  label: 'COPY URL',
                  color: C.accent,
                  onTap: _copyUrl,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _smallButton(
                  C: C,
                  isComic: isComic,
                  isHud: isHud,
                  icon: Icons.open_in_new_rounded,
                  label: 'BUKA',
                  color: C.primaryHi,
                  onTap: () {
                    Clipboard.setData(
                        ClipboardData(text: _uploadedUrl!));
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text(
                            'URL di-copy, paste di browser'),
                        backgroundColor: Colors.green[700],
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(
      AppPalette C, bool isComic, bool isHud) {
    final enabled = _selectedFile != null && !_isUploading;

    return GestureDetector(
      onTap: enabled ? _upload : null,
      child: Container(
        height: 56,
        decoration: isHud
            ? BoxDecoration(
                color: enabled
                    ? C.primaryHi.withOpacity(0.15)
                    : C.bgDeep.withOpacity(0.5),
                border: Border.all(
                  color: enabled
                      ? C.primaryHi
                      : C.hudTextDim().withOpacity(0.4),
                  width: 1.4,
                ),
                boxShadow: enabled
                    ? [
                        BoxShadow(
                          color: C.primaryHi.withOpacity(0.5),
                          blurRadius: 14,
                        ),
                      ]
                    : null,
              )
            : BoxDecoration(
                color: enabled
                    ? (isComic ? C.primaryHi : null)
                    : (isComic ? C.bgDark : C.bg),
                gradient: enabled && !isComic
                    ? LinearGradient(
                        colors: [C.primaryHi, C.primary],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : null,
                borderRadius: BorderRadius.circular(isComic ? 14 : 12),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (enabled
                          ? C.accent
                          : C.textSub.withOpacity(0.3)),
                  width: isComic ? 4 : 1.5,
                ),
                boxShadow: isComic && enabled
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(5, 5),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_isUploading)
              SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudText() : Colors.white),
                ),
              )
            else
              Icon(
                Icons.cloud_upload_rounded,
                color: enabled
                    ? (isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.hudText() : Colors.white))
                    : (isComic
                        ? C.comicTextMuted
                        : (isHud ? C.hudTextDim() : C.textSub)),
                size: 20,
              ),
            const SizedBox(width: 10),
            Text(
              _isUploading ? 'MENGUPLOAD...' : 'UPLOAD SEKARANG',
              style: TextStyle(
                color: enabled
                    ? (isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.hudText() : Colors.white))
                    : (isComic
                        ? C.comicTextMuted
                        : (isHud ? C.hudTextDim() : C.textSub)),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: isComic ? 16 : 13,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showImageOptions() {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Container(
        decoration: isHud
            ? BoxDecoration(
                color: C.hudBg(),
                border: Border.all(color: C.hudBorder(), width: 1.2),
              )
            : BoxDecoration(
                color: C.bgDark,
                borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(24)),
                border: isComic
                    ? Border.all(color: Colors.black, width: 4)
                    : null,
              ),
        padding: const EdgeInsets.all(20),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: isComic ? 5 : 4,
                decoration: BoxDecoration(
                  color: isComic ? Colors.black : C.textSub,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'PILIH SUMBER FOTO',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 18 : 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: _sheetButton(
                      C: C,
                      isComic: isComic,
                      isHud: isHud,
                      icon: Icons.camera_alt_rounded,
                      label: 'KAMERA',
                      onTap: () {
                        Navigator.pop(ctx);
                        _pickImage(ImageSource.camera);
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _sheetButton(
                      C: C,
                      isComic: isComic,
                      isHud: isHud,
                      icon: Icons.photo_library_rounded,
                      label: 'GALERI',
                      onTap: () {
                        Navigator.pop(ctx);
                        _pickImage(ImageSource.gallery);
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sheetButton({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52,
        decoration: isHud
            ? BoxDecoration(
                color: C.accent.withOpacity(0.15),
                border: Border.all(color: C.accent, width: 1.4),
                boxShadow: [
                  BoxShadow(
                    color: C.accent.withOpacity(0.4),
                    blurRadius: 10,
                  ),
                ],
              )
            : BoxDecoration(
                color: isComic
                    ? C.primaryHi
                    : C.accent.withOpacity(0.2),
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                border: Border.all(
                  color: isComic ? Colors.black : C.accent,
                  width: isComic ? 3 : 1.5,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isComic
                  ? C.contrastTextOn(C.primaryHi)
                  : (isHud ? C.hudText() : C.accent),
              size: 18,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isComic
                    ? C.contrastTextOn(C.primaryHi)
                    : (isHud ? C.hudText() : C.accent),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: isComic ? 14 : 11,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _HalftonePainter extends CustomPainter {
  final Color color;
  _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}