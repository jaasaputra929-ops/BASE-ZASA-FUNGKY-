// asmaul_husna_page.dart — 99 Nama Allah (INDUSTRIAL SKEUO + HUD)
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.9),
              blurRadius: size * 1.8,
              spreadRadius: size * 0.3,
            ),
          ],
        ),
      );
    }

    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
              color: Colors.black.withOpacity(0.85),
              width: size * 0.1),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.75 * opacity),
              blurRadius: size * 1.4,
              spreadRadius: size * 0.2,
            ),
            BoxShadow(
              color: color.withOpacity(0.35 * opacity),
              blurRadius: size * 2.6,
              spreadRadius: size * 0.4,
            ),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  final double rotation;
  const _Screw({required this.C, this.size = 14, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.8, 1.5),
            blurRadius: 2.5,
            spreadRadius: -0.5,
          ),
          const BoxShadow(
            color: Colors.white38,
            offset: Offset(-0.8, -0.8),
            blurRadius: 1.5,
          ),
        ],
      ),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.9),
              borderRadius: BorderRadius.circular(size * 0.05),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withOpacity(0.6), width: 1),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.5, 1),
            blurRadius: 1.5,
          ),
          const BoxShadow(
            color: Colors.white54,
            offset: Offset(-0.5, -0.5),
            blurRadius: 1,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: C.accent.withOpacity(0.15),
              blurRadius: 12,
            ),
          ],
        ),
        child: Stack(
          children: [
            child,
            Positioned(
                top: 0,
                left: 0,
                child: SizedBox(
                  width: 12,
                  height: 12,
                  child: CustomPaint(
                    painter: _HudCornerPainter(
                        color: C.accent.withOpacity(0.7)),
                  ),
                )),
            Positioned(
                top: 0,
                right: 0,
                child: SizedBox(
                  width: 12,
                  height: 12,
                  child: CustomPaint(
                    painter: _HudCornerPainter(
                        color: C.accent.withOpacity(0.7)),
                  ),
                )),
            Positioned(
                bottom: 0,
                left: 0,
                child: SizedBox(
                  width: 12,
                  height: 12,
                  child: CustomPaint(
                    painter: _HudCornerPainter(
                        color: C.accent.withOpacity(0.7)),
                  ),
                )),
            Positioned(
                bottom: 0,
                right: 0,
                child: SizedBox(
                  width: 12,
                  height: 12,
                  child: CustomPaint(
                    painter: _HudCornerPainter(
                        color: C.accent.withOpacity(0.7)),
                  ),
                )),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
          const BoxShadow(
            color: Colors.white12,
            offset: Offset(-1, -1),
            blurRadius: 3,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// LEATHER WALL
// ═══════════════════════════════════════════════════════════
class _LeatherWall extends StatelessWidget {
  final AppPalette C;
  const _LeatherWall({required this.C});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    if (isHud) {
      return Container(
        color: C.hudBg(),
        child: CustomPaint(
          painter: _HudGridPainter(color: C.hudGridLine()),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(-0.3, -0.3),
          radius: 1.2,
          colors: [C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.6, 1.0],
        ),
      ),
      child: CustomPaint(painter: const _LeatherTexturePainter()),
    );
  }
}

class _LeatherTexturePainter extends CustomPainter {
  const _LeatherTexturePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rand = math.Random(42);
    final dotPaint = Paint()..color = Colors.black.withOpacity(0.06);
    for (int i = 0; i < 300; i++) {
      canvas.drawCircle(
        Offset(rand.nextDouble() * size.width,
            rand.nextDouble() * size.height),
        rand.nextDouble() * 1.2,
        dotPaint,
      );
    }
    final linePaint = Paint()
      ..color = Colors.black.withOpacity(0.04)
      ..strokeWidth = 0.5;
    for (int i = 0; i < 100; i++) {
      final x = rand.nextDouble() * size.width;
      final y = rand.nextDouble() * size.height;
      final len = rand.nextDouble() * 12 + 3;
      final angle = rand.nextDouble() * math.pi;
      canvas.drawLine(
        Offset(x, y),
        Offset(x + math.cos(angle) * len, y + math.sin(angle) * len),
        linePaint,
      );
    }
  }

  @override
  bool shouldRepaint(_LeatherTexturePainter old) => false;
}

// ═══════════════════════════════════════════════════════════
// ASMAUL HUSNA PAGE
// ═══════════════════════════════════════════════════════════
class AsmaulHusnaPage extends StatefulWidget {
  const AsmaulHusnaPage({super.key});

  @override
  State<AsmaulHusnaPage> createState() => _AsmaulHusnaPageState();
}

class _AsmaulHusnaPageState extends State<AsmaulHusnaPage> {
  final TextEditingController _searchCtrl = TextEditingController();
  List<Map<String, String>> _allData = [];
  List<Map<String, String>> _filtered = [];

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _allData = _asmaulHusnaData;
    _filtered = _allData;
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _filterData(String query) {
    if (query.isEmpty) {
      setState(() => _filtered = _allData);
      return;
    }
    final q = query.toLowerCase();
    setState(() {
      _filtered = _allData.where((item) {
        return item['latin']!.toLowerCase().contains(q) ||
            item['arab']!.contains(q) ||
            item['arti']!.toLowerCase().contains(q) ||
            item['nomor']!.contains(q);
      }).toList();
    });
  }

  void _showDetail(Map<String, String> item, AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
        ),
        child: _MetalPlate(
          C: C,
          radius: 24,
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: C.textSub.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: 20),

              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 6),
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.2),
                        border: Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: LinearGradient(
                          colors: [C.accentHi, C.accent, C.primaryLo],
                        ),
                        border:
                            Border.all(color: C.accentShine, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: C.accent.withOpacity(0.5),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _Led(color: C.bgDeep, size: 5, blink: true),
                    const SizedBox(width: 8),
                    Text(
                      'NOMOR ${item['nomor']}',
                      style: TextStyle(
                        color:
                            isHud ? C.hudNeon() : C.bgDeep,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),

              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 18),
                decoration: isHud
                    ? BoxDecoration(
                        color: C.bgDeep.withOpacity(0.7),
                        border: Border.all(
                            color: C.accent.withOpacity(0.4), width: 1),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.black.withOpacity(0.4),
                        border: Border.all(
                          color: C.accent.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                child: Text(
                  item['arab']!,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: isHud ? C.hudNeon() : C.accentShine,
                    fontSize: 40,
                    fontWeight: FontWeight.w700,
                    height: 1.5,
                    shadows: [
                      Shadow(
                        color: C.accent.withOpacity(0.6),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      C.accent.withOpacity(0.6),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),

              Text(
                item['latin']!,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isHud ? C.hudText() : C.text,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(0, 2),
                      blurRadius: 4,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 8),
                decoration: isHud
                    ? BoxDecoration(
                        color: C.bgDeep.withOpacity(0.7),
                        border: Border.all(
                            color: C.accent.withOpacity(0.5), width: 1),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: C.bgDeep,
                        border: Border.all(
                          color: C.accent.withOpacity(0.5),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.7),
                            offset: const Offset(0, 2),
                            blurRadius: 4,
                          ),
                        ],
                      ),
                child: Text(
                  item['arti']!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isHud ? C.hudNeon() : C.accentShine,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
              const SizedBox(height: 22),

              Row(
                children: [
                  Expanded(
                    child: _BottomButton(
                      C: C,
                      label: 'COPY ARAB',
                      icon: Icons.copy_rounded,
                      color: C.accent,
                      onTap: () {
                        Clipboard.setData(
                            ClipboardData(text: item['arab']!));
                        ScaffoldMessenger.of(ctx).showSnackBar(
                          SnackBar(
                            content: Row(
                              children: [
                                _Led(
                                    color: C.primaryHi,
                                    size: 8,
                                    blink: true),
                                const SizedBox(width: 10),
                                Text(
                                  'Arab berhasil di-copy',
                                  style: TextStyle(
                                    color: C.text,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                            backgroundColor: C.bgDark,
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                              side: BorderSide(
                                  color: C.primaryHi, width: 1.5),
                            ),
                            margin: const EdgeInsets.all(16),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _BottomButton(
                      C: C,
                      label: 'TUTUP',
                      icon: Icons.close_rounded,
                      color: C.primaryHi,
                      onTap: () => Navigator.pop(ctx),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return Scaffold(
          backgroundColor:
              AppTheme.currentStyle.value == ThemeStyle.hudTactical
                  ? C.hudBg()
                  : C.bgDeep,
          body: Stack(
            children: [
              Positioned.fill(
                child: RepaintBoundary(child: _LeatherWall(C: C)),
              ),
              SafeArea(
                child: Column(
                  children: [
                    const SizedBox(height: 8),
                    _buildTopBar(C),
                    const SizedBox(height: 10),
                    _buildSearchBar(C),
                    const SizedBox(height: 8),
                    _buildInfoBar(C),
                    const SizedBox(height: 8),
                    Expanded(
                      child: _filtered.isEmpty
                          ? _buildEmpty(C)
                          : _buildList(C),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36,
                height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.1),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                        boxShadow: [
                          BoxShadow(
                            color: C.accent.withOpacity(0.3),
                            blurRadius: 8,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [C.text, C.bg, C.bgDark],
                        ),
                        border:
                            Border.all(color: C.primaryLo, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.7),
                            offset: const Offset(0, 3),
                            blurRadius: 5,
                          ),
                        ],
                      ),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: C.accent, size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36,
              height: 36,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border: Border.all(color: C.accent, width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: C.accent.withOpacity(0.4),
                          blurRadius: 10,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        center: const Alignment(-0.3, -0.3),
                        colors: [C.accentHi, C.accent, C.primaryLo],
                      ),
                      border:
                          Border.all(color: C.accentShine, width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: C.accent.withOpacity(0.5),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
              child: Icon(Icons.auto_awesome_rounded,
                  color: C.bgDeep, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ASMAUL HUSNA',
                    style: TextStyle(
                      color: isHud ? C.hudNeon() : C.accent,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 13,
                      letterSpacing: 2,
                      shadows: const [
                        Shadow(
                          color: Colors.black,
                          offset: Offset(0, 1),
                          blurRadius: 2,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      _Led(color: C.primaryHi, size: 4, blink: true),
                      const SizedBox(width: 6),
                      Text(
                        '99 NAMA ALLAH · BEAUTIFUL NAMES',
                        style: TextStyle(
                          color: isHud
                              ? C.hudTextDim()
                              : C.text.withOpacity(0.55),
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                          fontSize: 8,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            _Screw(C: C, size: 12),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar(AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isHud) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
          decoration: BoxDecoration(
            color: C.bgDeep.withOpacity(0.7),
            border: Border.all(
                color: C.accent.withOpacity(0.4), width: 1),
            boxShadow: [
              BoxShadow(
                color: C.accent.withOpacity(0.15),
                blurRadius: 10,
              ),
            ],
          ),
          child: Row(
            children: [
              _Led(color: C.accent, size: 5, blink: true),
              const SizedBox(width: 10),
              Icon(Icons.search_rounded, color: C.accent, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) {
                    _filterData(v);
                    setState(() {});
                  },
                  style: TextStyle(
                    color: C.hudText(),
                    fontFamily: 'ShareTechMono',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                  cursorColor: C.accent,
                  decoration: InputDecoration(
                    hintText: 'Cari nama Allah...',
                    hintStyle: TextStyle(
                      color: C.hudTextDim(),
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      letterSpacing: 1,
                    ),
                    border: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
              if (_searchCtrl.text.isNotEmpty)
                GestureDetector(
                  onTap: () {
                    _searchCtrl.clear();
                    _filterData('');
                    setState(() {});
                  },
                  child: Icon(Icons.close_rounded,
                      color: C.hudTextDim(), size: 16),
                ),
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.text, C.bg, C.bgDark],
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              offset: const Offset(0, 4),
              blurRadius: 8,
            ),
          ],
        ),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(9),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [C.bgDeep, C.bgDark],
            ),
            border: Border.all(color: C.bgDark, width: 1.5),
          ),
          child: Row(
            children: [
              _Led(color: C.accent, size: 5, blink: true),
              const SizedBox(width: 10),
              Icon(Icons.search_rounded, color: C.accent, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) {
                    _filterData(v);
                    setState(() {});
                  },
                  style: TextStyle(
                    color: C.text,
                    fontFamily: 'ShareTechMono',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                  cursorColor: C.accent,
                  decoration: InputDecoration(
                    hintText: 'Cari nama Allah...',
                    hintStyle: TextStyle(
                      color: C.textSub.withOpacity(0.6),
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      letterSpacing: 1,
                    ),
                    border: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
              if (_searchCtrl.text.isNotEmpty)
                GestureDetector(
                  onTap: () {
                    _searchCtrl.clear();
                    _filterData('');
                    setState(() {});
                  },
                  child: Icon(Icons.close_rounded,
                      color: C.textSub, size: 16),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoBar(AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            decoration: isHud
                ? BoxDecoration(
                    color: C.accent.withOpacity(0.15),
                    border: Border.all(color: C.accent, width: 1),
                  )
                : BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    gradient: LinearGradient(
                      colors: [C.accentHi, C.accent, C.primaryLo],
                    ),
                    border:
                        Border.all(color: C.accentShine, width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        offset: const Offset(0, 2),
                        blurRadius: 4,
                      ),
                    ],
                  ),
            child: Text(
              '${_filtered.length} NAMA',
              style: TextStyle(
                color: isHud ? C.hudNeon() : C.bgDeep,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const _DzikirInfoPage(),
              ),
            ),
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 3),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.1),
                      border: Border.all(color: C.accent, width: 1),
                    )
                  : BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      color: Colors.black.withOpacity(0.5),
                      border: Border.all(
                          color: C.accent.withOpacity(0.5), width: 1),
                    ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: C.accent, size: 12),
                  const SizedBox(width: 5),
                  Text(
                    'INFO',
                    style: TextStyle(
                      color: C.accent,
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList(AppPalette C) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 24),
      physics: const BouncingScrollPhysics(),
      itemCount: _filtered.length,
      itemBuilder: (_, i) => _buildTile(_filtered[i], C),
    );
  }

  Widget _buildTile(Map<String, String> item, AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          _showDetail(item, C);
        },
        child: isHud
            ? Container(
                decoration: BoxDecoration(
                  color: C.hudPanel(),
                  border: Border.all(
                      color: C.hudBorder(), width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: C.accent.withOpacity(0.12),
                      blurRadius: 8,
                    ),
                  ],
                ),
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 10),
                child: _tileContent(item, C, isComic, isHud),
              )
            : Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [C.text, C.bg, C.bgDark, C.bgDeep],
                    stops: const [0.0, 0.4, 0.7, 1.0],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.75),
                      offset: const Offset(0, 6),
                      blurRadius: 10,
                    ),
                    const BoxShadow(
                      color: Colors.white24,
                      offset: Offset(-1, -1),
                      blurRadius: 3,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(3),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [C.bg, C.bgDark, C.bgDeep],
                    ),
                    border:
                        Border.all(color: Colors.black.withOpacity(0.5)),
                  ),
                  child: _tileContent(item, C, isComic, isHud),
                ),
              ),
      ),
    );
  }

  Widget _tileContent(Map<String, String> item, AppPalette C,
      bool isComic, bool isHud) {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: isHud
              ? BoxDecoration(
                  color: C.accent.withOpacity(0.15),
                  border: Border.all(color: C.accent, width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: C.accent.withOpacity(0.4),
                      blurRadius: 8,
                    ),
                  ],
                )
              : BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [C.accentHi, C.accent, C.primaryLo],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border:
                      Border.all(color: C.accentShine, width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: C.accent.withOpacity(0.4),
                      blurRadius: 8,
                    ),
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      offset: const Offset(0, 2),
                      blurRadius: 3,
                    ),
                  ],
                ),
          child: Center(
            child: Text(
              item['nomor']!,
              style: TextStyle(
                color: isHud ? C.hudNeon() : C.bgDeep,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item['latin']!,
                style: TextStyle(
                  color: isHud ? C.hudText() : C.text,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 3),
              Text(
                item['arti']!,
                style: TextStyle(
                  color: isHud
                      ? C.hudTextDim()
                      : C.text.withOpacity(0.55),
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 0.3,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Text(
          item['arab']!,
          style: TextStyle(
            color: isHud ? C.hudNeon() : C.accentShine,
            fontSize: 20,
            fontWeight: FontWeight.w700,
            shadows: [
              Shadow(
                color: C.accent.withOpacity(0.6),
                blurRadius: 6,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildEmpty(AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _Led(color: C.accent, size: 12, blink: true),
          const SizedBox(height: 16),
          Icon(Icons.search_off_rounded,
              color: isHud ? C.hudTextDim() : C.textSub, size: 56),
          const SizedBox(height: 12),
          Text(
            'NOT FOUND',
            style: TextStyle(
              color: isHud ? C.hudTextDim() : C.textSub,
              fontSize: 11,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// BOTTOM BUTTON
// ═══════════════════════════════════════════════════════════
class _BottomButton extends StatefulWidget {
  final AppPalette C;
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _BottomButton({
    required this.C,
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  State<_BottomButton> createState() => _BottomButtonState();
}

class _BottomButtonState extends State<_BottomButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: 46,
        decoration: isHud
            ? BoxDecoration(
                color: _pressed
                    ? widget.color.withOpacity(0.25)
                    : widget.color.withOpacity(0.12),
                border: Border.all(color: widget.color, width: 1.4),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withOpacity(0.35),
                          blurRadius: 10,
                        ),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: LinearGradient(
                  colors: [
                    widget.color.withOpacity(0.9),
                    widget.color,
                    widget.color.withOpacity(0.7),
                  ],
                ),
                border: Border.all(
                    color: widget.color.withOpacity(0.9), width: 1.5),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withOpacity(0.4),
                          blurRadius: 10,
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          offset: const Offset(0, 3),
                          blurRadius: 5,
                        ),
                      ],
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(widget.icon,
                color: isHud ? C.hudText() : C.text, size: 16),
            const SizedBox(width: 8),
            Text(
              widget.label,
              style: TextStyle(
                color: isHud ? C.hudText() : C.text,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HALAMAN INFO DZIKIR
// ═══════════════════════════════════════════════════════════
class _DzikirInfoPage extends StatelessWidget {
  const _DzikirInfoPage();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        final style = AppTheme.currentStyle.value;
        final isHud = style == ThemeStyle.hudTactical;

        return Scaffold(
          backgroundColor: isHud ? C.hudBg() : C.bgDeep,
          body: Stack(
            children: [
              Positioned.fill(
                child: RepaintBoundary(child: _LeatherWall(C: C)),
              ),
              SafeArea(
                child: Column(
                  children: [
                    const SizedBox(height: 8),
                    _buildTopBar(context, C),
                    const SizedBox(height: 10),
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(14, 4, 14, 24),
                        physics: const BouncingScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildInfoCard(
                              C,
                              icon: Icons.star_rounded,
                              title: 'APA ITU ASMAUL HUSNA?',
                              content:
                                  'Asmaul Husna (الأسماء الحسنى) adalah 99 nama Allah yang indah dan baik. Setiap nama mencerminkan sifat-sifat kesempurnaan Allah SWT.',
                            ),
                            const SizedBox(height: 12),
                            _buildInfoCard(
                              C,
                              icon: Icons.menu_book_rounded,
                              title: 'DALIL AL-QUR\'AN',
                              content:
                                  '"Dan Allah memiliki Asmaul Husna (nama-nama yang terbaik), maka bermohonlah kepada-Nya dengan menyebut Asmaul Husna itu..."',
                              footer: '(QS. Al-A\'raf: 180)',
                            ),
                            const SizedBox(height: 12),
                            _buildBenefitCard(C),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTopBar(BuildContext context, AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36,
                height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.1),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [C.text, C.bg, C.bgDark],
                        ),
                        border:
                            Border.all(color: C.primaryLo, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.7),
                            offset: const Offset(0, 3),
                            blurRadius: 5,
                          ),
                        ],
                      ),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: C.accent, size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'TENTANG ASMAUL HUSNA',
                style: TextStyle(
                  color: isHud ? C.hudNeon() : C.accent,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 2,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
            _Led(color: C.primaryHi, size: 5, blink: true),
            const SizedBox(width: 8),
            _Screw(C: C, size: 12),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(
    AppPalette C, {
    required IconData icon,
    required String title,
    required String content,
    String? footer,
  }) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          colors: [C.accentHi, C.accent, C.primaryLo],
                        ),
                        border: Border.all(
                            color: C.accentShine, width: 1.2),
                        boxShadow: [
                          BoxShadow(
                            color: C.accent.withOpacity(0.5),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                child: Icon(icon,
                    color: isHud ? C.hudNeon() : C.bgDeep, size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: isHud ? C.hudNeon() : C.accent,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(
                        color: Colors.black,
                        offset: Offset(0, 1),
                        blurRadius: 2,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            content,
            style: TextStyle(
              color: isHud ? C.hudText() : C.text,
              fontSize: 12,
              height: 1.7,
              fontWeight: FontWeight.w600,
            ),
          ),
          if (footer != null) ...[
            const SizedBox(height: 6),
            Text(
              footer,
              style: TextStyle(
                color: isHud ? C.hudTextDim() : C.textSub,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildBenefitCard(AppPalette C) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final benefits = [
      'Menenangkan hati dan pikiran',
      'Mendekatkan diri kepada Allah',
      'Menambah keimanan & ketakwaan',
      'Mendapat pahala & keberkahan',
      'Melatih kesabaran & keikhlasan',
    ];

    if (isHud) {
      return _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: C.accent.withOpacity(0.15),
                    border: Border.all(color: C.accent, width: 1.2),
                  ),
                  child: Icon(Icons.lightbulb_rounded,
                      color: C.hudNeon(), size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  'MANFAAT DZIKIR',
                  style: TextStyle(
                    color: C.hudNeon(),
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ...benefits.map(
              (text) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 6),
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: C.accent,
                        boxShadow: [
                          BoxShadow(
                            color: C.accent.withOpacity(0.6),
                            blurRadius: 4,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        text,
                        style: TextStyle(
                          color: C.hudText(),
                          fontSize: 12,
                          height: 1.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }

    return _MetalPlate(
      C: C,
      brass: true,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: C.bgDeep.withOpacity(0.2),
                  border: Border.all(
                      color: C.bgDeep.withOpacity(0.6), width: 1.5),
                ),
                child: Icon(Icons.lightbulb_rounded,
                    color: C.bgDeep, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                'MANFAAT DZIKIR',
                style: TextStyle(
                  color: C.bgDeep,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ...benefits.map(
            (text) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 6),
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: C.bgDeep,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.4),
                          blurRadius: 2,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      text,
                      style: TextStyle(
                        color: C.bgDeep,
                        fontSize: 12,
                        height: 1.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DATA ASMAUL HUSNA (99 NAMA)
// ═══════════════════════════════════════════════════════════
final List<Map<String, String>> _asmaulHusnaData = [
  {'nomor': '1', 'arab': 'الرَّحْمَنُ', 'latin': 'Ar-Rahman', 'arti': 'Yang Maha Pengasih'},
  {'nomor': '2', 'arab': 'الرَّحِيمُ', 'latin': 'Ar-Rahim', 'arti': 'Yang Maha Penyayang'},
  {'nomor': '3', 'arab': 'الْمَلِكُ', 'latin': 'Al-Malik', 'arti': 'Yang Maha Merajai'},
  {'nomor': '4', 'arab': 'الْقُدُّوسُ', 'latin': 'Al-Quddus', 'arti': 'Yang Maha Suci'},
  {'nomor': '5', 'arab': 'السَّلَامُ', 'latin': 'As-Salam', 'arti': 'Yang Maha Memberi Kesejahteraan'},
  {'nomor': '6', 'arab': 'الْمُؤْمِنُ', 'latin': 'Al-Mu\'min', 'arti': 'Yang Maha Memberi Keamanan'},
  {'nomor': '7', 'arab': 'الْمُهَيْمِنُ', 'latin': 'Al-Muhaimin', 'arti': 'Yang Maha Mengatur'},
  {'nomor': '8', 'arab': 'الْعَزِيزُ', 'latin': 'Al-\'Aziz', 'arti': 'Yang Maha Perkasa'},
  {'nomor': '9', 'arab': 'الْجَبَّارُ', 'latin': 'Al-Jabbar', 'arti': 'Yang Maha Memaksa'},
  {'nomor': '10', 'arab': 'الْمُتَكَبِّرُ', 'latin': 'Al-Mutakabbir', 'arti': 'Yang Maha Megah'},
  {'nomor': '11', 'arab': 'الْخَالِقُ', 'latin': 'Al-Khaliq', 'arti': 'Yang Maha Pencipta'},
  {'nomor': '12', 'arab': 'الْبَارِئُ', 'latin': 'Al-Bari\'', 'arti': 'Yang Maha Melepaskan'},
  {'nomor': '13', 'arab': 'الْمُصَوِّرُ', 'latin': 'Al-Musawwir', 'arti': 'Yang Maha Membentuk Rupa'},
  {'nomor': '14', 'arab': 'الْغَفَّارُ', 'latin': 'Al-Ghaffar', 'arti': 'Yang Maha Pengampun'},
  {'nomor': '15', 'arab': 'الْقَهَّارُ', 'latin': 'Al-Qahhar', 'arti': 'Yang Maha Memaksa'},
  {'nomor': '16', 'arab': 'الْوَهَّابُ', 'latin': 'Al-Wahhab', 'arti': 'Yang Maha Pemberi Karunia'},
  {'nomor': '17', 'arab': 'الرَّزَّاقُ', 'latin': 'Ar-Razzaq', 'arti': 'Yang Maha Pemberi Rezeki'},
  {'nomor': '18', 'arab': 'الْفَتَّاحُ', 'latin': 'Al-Fattah', 'arti': 'Yang Maha Pembuka Rahmat'},
  {'nomor': '19', 'arab': 'الْعَلِيمُ', 'latin': 'Al-\'Alim', 'arti': 'Yang Maha Mengetahui'},
  {'nomor': '20', 'arab': 'الْقَابِضُ', 'latin': 'Al-Qabidh', 'arti': 'Yang Maha Menyempitkan'},
  {'nomor': '21', 'arab': 'الْبَاسِطُ', 'latin': 'Al-Basith', 'arti': 'Yang Maha Melapangkan'},
  {'nomor': '22', 'arab': 'الْخَافِضُ', 'latin': 'Al-Khafidh', 'arti': 'Yang Maha Merendahkan'},
  {'nomor': '23', 'arab': 'الرَّافِعُ', 'latin': 'Ar-Rafi\'', 'arti': 'Yang Maha Meninggikan'},
  {'nomor': '24', 'arab': 'الْمُعِزُّ', 'latin': 'Al-Mu\'izz', 'arti': 'Yang Maha Memuliakan'},
  {'nomor': '25', 'arab': 'الْمُذِلُّ', 'latin': 'Al-Mudzill', 'arti': 'Yang Maha Menghinakan'},
  {'nomor': '26', 'arab': 'السَّمِيعُ', 'latin': 'As-Sami\'', 'arti': 'Yang Maha Mendengar'},
  {'nomor': '27', 'arab': 'الْبَصِيرُ', 'latin': 'Al-Basir', 'arti': 'Yang Maha Melihat'},
  {'nomor': '28', 'arab': 'الْحَكَمُ', 'latin': 'Al-Hakam', 'arti': 'Yang Maha Menetapkan'},
  {'nomor': '29', 'arab': 'الْعَدْلُ', 'latin': 'Al-\'Adl', 'arti': 'Yang Maha Adil'},
  {'nomor': '30', 'arab': 'اللَّطِيفُ', 'latin': 'Al-Lathif', 'arti': 'Yang Maha Lembut'},
  {'nomor': '31', 'arab': 'الْخَبِيرُ', 'latin': 'Al-Khabir', 'arti': 'Yang Maha Mengenal'},
  {'nomor': '32', 'arab': 'الْحَلِيمُ', 'latin': 'Al-Halim', 'arti': 'Yang Maha Penyantun'},
  {'nomor': '33', 'arab': 'الْعَظِيمُ', 'latin': 'Al-\'Azhim', 'arti': 'Yang Maha Agung'},
  {'nomor': '34', 'arab': 'الْغَفُورُ', 'latin': 'Al-Ghafur', 'arti': 'Yang Maha Pengampun'},
  {'nomor': '35', 'arab': 'الشَّكُورُ', 'latin': 'Asy-Syakur', 'arti': 'Yang Maha Pembalas Budi'},
  {'nomor': '36', 'arab': 'الْعَلِيُّ', 'latin': 'Al-\'Aliyy', 'arti': 'Yang Maha Tinggi'},
  {'nomor': '37', 'arab': 'الْكَبِيرُ', 'latin': 'Al-Kabir', 'arti': 'Yang Maha Besar'},
  {'nomor': '38', 'arab': 'الْحَفِيظُ', 'latin': 'Al-Hafizh', 'arti': 'Yang Maha Menjaga'},
  {'nomor': '39', 'arab': 'الْمُقِيتُ', 'latin': 'Al-Muqit', 'arti': 'Yang Maha Pemberi Kecukupan'},
  {'nomor': '40', 'arab': 'الْحَسِيبُ', 'latin': 'Al-Hasib', 'arti': 'Yang Maha Membuat Perhitungan'},
  {'nomor': '41', 'arab': 'الْجَلِيلُ', 'latin': 'Al-Jalil', 'arti': 'Yang Maha Luhur'},
  {'nomor': '42', 'arab': 'الْكَرِيمُ', 'latin': 'Al-Karim', 'arti': 'Yang Maha Pemurah'},
  {'nomor': '43', 'arab': 'الرَّقِيبُ', 'latin': 'Ar-Raqib', 'arti': 'Yang Maha Mengawasi'},
  {'nomor': '44', 'arab': 'الْمُجِيبُ', 'latin': 'Al-Mujib', 'arti': 'Yang Maha Mengabulkan'},
  {'nomor': '45', 'arab': 'الْوَاسِعُ', 'latin': 'Al-Wasi\'', 'arti': 'Yang Maha Luas'},
  {'nomor': '46', 'arab': 'الْحَكِيمُ', 'latin': 'Al-Hakim', 'arti': 'Yang Maha Bijaksana'},
  {'nomor': '47', 'arab': 'الْوَدُودُ', 'latin': 'Al-Wadud', 'arti': 'Yang Maha Mengasihi'},
  {'nomor': '48', 'arab': 'الْمَجِيدُ', 'latin': 'Al-Majid', 'arti': 'Yang Maha Mulia'},
  {'nomor': '49', 'arab': 'الْبَاعِثُ', 'latin': 'Al-Ba\'its', 'arti': 'Yang Maha Membangkitkan'},
  {'nomor': '50', 'arab': 'الشَّهِيدُ', 'latin': 'Asy-Syahid', 'arti': 'Yang Maha Menyaksikan'},
  {'nomor': '51', 'arab': 'الْحَقُّ', 'latin': 'Al-Haqq', 'arti': 'Yang Maha Benar'},
  {'nomor': '52', 'arab': 'الْوَكِيلُ', 'latin': 'Al-Wakil', 'arti': 'Yang Maha Memelihara'},
  {'nomor': '53', 'arab': 'الْقَوِيُّ', 'latin': 'Al-Qawiyy', 'arti': 'Yang Maha Kuat'},
  {'nomor': '54', 'arab': 'الْمَتِينُ', 'latin': 'Al-Matin', 'arti': 'Yang Maha Kokoh'},
  {'nomor': '55', 'arab': 'الْوَلِيُّ', 'latin': 'Al-Waliyy', 'arti': 'Yang Maha Melindungi'},
  {'nomor': '56', 'arab': 'الْحَمِيدُ', 'latin': 'Al-Hamid', 'arti': 'Yang Maha Terpuji'},
  {'nomor': '57', 'arab': 'الْمُحْصِي', 'latin': 'Al-Muhshi', 'arti': 'Yang Maha Menghitung'},
  {'nomor': '58', 'arab': 'الْمُبْدِئُ', 'latin': 'Al-Mubdi\'', 'arti': 'Yang Maha Memulai'},
  {'nomor': '59', 'arab': 'الْمُعِيدُ', 'latin': 'Al-Mu\'id', 'arti': 'Yang Maha Mengembalikan'},
  {'nomor': '60', 'arab': 'الْمُحْيِي', 'latin': 'Al-Muhyi', 'arti': 'Yang Maha Menghidupkan'},
  {'nomor': '61', 'arab': 'الْمُمِيتُ', 'latin': 'Al-Mumit', 'arti': 'Yang Maha Mematikan'},
  {'nomor': '62', 'arab': 'الْحَيُّ', 'latin': 'Al-Hayy', 'arti': 'Yang Maha Hidup'},
  {'nomor': '63', 'arab': 'الْقَيُّومُ', 'latin': 'Al-Qayyum', 'arti': 'Yang Maha Mandiri'},
  {'nomor': '64', 'arab': 'الْوَاجِدُ', 'latin': 'Al-Wajid', 'arti': 'Yang Maha Penemu'},
  {'nomor': '65', 'arab': 'الْمَاجِدُ', 'latin': 'Al-Majid', 'arti': 'Yang Maha Mulia'},
  {'nomor': '66', 'arab': 'الْوَاحِدُ', 'latin': 'Al-Wahid', 'arti': 'Yang Maha Tunggal'},
  {'nomor': '67', 'arab': 'الْأَحَدُ', 'latin': 'Al-Ahad', 'arti': 'Yang Maha Esa'},
  {'nomor': '68', 'arab': 'الصَّمَدُ', 'latin': 'Ash-Shamad', 'arti': 'Yang Maha Dibutuhkan'},
  {'nomor': '69', 'arab': 'الْقَادِرُ', 'latin': 'Al-Qadir', 'arti': 'Yang Maha Menentukan'},
  {'nomor': '70', 'arab': 'الْمُقْتَدِرُ', 'latin': 'Al-Muqtadir', 'arti': 'Yang Maha Berkuasa'},
  {'nomor': '71', 'arab': 'الْمُقَدِّمُ', 'latin': 'Al-Muqaddim', 'arti': 'Yang Maha Mendahulukan'},
  {'nomor': '72', 'arab': 'الْمُؤَخِّرُ', 'latin': 'Al-Mu\'akhkhir', 'arti': 'Yang Maha Mengakhirkan'},
  {'nomor': '73', 'arab': 'الْأَوَّلُ', 'latin': 'Al-Awwal', 'arti': 'Yang Maha Awal'},
  {'nomor': '74', 'arab': 'الْآخِرُ', 'latin': 'Al-Akhir', 'arti': 'Yang Maha Akhir'},
  {'nomor': '75', 'arab': 'الظَّاهِرُ', 'latin': 'Azh-Zhahir', 'arti': 'Yang Maha Nyata'},
  {'nomor': '76', 'arab': 'الْبَاطِنُ', 'latin': 'Al-Bathin', 'arti': 'Yang Maha Tersembunyi'},
  {'nomor': '77', 'arab': 'الْوَالِي', 'latin': 'Al-Wali', 'arti': 'Yang Maha Memerintah'},
  {'nomor': '78', 'arab': 'الْمُتَعَالِي', 'latin': 'Al-Muta\'ali', 'arti': 'Yang Maha Tinggi'},
  {'nomor': '79', 'arab': 'الْبَرُّ', 'latin': 'Al-Barr', 'arti': 'Yang Maha Penderma'},
  {'nomor': '80', 'arab': 'التَّوَّابُ', 'latin': 'At-Tawwab', 'arti': 'Yang Maha Penerima Taubat'},
  {'nomor': '81', 'arab': 'الْمُنْتَقِمُ', 'latin': 'Al-Muntaqim', 'arti': 'Yang Maha Pemberi Balasan'},
  {'nomor': '82', 'arab': 'الْعَفُوُّ', 'latin': 'Al-\'Afuww', 'arti': 'Yang Maha Pemaaf'},
  {'nomor': '83', 'arab': 'الرَّءُوفُ', 'latin': 'Ar-Ra\'uf', 'arti': 'Yang Maha Pengasih'},
  {'nomor': '84', 'arab': 'مَالِكُ الْمُلْكِ', 'latin': 'Malikul Mulk', 'arti': 'Yang Maha Penguasa Kerajaan'},
  {'nomor': '85', 'arab': 'ذُو الْجَلَالِ وَالْإِكْرَامِ', 'latin': 'Dzul Jalali wal Ikram', 'arti': 'Yang Maha Pemilik Kebesaran dan Kemuliaan'},
  {'nomor': '86', 'arab': 'الْمُقْسِطُ', 'latin': 'Al-Muqsith', 'arti': 'Yang Maha Pemberi Keadilan'},
  {'nomor': '87', 'arab': 'الْجَامِعُ', 'latin': 'Al-Jami\'', 'arti': 'Yang Maha Mengumpulkan'},
  {'nomor': '88', 'arab': 'الْغَنِيُّ', 'latin': 'Al-Ghaniyy', 'arti': 'Yang Maha Kaya'},
  {'nomor': '89', 'arab': 'الْمُغْنِي', 'latin': 'Al-Mughni', 'arti': 'Yang Maha Pemberi Kekayaan'},
  {'nomor': '90', 'arab': 'الْمَانِعُ', 'latin': 'Al-Mani\'', 'arti': 'Yang Maha Mencegah'},
  {'nomor': '91', 'arab': 'الضَّارُّ', 'latin': 'Adh-Dharr', 'arti': 'Yang Maha Pemberi Bahaya'},
  {'nomor': '92', 'arab': 'النَّافِعُ', 'latin': 'An-Nafi\'', 'arti': 'Yang Maha Pemberi Manfaat'},
  {'nomor': '93', 'arab': 'النُّورُ', 'latin': 'An-Nur', 'arti': 'Yang Maha Bercahaya'},
  {'nomor': '94', 'arab': 'الْهَادِي', 'latin': 'Al-Hadi', 'arti': 'Yang Maha Pemberi Petunjuk'},
  {'nomor': '95', 'arab': 'الْبَدِيعُ', 'latin': 'Al-Badi\'', 'arti': 'Yang Maha Pencipta'},
  {'nomor': '96', 'arab': 'الْبَاقِي', 'latin': 'Al-Baqi', 'arti': 'Yang Maha Kekal'},
  {'nomor': '97', 'arab': 'الْوَارِثُ', 'latin': 'Al-Warits', 'arti': 'Yang Maha Pewaris'},
  {'nomor': '98', 'arab': 'الرَّشِيدُ', 'latin': 'Ar-Rasyid', 'arti': 'Yang Maha Pandai'},
  {'nomor': '99', 'arab': 'الصَّبُورُ', 'latin': 'Ash-Shabur', 'arti': 'Yang Maha Sabar'},
];