// lib/admin_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:math' as math;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'app_theme.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// ADMIN PAGE
// ═══════════════════════════════════════════════════════════
class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({super.key, required this.sessionKey});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage>
    with TickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['vip', 'reseller', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  late AnimationController _headerController;
  late AnimationController _pulseController;
  late Animation<double> _headerFade;
  late Animation<double> _headerSlide;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;

    _headerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _headerFade = CurvedAnimation(
      parent: _headerController,
      curve: Curves.easeOut,
    );
    _headerSlide = Tween<double>(begin: -24, end: 0).animate(
      CurvedAnimation(parent: _headerController, curve: Curves.easeOutCubic),
    );
    _pulse = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _headerController.forward();
    _fetchUsers();
  }

  @override
  void dispose() {
    _headerController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    final C = AppTheme.current.value;
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert(C, 'Error', data['message'] ?? 'Tidak diizinkan.', isError: true);
      }
    } catch (_) {
      _alert(C, 'Koneksi Gagal', 'Tidak dapat menghubungi server.', isError: true);
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final C = AppTheme.current.value;
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert(C, 'Perhatian', 'Masukkan username yang ingin dihapus.',
          isError: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert(C, 'Berhasil',
            "User '${data['user']['username']}' telah dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert(C, 'Gagal', data['message'] ?? 'Gagal menghapus user.',
            isError: true);
      }
    } catch (_) {
      _alert(C, 'Error', 'Tidak dapat menghubungi server.', isError: true);
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final C = AppTheme.current.value;
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _alert(C, 'Perhatian', 'Semua field wajib diisi.', isError: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$newUserRole'));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert(
            C, 'Sukses', "Akun '${data['user']['username']}' berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() => newUserRole = 'member');
        _fetchUsers();
      } else {
        _alert(C, 'Gagal', data['message'] ?? 'Gagal membuat akun.',
            isError: true);
      }
    } catch (_) {
      _alert(C, 'Error', 'Gagal menghubungi server.', isError: true);
    }
    setState(() => isLoading = false);
  }

  void _alert(AppPalette C, String title, String message,
      {bool isError = false}) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final baseColor = isError ? C.primaryHi : C.accent;

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 300),
      transitionBuilder: (ctx, anim, _, child) {
        return ScaleTransition(
          scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
          child: FadeTransition(opacity: anim, child: child),
        );
      },
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        child: isHud
            ? Container(
                constraints: const BoxConstraints(maxWidth: 360),
                decoration: BoxDecoration(
                  color: C.hudPanel(),
                  border: Border.all(
                    color: isError
                        ? C.primaryHi
                        : C.hudBorder(),
                    width: 1.4,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: baseColor.withOpacity(0.35),
                      blurRadius: 20,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: baseColor.withOpacity(0.15),
                        border: Border.all(color: baseColor, width: 1.4),
                        boxShadow: [
                          BoxShadow(
                            color: baseColor.withOpacity(0.4),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: Icon(
                        isError
                            ? Icons.warning_amber_rounded
                            : Icons.check_circle_outline,
                        color: baseColor,
                        size: 28,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      title.toUpperCase(),
                      style: TextStyle(
                        color: isError
                            ? C.primaryHi
                            : C.hudNeon(),
                        fontFamily: 'Orbitron',
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: C.hudText(),
                        fontFamily: 'ShareTechMono',
                        fontSize: 12,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 22),
                    _buildButton(
                      C,
                      label: 'OK',
                      onTap: () => Navigator.pop(ctx),
                      fullWidth: true,
                      isDestructive: isError,
                    ),
                  ],
                ),
              )
            : (isComic
                ? Container(
                    constraints: const BoxConstraints(maxWidth: 360),
                    decoration: BoxDecoration(
                      color: C.bgDark,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.black, width: 4),
                      boxShadow: const [
                        BoxShadow(
                            color: Colors.black,
                            offset: Offset(6, 6),
                            blurRadius: 0),
                      ],
                    ),
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: baseColor,
                            border:
                                Border.all(color: Colors.black, width: 3),
                          ),
                          child: Icon(
                            isError
                                ? Icons.warning_amber_rounded
                                : Icons.check_circle_outline,
                            color: C.contrastTextOn(baseColor),
                            size: 28,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(title.toUpperCase(),
                            style: TextStyle(
                              color: C.comicText,
                              fontFamily: 'Bangers',
                              fontSize: 22,
                              letterSpacing: 2,
                            )),
                        const SizedBox(height: 10),
                        Text(message,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: C.comicTextSub,
                              fontFamily: 'ComicNeue',
                              fontSize: 13,
                              height: 1.5,
                            )),
                        const SizedBox(height: 22),
                        _buildButton(
                          C,
                          label: 'OK',
                          onTap: () => Navigator.pop(ctx),
                          fullWidth: true,
                          isDestructive: isError,
                        ),
                      ],
                    ),
                  )
                : Container(
                    constraints: const BoxConstraints(maxWidth: 360),
                    decoration: BoxDecoration(
                      color: C.bgDark,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: baseColor.withOpacity(0.4),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: baseColor.withOpacity(0.15),
                          blurRadius: 40,
                          spreadRadius: 0,
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: baseColor.withOpacity(0.12),
                          ),
                          child: Icon(
                            isError
                                ? Icons.warning_amber_rounded
                                : Icons.check_circle_outline,
                            color: baseColor,
                            size: 26,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(title,
                            style: TextStyle(
                              color: C.text,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.3,
                            )),
                        const SizedBox(height: 10),
                        Text(message,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: C.textSub, fontSize: 14, height: 1.5)),
                        const SizedBox(height: 24),
                        _buildButton(
                          C,
                          label: 'OK',
                          onTap: () => Navigator.pop(ctx),
                          isDestructive: false,
                          fullWidth: true,
                        ),
                      ],
                    ),
                  )),
      ),
    );
  }

  Future<bool?> _confirmDelete(AppPalette C, String username) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    return showGeneralDialog<bool>(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 280),
      transitionBuilder: (ctx, anim, _, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        child: isHud
            ? Container(
                constraints: const BoxConstraints(maxWidth: 360),
                decoration: BoxDecoration(
                  color: C.hudPanel(),
                  border: Border.all(color: C.primaryHi, width: 1.4),
                  boxShadow: [
                    BoxShadow(
                      color: C.primaryHi.withOpacity(0.35),
                      blurRadius: 20,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: C.primaryHi.withOpacity(0.15),
                        border: Border.all(color: C.primaryHi, width: 1.4),
                        boxShadow: [
                          BoxShadow(
                            color: C.primaryHi.withOpacity(0.4),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: Icon(Icons.delete_outline_rounded,
                          color: C.primaryHi, size: 28),
                    ),
                    const SizedBox(height: 16),
                    Text('HAPUS USER?',
                        style: TextStyle(
                          color: C.primaryHi,
                          fontFamily: 'Orbitron',
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                        )),
                    const SizedBox(height: 10),
                    Text("Yakin ingin menghapus '$username'?",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: C.hudText(),
                          fontFamily: 'ShareTechMono',
                          fontSize: 12,
                          height: 1.5,
                        )),
                    const SizedBox(height: 22),
                    Row(
                      children: [
                        Expanded(
                          child: _buildButton(
                            C,
                            label: 'BATAL',
                            onTap: () => Navigator.pop(ctx, false),
                            isOutline: true,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _buildButton(
                            C,
                            label: 'HAPUS',
                            onTap: () => Navigator.pop(ctx, true),
                            isDestructive: true,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              )
            : (isComic
                ? Container(
                    constraints: const BoxConstraints(maxWidth: 360),
                    decoration: BoxDecoration(
                      color: C.bgDark,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.black, width: 4),
                      boxShadow: const [
                        BoxShadow(
                            color: Colors.black,
                            offset: Offset(6, 6),
                            blurRadius: 0),
                      ],
                    ),
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: C.primaryHi,
                            border:
                                Border.all(color: Colors.black, width: 3),
                          ),
                          child: Icon(Icons.delete_outline_rounded,
                              color: C.contrastTextOn(C.primaryHi),
                              size: 28),
                        ),
                        const SizedBox(height: 16),
                        Text('HAPUS USER?',
                            style: TextStyle(
                              color: C.comicText,
                              fontFamily: 'Bangers',
                              fontSize: 22,
                              letterSpacing: 2,
                            )),
                        const SizedBox(height: 10),
                        Text("Yakin ingin menghapus '$username'?",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: C.comicTextSub,
                              fontFamily: 'ComicNeue',
                              fontSize: 13,
                              height: 1.5,
                            )),
                        const SizedBox(height: 22),
                        Row(
                          children: [
                            Expanded(
                              child: _buildButton(
                                C,
                                label: 'BATAL',
                                onTap: () => Navigator.pop(ctx, false),
                                isOutline: true,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildButton(
                                C,
                                label: 'HAPUS',
                                onTap: () => Navigator.pop(ctx, true),
                                isDestructive: true,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                : Container(
                    constraints: const BoxConstraints(maxWidth: 360),
                    decoration: BoxDecoration(
                      color: C.bgDark,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: C.primaryHi.withOpacity(0.35), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: C.primaryHi.withOpacity(0.12),
                          blurRadius: 40,
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: C.primaryHi.withOpacity(0.12),
                          ),
                          child: Icon(Icons.delete_outline_rounded,
                              color: C.primaryHi, size: 26),
                        ),
                        const SizedBox(height: 16),
                        Text('Hapus User',
                            style: TextStyle(
                                color: C.text,
                                fontSize: 18,
                                fontWeight: FontWeight.w700)),
                        const SizedBox(height: 10),
                        Text(
                            "Yakin ingin menghapus '$username'?\nTindakan ini tidak bisa dibatalkan.",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: C.textSub, fontSize: 14, height: 1.5)),
                        const SizedBox(height: 24),
                        Row(
                          children: [
                            Expanded(
                              child: _buildButton(
                                C,
                                label: 'Batal',
                                onTap: () => Navigator.pop(ctx, false),
                                isOutline: true,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildButton(
                                C,
                                label: 'Hapus',
                                onTap: () => Navigator.pop(ctx, true),
                                isDestructive: true,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  )),
      ),
    );
  }

  Widget _buildButton(
    AppPalette C, {
    required String label,
    required VoidCallback onTap,
    bool isDestructive = false,
    bool isOutline = false,
    bool fullWidth = false,
    dynamic icon,
    bool loading = false,
    bool isComic = false,
  }) {
    final style = AppTheme.currentStyle.value;
    final comicMode = style == ThemeStyle.comic3d;
    final hudMode = style == ThemeStyle.hudTactical;
    final Color baseColor = isDestructive ? C.primaryHi : C.accent;

    if (hudMode) {
      final color = isOutline ? C.hudTextDim() : baseColor;
      final fg = isOutline ? C.hudText() : C.hudText();
      return SizedBox(
        width: fullWidth ? double.infinity : null,
        height: 50,
        child: _PressableButton(
          onTap: loading ? null : onTap,
          child: Container(
            decoration: BoxDecoration(
              color: isOutline
                  ? C.bgDeep.withOpacity(0.6)
                  : baseColor.withOpacity(0.15),
              border: Border.all(color: color, width: 1.4),
              boxShadow: isOutline
                  ? null
                  : [
                      BoxShadow(
                        color: baseColor.withOpacity(0.35),
                        blurRadius: 10,
                      ),
                    ],
            ),
            child: loading
                ? Center(
                    child: SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: fg),
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (icon != null) ...[
                        _DynamicIcon(icon, size: 16, color: fg),
                        const SizedBox(width: 8),
                      ],
                      Text(
                        label,
                        style: TextStyle(
                          color: fg,
                          fontFamily: 'Orbitron',
                          fontSize: 12,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      );
    }

    if (comicMode) {
      final bg = isOutline ? C.bgDark : baseColor;
      final fg = isOutline ? C.comicText : C.contrastTextOn(baseColor);
      return SizedBox(
        width: fullWidth ? double.infinity : null,
        height: 50,
        child: _PressableButton(
          onTap: loading ? null : onTap,
          child: Container(
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.black, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0),
              ],
            ),
            child: loading
                ? Center(
                    child: SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: fg),
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (icon != null) ...[
                        _DynamicIcon(icon, size: 16, color: fg),
                        const SizedBox(width: 8),
                      ],
                      Text(
                        label,
                        style: TextStyle(
                          color: fg,
                          fontFamily: 'Bangers',
                          fontSize: 16,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      );
    }

    return SizedBox(
      width: fullWidth ? double.infinity : null,
      height: 46,
      child: _PressableButton(
        onTap: loading ? null : onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          decoration: BoxDecoration(
            gradient: isOutline
                ? null
                : LinearGradient(
                    colors: [
                      baseColor,
                      baseColor.withOpacity(0.7),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            color: isOutline ? Colors.transparent : null,
            borderRadius: BorderRadius.circular(12),
            border: isOutline
                ? Border.all(color: C.bg, width: 1.5)
                : null,
            boxShadow: isOutline
                ? null
                : [
                    BoxShadow(
                      color: baseColor.withOpacity(0.25),
                      blurRadius: 16,
                      offset: const Offset(0, 4),
                    ),
                  ],
          ),
          child: loading
              ? Center(
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: C.bgDeep),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[
                      _DynamicIcon(icon,
                          size: 16,
                          color: isOutline ? C.textSub : C.bgDeep),
                      const SizedBox(width: 8),
                    ],
                    Text(
                      label,
                      style: TextStyle(
                        color: isOutline ? C.textSub : C.bgDeep,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildInput(
    AppPalette C, {
    required bool isComic,
    required String label,
    required TextEditingController controller,
    required dynamic icon,
    TextInputType type = TextInputType.text,
    bool obscure = false,
  }) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    if (isHud) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Text(label.toUpperCase(),
                  style: TextStyle(
                    color: C.hudNeon(),
                    fontFamily: 'Orbitron',
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  )),
            ),
            Container(
              decoration: BoxDecoration(
                color: C.bgDeep.withOpacity(0.7),
                border: Border.all(
                    color: C.accent.withOpacity(0.4), width: 1),
              ),
              child: TextField(
                controller: controller,
                keyboardType: type,
                obscureText: obscure,
                style: TextStyle(
                    color: C.hudText(),
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                    fontSize: 13),
                cursorColor: C.accent,
                decoration: InputDecoration(
                  prefixIcon: _DynamicIcon(icon,
                      color: C.accent, size: 18),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                ),
              ),
            ),
          ],
        ),
      );
    }

    if (isComic) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Text(label.toUpperCase(),
                  style: TextStyle(
                    color: C.comicText,
                    fontFamily: 'Bangers',
                    fontSize: 13,
                    letterSpacing: 1.5,
                  )),
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
              ),
              child: TextField(
                controller: controller,
                keyboardType: type,
                obscureText: obscure,
                style: const TextStyle(
                    color: Colors.black,
                    fontFamily: 'ComicNeue',
                    fontWeight: FontWeight.w700,
                    fontSize: 14),
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  prefixIcon: _DynamicIcon(icon, color: C.primaryHi, size: 18),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        obscureText: obscure,
        style: TextStyle(
            color: C.text, fontSize: 14, fontWeight: FontWeight.w500),
        cursorColor: C.accent,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: C.textSub, fontSize: 13),
          floatingLabelStyle: TextStyle(color: C.accent, fontSize: 12),
          prefixIcon: _DynamicIcon(icon, color: C.text, size: 18),
          filled: true,
          fillColor: C.bgDeep,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: C.bg),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: C.bg),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: C.accent, width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown(
    AppPalette C, {
    required bool isComic,
    required String value,
    required List<String> options,
    required ValueChanged<String?> onChanged,
    String? label,
  }) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    if (isHud) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (label != null)
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 6),
                child: Text(label.toUpperCase(),
                    style: TextStyle(
                      color: C.hudNeon(),
                      fontFamily: 'Orbitron',
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    )),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: C.bgDeep.withOpacity(0.7),
                border: Border.all(
                    color: C.accent.withOpacity(0.4), width: 1),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: value,
                  isExpanded: true,
                  dropdownColor: C.hudPanelHi(),
                  style: TextStyle(
                    color: C.hudText(),
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                  icon: Icon(Icons.expand_more,
                      color: C.accent, size: 20),
                  items: options
                      .map((opt) => DropdownMenuItem(
                          value: opt, child: Text(opt.toUpperCase())))
                      .toList(),
                  onChanged: onChanged,
                ),
              ),
            ),
          ],
        ),
      );
    }

    if (isComic) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (label != null)
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 6),
                child: Text(label.toUpperCase(),
                    style: TextStyle(
                      color: C.comicText,
                      fontFamily: 'Bangers',
                      fontSize: 13,
                      letterSpacing: 1.5,
                    )),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: value,
                  isExpanded: true,
                  dropdownColor: Colors.white,
                  style: const TextStyle(
                    color: Colors.black,
                    fontFamily: 'ComicNeue',
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                  items: options
                      .map((opt) => DropdownMenuItem(
                          value: opt, child: Text(opt.toUpperCase())))
                      .toList(),
                  onChanged: onChanged,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: C.bg),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (label != null)
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 2),
              child:
                  Text(label, style: TextStyle(color: C.textSub, fontSize: 11)),
            ),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              dropdownColor: C.bgDark,
              icon: Icon(Icons.expand_more, color: C.text, size: 20),
              style: TextStyle(
                  color: C.text,
                  fontSize: 14,
                  fontWeight: FontWeight.w500),
              items: options.map((opt) {
                return DropdownMenuItem(
                  value: opt,
                  child: Text(opt.toUpperCase(),
                      style: const TextStyle(letterSpacing: 0.5)),
                );
              }).toList(),
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(
    AppPalette C, {
    required bool isComic,
    required String title,
    required String subtitle,
    required dynamic icon,
    required List<Widget> children,
    Color? accentColor,
  }) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final color = accentColor ?? C.accent;

    if (isHud) {
      return Container(
        margin: const EdgeInsets.only(bottom: 20),
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.15),
              blurRadius: 12,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                      color: C.accent.withOpacity(0.3), width: 1),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      border: Border.all(color: color, width: 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.35),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: _DynamicIcon(icon,
                        color: color, size: 18),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: TextStyle(
                              color: C.hudNeon(),
                              fontSize: 13,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                            )),
                        Text(subtitle,
                            style: TextStyle(
                                color: C.hudTextDim(),
                                fontFamily: 'ShareTechMono',
                                fontSize: 10)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: children,
              ),
            ),
          ],
        ),
      );
    }

    if (isComic) {
      return Container(
        margin: const EdgeInsets.only(bottom: 20),
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Colors.black, width: 3),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.black, width: 2.5),
                    ),
                    child: _DynamicIcon(icon,
                        color: C.contrastTextOn(color), size: 18),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: TextStyle(
                              color: C.comicText,
                              fontSize: 16,
                              fontFamily: 'Bangers',
                              letterSpacing: 1.5,
                            )),
                        Text(subtitle,
                            style: TextStyle(
                                color: C.comicTextSub,
                                fontFamily: 'ComicNeue',
                                fontSize: 11)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: children,
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      decoration: BoxDecoration(
        color: C.bgDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: C.bg),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.06),
            blurRadius: 30,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
            decoration: BoxDecoration(
              border:
                  Border(bottom: BorderSide(color: C.bg.withOpacity(0.6))),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: color.withOpacity(0.2)),
                  ),
                  child: _DynamicIcon(icon, color: color, size: 18),
                ),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: TextStyle(
                          color: C.text,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        )),
                    Text(subtitle,
                        style: TextStyle(color: C.textSub, fontSize: 11)),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: children,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserItem(AppPalette C, bool isComic, Map user, int index) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index * 50).clamp(0, 400)),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(
          offset: Offset(0, 12 * (1 - v)),
          child: child,
        ),
      ),
      child: isHud
          ? Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: C.bgDeep.withOpacity(0.6),
                border: Border.all(
                    color: C.accent.withOpacity(0.4), width: 1),
              ),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: C.primaryHi.withOpacity(0.15),
                      border:
                          Border.all(color: C.primaryHi, width: 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: C.primaryHi.withOpacity(0.3),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        (user['username'] as String)
                            .substring(0, 1)
                            .toUpperCase(),
                        style: TextStyle(
                          color: C.hudNeon(),
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user['username'],
                            style: TextStyle(
                                color: C.hudText(),
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                letterSpacing: 1)),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            _badge(C, user['role'].toUpperCase(), isComic),
                            const SizedBox(width: 8),
                            Text("Exp: ${user['expiredDate']}",
                                style: TextStyle(
                                    color: C.hudTextDim(),
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700)),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text("Parent: ${user['parent'] ?? 'SYSTEM'}",
                            style: TextStyle(
                                color: C.hudTextDim(),
                                fontFamily: 'ShareTechMono',
                                fontSize: 10)),
                      ],
                    ),
                  ),
                  _IconBtn(
                    C: C,
                    icon: Icons.delete_outline_rounded,
                    color: C.primaryHi,
                    isComic: false,
                    onTap: () async {
                      final confirm =
                          await _confirmDelete(C, user['username']);
                      if (confirm == true) {
                        deleteController.text = user['username'];
                        _deleteUser();
                      }
                    },
                  ),
                ],
              ),
            )
          : isComic
              ? Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.black, width: 3),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: C.primaryHi,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.black, width: 2.5),
                        ),
                        child: Center(
                          child: Text(
                            (user['username'] as String)
                                .substring(0, 1)
                                .toUpperCase(),
                            style: TextStyle(
                              color: C.contrastTextOn(C.primaryHi),
                              fontFamily: 'Bangers',
                              fontWeight: FontWeight.w700,
                              fontSize: 20,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(user['username'],
                                style: const TextStyle(
                                    color: Colors.black,
                                    fontFamily: 'Bangers',
                                    fontWeight: FontWeight.w700,
                                    fontSize: 16,
                                    letterSpacing: 1)),
                            const SizedBox(height: 3),
                            Row(
                              children: [
                                _badge(C, user['role'].toUpperCase(), true),
                                const SizedBox(width: 8),
                                Text("Exp: ${user['expiredDate']}",
                                    style: TextStyle(
                                        color: Colors.black.withOpacity(0.6),
                                        fontFamily: 'ComicNeue',
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700)),
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text("Parent: ${user['parent'] ?? 'SYSTEM'}",
                                style: TextStyle(
                                    color: Colors.black.withOpacity(0.4),
                                    fontFamily: 'ComicNeue',
                                    fontSize: 11)),
                          ],
                        ),
                      ),
                      _IconBtn(
                        C: C,
                        icon: Icons.delete_outline_rounded,
                        color: C.primaryHi,
                        isComic: true,
                        onTap: () async {
                          final confirm =
                              await _confirmDelete(C, user['username']);
                          if (confirm == true) {
                            deleteController.text = user['username'];
                            _deleteUser();
                          }
                        },
                      ),
                    ],
                  ),
                )
              : Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: C.bgDeep,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: C.bg),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: C.accent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(
                            (user['username'] as String)
                                .substring(0, 1)
                                .toUpperCase(),
                            style: TextStyle(
                              color: C.accent,
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(user['username'],
                                style: TextStyle(
                                    color: C.text,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14)),
                            const SizedBox(height: 3),
                            Row(
                              children: [
                                _badge(C, user['role'].toUpperCase(), false),
                                const SizedBox(width: 8),
                                Text("Exp: ${user['expiredDate']}",
                                    style: TextStyle(
                                        color: C.textSub, fontSize: 11)),
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text("Parent: ${user['parent'] ?? 'SYSTEM'}",
                                style: TextStyle(
                                    color: C.text.withOpacity(0.4),
                                    fontSize: 11)),
                          ],
                        ),
                      ),
                      _IconBtn(
                        C: C,
                        icon: Icons.delete_outline_rounded,
                        color: C.primaryHi,
                        isComic: false,
                        onTap: () async {
                          final confirm =
                              await _confirmDelete(C, user['username']);
                          if (confirm == true) {
                            deleteController.text = user['username'];
                            _deleteUser();
                          }
                        },
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _badge(AppPalette C, String label, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    if (isHud) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(
          color: C.accent.withOpacity(0.15),
          border: Border.all(
              color: C.accent.withOpacity(0.6), width: 1),
        ),
        child: Text(label,
            style: TextStyle(
                color: C.hudNeon(),
                fontSize: 9,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                letterSpacing: 1)),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: isComic
            ? C.primaryHi
            : C.accent.withOpacity(0.1),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.3),
          width: isComic ? 2 : 1,
        ),
      ),
      child: Text(label,
          style: TextStyle(
              color: isComic ? C.contrastTextOn(C.primaryHi) : C.accent,
              fontSize: 10,
              fontFamily: isComic ? 'Bangers' : 'ShareTechMono',
              fontWeight: FontWeight.w700)),
    );
  }

  Widget _buildPagination(AppPalette C, bool isComic) {
    if (totalPages <= 1) return const SizedBox();
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _PillBtn(
            C: C,
            isComic: isComic,
            icon: Icons.chevron_left,
            enabled: currentPage > 1,
            onTap: () => setState(() => currentPage--),
          ),
          const SizedBox(width: 6),
          ...List.generate(totalPages, (i) {
            final page = i + 1;
            final active = page == currentPage;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: _PillBtn(
                C: C,
                isComic: isComic,
                label: '$page',
                active: active,
                onTap: () => setState(() => currentPage = page),
              ),
            );
          }),
          const SizedBox(width: 6),
          _PillBtn(
            C: C,
            isComic: isComic,
            icon: Icons.chevron_right,
            enabled: currentPage < totalPages,
            onTap: () => setState(() => currentPage++),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          )
                        : (isHud
                            ? CustomPaint(
                                painter: _HudGridPainter(
                                    color: C.hudGridLine()),
                              )
                            : _GridBackground(C: C)),
                  ),

                  SafeArea(
                    child: CustomScrollView(
                      physics: const BouncingScrollPhysics(),
                      slivers: [
                        SliverToBoxAdapter(
                          child: AnimatedBuilder(
                            animation: _headerController,
                            builder: (_, __) => Opacity(
                              opacity: _headerFade.value,
                              child: Transform.translate(
                                offset: Offset(0, _headerSlide.value),
                                child: _buildHeader(C, isComic),
                              ),
                            ),
                          ),
                        ),

                        SliverPadding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
                          sliver: SliverList(
                            delegate: SliverChildListDelegate([
                              _buildStatsRow(C, isComic),
                              const SizedBox(height: 24),

                              _buildSection(
                                C,
                                isComic: isComic,
                                title: isComic
                                    ? 'HAPUS USER'
                                    : 'Hapus User',
                                subtitle: 'Nonaktifkan akun dari sistem',
                                icon: FontAwesomeIcons.userSlash,
                                accentColor: C.primaryHi,
                                children: [
                                  _buildInput(
                                    C,
                                    isComic: isComic,
                                    label: 'Username Target',
                                    controller: deleteController,
                                    icon: FontAwesomeIcons.user,
                                  ),
                                  const SizedBox(height: 4),
                                  _buildButton(
                                    C,
                                    label: 'HAPUS AKUN',
                                    onTap: _deleteUser,
                                    icon: Icons.delete_outline_rounded,
                                    isDestructive: true,
                                    fullWidth: true,
                                    loading: isLoading,
                                  ),
                                ],
                              ),

                              _buildSection(
                                C,
                                isComic: isComic,
                                title: isComic
                                    ? 'BUAT AKUN BARU'
                                    : 'Buat Akun Baru',
                                subtitle: 'Tambah pengguna ke sistem',
                                icon: FontAwesomeIcons.userPlus,
                                children: [
                                  _buildInput(
                                    C,
                                    isComic: isComic,
                                    label: 'Username',
                                    controller: createUsernameController,
                                    icon: FontAwesomeIcons.user,
                                  ),
                                  _buildInput(
                                    C,
                                    isComic: isComic,
                                    label: 'Password',
                                    controller: createPasswordController,
                                    icon: FontAwesomeIcons.lock,
                                    obscure: true,
                                  ),
                                  _buildInput(
                                    C,
                                    isComic: isComic,
                                    label: 'Durasi (Hari)',
                                    controller: createDayController,
                                    icon: FontAwesomeIcons.calendarDay,
                                    type: TextInputType.number,
                                  ),
                                  _buildDropdown(
                                    C,
                                    isComic: isComic,
                                    value: newUserRole,
                                    options: roleOptions,
                                    label: 'Role',
                                    onChanged: (v) => setState(
                                        () => newUserRole = v ?? 'member'),
                                  ),
                                  const SizedBox(height: 16),
                                  _buildButton(
                                    C,
                                    label: 'BUAT AKUN',
                                    onTap: _createAccount,
                                    icon: Icons.add_rounded,
                                    fullWidth: true,
                                    loading: isLoading,
                                  ),
                                ],
                              ),

                              _buildSection(
                                C,
                                isComic: isComic,
                                title: isComic
                                    ? 'USER MANAGEMENT'
                                    : 'User Management',
                                subtitle:
                                    '${filteredList.length} pengguna ditemukan',
                                icon: FontAwesomeIcons.users,
                                children: [
                                  _buildDropdown(
                                    C,
                                    isComic: isComic,
                                    value: selectedRole,
                                    options: roleOptions,
                                    label: 'Filter Role',
                                    onChanged: (v) {
                                      if (v != null) {
                                        selectedRole = v;
                                        _filterAndPaginate();
                                      }
                                    },
                                  ),
                                  const SizedBox(height: 16),
                                  if (isLoading)
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 32),
                                      child: Center(
                                        child: _LoadingDots(
                                            C: C, isComic: isComic),
                                      ),
                                    )
                                  else if (filteredList.isEmpty)
                                    _buildEmptyState(C, isComic)
                                  else
                                    Column(
                                      children: [
                                        ..._getCurrentPageData()
                                            .asMap()
                                            .entries
                                            .map((e) => _buildUserItem(
                                                C, isComic, e.value, e.key))
                                            .toList(),
                                        const SizedBox(height: 16),
                                        _buildPagination(C, isComic),
                                      ],
                                    ),
                                ],
                              ),
                            ]),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildHeader(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 20),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (_, __) => Container(
              width: 44,
              height: 44,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border: Border.all(
                        color: C.accent.withOpacity(0.4 + 0.5 * _pulse.value),
                        width: 1.4,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color:
                              C.accent.withOpacity(0.3 * _pulse.value),
                          blurRadius: 16,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      color: isComic ? C.primaryHi : C.bgDark,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isComic
                            ? Colors.black
                            : C.accent.withOpacity(0.4 * _pulse.value),
                        width: isComic ? 3 : 1,
                      ),
                      boxShadow: isComic
                          ? const [
                              BoxShadow(
                                  color: Colors.black,
                                  offset: Offset(3, 3),
                                  blurRadius: 0),
                            ]
                          : [
                              BoxShadow(
                                color: C.accent
                                    .withOpacity(0.2 * _pulse.value),
                                blurRadius: 16,
                              ),
                            ],
                    ),
              child: Icon(Icons.admin_panel_settings_outlined,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.accent : C.accent),
                  size: 22),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: isHud
                ? Text('ADMIN DASHBOARD',
                    style: TextStyle(
                      color: C.hudNeon(),
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2.5,
                      shadows: [
                        Shadow(
                          color: C.accent.withOpacity(0.6),
                          blurRadius: 8,
                        ),
                      ],
                    ))
                : (isComic
                    ? Text('ADMIN DASHBOARD',
                        style: TextStyle(
                          color: C.comicText,
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Bangers',
                          letterSpacing: 2,
                        ))
                    : ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          colors: [C.accent, C.accentHi],
                        ).createShader(bounds),
                        child: const Text('Admin Dashboard',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -0.3,
                            )),
                      )),
          ),
          _IconBtn(
            C: C,
            icon: Icons.refresh_rounded,
            color: isComic
                ? C.comicText
                : (isHud ? C.hudText() : C.textSub),
            isComic: isComic,
            onTap: _fetchUsers,
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow(AppPalette C, bool isComic) {
    final totalAll = fullUserList.length;
    final totalReseller =
        fullUserList.where((u) => u['role'] == 'reseller').length;
    final totalMember =
        fullUserList.where((u) => u['role'] == 'member').length;

    return Row(
      children: [
        _buildStatCard(C, isComic, 'Total User', '$totalAll',
            Icons.people_outline_rounded, C.accent),
        const SizedBox(width: 10),
        _buildStatCard(C, isComic, 'Reseller', '$totalReseller',
            Icons.storefront_outlined, C.primaryHi),
        const SizedBox(width: 10),
        _buildStatCard(C, isComic, 'Member', '$totalMember',
            Icons.person_outline_rounded, C.accentHi),
      ],
    );
  }

  Widget _buildStatCard(AppPalette C, bool isComic,
      String label, String value, dynamic icon, Color color) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Expanded(
      child: Container(
        padding:
            const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        decoration: isHud
            ? BoxDecoration(
                color: C.hudPanel(),
                border: Border.all(
                    color: color.withOpacity(0.5), width: 1),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.2),
                    blurRadius: 10,
                  ),
                ],
              )
            : BoxDecoration(
                color: isComic ? C.bgDark : C.bgDark,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                    color: isComic ? Colors.black : C.bg,
                    width: isComic ? 3 : 1),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                            color: Colors.black,
                            offset: Offset(4, 4),
                            blurRadius: 0),
                      ]
                    : null,
              ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _DynamicIcon(icon,
                color: isComic
                    ? C.contrastTextOn(color)
                    : color,
                size: 18),
            const SizedBox(height: 8),
            Text(value,
                style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : color),
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontSize: isComic ? 22 : 20,
                    fontWeight: FontWeight.w900)),
            Text(label,
                style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : (isHud ? C.hudTextDim() : C.textSub),
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontSize: 10)),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          Icon(Icons.inbox_outlined,
              color: isComic
                  ? C.comicTextMuted
                  : (isHud
                      ? C.hudTextDim()
                      : C.text.withOpacity(0.4)),
              size: 40),
          const SizedBox(height: 12),
          Text('Tidak ada data',
              style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud ? C.hudTextDim() : C.textSub),
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontSize: 14)),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// Helper Widgets
// ═══════════════════════════════════════════════════════════

class _IconBtn extends StatefulWidget {
  final AppPalette C;
  final dynamic icon;
  final Color color;
  final bool isComic;
  final VoidCallback onTap;
  const _IconBtn(
      {required this.C,
      required this.icon,
      required this.color,
      required this.isComic,
      required this.onTap});

  @override
  State<_IconBtn> createState() => _IconBtnState();
}

class _IconBtnState extends State<_IconBtn> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: 38,
        height: 38,
        decoration: isHud
            ? BoxDecoration(
                color: _pressed
                    ? widget.color.withOpacity(0.25)
                    : widget.color.withOpacity(0.1),
                border: Border.all(color: widget.color, width: 1.2),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withOpacity(0.35),
                          blurRadius: 8,
                        ),
                      ],
              )
            : BoxDecoration(
                color: widget.isComic
                    ? (_pressed
                        ? widget.color.withOpacity(0.3)
                        : widget.C.bgDark)
                    : (_pressed
                        ? widget.color.withOpacity(0.15)
                        : widget.C.bgDeep),
                borderRadius:
                    BorderRadius.circular(widget.isComic ? 10 : 10),
                border: Border.all(
                  color:
                      widget.isComic ? Colors.black : widget.C.bg,
                  width: widget.isComic ? 2.5 : 1,
                ),
              ),
        child: _DynamicIcon(widget.icon,
            color: widget.isComic
                ? widget.C.contrastTextOn(widget.color)
                : (isHud ? widget.color : widget.color),
            size: 18),
      ),
    );
  }
}

class _PillBtn extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final String? label;
  final dynamic icon;
  final bool active;
  final bool enabled;
  final VoidCallback onTap;

  const _PillBtn({
    required this.C,
    required this.isComic,
    this.label,
    this.icon,
    this.active = false,
    this.enabled = true,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    if (isHud) {
      final Color bg = active
          ? C.accent.withOpacity(0.2)
          : C.bgDeep.withOpacity(0.6);
      final Color fg = active ? C.hudNeon() : C.hudTextDim();
      return GestureDetector(
        onTap: enabled ? onTap : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: bg,
            border: Border.all(
              color: active ? C.accent : C.accent.withOpacity(0.3),
              width: 1,
            ),
            boxShadow: active
                ? [
                    BoxShadow(
                      color: C.accent.withOpacity(0.5),
                      blurRadius: 8,
                    ),
                  ]
                : null,
          ),
          child: Center(
            child: icon != null
                ? _DynamicIcon(icon,
                    size: 16,
                    color: enabled ? fg : C.hudTextDim().withOpacity(0.3))
                : Text(
                    label ?? '',
                    style: TextStyle(
                      color: fg,
                      fontSize: 13,
                      fontFamily: 'Orbitron',
                      fontWeight:
                          active ? FontWeight.w900 : FontWeight.w400,
                    ),
                  ),
          ),
        ),
      );
    }

    final Color bg = active
        ? (isComic ? C.primaryHi : C.accent)
        : (isComic ? C.bgDark : C.bgDeep);
    final Color fg = active
        ? (isComic ? C.contrastTextOn(C.primaryHi) : Colors.black)
        : (isComic ? C.comicText : C.textSub);

    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isComic
                ? Colors.black
                : (active ? C.accent : C.bg),
            width: isComic ? 3 : 1,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                      color: Colors.black,
                      offset: Offset(2, 2),
                      blurRadius: 0),
                ]
              : null,
        ),
        child: Center(
          child: icon != null
              ? _DynamicIcon(icon,
                  size: 16,
                  color: enabled
                      ? fg
                      : (isComic ? C.comicTextMuted : C.bg))
              : Text(
                  label ?? '',
                  style: TextStyle(
                    color: fg,
                    fontSize: isComic ? 14 : 13,
                    fontFamily: isComic ? 'Bangers' : null,
                    fontWeight:
                        active ? FontWeight.w700 : FontWeight.w400,
                  ),
                ),
        ),
      ),
    );
  }
}

class _PressableButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  const _PressableButton({required this.child, this.onTap});

  @override
  State<_PressableButton> createState() => _PressableButtonState();
}

class _PressableButtonState extends State<_PressableButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap?.call();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedOpacity(
          opacity: widget.onTap == null ? 0.45 : (_down ? 0.85 : 1.0),
          duration: const Duration(milliseconds: 100),
          child: widget.child,
        ),
      ),
    );
  }
}

class _LoadingDots extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  const _LoadingDots({required this.C, required this.isComic});

  @override
  State<_LoadingDots> createState() => _LoadingDotsState();
}

class _LoadingDotsState extends State<_LoadingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            final delay = i / 3;
            final t = ((_c.value - delay) % 1.0).clamp(0.0, 1.0);
            final scale = math.sin(t * math.pi);
            final style = AppTheme.currentStyle.value;
            final isHud = style == ThemeStyle.hudTactical;
            final baseColor = widget.isComic
                ? widget.C.primaryHi
                : (isHud ? widget.C.accent : widget.C.accent);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Transform.scale(
                scale: 0.5 + scale * 0.5,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: isHud ? BoxShape.rectangle : BoxShape.circle,
                    color: baseColor.withOpacity(0.4 + scale * 0.6),
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}

class _GridBackground extends StatelessWidget {
  final AppPalette C;
  const _GridBackground({required this.C});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _GridPainter(C: C),
    );
  }
}

class _GridPainter extends CustomPainter {
  final AppPalette C;
  _GridPainter({required this.C});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = C.accent.withOpacity(0.03)
      ..strokeWidth = 0.5;

    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    final gradient = RadialGradient(
      center: Alignment.topCenter,
      radius: 1.5,
      colors: [
        Colors.transparent,
        C.bgDeep.withOpacity(0.85),
      ],
    );
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()
        ..shader =
            gradient.createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );
  }

  @override
  bool shouldRepaint(_GridPainter old) => old.C != C;
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!
                .map((s) =>
                    BoxShadow(color: s.color, blurRadius: s.blurRadius))
                .toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END