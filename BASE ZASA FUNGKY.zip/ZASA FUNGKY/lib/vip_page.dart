// vip_page.dart — VIP Dashboard (Full 3 Style Support)
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18)),
      );
    }

    if (isHud) {
      if (!blink) {
        return Container(
          width: size, height: size,
          decoration: BoxDecoration(
            color: color,
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3),
            ]),
        );
      }
      return ValueListenableBuilder<double>(
        valueListenable: _Pulse.v,
        builder: (_, v, __) => Container(
          width: size, height: size,
          decoration: BoxDecoration(
            color: color.withOpacity(0.4 + v * 0.6),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3),
            ]),
        ),
      );
    }

    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55));
  }

  Widget _dot(double opacity) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0]),
          border: Border.all(
              color: Colors.black.withOpacity(0.85),
              width: size * 0.1),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.75 * opacity),
                blurRadius: size * 1.4, spreadRadius: size * 0.2),
          ]),
      );
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  final double rotation;
  const _Screw({required this.C, this.size = 14, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();
    if (isHud) {
      return SizedBox(
        width: size, height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0])),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.7, height: size * 0.11,
            color: Colors.black.withOpacity(0.9)))),
    );
  }
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();
    if (isHud) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withOpacity(0.6), width: 1)),
      );
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0])),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6),
                blurRadius: 0),
          ]),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 12),
          ]),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ]),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12, height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.8)),
        ));
}

class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 48,
  });
  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    final textColor = isComic
        ? C.contrastTextOn(widget.color)
        : (isHud ? widget.color : Colors.white);

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(
                _pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: isHud
            ? BoxDecoration(
                color: widget.color.withOpacity(_pressed ? 0.25 : 0.15),
                border: Border.all(color: widget.color, width: 1.4),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                            color: widget.color.withOpacity(0.4),
                            blurRadius: 10),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                gradient: isComic
                    ? null
                    : LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: _pressed
                            ? [
                                widget.color.withOpacity(0.4),
                                widget.color.withOpacity(0.2)
                              ]
                            : [widget.color, widget.color.withOpacity(0.7)],
                      ),
                color: isComic ? widget.color : null,
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : widget.color.withOpacity(0.9),
                  width: isComic ? 3.5 : 1.5,
                ),
                boxShadow: isComic
                    ? (_pressed
                        ? []
                        : const [
                            BoxShadow(
                                color: Colors.black,
                                offset: Offset(4, 4),
                                blurRadius: 0),
                          ])
                    : null,
              ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic && !isHud) ...[
              Positioned(top: 3, left: 3, child: _Rivet(C: C, size: 5)),
              Positioned(top: 3, right: 3, child: _Rivet(C: C, size: 5)),
              Positioned(bottom: 3, left: 3, child: _Rivet(C: C, size: 5)),
              Positioned(bottom: 3, right: 3, child: _Rivet(C: C, size: 5)),
            ],
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: IconTheme(
                data: IconThemeData(color: textColor),
                child: DefaultTextStyle(
                  style: TextStyle(
                    color: textColor,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    shadows: isComic
                        ? [
                            Shadow(
                                color: textColor == Colors.white
                                    ? Colors.black
                                    : Colors.white,
                                offset: const Offset(2, 2),
                                blurRadius: 0),
                          ]
                        : null,
                  ),
                  child: widget.child,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NeoInput extends StatelessWidget {
  final AppPalette C;
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final TextInputType? keyboardType;
  const _NeoInput({
    required this.C,
    required this.controller,
    required this.hint,
    required this.icon,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: TextField(
          controller: controller,
          keyboardType: keyboardType,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 14,
            fontFamily: 'ComicNeue',
            fontWeight: FontWeight.w700,
            letterSpacing: 1,
          ),
          cursorColor: Colors.black,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: Colors.black.withOpacity(0.4),
              fontSize: 13,
              fontFamily: 'ComicNeue',
              letterSpacing: 1,
            ),
            prefixIcon: Icon(icon, color: C.primaryHi, size: 18),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 14),
          ),
        ),
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.bgDeep.withOpacity(0.6),
          border: Border.all(
              color: C.accent.withOpacity(0.5), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 8),
          ],
        ),
        child: TextField(
          controller: controller,
          keyboardType: keyboardType,
          style: TextStyle(
            color: C.hudText(),
            fontSize: 13,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w600,
            letterSpacing: 1,
          ),
          cursorColor: C.accent,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: C.hudTextDim(),
              fontSize: 11,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1,
            ),
            prefixIcon: Icon(icon, color: C.accent, size: 18),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 14),
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.bgDeep, C.bgDark],
        ),
        border: Border.all(color: C.accent.withOpacity(0.3), width: 1.5),
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        style: TextStyle(
          color: C.text,
          fontSize: 13,
          fontFamily: 'ShareTechMono',
          fontWeight: FontWeight.w700,
          letterSpacing: 1,
        ),
        cursorColor: C.accent,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
            color: C.textSub.withOpacity(0.6),
            fontSize: 11,
            fontFamily: 'ShareTechMono',
            letterSpacing: 1,
          ),
          prefixIcon: Icon(icon, color: C.accent, size: 18),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// VIP PAGE
// ═══════════════════════════════════════════════════════════
class VipPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const VipPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });
  @override
  State<VipPage> createState() => _VipPageState();
}

class _VipPageState extends State<VipPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['reseller', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();
  final changeRoleUsernameController = TextEditingController();

  String newUserRole = 'member';
  String newChangeRole = 'member';
  bool isLoading = false;

  static const String _baseUrl = 'http://angelacantik.zone.id:3631';

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    changeRoleUsernameController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
          Uri.parse('$_baseUrl/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$_baseUrl/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$_baseUrl/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole'));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses",
            "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$_baseUrl/editUser?key=$sessionKey&username=$u&addDays=$d'));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _changeRole() async {
    final u = changeRoleUsernameController.text.trim();
    if (u.isEmpty) {
      _alert("Peringatan", "Masukkan username target.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$_baseUrl/changeRole?key=$sessionKey&username=$u&role=$newChangeRole'));
      final data = jsonDecode(res.body);
      if (data['changed'] == true) {
        _alert("Sukses",
            "Role berhasil diubah jadi ${newChangeRole.toUpperCase()}.");
        changeRoleUsernameController.clear();
        newChangeRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah role.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: isComic
            ? Container(
                decoration: BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(6, 6),
                        blurRadius: 0),
                  ],
                ),
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: C.accent,
                            shape: BoxShape.circle,
                            border:
                                Border.all(color: Colors.black, width: 3),
                          ),
                          child: Icon(Icons.info_outline,
                              color: C.contrastTextOn(C.accent), size: 18),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            title.toUpperCase(),
                            style: TextStyle(
                              color: C.comicText,
                              fontFamily: 'Bangers',
                              fontSize: 18,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: C.comicTextSub,
                        fontFamily: 'ComicNeue',
                        fontSize: 13,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 20),
                    _ComicDialogButton(
                      C: C,
                      label: 'OK',
                      onTap: () => Navigator.pop(context),
                    ),
                  ],
                ),
              )
            : _MetalPlate(
                C: C,
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        _Screw(C: C, size: 12),
                        const SizedBox(width: 10),
                        _Led(color: C.accent, size: 8, blink: !isComic),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(title.toUpperCase(),
                              style: TextStyle(
                                color: isHud ? C.hudNeon() : C.accent,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 2,
                              )),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(message,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: isHud ? C.hudText() : C.text,
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                          height: 1.5,
                        )),
                    const SizedBox(height: 20),
                    _IndustrialButton(
                      C: C,
                      color: C.primaryHi,
                      height: 44,
                      onTap: () => Navigator.pop(context),
                      child: Center(
                          child: Text('OK',
                              style: TextStyle(
                                color: isComic
                                    ? C.contrastTextOn(C.primaryHi)
                                    : (isHud
                                        ? C.hudNeon()
                                        : Colors.white),
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 2,
                              ))),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withOpacity(0.12)),
                            ),
                          )
                        : (isHud
                            ? Container(
                                color: C.hudBg(),
                                child: CustomPaint(
                                  painter: _HudGridPainter(
                                      color: C.hudGridLine()),
                                ),
                              )
                            : Container(
                                decoration: BoxDecoration(
                                  gradient: RadialGradient(
                                    center: const Alignment(-0.3, -0.3),
                                    radius: 1.2,
                                    colors: [C.bg, C.bgDark, C.bgDeep],
                                    stops: const [0.0, 0.6, 1.0],
                                  ),
                                ),
                              )),
                  ),
                  SafeArea(
                    child: Column(
                      children: [
                        const SizedBox(height: 8),
                        _buildTopBar(C, isComic, isHud),
                        Expanded(
                          child: SingleChildScrollView(
                            physics: const BouncingScrollPhysics(),
                            padding:
                                const EdgeInsets.fromLTRB(14, 12, 14, 24),
                            child: Column(
                              children: [
                                _buildDeleteCard(C, isComic, isHud),
                                const SizedBox(height: 14),
                                _buildCreateCard(C, isComic, isHud),
                                const SizedBox(height: 14),
                                _buildExtendCard(C, isComic, isHud),
                                const SizedBox(height: 14),
                                _buildChangeRoleCard(C, isComic, isHud),
                                const SizedBox(height: 14),
                                _buildUserListCard(C, isComic, isHud),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                      color: Colors.black,
                      offset: Offset(5, 5),
                      blurRadius: 0),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 36, height: 36,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border:
                              Border.all(color: C.accent, width: 1.2),
                        )
                      : BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          gradient: isComic
                              ? null
                              : LinearGradient(
                                  colors: [C.text, C.bg, C.bgDark]),
                          color: isComic ? C.accent : null,
                          border: Border.all(
                              color:
                                  isComic ? Colors.black : C.primaryLo,
                              width: isComic ? 2.5 : 1.5),
                        ),
                  child: Icon(Icons.arrow_back_ios_new_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.accent)
                          : (isHud ? C.hudNeon() : C.accent),
                      size: 16),
                ),
              ),
              const SizedBox(width: 12),
              Container(
                width: 36, height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isComic
                            ? null
                            : RadialGradient(colors: [
                                C.accentHi,
                                C.accent,
                                C.primaryLo
                              ]),
                        color: isComic ? C.primaryHi : null,
                        border: Border.all(
                            color:
                                isComic ? Colors.black : C.accentShine,
                            width: isComic ? 3 : 1.5),
                      ),
                child: Icon(Icons.star_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.hudNeon() : C.bgDeep),
                    size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('VIP DASHBOARD',
                        style: TextStyle(
                          color: isComic
                              ? C.comicText
                              : (isHud ? C.hudNeon() : C.accent),
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: isComic ? 18 : 13,
                          letterSpacing: isComic ? 2 : 2.5,
                          shadows: isComic
                              ? [
                                  Shadow(
                                      color: C.comicTextOutline,
                                      offset: const Offset(1, 1),
                                      blurRadius: 0),
                                ]
                              : (isHud
                                  ? [
                                      Shadow(
                                          color: C.accent
                                              .withOpacity(0.5),
                                          blurRadius: 8),
                                    ]
                                  : null))),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        _Led(color: C.primaryHi, size: 4, blink: !isComic),
                        const SizedBox(width: 6),
                        Text('MANAGE USER · ${widget.username}',
                            style: TextStyle(
                              color: isComic
                                  ? C.comicTextSub
                                  : (isHud
                                      ? C.hudTextDim()
                                      : C.text.withOpacity(0.55)),
                              fontFamily:
                                  isComic ? 'ComicNeue' : 'ShareTechMono',
                              fontSize: 8,
                              letterSpacing: 1.2)),
                      ],
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: _fetchUsers,
                child: Container(
                  width: 32, height: 32,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border:
                              Border.all(color: C.accent, width: 1.2),
                        )
                      : BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          gradient: isComic
                              ? null
                              : LinearGradient(colors: [
                                  C.accentHi,
                                  C.accent,
                                  C.primaryLo
                                ]),
                          color: isComic ? C.accent : null,
                          border: Border.all(
                              color:
                                  isComic ? Colors.black : C.accentShine,
                              width: isComic ? 2.5 : 1),
                        ),
                  child: Icon(Icons.refresh_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.accent)
                          : (isHud ? C.hudNeon() : C.bgDeep),
                      size: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _cardHeader(AppPalette C, bool isComic, bool isHud,
      IconData icon, String title, Color color) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: isHud
              ? BoxDecoration(
                  color: color.withOpacity(0.15),
                  border: Border.all(color: color, width: 1.2),
                  boxShadow: [
                    BoxShadow(
                        color: color.withOpacity(0.4),
                        blurRadius: 6),
                  ],
                )
              : BoxDecoration(
                  shape: BoxShape.circle,
                  color: isComic ? color : color.withOpacity(0.2),
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : color.withOpacity(0.6),
                      width: isComic ? 3 : 1.2)),
          child: Icon(icon,
              color: isComic ? C.contrastTextOn(color) : color,
              size: 14,
              shadows: isHud
                  ? [
                      Shadow(
                          color: color.withOpacity(0.5),
                          blurRadius: 4),
                    ]
                  : null),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(title,
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudNeon() : color),
                fontSize: isComic ? 15 : 11,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 1.5,
                shadows: isComic
                    ? [
                        Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0),
                      ]
                    : (isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.4),
                                blurRadius: 6),
                          ]
                        : null))),
        ),
        if (!isComic && !isHud) _Screw(C: C, size: 10),
        if (isHud) _Led(color: color, size: 5, blink: true),
      ],
    );
  }

  Widget _buildDeleteCard(AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _cardHeader(C, isComic, isHud,
              Icons.person_remove_rounded, 'DELETE USER', C.primaryHi),
          const SizedBox(height: 12),
          _NeoInput(C: C, controller: deleteController,
              hint: 'Username Target', icon: Icons.person_rounded),
          const SizedBox(height: 12),
          _IndustrialButton(
            C: C, color: C.primaryHi, onTap: _deleteUser,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.delete_outline_rounded, size: 16),
                const SizedBox(width: 8),
                Text('DELETE ACCOUNT',
                    style: TextStyle(
                      fontSize: isComic ? 15 : 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreateCard(AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _cardHeader(C, isComic, isHud,
              Icons.person_add_rounded, 'CREATE ACCOUNT', C.accent),
          const SizedBox(height: 12),
          _NeoInput(C: C, controller: createUsernameController,
              hint: 'Username', icon: Icons.person_rounded),
          const SizedBox(height: 10),
          _NeoInput(C: C, controller: createPasswordController,
              hint: 'Password', icon: Icons.lock_rounded),
          const SizedBox(height: 10),
          _NeoInput(C: C, controller: createDayController,
              hint: 'Durasi (Hari)', icon: Icons.calendar_today_rounded,
              keyboardType: TextInputType.number),
          const SizedBox(height: 10),
          _roleDropdown(C, isComic, isHud, newUserRole, (v) =>
              setState(() => newUserRole = v ?? 'member')),
          const SizedBox(height: 12),
          _IndustrialButton(
            C: C, color: C.accent, onTap: _createAccount,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.add_rounded, size: 16),
                const SizedBox(width: 8),
                Text('CREATE ACCOUNT',
                    style: TextStyle(
                      fontSize: isComic ? 15 : 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExtendCard(AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _cardHeader(C, isComic, isHud,
              Icons.access_time_rounded, 'EXTEND DURATION', C.accentHi),
          const SizedBox(height: 12),
          _NeoInput(C: C, controller: editUsernameController,
              hint: 'Username Target', icon: Icons.person_rounded),
          const SizedBox(height: 10),
          _NeoInput(C: C, controller: editDayController,
              hint: 'Tambah Hari', icon: Icons.calendar_today_rounded,
              keyboardType: TextInputType.number),
          const SizedBox(height: 12),
          _IndustrialButton(
            C: C, color: C.accentHi, onTap: _editUser,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.timer_rounded, size: 16),
                const SizedBox(width: 8),
                Text('ADD DAYS',
                    style: TextStyle(
                      fontSize: isComic ? 15 : 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChangeRoleCard(AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _cardHeader(C, isComic, isHud,
              Icons.swap_horiz_rounded, 'CHANGE ROLE', C.accentShine),
          const SizedBox(height: 12),
          _NeoInput(C: C, controller: changeRoleUsernameController,
              hint: 'Username Target', icon: Icons.person_rounded),
          const SizedBox(height: 10),
          _roleDropdown(C, isComic, isHud, newChangeRole, (v) =>
              setState(() => newChangeRole = v ?? 'member')),
          const SizedBox(height: 12),
          _IndustrialButton(
            C: C, color: C.accentShine, onTap: _changeRole,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.swap_horiz_rounded, size: 16),
                const SizedBox(width: 8),
                Text('CHANGE ROLE',
                    style: TextStyle(
                      fontSize: isComic ? 15 : 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _roleDropdown(AppPalette C, bool isComic, bool isHud,
      String value, ValueChanged<String?> onChanged) {
    if (isComic) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            value: value, isExpanded: true, dropdownColor: Colors.white,
            style: const TextStyle(
                color: Colors.black,
                fontFamily: 'ComicNeue',
                fontWeight: FontWeight.w700,
                fontSize: 13),
            items: roleOptions
                .map((r) => DropdownMenuItem(
                    value: r, child: Text(r.toUpperCase())))
                .toList(),
            onChanged: onChanged,
          ),
        ),
      );
    }

    if (isHud) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: C.bgDeep.withOpacity(0.6),
          border: Border.all(
              color: C.accent.withOpacity(0.5), width: 1.2),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            value: value,
            isExpanded: true,
            dropdownColor: C.hudPanel(),
            style: TextStyle(
              color: C.hudText(),
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w700,
              fontSize: 12,
              letterSpacing: 1,
            ),
            iconEnabledColor: C.accent,
            items: roleOptions
                .map((r) => DropdownMenuItem(
                    value: r,
                    child: Text(r.toUpperCase(),
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          fontSize: 12,
                          letterSpacing: 1,
                          color: C.hudText(),
                        ))))
                .toList(),
            onChanged: onChanged,
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: C.bgDeep,
        border: Border.all(color: C.accent.withOpacity(0.3), width: 1.5),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value, isExpanded: true, dropdownColor: C.bgDark,
          style: TextStyle(
              color: C.text,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w700,
              fontSize: 12),
          items: roleOptions
              .map((r) =>
                  DropdownMenuItem(value: r, child: Text(r.toUpperCase())))
              .toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildUserListCard(AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _cardHeader(C, isComic, isHud,
              Icons.people_rounded, 'USER LIST', C.accentHi),
          const SizedBox(height: 12),
          _roleDropdown(C, isComic, isHud, selectedRole, (v) {
            if (v != null) {
              selectedRole = v;
              _filterAndPaginate();
            }
          }),
          const SizedBox(height: 14),
          if (isLoading)
            Center(
                child: Padding(
              padding: const EdgeInsets.all(20),
              child: CircularProgressIndicator(
                  color: isComic
                      ? Colors.black
                      : (isHud ? C.hudNeon() : C.accent),
                  strokeWidth: 2),
            ))
          else ...[
            ..._getCurrentPageData().map((u) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: _buildUserItem(C, isComic, isHud, u),
                )),
            if (totalPages > 1) ...[
              const SizedBox(height: 12),
              Wrap(
                spacing: 8, runSpacing: 8,
                children: List.generate(totalPages, (index) {
                  final page = index + 1;
                  final isActive = currentPage == page;
                  return GestureDetector(
                    onTap: () => setState(() => currentPage = page),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: isHud
                          ? BoxDecoration(
                              color: isActive
                                  ? C.accent.withOpacity(0.25)
                                  : C.accent.withOpacity(0.05),
                              border: Border.all(
                                  color: isActive
                                      ? C.accent
                                      : C.accent.withOpacity(0.3),
                                  width: 1),
                              boxShadow: isActive
                                  ? [
                                      BoxShadow(
                                          color: C.accent
                                              .withOpacity(0.5),
                                          blurRadius: 8),
                                    ]
                                  : null,
                            )
                          : BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(isComic ? 10 : 8),
                              gradient: isComic
                                  ? null
                                  : (isActive
                                      ? LinearGradient(colors: [
                                          C.accentHi,
                                          C.accent,
                                          C.primaryLo
                                        ])
                                      : LinearGradient(
                                          colors: [C.bg, C.bgDark])),
                              color: isComic
                                  ? (isActive ? C.primaryHi : C.bgDark)
                                  : null,
                              border: Border.all(
                                color: isComic
                                    ? Colors.black
                                    : (isActive
                                        ? C.accentShine
                                        : C.textSub.withOpacity(0.4)),
                                width: isComic ? 3 : 1.2),
                              boxShadow: isComic
                                  ? const [
                                      BoxShadow(
                                          color: Colors.black,
                                          offset: Offset(2, 2),
                                          blurRadius: 0),
                                    ]
                                  : null,
                            ),
                      child: Text('$page',
                          style: TextStyle(
                            color: isComic
                                ? (isActive
                                    ? C.contrastTextOn(C.primaryHi)
                                    : C.comicText)
                                : (isHud
                                    ? (isActive
                                        ? C.hudNeon()
                                        : C.hudTextDim())
                                    : (isActive ? C.bgDeep : C.text)),
                            fontWeight: FontWeight.w900,
                            fontFamily: isComic ? 'Bangers' : 'Orbitron',
                            fontSize: isComic ? 14 : 11,
                            letterSpacing: isHud ? 1 : null)),
                    ),
                  );
                }),
              ),
            ],
          ],
        ],
      ),
    );
  }

  Widget _buildUserItem(
      AppPalette C, bool isComic, bool isHud, dynamic u) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: isHud
          ? BoxDecoration(
              color: C.bgDeep.withOpacity(0.6),
              border: Border.all(
                  color: C.accent.withOpacity(0.35), width: 1),
            )
          : BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 12 : 10),
              color: isComic ? Colors.white : Colors.black.withOpacity(0.4),
              border: Border.all(
                  color:
                      isComic ? Colors.black : C.accent.withOpacity(0.2),
                  width: isComic ? 3 : 1),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                          color: Colors.black,
                          offset: Offset(2, 2),
                          blurRadius: 0),
                    ]
                  : null,
            ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: isHud
                ? BoxDecoration(
                    color: C.accent.withOpacity(0.15),
                    border: Border.all(
                        color: C.accent.withOpacity(0.6), width: 1),
                  )
                : BoxDecoration(
                    shape: BoxShape.circle,
                    color: isComic
                        ? C.primaryHi
                        : C.accent.withOpacity(0.2),
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : C.accent.withOpacity(0.6),
                        width: isComic ? 2.5 : 1),
                  ),
            child: Icon(Icons.person_rounded,
                color: isComic
                    ? C.contrastTextOn(C.primaryHi)
                    : C.accent,
                size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
              child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(u['username'],
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudText() : C.text),
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 15 : 13,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isHud ? 1 : null,
                  )),
              const SizedBox(height: 3),
              Text(
                  "ROLE: ${u['role'].toString().toUpperCase()} | EXP: ${u['expiredDate']}",
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withOpacity(0.6)
                        : (isHud ? C.hudTextDim() : C.textSub),
                    fontSize: isComic ? 11 : 10,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    letterSpacing: isHud ? 0.5 : null),
              ),
            ],
          )),
          GestureDetector(
            onTap: () async {
              final confirm = await _confirmDelete(C, isComic, isHud);
              if (confirm == true) {
                deleteController.text = u['username'];
                _deleteUser();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.primaryHi.withOpacity(0.15),
                      border: Border.all(
                          color: C.primaryHi.withOpacity(0.6),
                          width: 1),
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      color: isComic
                          ? C.accent
                          : C.primaryHi.withOpacity(0.2),
                      border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.primaryHi.withOpacity(0.6),
                          width: isComic ? 2.5 : 1),
                    ),
              child: Icon(Icons.delete_outline_rounded,
                  color: isComic
                      ? C.contrastTextOn(C.accent)
                      : (isHud ? C.primaryHi : Colors.white),
                  size: 14),
            ),
          ),
        ],
      ),
    );
  }

  Future<bool?> _confirmDelete(
      AppPalette C, bool isComic, bool isHud) {
    return showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: isComic
            ? Container(
                decoration: BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(6, 6),
                        blurRadius: 0),
                  ],
                ),
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('HAPUS USER INI?',
                        style: TextStyle(
                          color: C.comicText,
                          fontFamily: 'Bangers',
                          fontSize: 20,
                          letterSpacing: 2,
                        )),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: _ComicDialogButton(
                            C: C, label: 'BATAL',
                            color: C.bg,
                            onTap: () => Navigator.pop(context, false),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _ComicDialogButton(
                            C: C, label: 'HAPUS',
                            color: C.primaryHi,
                            onTap: () => Navigator.pop(context, true),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              )
            : _MetalPlate(
                C: C, padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        if (!isComic) _Screw(C: C, size: 12),
                        if (!isComic) const SizedBox(width: 10),
                        _Led(color: C.primaryHi, size: 8, blink: !isComic),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text('HAPUS USER INI?',
                              style: TextStyle(
                                color:
                                    isHud ? C.hudNeon() : C.accent,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: isHud ? 12 : 13,
                                letterSpacing: 2,
                              )),
                        ),
                        if (isHud) _Led(color: C.accent, size: 8, blink: true),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                            child: _IndustrialButton(
                          C: C, color: C.textSub,
                          onTap: () => Navigator.pop(context, false),
                          child: Center(
                              child: Text('BATAL',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron',
                                    letterSpacing: 1.5))),
                        )),
                        const SizedBox(width: 10),
                        Expanded(
                            child: _IndustrialButton(
                          C: C, color: C.primaryHi,
                          onTap: () => Navigator.pop(context, true),
                          child: Center(
                              child: Text('HAPUS',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron',
                                    letterSpacing: 1.5))),
                        )),
                      ],
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}

class _ComicDialogButton extends StatelessWidget {
  final AppPalette C;
  final String label;
  final Color? color;
  final VoidCallback onTap;

  const _ComicDialogButton({
    required this.C,
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final bg = color ?? C.primaryHi;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: C.contrastTextOn(bg),
              fontFamily: 'Bangers',
              fontSize: 16,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ),
      ),
    );
  }
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}