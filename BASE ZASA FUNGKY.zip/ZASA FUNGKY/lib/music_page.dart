// lib/music_page.dart — Support Style Switcher (FIXED)
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'app_theme.dart';

const String _kSearchEndpoint =
    "http://angelacantik.zone.id:3631/deezer/search";
const String _kTopChartEndpoint =
    "http://angelacantik.zone.id:3631/deezer/chart?limit=30";

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(
        Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.9),
              blurRadius: size * 1.8,
              spreadRadius: size * 0.3,
            ),
          ],
        ),
      );
    }

    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
              color: Colors.black.withOpacity(0.85), width: size * 0.1),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.75 * opacity),
                blurRadius: size * 1.4,
                spreadRadius: size * 0.2),
          ],
        ),
      );
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6),
              blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12,
        height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.8)),
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// MUSIC PAGE
// ═══════════════════════════════════════════════════════════
class MusicPage extends StatefulWidget {
  const MusicPage({super.key});

  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage>
    with TickerProviderStateMixin {
  final TextEditingController _searchCtrl = TextEditingController();
  final FocusNode _searchFocus = FocusNode();
  final AudioPlayer _player = AudioPlayer();
  final ScrollController _scrollCtrl = ScrollController();

  List<_Track> _searchResults = [];
  List<_Track> _topTracks = [];

  bool _isSearching = false;
  bool _hasSearched = false;
  bool _isLoadingTop = true;
  String? _topError;
  String? _searchError;

  String? _currentlyPlayingId;
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _currentDuration = Duration.zero;
  _Track? _currentTrack;

  String? _bufferingId;
  bool get _isBuffering => _bufferingId != null;

  int _selectedChip = 0;
  final List<String> _chips = const [
    "Semua",
    "Musik",
    "Trending",
    "Baru"
  ];

  Timer? _debounce;
  late AnimationController _entryAnim;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _entryAnim = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    )..forward();

    _fetchTopTracks();

    _player.onPlayerComplete.listen((_) {
      if (!mounted) return;
      setState(() {
        _isPlaying = false;
        _currentlyPlayingId = null;
        _currentTrack = null;
        _currentPosition = Duration.zero;
      });
    });

    _player.onDurationChanged.listen((d) {
      if (!mounted) return;
      setState(() => _currentDuration = d);
    });

    _player.onPositionChanged.listen((p) {
      if (!mounted) return;
      setState(() => _currentPosition = p);
    });

    _player.onPlayerStateChanged.listen((state) {
      if (!mounted) return;
      if (state == PlayerState.playing && _bufferingId != null) {
        setState(() => _bufferingId = null);
      }
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _entryAnim.dispose();
    _searchCtrl.dispose();
    _searchFocus.dispose();
    _scrollCtrl.dispose();
    _player.dispose();
    super.dispose();
  }

  Future<void> _fetchTopTracks() async {
    setState(() {
      _isLoadingTop = true;
      _topError = null;
    });
    try {
      final res = await http
          .get(Uri.parse(_kTopChartEndpoint))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = (body['data'] as List?) ?? const [];
        final list = raw
            .whereType<Map<String, dynamic>>()
            .map(_Track.fromDeezer)
            .where((t) => t.previewUrl.isNotEmpty)
            .toList();
        if (mounted) {
          setState(() {
            _topTracks = list;
            _isLoadingTop = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isLoadingTop = false;
            _topError = "Gagal memuat (HTTP ${res.statusCode})";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingTop = false;
          _topError = "Gagal memuat: $e";
        });
      }
    }
  }

  Future<void> _searchMusic(String query) async {
    final q = query.trim();
    if (q.isEmpty) {
      setState(() {
        _searchResults = [];
        _isSearching = false;
        _hasSearched = false;
        _searchError = null;
      });
      return;
    }

    setState(() {
      _isSearching = true;
      _hasSearched = true;
      _searchError = null;
    });

    try {
      final uri = Uri.parse(
          "$_kSearchEndpoint?q=${Uri.encodeQueryComponent(q)}&limit=40");
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = (body['data'] as List?) ?? const [];
        final list = raw
            .whereType<Map<String, dynamic>>()
            .map(_Track.fromDeezer)
            .toList();
        if (mounted) {
          setState(() {
            _searchResults = list;
            _isSearching = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isSearching = false;
            _searchError = "Gagal mencari (HTTP ${res.statusCode})";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _searchError = "Gagal mencari: $e";
        });
      }
    }
  }

  void _onSearchChanged(String q) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () => _searchMusic(q));
  }

  Future<void> _togglePlay(_Track track, AppPalette C) async {
    if (track.previewUrl.isEmpty) {
      _showSnack(C, "Preview audio tidak tersedia untuk lagu ini.");
      return;
    }

    try {
      if (_currentlyPlayingId == track.id && _isPlaying) {
        await _player.pause();
        if (mounted) setState(() => _isPlaying = false);
        return;
      }
      if (_currentlyPlayingId == track.id && !_isPlaying) {
        await _player.resume();
        if (mounted) setState(() => _isPlaying = true);
        return;
      }
      await _player.stop();
      if (mounted) {
        setState(() {
          _currentlyPlayingId = track.id;
          _currentTrack = track;
          _isPlaying = true;
          _currentPosition = Duration.zero;
          _currentDuration = Duration.zero;
          _bufferingId = track.id;
        });
      }
      await _player.play(UrlSource(track.previewUrl));
    } catch (e) {
      if (mounted) setState(() => _bufferingId = null);
      _showSnack(C, "Gagal memutar: $e");
    }
  }

  Future<void> _stopPlayer() async {
    await _player.stop();
    if (mounted) {
      setState(() {
        _isPlaying = false;
        _currentlyPlayingId = null;
        _currentTrack = null;
        _currentPosition = Duration.zero;
        _bufferingId = null;
      });
    }
  }

  void _showSnack(AppPalette C, String msg) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: C.primaryHi, size: 8, blink: !isComic),
            const SizedBox(width: 10),
            Expanded(
              child: Text(msg,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudText() : C.text),
                    fontWeight: FontWeight.w700,
                    fontSize: isComic ? 13 : 12,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                  )),
            ),
          ],
        ),
        backgroundColor: isHud ? C.hudPanel() : C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(
              color: C.primaryHi, width: isComic ? 3 : 1.5),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 4) return "Selamat malam";
    if (h < 11) return "Selamat pagi";
    if (h < 15) return "Selamat siang";
    if (h < 19) return "Selamat sore";
    return "Selamat malam";
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              radius: 1.2,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                              stops: const [0.0, 0.6, 1.0],
                            ),
                          )),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _buildTopBar(C, isComic, isHud),
                          const SizedBox(height: 10),
                          _buildSearchBar(C, isComic, isHud),
                          const SizedBox(height: 6),
                          Expanded(
                            child: FadeTransition(
                              opacity: CurvedAnimation(
                                  parent: _entryAnim,
                                  curve: Curves.easeOut),
                              child: CustomScrollView(
                                controller: _scrollCtrl,
                                physics:
                                    const BouncingScrollPhysics(),
                                slivers: [
                                  if (!_hasSearched)
                                    SliverToBoxAdapter(
                                        child: _buildChips(
                                            C, isComic, isHud)),
                                  if (_hasSearched) ...[
                                    SliverToBoxAdapter(
                                      child: _buildSectionHeader(
                                          C,
                                          isComic,
                                          isHud,
                                          "HASIL PENCARIAN",
                                          _searchResults.length),
                                    ),
                                    SliverToBoxAdapter(
                                      child: _buildVerticalList(
                                          C,
                                          isComic,
                                          isHud,
                                          _searchResults,
                                          isLoading: _isSearching,
                                          error: _searchError,
                                          emptyMsg:
                                              'Tidak ada hasil untuk "${_searchCtrl.text}"'),
                                    ),
                                  ] else ...[
                                    SliverToBoxAdapter(
                                        child: _buildQuickPicks(
                                            C, isComic, isHud)),
                                    SliverToBoxAdapter(
                                      child: _buildSectionHeader(
                                          C,
                                          isComic,
                                          isHud,
                                          "SEDANG TRENDING",
                                          _topTracks.length),
                                    ),
                                    SliverToBoxAdapter(
                                        child: _buildTrendingRow(
                                            C, isComic, isHud)),
                                    SliverToBoxAdapter(
                                      child: _buildSectionHeader(
                                          C,
                                          isComic,
                                          isHud,
                                          "CHART TERPOPULER",
                                          _topTracks.length),
                                    ),
                                    SliverToBoxAdapter(
                                      child: _buildVerticalList(
                                          C,
                                          isComic,
                                          isHud,
                                          _topTracks,
                                          isLoading: _isLoadingTop,
                                          error: _topError,
                                          emptyMsg: "Belum ada data."),
                                    ),
                                  ],
                                  SliverToBoxAdapter(
                                    child: SizedBox(
                                        height:
                                            _currentTrack != null
                                                ? 110
                                                : 24),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (_currentTrack != null)
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: _buildMiniPlayer(C, isComic, isHud),
                      ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic, bool isHud) {
    final backIconColor = isComic
        ? C.contrastTextOn(C.accent)
        : (isHud ? C.accent : C.accent);
    final badgeIconColor = isComic
        ? C.contrastTextOn(C.primaryHi)
        : (isHud ? C.accentHi : C.bgDeep);
    final refreshIconColor = isComic
        ? C.contrastTextOn(C.accent)
        : (isHud ? C.accent : C.bgDeep);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36,
                height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.1),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                        boxShadow: [
                          BoxShadow(
                            color: C.accent.withOpacity(0.3),
                            blurRadius: 8,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: isComic
                            ? null
                            : LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [C.text, C.bg, C.bgDark]),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : C.primaryLo,
                            width: isComic ? 3 : 1.5),
                      ),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: backIconColor, size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36,
              height: 36,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accentHi.withOpacity(0.15),
                      border:
                          Border.all(color: C.accentHi, width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: C.accentHi.withOpacity(0.35),
                          blurRadius: 10,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              colors: [
                                C.accentHi,
                                C.accent,
                                C.primaryLo
                              ]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color:
                              isComic ? Colors.black : C.accentShine,
                          width: isComic ? 3 : 1.5),
                    ),
              child: Icon(Icons.music_note_rounded,
                  color: badgeIconColor, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('MUSIC PLAYER',
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 18 : 13,
                        letterSpacing: isComic ? 1.5 : 2.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : null,
                      )),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      _Led(
                          color: C.primaryHi,
                          size: 4,
                          blink: !isComic),
                      const SizedBox(width: 6),
                      Text(
                          'DEEZER · STREAM · ${_greeting().toUpperCase()}',
                          style: TextStyle(
                            color: isComic
                                ? C.comicTextSub
                                : (isHud
                                    ? C.hudTextDim()
                                    : C.text.withOpacity(0.55)),
                            fontFamily: isComic
                                ? 'ComicNeue'
                                : 'ShareTechMono',
                            fontWeight: FontWeight.w700,
                            fontSize: 8,
                            letterSpacing: 1.2,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: _fetchTopTracks,
              child: Container(
                width: 32,
                height: 32,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.1),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                        boxShadow: [
                          BoxShadow(
                            color: C.accent.withOpacity(0.3),
                            blurRadius: 8,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: isComic
                            ? null
                            : LinearGradient(colors: [
                                C.accentHi,
                                C.accent,
                                C.primaryLo
                              ]),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : C.accentShine,
                            width: isComic ? 2.5 : 1),
                      ),
                child: Icon(Icons.refresh_rounded,
                    color: refreshIconColor, size: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar(AppPalette C, bool isComic, bool isHud) {
    final searchTextColor =
        isComic ? C.comicText : (isHud ? C.hudText() : C.text);
    final searchHintColor = isComic
        ? C.comicTextMuted
        : (isHud ? C.hudTextDim() : C.textSub.withOpacity(0.6));
    final iconColor =
        isComic ? C.comicText : (isHud ? C.accent : C.accent);
    final clearColor = isComic
        ? C.comicTextSub
        : (isHud ? C.hudTextDim() : C.textSub);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(3),
        decoration: isHud
            ? BoxDecoration(
                color: C.bgDeep.withOpacity(0.7),
                border: Border.all(
                    color: C.accent.withOpacity(0.4), width: 1),
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 16 : 12),
                gradient: isComic
                    ? null
                    : LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [C.text, C.bg, C.bgDark]),
                color: isComic ? C.bgDark : null,
                border: isComic
                    ? Border.all(color: Colors.black, width: 4)
                    : null,
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                            color: Colors.black,
                            offset: Offset(5, 5),
                            blurRadius: 0),
                      ]
                    : null,
              ),
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
          decoration: (isComic || isHud)
              ? null
              : BoxDecoration(
                  borderRadius: BorderRadius.circular(9),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [C.bgDeep, C.bgDark]),
                  border: Border.all(color: C.bgDark, width: 1.5)),
          child: Row(
            children: [
              _Led(color: C.accent, size: 5, blink: !isComic),
              const SizedBox(width: 10),
              Icon(Icons.search_rounded, color: iconColor, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  focusNode: _searchFocus,
                  style: TextStyle(
                    color: searchTextColor,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                  cursorColor: isComic ? C.comicText : C.accent,
                  decoration: InputDecoration(
                    isDense: true,
                    border: InputBorder.none,
                    hintText: "Cari lagu atau artis...",
                    hintStyle: TextStyle(
                      color: searchHintColor,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontSize: 11,
                      letterSpacing: 1,
                    ),
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onChanged: _onSearchChanged,
                  onSubmitted: _searchMusic,
                  textInputAction: TextInputAction.search,
                ),
              ),
              if (_searchCtrl.text.isNotEmpty)
                GestureDetector(
                  onTap: () {
                    _searchCtrl.clear();
                    _onSearchChanged('');
                  },
                  child: Icon(Icons.close_rounded,
                      color: clearColor, size: 16),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChips(AppPalette C, bool isComic, bool isHud) {
    return SizedBox(
      height: 48,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
        itemCount: _chips.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final selected = _selectedChip == i;
          final chipColor = isComic
              ? (selected ? C.primaryHi : C.bgDark)
              : (isHud
                  ? (selected
                      ? C.accent.withOpacity(0.2)
                      : C.bgDeep.withOpacity(0.6))
                  : Colors.transparent);
          final textColor = isComic
              ? C.contrastTextOn(chipColor)
              : (isHud
                  ? (selected ? C.hudNeon() : C.hudTextDim())
                  : (selected ? C.bgDeep : C.text));

          return GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _selectedChip = i);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              alignment: Alignment.center,
              decoration: isHud
                  ? BoxDecoration(
                      color: chipColor,
                      border: Border.all(
                        color: selected
                            ? C.accent
                            : C.accent.withOpacity(0.3),
                        width: selected ? 1.4 : 1,
                      ),
                      boxShadow: selected
                          ? [
                              BoxShadow(
                                color: C.accent.withOpacity(0.4),
                                blurRadius: 8,
                              ),
                            ]
                          : null,
                    )
                  : BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(isComic ? 12 : 8),
                      gradient: selected && !isComic
                          ? LinearGradient(colors: [
                              C.accentHi,
                              C.accent,
                              C.primaryLo
                            ])
                          : null,
                      color: isComic ? chipColor : null,
                      border: Border.all(
                        color: isComic
                            ? Colors.black
                            : (selected
                                ? C.accentShine
                                : C.textSub.withOpacity(0.4)),
                        width: isComic ? 3 : 1.2,
                      ),
                      boxShadow: isComic
                          ? const [
                              BoxShadow(
                                  color: Colors.black,
                                  offset: Offset(3, 3),
                                  blurRadius: 0),
                            ]
                          : (selected
                              ? [
                                  BoxShadow(
                                      color: C.accent.withOpacity(0.5),
                                      blurRadius: 10)
                                ]
                              : null),
                    ),
              child: Text(
                _chips[i],
                style: TextStyle(
                  color: textColor,
                  fontSize: isComic ? 13 : 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1 : 1,
                  shadows: isComic && selected
                      ? [
                          Shadow(
                            color: textColor == Colors.white
                                ? Colors.black
                                : Colors.white,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSectionHeader(AppPalette C, bool isComic, bool isHud,
      String title, int count) {
    final countTextColor = isComic
        ? C.contrastTextOn(C.primaryHi)
        : (isHud ? C.hudNeon() : C.bgDeep);

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
      child: Row(
        children: [
          _Led(color: C.primaryHi, size: 6, blink: !isComic),
          const SizedBox(width: 10),
          Text(title,
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudNeon() : C.accent),
                fontSize: isComic ? 15 : 11,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 1.5 : 2,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              )),
          const Spacer(),
          if (count > 0)
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border: Border.all(color: C.accent, width: 1),
                    )
                  : BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(isComic ? 8 : 4),
                      gradient: isComic
                          ? null
                          : LinearGradient(colors: [
                              C.accentHi,
                              C.accent,
                              C.primaryLo
                            ]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.accentShine,
                          width: isComic ? 2.5 : 1),
                    ),
              child: Text('$count',
                  style: TextStyle(
                    color: countTextColor,
                    fontSize: isComic ? 11 : 9,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  )),
            ),
        ],
      ),
    );
  }

  Widget _buildQuickPicks(AppPalette C, bool isComic, bool isHud) {
    if (_isLoadingTop) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Center(
          child: CircularProgressIndicator(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.accent : C.accent),
              strokeWidth: 2),
        ),
      );
    }
    if (_topTracks.isEmpty) return const SizedBox.shrink();
    final picks = _topTracks.take(6).toList();

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      child: Column(
        children: List.generate((picks.length / 2).ceil(), (row) {
          final left = picks[row * 2];
          final rightIdx = row * 2 + 1;
          final right =
              rightIdx < picks.length ? picks[rightIdx] : null;
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              children: [
                Expanded(
                    child: _quickPickTile(C, isComic, isHud, left)),
                const SizedBox(width: 8),
                Expanded(
                    child: right != null
                        ? _quickPickTile(C, isComic, isHud, right)
                        : const SizedBox.shrink()),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _quickPickTile(
      AppPalette C, bool isComic, bool isHud, _Track t) {
    final bool isActive = _currentlyPlayingId == t.id;
    final tileBg = isComic
        ? (isActive ? C.primaryHi : C.bgDark)
        : (isHud
            ? (isActive
                ? C.accent.withOpacity(0.15)
                : C.bgDeep.withOpacity(0.6))
            : null);
    final textColor = isComic
        ? C.contrastTextOn(tileBg ?? C.bgDark)
        : (isHud
            ? (isActive ? C.hudNeon() : C.hudText())
            : (isActive ? C.bgDeep : C.text));
    final thumbIconColor = isComic
        ? C.comicText
        : (isHud ? C.hudTextDim() : C.textSub);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius:
            BorderRadius.circular(isHud ? 0 : (isComic ? 12 : 10)),
        onTap: () => _togglePlay(t, C),
        child: Container(
          height: 60,
          decoration: isHud
              ? BoxDecoration(
                  color: tileBg,
                  border: Border.all(
                    color: isActive
                        ? C.accent
                        : C.accent.withOpacity(0.3),
                    width: isActive ? 1.4 : 1,
                  ),
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                            color: C.accent.withOpacity(0.4),
                            blurRadius: 10,
                          ),
                        ]
                      : null,
                )
              : BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                  gradient: isActive && !isComic
                      ? LinearGradient(colors: [
                          C.accentHi,
                          C.accent,
                          C.primaryLo
                        ])
                      : (isComic
                          ? null
                          : LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [C.bg, C.bgDark, C.bgDeep])),
                  color: tileBg,
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : (isActive
                              ? C.accentShine
                              : C.textSub.withOpacity(0.3)),
                      width: isComic ? 3.5 : (isActive ? 1.5 : 1)),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                              color: Colors.black,
                              offset: Offset(4, 4),
                              blurRadius: 0),
                        ]
                      : [
                          BoxShadow(
                            color: isActive
                                ? C.accent.withOpacity(0.5)
                                : Colors.black.withOpacity(0.6),
                            offset: const Offset(0, 3),
                            blurRadius: isActive ? 10 : 5,
                          ),
                        ],
                ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: isHud
                    ? BorderRadius.zero
                    : const BorderRadius.horizontal(
                        left: Radius.circular(7)),
                child: t.thumbnail.isEmpty
                    ? Container(
                        width: 56,
                        height: 60,
                        color: C.bgDeep,
                        child: Icon(Icons.music_note,
                            color: thumbIconColor, size: 22))
                    : Image.network(t.thumbnail,
                        width: 56,
                        height: 60,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                            width: 56,
                            height: 60,
                            color: C.bgDeep,
                            child: Icon(Icons.broken_image_rounded,
                                color: thumbIconColor,
                                size: 22))),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(t.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: textColor,
                      fontSize: isComic ? 13 : 11,
                      fontWeight: FontWeight.w900,
                      fontFamily:
                          isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 0.3,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: textColor == Colors.white
                                    ? Colors.black
                                    : Colors.white,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    )),
              ),
              if (_bufferingId == t.id)
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.accent : C.accent),
                    ),
                  ),
                )
              else if (isActive)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Icon(Icons.volume_up_rounded,
                      color: textColor, size: 16),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTrendingRow(AppPalette C, bool isComic, bool isHud) {
    if (_isLoadingTop) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Center(
          child: CircularProgressIndicator(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.accent : C.accent),
              strokeWidth: 2),
        ),
      );
    }
    if (_topError != null)
      return _errorBox(C, isComic, isHud, _topError!);
    if (_topTracks.isEmpty) {
      return Padding(
        padding:
            const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Text("Belum ada data.",
            style: TextStyle(
                color: isComic
                    ? C.comicTextSub
                    : (isHud ? C.hudTextDim() : C.textSub),
                fontSize: isComic ? 13 : 12,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w600)),
      );
    }

    return SizedBox(
      height: 210,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        itemCount: _topTracks.length > 15 ? 15 : _topTracks.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (_, i) =>
            _trendingCard(C, isComic, isHud, _topTracks[i]),
      ),
    );
  }

  Widget _trendingCard(
      AppPalette C, bool isComic, bool isHud, _Track t) {
    final bool isActive = _currentlyPlayingId == t.id;
    final bool playing = isActive && _isPlaying;
    final playBtnColor =
        isComic ? C.primaryHi : (isHud ? C.accent : C.accent);
    final playIconColor = isComic
        ? C.contrastTextOn(playBtnColor)
        : (isHud ? C.hudNeon() : C.bgDeep);
    final titleColor = isComic
        ? (isActive ? C.primaryHi : C.comicText)
        : (isHud
            ? (isActive ? C.hudNeon() : C.hudText())
            : (isActive ? C.accent : C.text));
    final thumbIconColor = isComic
        ? C.comicText
        : (isHud ? C.hudTextDim() : C.textSub);

    return SizedBox(
      width: 140,
      child: GestureDetector(
        onTap: () => _togglePlay(t, C),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              alignment: Alignment.bottomRight,
              children: [
                Container(
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.bgDeep.withOpacity(0.5),
                          border: Border.all(
                              color: C.accent.withOpacity(0.4),
                              width: 1),
                        )
                      : BoxDecoration(
                          borderRadius: BorderRadius.circular(
                              isComic ? 14 : 12),
                          gradient: isComic
                              ? null
                              : LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    C.text,
                                    C.bg,
                                    C.bgDark,
                                    C.bgDeep
                                  ],
                                  stops: const [
                                    0.0,
                                    0.4,
                                    0.7,
                                    1.0
                                  ]),
                          color: isComic ? C.bgDark : null,
                          border: isComic
                              ? Border.all(
                                  color: Colors.black, width: 4)
                              : null,
                          boxShadow: isComic
                              ? const [
                                  BoxShadow(
                                      color: Colors.black,
                                      offset: Offset(5, 5),
                                      blurRadius: 0),
                                ]
                              : [
                                  BoxShadow(
                                      color: Colors.black
                                          .withOpacity(0.75),
                                      offset: const Offset(0, 6),
                                      blurRadius: 10),
                                ]),
                  padding: const EdgeInsets.all(2),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(
                        isHud ? 0 : (isComic ? 10 : 10)),
                    child: t.thumbnail.isEmpty
                        ? Container(
                            width: 140,
                            height: 140,
                            color: C.bgDeep,
                            child: Icon(Icons.music_note,
                                color: thumbIconColor, size: 30))
                        : Image.network(t.thumbnail,
                            width: 140,
                            height: 140,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                                width: 140,
                                height: 140,
                                color: C.bgDeep,
                                child: Icon(
                                    Icons.broken_image_rounded,
                                    color: thumbIconColor,
                                    size: 30))),
                  ),
                ),
                Positioned(
                  right: 6,
                  bottom: 6,
                  child: Container(
                    width: 38,
                    height: 38,
                    alignment: Alignment.center,
                    decoration: isHud
                        ? BoxDecoration(
                            color: playBtnColor.withOpacity(0.2),
                            border: Border.all(
                                color: playBtnColor, width: 1.4),
                            boxShadow: [
                              BoxShadow(
                                color: playBtnColor.withOpacity(0.5),
                                blurRadius: 10,
                              ),
                            ],
                          )
                        : BoxDecoration(
                            shape: isComic
                                ? BoxShape.rectangle
                                : BoxShape.circle,
                            borderRadius: isComic
                                ? BorderRadius.circular(10)
                                : null,
                            gradient: isComic
                                ? null
                                : LinearGradient(colors: [
                                    C.accentHi,
                                    C.accent,
                                    C.primaryLo
                                  ]),
                            color: isComic ? playBtnColor : null,
                            border: Border.all(
                                color: isComic
                                    ? Colors.black
                                    : C.accentShine,
                                width: isComic ? 3 : 1.5),
                            boxShadow: isComic
                                ? null
                                : [
                                    BoxShadow(
                                      color:
                                          C.accent.withOpacity(0.6),
                                      blurRadius: 10),
                                  ],
                          ),
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: _bufferingId == t.id
                          ? SizedBox(
                              key: const ValueKey('buffering'),
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: playIconColor))
                          : Icon(
                              playing
                                  ? Icons.pause_rounded
                                  : Icons.play_arrow_rounded,
                              key: const ValueKey('icon'),
                              color: playIconColor,
                              size: 20),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(t.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: titleColor,
                  fontSize: isComic ? 13 : 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 0.3,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                )),
            const SizedBox(height: 3),
            Text(t.artist,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud
                          ? C.hudTextDim()
                          : C.text.withOpacity(0.55)),
                  fontSize: isComic ? 11 : 9.5,
                  fontWeight: FontWeight.w700,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildVerticalList(AppPalette C, bool isComic, bool isHud,
      List<_Track> tracks,
      {required bool isLoading,
      String? error,
      String emptyMsg = "Tidak ada data."}) {
    if (isLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: CircularProgressIndicator(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.accent : C.accent),
              strokeWidth: 2),
        ),
      );
    }
    if (error != null) return _errorBox(C, isComic, isHud, error);
    if (tracks.isEmpty) {
      return Padding(
        padding:
            const EdgeInsets.symmetric(vertical: 30, horizontal: 16),
        child: Center(
          child: Text(emptyMsg,
              style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud ? C.hudTextDim() : C.textSub),
                  fontSize: isComic ? 13 : 12,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w600)),
        ),
      );
    }

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      itemCount: tracks.length,
      itemBuilder: (_, i) =>
          _trackRow(C, isComic, isHud, tracks[i], index: i),
    );
  }

  Widget _errorBox(
      AppPalette C, bool isComic, bool isHud, String error) {
    final errorTextColor = isComic
        ? C.comicText
        : (isHud ? C.hudText() : C.text);
    final errorIconColor = isComic
        ? C.comicText
        : (isHud ? C.accent : C.primaryHi);

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: isHud
            ? BoxDecoration(
                color: Colors.red.withOpacity(0.1),
                border: Border.all(color: Colors.red, width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.red.withOpacity(0.3),
                    blurRadius: 10,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                color: isComic ? C.bgDark : C.bgDeep,
                border: Border.all(
                    color: isComic ? Colors.black : C.primaryHi,
                    width: isComic ? 3 : 1.5),
              ),
        child: Row(
          children: [
            _Led(color: C.primaryHi, size: 8, blink: !isComic),
            const SizedBox(width: 10),
            Icon(Icons.error_outline_rounded,
                color: errorIconColor, size: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Text(error,
                  style: TextStyle(
                      color: errorTextColor,
                      fontSize: isComic ? 13 : 11.5,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _trackRow(
      AppPalette C, bool isComic, bool isHud, _Track t, {int? index}) {
    final bool isActive = _currentlyPlayingId == t.id;
    final bool playing = isActive && _isPlaying;

    final tileBg = isComic
        ? (isActive ? C.primaryHi : C.bgDark)
        : (isHud
            ? (isActive
                ? C.accent.withOpacity(0.15)
                : C.bgDeep.withOpacity(0.6))
            : null);
    final titleColor = isComic
        ? C.contrastTextOn(tileBg ?? C.bgDark)
        : (isHud
            ? (isActive ? C.hudNeon() : C.hudText())
            : (isActive ? C.bgDeep : C.text));
    final artistColor = isComic
        ? C.contrastTextOn(tileBg ?? C.bgDark).withOpacity(0.8)
        : (isHud
            ? C.hudTextDim()
            : (isActive
                ? C.bgDeep.withOpacity(0.75)
                : C.text.withOpacity(0.55)));
    final iconBtnColor = isComic
        ? C.contrastTextOn(tileBg ?? C.bgDark)
        : (isHud ? C.accent : (isActive ? C.bgDeep : C.accent));
    final thumbIconColor = isComic
        ? C.contrastTextOn(tileBg ?? C.bgDark)
        : (isHud ? C.hudTextDim() : C.textSub);

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(
              isHud ? 0 : (isComic ? 12 : 10)),
          onTap: () => _togglePlay(t, C),
          child: Container(
            decoration: isHud
                ? BoxDecoration(
                    color: tileBg,
                    border: Border.all(
                      color: isActive
                          ? C.accent
                          : C.accent.withOpacity(0.3),
                      width: isActive ? 1.4 : 1,
                    ),
                    boxShadow: isActive
                        ? [
                            BoxShadow(
                              color: C.accent.withOpacity(0.4),
                              blurRadius: 10,
                            ),
                          ]
                        : null,
                  )
                : BoxDecoration(
                    borderRadius:
                        BorderRadius.circular(isComic ? 12 : 10),
                    gradient: isActive && !isComic
                        ? LinearGradient(colors: [
                            C.accentHi,
                            C.accent,
                            C.primaryLo
                          ])
                        : (isComic
                            ? null
                            : LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [C.bg, C.bgDark, C.bgDeep])),
                    color: tileBg,
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : (isActive
                                ? C.accentShine
                                : C.textSub.withOpacity(0.3)),
                        width: isComic ? 3.5 : (isActive ? 1.5 : 1)),
                    boxShadow: isComic
                        ? const [
                            BoxShadow(
                                color: Colors.black,
                                offset: Offset(4, 4),
                                blurRadius: 0),
                          ]
                        : [
                            BoxShadow(
                              color: isActive
                                  ? C.accent.withOpacity(0.5)
                                  : Colors.black.withOpacity(0.6),
                              offset: const Offset(0, 3),
                              blurRadius: isActive ? 10 : 5,
                            ),
                          ],
                  ),
            padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            child: Row(
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(
                          isHud ? 0 : (isComic ? 8 : 6)),
                      child: t.thumbnail.isEmpty
                          ? Container(
                              width: 50,
                              height: 50,
                              color: C.bgDeep,
                              child: Icon(Icons.music_note,
                                  color: thumbIconColor, size: 22))
                          : Image.network(t.thumbnail,
                              width: 50,
                              height: 50,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) =>
                                  Container(
                                      width: 50,
                                      height: 50,
                                      color: C.bgDeep,
                                      child: Icon(
                                          Icons
                                              .broken_image_rounded,
                                          color: thumbIconColor,
                                          size: 22))),
                    ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(t.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: titleColor,
                            fontSize: isComic ? 14 : 12.5,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 0.3,
                            shadows: isComic
                                ? [
                                    Shadow(
                                      color: titleColor == Colors.white
                                          ? Colors.black
                                          : Colors.white,
                                      offset: const Offset(1, 1),
                                      blurRadius: 0,
                                    ),
                                  ]
                                : null,
                          )),
                      const SizedBox(height: 3),
                      Text(t.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: artistColor,
                            fontSize: isComic ? 11 : 10,
                            fontWeight: FontWeight.w700,
                            fontFamily: isComic
                                ? 'ComicNeue'
                                : 'ShareTechMono',
                          )),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: _bufferingId == t.id
                      ? SizedBox(
                          key: const ValueKey('buffering'),
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: iconBtnColor))
                      : isActive
                          ? Icon(
                              playing
                                  ? Icons.pause_rounded
                                  : Icons.equalizer_rounded,
                              key: const ValueKey('active'),
                              color: iconBtnColor,
                              size: 20)
                          : Icon(
                              Icons.play_arrow_rounded,
                              key: const ValueKey('idle'),
                              color: iconBtnColor,
                              size: 20),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMiniPlayer(AppPalette C, bool isComic, bool isHud) {
    final t = _currentTrack!;
    final pos = _currentPosition.inMilliseconds.toDouble();
    final dur = _currentDuration.inMilliseconds <= 0
        ? 1.0
        : _currentDuration.inMilliseconds.toDouble();
    final progress = (pos / dur).clamp(0.0, 1.0);

    final playBtnColor =
        isComic ? C.primaryHi : (isHud ? C.accent : C.accent);
    final playIconColor = isComic
        ? C.contrastTextOn(playBtnColor)
        : (isHud ? C.hudNeon() : C.bgDeep);
    final stopBtnColor = isComic
        ? C.accent
        : (isHud ? C.primaryHi : C.primaryHi);
    final stopIconColor = isComic
        ? C.contrastTextOn(stopBtnColor)
        : (isHud ? C.hudText() : C.text);
    final titleColor =
        isComic ? C.comicText : (isHud ? C.hudText() : C.text);
    final artistColor = isComic
        ? C.comicTextSub
        : (isHud ? C.hudTextDim() : C.text.withOpacity(0.6));
    final thumbIconColor = isComic
        ? C.comicText
        : (isHud ? C.hudTextDim() : C.textSub);
    final progressBg =
        isComic ? C.bg : (isHud ? C.bgDeep : C.bgDeep);
    final progressColor =
        isComic ? C.primaryHi : (isHud ? C.accent : C.accent);

    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
      child: _MetalPlate(
        C: C,
        radius: 14,
        padding: EdgeInsets.zero,
        child: ClipRRect(
          borderRadius:
              BorderRadius.circular(isHud ? 0 : (isComic ? 12 : 11)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              LinearProgressIndicator(
                value: progress,
                minHeight: isComic ? 5 : 3,
                backgroundColor: progressBg,
                valueColor: AlwaysStoppedAnimation(progressColor),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(
                          isHud ? 0 : (isComic ? 10 : 8)),
                      child: t.thumbnail.isEmpty
                          ? Container(
                              width: 46,
                              height: 46,
                              color: C.bgDeep,
                              child: Icon(Icons.music_note,
                                  color: thumbIconColor, size: 20))
                          : Image.network(t.thumbnail,
                              width: 46,
                              height: 46,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) =>
                                  Container(
                                      width: 46,
                                      height: 46,
                                      color: C.bgDeep,
                                      child: Icon(
                                          Icons.music_note,
                                          color: thumbIconColor,
                                          size: 20))),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(t.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: titleColor,
                                fontSize: isComic ? 15 : 12.5,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                letterSpacing: 0.3,
                                shadows: isComic
                                    ? [
                                        Shadow(
                                          color:
                                              C.comicTextOutline,
                                          offset: const Offset(1, 1),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : const [
                                        Shadow(
                                            color: Colors.black,
                                            offset: Offset(0, 1),
                                            blurRadius: 2),
                                      ])),
                          const SizedBox(height: 3),
                          Row(
                            children: [
                              Flexible(
                                child: Text(t.artist,
                                    maxLines: 1,
                                    overflow:
                                        TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: artistColor,
                                      fontSize: isComic ? 11 : 10,
                                      fontWeight: FontWeight.w700,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                    )),
                              ),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 1.5),
                                decoration: isHud
                                    ? BoxDecoration(
                                        color: C.accent
                                            .withOpacity(0.15),
                                        border: Border.all(
                                            color: C.accent,
                                            width: 1),
                                      )
                                    : BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(
                                                isComic ? 6 : 6),
                                        gradient: isComic
                                            ? null
                                            : LinearGradient(colors: [
                                                C.accentHi,
                                                C.accent,
                                                C.primaryLo
                                              ]),
                                        color: isComic
                                            ? C.primaryHi
                                            : null,
                                        border: Border.all(
                                            color: isComic
                                                ? Colors.black
                                                : C.accentShine,
                                            width:
                                                isComic ? 2 : 1),
                                      ),
                                child: Text(
                                  "Pratinjau ${_fmtMs(_currentDuration)}",
                                  style: TextStyle(
                                    color: isComic
                                        ? C.contrastTextOn(C.primaryHi)
                                        : (isHud
                                            ? C.hudNeon()
                                            : C.bgDeep),
                                    fontSize: isComic ? 9.5 : 8.5,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: isComic
                                        ? 'Bangers'
                                        : 'Orbitron',
                                  )),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    _bufferingId == t.id
                        ? SizedBox(
                            width: 32,
                            height: 32,
                            child: Padding(
                              padding: const EdgeInsets.all(6),
                              child: CircularProgressIndicator(
                                strokeWidth: 2.4,
                                color: isComic
                                    ? C.comicText
                                    : (isHud ? C.accent : C.accent),
                              ),
                            ),
                          )
                        : GestureDetector(
                            onTap: () => _togglePlay(t, C),
                            child: Container(
                              width: 40,
                              height: 40,
                              decoration: isHud
                                  ? BoxDecoration(
                                      color: playBtnColor
                                          .withOpacity(0.2),
                                      border: Border.all(
                                          color: playBtnColor,
                                          width: 1.4),
                                      boxShadow: [
                                        BoxShadow(
                                          color: playBtnColor
                                              .withOpacity(0.5),
                                          blurRadius: 10,
                                        ),
                                      ],
                                    )
                                  : BoxDecoration(
                                      shape: isComic
                                          ? BoxShape.rectangle
                                          : BoxShape.circle,
                                      borderRadius: isComic
                                          ? BorderRadius.circular(10)
                                          : null,
                                      gradient: isComic
                                          ? null
                                          : LinearGradient(colors: [
                                              C.accentHi,
                                              C.accent,
                                              C.primaryLo
                                            ]),
                                      color:
                                          isComic ? playBtnColor : null,
                                      border: Border.all(
                                          color: isComic
                                              ? Colors.black
                                              : C.accentShine,
                                          width: isComic ? 3 : 1.5),
                                      boxShadow: isComic
                                          ? null
                                          : [
                                              BoxShadow(
                                                color: C.accent
                                                    .withOpacity(0.6),
                                                blurRadius: 10,
                                              ),
                                            ]),
                              child: Icon(
                                _isPlaying
                                    ? Icons.pause_rounded
                                    : Icons.play_arrow_rounded,
                                color: playIconColor,
                                size: 22,
                              ),
                            ),
                          ),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: _stopPlayer,
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: isHud
                            ? BoxDecoration(
                                color:
                                    stopBtnColor.withOpacity(0.15),
                                border: Border.all(
                                    color: stopBtnColor, width: 1.2),
                                boxShadow: [
                                  BoxShadow(
                                    color: stopBtnColor
                                        .withOpacity(0.35),
                                    blurRadius: 8,
                                  ),
                                ],
                              )
                            : BoxDecoration(
                                shape: isComic
                                    ? BoxShape.rectangle
                                    : BoxShape.circle,
                                borderRadius: isComic
                                    ? BorderRadius.circular(10)
                                    : null,
                                gradient: isComic
                                    ? null
                                    : LinearGradient(colors: [
                                        C.primaryHi,
                                        C.primary,
                                        C.primaryLo
                                      ]),
                                color: isComic ? stopBtnColor : null,
                                border: Border.all(
                                    color: isComic
                                        ? Colors.black
                                        : C.primaryLo,
                                    width: isComic ? 3 : 1.5),
                              ),
                        child: Icon(Icons.close_rounded,
                            color: stopIconColor, size: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _fmtMs(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return "$m:${s.toString().padLeft(2, '0')}";
  }
}

// ── MODEL ────────────────────────────────────────────────────
class _Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String thumbnail;
  final String previewUrl;
  final int duration;
  final int rank;

  _Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.thumbnail,
    required this.previewUrl,
    required this.duration,
    required this.rank,
  });

  factory _Track.fromDeezer(Map<String, dynamic> json) {
    final artistMap = json['artist'];
    final albumMap = json['album'];
    String thumb = '';
    if (albumMap is Map) {
      thumb = (albumMap['cover_xl'] ??
              albumMap['cover_big'] ??
              albumMap['cover_medium'] ??
              albumMap['cover'] ??
              '')
          .toString();
    }
    return _Track(
      id: (json['id'] ?? '').toString(),
      title:
          (json['title_short'] ?? json['title'] ?? '').toString(),
      artist:
          (artistMap is Map ? (artistMap['name'] ?? '') : '').toString(),
      album:
          (albumMap is Map ? (albumMap['title'] ?? '') : '').toString(),
      thumbnail: thumb,
      previewUrl: (json['preview'] ?? '').toString(),
      duration: (json['duration'] is int)
          ? json['duration'] as int
          : int.tryParse((json['duration'] ?? '0').toString()) ?? 0,
      rank: (json['rank'] is int)
          ? json['rank'] as int
          : int.tryParse((json['rank'] ?? '0').toString()) ?? 0,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}