// quran_api.dart — API Helper buat Al-Qur'an
import 'dart:convert';
import 'package:http/http.dart' as http;

class QuranApi {
  static const String baseUrl = 'http://angelacantik.zone.id:3631/quran';

  /// Ambil daftar 114 surah
  static Future<List<QuranSurah>> getSurahList() async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/surah'))
          .timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['code'] == 200 && data['data'] != null) {
          return (data['data'] as List)
              .map((e) => QuranSurah.fromJson(e))
              .toList();
        }
      }
      return [];
    } catch (e) {
      print('[QURAN API ERROR] getSurahList: $e');
      return [];
    }
  }

  /// Ambil detail surah + ayat-ayat
  static Future<QuranSurahDetail?> getSurahDetail(int nomor) async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/surah/$nomor'))
          .timeout(const Duration(seconds: 20));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['code'] == 200 && data['data'] != null) {
          return QuranSurahDetail.fromJson(data['data']);
        }
      }
      return null;
    } catch (e) {
      print('[QURAN API ERROR] getSurahDetail($nomor): $e');
      return null;
    }
  }

  /// Cari surah
  static Future<List<QuranSurah>> searchSurah(String query) async {
    try {
      final res = await http
          .get(Uri.parse(
              '$baseUrl/search?q=${Uri.encodeComponent(query)}'))
          .timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['data'] != null) {
          return (data['data'] as List)
              .map((e) => QuranSurah.fromJson(e))
              .toList();
        }
      }
      return [];
    } catch (e) {
      print('[QURAN API ERROR] searchSurah: $e');
      return [];
    }
  }
}

// ─── MODEL: Surah (untuk list) ─────────────────────────────
class QuranSurah {
  final int nomor;
  final String nama;
  final String namaLatin;
  final int jumlahAyat;
  final String tempatTurun;
  final String arti;
  final String deskripsi;
  final String audioFull;

  QuranSurah({
    required this.nomor,
    required this.nama,
    required this.namaLatin,
    required this.jumlahAyat,
    required this.tempatTurun,
    required this.arti,
    required this.deskripsi,
    required this.audioFull,
  });

  factory QuranSurah.fromJson(Map<String, dynamic> json) {
    return QuranSurah(
      nomor: json['nomor'] ?? 0,
      nama: json['nama'] ?? '',
      namaLatin: json['namaLatin'] ?? '',
      jumlahAyat: json['jumlahAyat'] ?? 0,
      tempatTurun: json['tempatTurun'] ?? '',
      arti: json['arti'] ?? '',
      deskripsi: json['deskripsi'] ?? '',
      audioFull: json['audioFull']?['05'] ?? '',
    );
  }
}

// ─── MODEL: Surah Detail (untuk baca) ─────────────────────
class QuranSurahDetail {
  final int nomor;
  final String nama;
  final String namaLatin;
  final int jumlahAyat;
  final String tempatTurun;
  final String arti;
  final String deskripsi;
  final List<QuranAyat> ayat;

  QuranSurahDetail({
    required this.nomor,
    required this.nama,
    required this.namaLatin,
    required this.jumlahAyat,
    required this.tempatTurun,
    required this.arti,
    required this.deskripsi,
    required this.ayat,
  });

  factory QuranSurahDetail.fromJson(Map<String, dynamic> json) {
    return QuranSurahDetail(
      nomor: json['nomor'] ?? 0,
      nama: json['nama'] ?? '',
      namaLatin: json['namaLatin'] ?? '',
      jumlahAyat: json['jumlahAyat'] ?? 0,
      tempatTurun: json['tempatTurun'] ?? '',
      arti: json['arti'] ?? '',
      deskripsi: json['deskripsi'] ?? '',
      ayat: (json['ayat'] as List? ?? [])
          .map((e) => QuranAyat.fromJson(e))
          .toList(),
    );
  }
}

// ─── MODEL: Ayat ───────────────────────────────────────────
class QuranAyat {
  final int nomorAyat;
  final String teksArab;
  final String teksLatin;
  final String teksIndonesia;
  final String audio;

  QuranAyat({
    required this.nomorAyat,
    required this.teksArab,
    required this.teksLatin,
    required this.teksIndonesia,
    required this.audio,
  });

  factory QuranAyat.fromJson(Map<String, dynamic> json) {
    return QuranAyat(
      nomorAyat: json['nomorAyat'] ?? 0,
      teksArab: json['teksArab'] ?? '',
      teksLatin: json['teksLatin'] ?? '',
      teksIndonesia: json['teksIndonesia'] ?? '',
      audio: json['audio']?['05'] ?? '',
    );
  }
}