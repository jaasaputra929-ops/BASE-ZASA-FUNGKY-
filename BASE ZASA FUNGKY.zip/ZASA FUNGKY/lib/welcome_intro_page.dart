// lib/welcome_intro_page.dart — Full 3 Style Support (FINAL)
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'dashboard_page.dart';

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      if (!blink) {
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: color,
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3,
              ),
            ],
          ),
        );
      }
      return ValueListenableBuilder<double>(
        valueListenable: _Pulse.v,
        builder: (_, v, __) => Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: color.withOpacity(0.4 + v * 0.6),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3,
              ),
            ],
          ),
        ),
      );
    }

    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
              color: Colors.black.withOpacity(0.85), width: size * 0.1),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.75 * opacity),
                blurRadius: size * 1.4,
                spreadRadius: size * 0.2),
            BoxShadow(
                color: color.withOpacity(0.35 * opacity),
                blurRadius: size * 2.6,
                spreadRadius: size * 0.4),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  final double rotation;
  const _Screw({required this.C, this.size = 14, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();
    if (isHud) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();
    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withOpacity(0.6), width: 1),
        ),
      );
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6),
              blurRadius: 12),
          const BoxShadow(
              color: Colors.white24, offset: Offset(-1, -1), blurRadius: 3),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12,
        height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.8)),
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// WELCOME INTRO PAGE
// ═══════════════════════════════════════════════════════════
class WelcomeIntroPage extends StatefulWidget {
  final Map<String, dynamic> dashboardArgs;

  const WelcomeIntroPage({super.key, required this.dashboardArgs});

  @override
  State<WelcomeIntroPage> createState() => _WelcomeIntroPageState();
}

class _WelcomeIntroPageState extends State<WelcomeIntroPage>
    with TickerProviderStateMixin {
  static const Duration _loadDuration = Duration(milliseconds: 6000);

  late AnimationController _entryCtrl;
  late AnimationController _vinylCtrl;
  late AnimationController _loadCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _glowCtrl;

  late Animation<double> _fade;
  late Animation<double> _scale;
  late Animation<double> _vinylRotation;
  late Animation<double> _loadProgress;
  late Animation<double> _glow;

  int _lastPercent = -1;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _setupAnimations();
    _startLoading();
  }

  void _setupAnimations() {
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _vinylCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _loadCtrl = AnimationController(
      vsync: this,
      duration: _loadDuration,
    )..forward();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..repeat();

    _fade = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
    _scale = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutBack));
    _vinylRotation = Tween<double>(begin: 0.0, end: 2 * math.pi)
        .animate(CurvedAnimation(parent: _vinylCtrl, curve: Curves.linear));
    _loadProgress = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _loadCtrl, curve: Curves.easeInOut));
    _glow = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  void _startLoading() {
    _loadCtrl.addListener(() {
      final pct = (_loadCtrl.value * 100).toInt();
      if (pct != _lastPercent) {
        _lastPercent = pct;
        if (mounted) setState(() {});
        HapticFeedback.selectionClick();
      }

      if (_loadCtrl.value >= 1.0 && !_navigated) {
        _navigated = true;
        Future.delayed(const Duration(milliseconds: 700), _goToDashboard);
      }
    });
  }

  void _goToDashboard() {
    if (!mounted) return;
    HapticFeedback.heavyImpact();
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.dashboardArgs['username'] ?? '',
          password: widget.dashboardArgs['password'] ?? '',
          role: widget.dashboardArgs['role'] ?? '',
          sessionKey: widget.dashboardArgs['key'] ?? '',
          expiredDate: widget.dashboardArgs['expiredDate'] ?? '',
          listBug: List<Map<String, dynamic>>.from(
              widget.dashboardArgs['listBug'] ?? []),
          listDoos: List<Map<String, dynamic>>.from(
              widget.dashboardArgs['listDoos'] ?? []),
          news: List<dynamic>.from(widget.dashboardArgs['news'] ?? []),
        ),
        transitionDuration: const Duration(milliseconds: 600),
        transitionsBuilder: (_, anim, __, child) {
          return FadeTransition(
            opacity: anim,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.96, end: 1.0).animate(
                  CurvedAnimation(
                      parent: anim, curve: Curves.easeOutCubic)),
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _vinylCtrl.dispose();
    _loadCtrl.dispose();
    _pulseCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isHud ? C.hudBg() : (isComic ? C.bg : C.bgDark),
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withOpacity(0.12)),
                            ),
                          )
                        : (isHud
                            ? Container(
                                color: C.hudBg(),
                                child: CustomPaint(
                                  painter: _HudGridPainter(
                                      color: C.hudGridLine()),
                                ),
                              )
                            : Container(
                                decoration: BoxDecoration(
                                  gradient: RadialGradient(
                                    center: const Alignment(-0.3, -0.3),
                                    radius: 1.2,
                                    colors: [C.bg, C.bgDark, C.bgDeep],
                                    stops: const [0.0, 0.6, 1.0],
                                  ),
                                ),
                              )),
                  ),

                  if (!isComic && !isHud)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(painter: _LeatherWallPainter()),
                      ),
                    ),

                  if (!isComic && !isHud)
                    AnimatedBuilder(
                      animation: _glowCtrl,
                      builder: (_, __) => Positioned(
                        top: _glowCtrl.value *
                            MediaQuery.of(context).size.height,
                        left: 0,
                        right: 0,
                        child: Container(
                          height: 2,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                C.accentHi.withOpacity(0.25),
                                C.accentHi.withOpacity(0.5),
                                C.accentHi.withOpacity(0.25),
                                Colors.transparent,
                              ],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: C.accentHi.withOpacity(0.3),
                                blurRadius: 12,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                  SafeArea(
                    child: FadeTransition(
                      opacity: _fade,
                      child: ScaleTransition(
                        scale: _scale,
                        child: Column(
                          children: [
                            const Spacer(flex: 2),
                            _buildVinylLogo(C, isComic, isHud),
                            const SizedBox(height: 30),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 30),
                              child:
                                  _buildTitlePlate(C, isComic, isHud),
                            ),
                            const SizedBox(height: 14),
                            _buildStatusLine(C, isComic, isHud),
                            const Spacer(flex: 2),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 30),
                              child: _buildLoadingPanel(C, isComic, isHud),
                            ),
                            const SizedBox(height: 20),
                            _buildBottomInfo(C, isComic, isHud),
                            const Spacer(flex: 1),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // VINYL LOGO
  // ═══════════════════════════════════════════════════════════
  Widget _buildVinylLogo(AppPalette C, bool isComic, bool isHud) {
    // ═══ COMIC ═══
    if (isComic) {
      return SizedBox(
        width: 230,
        height: 230,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedBuilder(
              animation: _glow,
              builder: (_, __) => Container(
                width: 210 + (15 * _glow.value),
                height: 210 + (15 * _glow.value),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: C.accent.withOpacity(0.15),
                ),
              ),
            ),
            Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: C.primaryHi,
                border: Border.all(color: Colors.black, width: 5),
                boxShadow: const [
                  BoxShadow(
                      color: Colors.black,
                      offset: Offset(8, 8),
                      blurRadius: 0),
                ],
              ),
              padding: const EdgeInsets.all(6),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  border: Border.all(color: Colors.black, width: 4),
                ),
                padding: const EdgeInsets.all(6),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 3),
                  ),
                  padding: const EdgeInsets.all(4),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      AnimatedBuilder(
                        animation: _vinylRotation,
                        builder: (_, __) => Transform.rotate(
                          angle: _vinylRotation.value,
                          child: ClipOval(
                            child: Image.asset(
                              'assets/images/logo.jpg',
                              width: 140,
                              height: 140,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                width: 140,
                                height: 140,
                                color: Colors.white,
                                child: Icon(
                                    Icons.shield_moon_rounded,
                                    color: C.bgDeep,
                                    size: 60),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: C.bgDeep,
                          border:
                              Border.all(color: Colors.black, width: 2),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 8,
              right: 12,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: C.accent,
                  border: Border.all(color: Colors.black, width: 3),
                ),
              ),
            ),
            Positioned(
              bottom: 16,
              left: 8,
              child: Container(
                width: 18,
                height: 18,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: C.accentShine,
                  border: Border.all(color: Colors.black, width: 3),
                ),
              ),
            ),
            Positioned(
              top: 0,
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: C.primaryHi,
                  border: Border.all(color: Colors.black, width: 3),
                ),
              ),
            ),
          ],
        ),
      );
    }

    // ═══ HUD ═══
    if (isHud) {
      return SizedBox(
        width: 230,
        height: 230,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedBuilder(
              animation: _glow,
              builder: (_, __) => Container(
                width: 210 + (15 * _glow.value),
                height: 210 + (15 * _glow.value),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      C.accent.withOpacity(0.25 * _glow.value),
                      Colors.transparent,
                    ],
                    stops: const [0.5, 1.0],
                  ),
                ),
              ),
            ),
            Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                color: C.accent.withOpacity(0.1),
                border: Border.all(
                    color: C.accent.withOpacity(0.6), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: C.accent.withOpacity(0.5),
                    blurRadius: 30,
                    spreadRadius: 4,
                  ),
                ],
              ),
              padding: const EdgeInsets.all(6),
              child: Stack(
                children: [
                  Positioned(top: 0, left: 0, child: _cornerHud(C)),
                  Positioned(top: 0, right: 0, child: _cornerHud(C)),
                  Positioned(bottom: 0, left: 0, child: _cornerHud(C)),
                  Positioned(bottom: 0, right: 0, child: _cornerHud(C)),
                  Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.bgDeep.withOpacity(0.7),
                        border: Border.all(
                            color: C.accent.withOpacity(0.5), width: 1),
                      ),
                      padding: const EdgeInsets.all(8),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          AnimatedBuilder(
                            animation: _vinylRotation,
                            builder: (_, __) => Transform.rotate(
                              angle: _vinylRotation.value,
                              child: ClipOval(
                                child: Image.asset(
                                  'assets/images/logo.jpg',
                                  width: 130,
                                  height: 130,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) =>
                                      Container(
                                    width: 130,
                                    height: 130,
                                    color: C.bgDeep,
                                    child: Icon(
                                        Icons.shield_moon_rounded,
                                        color: C.hudNeon(),
                                        size: 60),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            width: 14,
                            height: 14,
                            decoration: BoxDecoration(
                              color: C.hudNeon(),
                              boxShadow: [
                                BoxShadow(
                                  color: C.accent.withOpacity(0.8),
                                  blurRadius: 8,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: 6,
              child: _Led(color: C.primaryHi, size: 11, blink: true),
            ),
          ],
        ),
      );
    }

    // ═══ ORIGINAL ═══
    return SizedBox(
      width: 230,
      height: 230,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: _glow,
            builder: (_, __) => Container(
              width: 210 + (15 * _glow.value),
              height: 210 + (15 * _glow.value),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    C.accent.withOpacity(0.35 * _glow.value),
                    C.accent.withOpacity(0.15 * _glow.value),
                    Colors.transparent,
                  ],
                  stops: const [0.5, 0.75, 1.0],
                ),
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _vinylCtrl,
            builder: (_, __) => Transform.rotate(
              angle: -_vinylRotation.value * 0.5,
              child: CustomPaint(
                size: const Size(220, 220),
                painter: _DashedRingPainter(
                  color: C.accent.withOpacity(0.5),
                  dashCount: 36,
                ),
              ),
            ),
          ),
          Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  C.accentShine,
                  C.accentHi,
                  C.accent,
                  C.primary,
                  C.primaryLo,
                ],
                stops: const [0.0, 0.2, 0.5, 0.8, 1.0],
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.9),
                  offset: const Offset(0, 10),
                  blurRadius: 24,
                ),
                BoxShadow(
                  color: C.accent.withOpacity(0.5),
                  blurRadius: 30,
                  spreadRadius: 4,
                ),
              ],
            ),
            padding: const EdgeInsets.all(6),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient:
                    RadialGradient(colors: [C.bgDark, C.bgDeep]),
              ),
              padding: const EdgeInsets.all(6),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [C.text, C.bg, C.bgDark],
                    stops: const [0.0, 0.7, 1.0],
                  ),
                  border: Border.all(
                    color: C.accent.withOpacity(0.6),
                    width: 1.5,
                  ),
                ),
                padding: const EdgeInsets.all(8),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _vinylRotation,
                      builder: (_, __) => Transform.rotate(
                        angle: _vinylRotation.value,
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/logo.jpg',
                            width: 130,
                            height: 130,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              width: 130,
                              height: 130,
                              color: C.bgDark,
                              child: Icon(Icons.shield_moon_rounded,
                                  color: C.accent, size: 60),
                            ),
                          ),
                        ),
                      ),
                    ),
                    IgnorePointer(
                      child: ClipOval(
                        child: Container(
                          width: 130,
                          height: 130,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withOpacity(0.15),
                                Colors.transparent,
                                Colors.transparent,
                                Colors.black.withOpacity(0.2),
                              ],
                              stops: const [0.0, 0.35, 0.65, 1.0],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient:
                            RadialGradient(colors: [C.text, C.bgDark]),
                        border: Border.all(
                          color: C.accent.withOpacity(0.7),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.9),
                            blurRadius: 4,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 6,
            child: _Led(color: C.primaryHi, size: 11, blink: true),
          ),
          Positioned(top: 20, left: 20, child: _Rivet(C: C, size: 9)),
          Positioned(top: 20, right: 20, child: _Rivet(C: C, size: 9)),
          Positioned(bottom: 20, left: 20, child: _Rivet(C: C, size: 9)),
          Positioned(bottom: 20, right: 20, child: _Rivet(C: C, size: 9)),
        ],
      ),
    );
  }

  Widget _cornerHud(AppPalette C) => SizedBox(
        width: 16,
        height: 16,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.9)),
        ),
      );

  // ═══════════════════════════════════════════════════════════
  // TITLE PLATE
  // ═══════════════════════════════════════════════════════════
  Widget _buildTitlePlate(AppPalette C, bool isComic, bool isHud) {
    if (isComic) {
      return Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
          ],
        ),
        child: Text(
          'WELCOME BACK',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: C.bgDeep,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            fontFamily: 'Bangers',
            letterSpacing: 4,
            height: 1,
          ),
        ),
      );
    }

    if (isHud) {
      return Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
                color: C.accent.withOpacity(0.4), blurRadius: 15),
          ],
        ),
        child: Stack(
          children: [
            Positioned(top: 0, left: 0, child: _cornerHud(C)),
            Positioned(top: 0, right: 0, child: _cornerHud(C)),
            Positioned(bottom: 0, left: 0, child: _cornerHud(C)),
            Positioned(bottom: 0, right: 0, child: _cornerHud(C)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Text(
                'WELCOME BACK',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: C.hudNeon(),
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 5,
                  height: 1,
                  shadows: [
                    Shadow(
                        color: C.accent.withOpacity(0.6),
                        blurRadius: 12),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.85),
            offset: const Offset(0, 8),
            blurRadius: 16,
          ),
          const BoxShadow(
              color: Colors.white24,
              offset: Offset(-1, -1),
              blurRadius: 3),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: Stack(
          children: [
            Transform.translate(
              offset: const Offset(1, 1),
              child: Text(
                'WELCOME BACK',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.4),
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 5,
                  height: 1,
                ),
              ),
            ),
            Text(
              'WELCOME BACK',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: C.accentShine,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 5,
                height: 1,
                shadows: [
                  Shadow(color: C.accent, blurRadius: 15),
                  Shadow(
                      color: C.primaryLo,
                      offset: const Offset(0, 1),
                      blurRadius: 2),
                  const Shadow(
                      color: Colors.black,
                      offset: Offset(0, 2),
                      blurRadius: 6),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STATUS LINE
  // ═══════════════════════════════════════════════════════════
  Widget _buildStatusLine(AppPalette C, bool isComic, bool isHud) {
    final username = widget.dashboardArgs['username'] ?? 'User';
    final role =
        (widget.dashboardArgs['role'] ?? 'user').toString().toUpperCase();

    if (isComic) {
      return Column(
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: C.primaryHi,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.black, width: 3),
              boxShadow: const [
                BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 2),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'HELLO, $username',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Bangers',
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(
                          color: Colors.black,
                          offset: Offset(1, 1),
                          blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: C.accentShine,
                    border: Border.all(color: Colors.black, width: 2),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'ROLE · $role · SECURE SESSION',
            style: TextStyle(
              color: Colors.black.withOpacity(0.6),
              fontSize: 10,
              fontWeight: FontWeight.w800,
              fontFamily: 'ComicNeue',
              letterSpacing: 2,
            ),
          ),
        ],
      );
    }

    if (isHud) {
      return Column(
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: C.accent.withOpacity(0.15),
              border: Border.all(color: C.accent, width: 1.2),
              boxShadow: [
                BoxShadow(
                    color: C.accent.withOpacity(0.4), blurRadius: 8),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _Led(color: C.primaryHi, size: 6, blink: true),
                const SizedBox(width: 8),
                Text(
                  'HELLO, $username',
                  style: TextStyle(
                    color: C.hudNeon(),
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(
                          color: C.accent.withOpacity(0.6),
                          blurRadius: 4),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                _Led(color: C.accent, size: 6, blink: true),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'ROLE · $role · SECURE SESSION',
            style: TextStyle(
              color: C.hudTextDim(),
              fontSize: 9,
              fontWeight: FontWeight.w600,
              fontFamily: 'ShareTechMono',
              letterSpacing: 3,
            ),
          ),
        ],
      );
    }

    return Column(
      children: [
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.black.withOpacity(0.6),
            border: Border.all(color: C.bgDark, width: 1),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  offset: const Offset(0, 3),
                  blurRadius: 6),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _Led(color: C.primaryHi, size: 6, blink: true),
              const SizedBox(width: 8),
              Text(
                'HELLO, $username',
                style: TextStyle(
                  color: C.text,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                  shadows: [Shadow(color: C.primaryHi, blurRadius: 4)],
                ),
              ),
              const SizedBox(width: 8),
              _Led(color: C.accent, size: 6, blink: true),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'ROLE · $role · SECURE SESSION',
          style: TextStyle(
            color: C.text.withOpacity(0.5),
            fontSize: 9,
            fontWeight: FontWeight.w600,
            fontFamily: 'ShareTechMono',
            letterSpacing: 3,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LOADING PANEL
  // ═══════════════════════════════════════════════════════════
  Widget _buildLoadingPanel(AppPalette C, bool isComic, bool isHud) {
    if (isComic) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
          ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: C.primaryHi,
                    border: Border.all(color: Colors.black, width: 2),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: AnimatedBuilder(
                    animation: _loadProgress,
                    builder: (_, __) {
                      final pct = (_loadProgress.value * 100).toInt();
                      final text = pct < 30
                          ? 'INITIALIZING CORE...'
                          : pct < 60
                              ? 'LOADING MODULES...'
                              : pct < 90
                                  ? 'SYNCING DATA...'
                                  : pct < 100
                                      ? 'FINALIZING...'
                                      : 'READY TO LAUNCH';
                      return Text(text,
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Bangers',
                            letterSpacing: 1.5,
                          ));
                    },
                  ),
                ),
                AnimatedBuilder(
                  animation: _loadProgress,
                  builder: (_, __) {
                    final pct = (_loadProgress.value * 100).toInt();
                    return Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: C.accent,
                        border:
                            Border.all(color: Colors.black, width: 2),
                      ),
                      child: Text('$pct%',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Bangers',
                            letterSpacing: 1,
                            shadows: [
                              Shadow(
                                  color: Colors.black,
                                  offset: Offset(1, 1),
                                  blurRadius: 0),
                            ],
                          )),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 12),
            AnimatedBuilder(
              animation: _loadProgress,
              builder: (_, __) => Container(
                height: 16,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.white,
                  border: Border.all(color: Colors.black, width: 3),
                ),
                padding: const EdgeInsets.all(2),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: _loadProgress.value.clamp(0.0, 1.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: C.primaryHi,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            AnimatedBuilder(
              animation: _loadProgress,
              builder: (_, __) => Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(11, (i) {
                  final active =
                      (_loadProgress.value * 10).round() >= i;
                  return Container(
                    width: 4,
                    height: active ? 12 : 6,
                    decoration: BoxDecoration(
                      color: active ? C.primaryHi : Colors.black26,
                      border:
                          Border.all(color: Colors.black, width: 1.5),
                      borderRadius: BorderRadius.circular(1),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      );
    }

    if (isHud) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.3), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Positioned(top: 0, left: 0, child: _cornerHud(C)),
            Positioned(top: 0, right: 0, child: _cornerHud(C)),
            Positioned(bottom: 0, left: 0, child: _cornerHud(C)),
            Positioned(bottom: 0, right: 0, child: _cornerHud(C)),
            Padding(
              padding: const EdgeInsets.all(4),
              child: Column(
                children: [
                  Row(
                    children: [
                      _Led(
                          color: C.primaryHi, size: 7, blink: true),
                      const SizedBox(width: 8),
                      Expanded(
                        child: AnimatedBuilder(
                          animation: _loadProgress,
                          builder: (_, __) {
                            final pct =
                                (_loadProgress.value * 100).toInt();
                            final text = pct < 30
                                ? 'INITIALIZING CORE...'
                                : pct < 60
                                    ? 'LOADING MODULES...'
                                    : pct < 90
                                        ? 'SYNCING DATA...'
                                        : pct < 100
                                            ? 'FINALIZING...'
                                            : 'READY TO LAUNCH';
                            return Text(text,
                                style: TextStyle(
                                  color: C.hudNeon(),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1.5,
                                  shadows: [
                                    Shadow(
                                        color: C.accent
                                            .withOpacity(0.5),
                                        blurRadius: 6),
                                  ],
                                ));
                          },
                        ),
                      ),
                      AnimatedBuilder(
                        animation: _loadProgress,
                        builder: (_, __) {
                          final pct =
                              (_loadProgress.value * 100).toInt();
                          return Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: C.accent.withOpacity(0.15),
                              border: Border.all(
                                  color: C.accent, width: 1),
                            ),
                            child: Text('$pct%',
                                style: TextStyle(
                                  color: C.hudNeon(),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1,
                                  shadows: [
                                    Shadow(
                                        color: C.accent
                                            .withOpacity(0.6),
                                        blurRadius: 4),
                                  ],
                                )),
                          );
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  AnimatedBuilder(
                    animation: _loadProgress,
                    builder: (_, __) => Container(
                      height: 10,
                      decoration: BoxDecoration(
                        color: C.bgDeep.withOpacity(0.7),
                        border: Border.all(
                            color: C.accent.withOpacity(0.4), width: 1),
                      ),
                      padding: const EdgeInsets.all(1.5),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor:
                            _loadProgress.value.clamp(0.0, 1.0),
                        child: Container(
                          color: C.accent,
                          boxShadow: [
                            BoxShadow(
                                color: C.accent.withOpacity(0.8),
                                blurRadius: 8),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Row(
            children: [
              _Screw(C: C, size: 11),
              const SizedBox(width: 8),
              _Led(color: C.accent, size: 7, blink: true),
              const SizedBox(width: 8),
              Expanded(
                child: AnimatedBuilder(
                  animation: _loadProgress,
                  builder: (_, __) {
                    final pct = (_loadProgress.value * 100).toInt();
                    final text = pct < 30
                        ? 'INITIALIZING CORE...'
                        : pct < 60
                            ? 'LOADING MODULES...'
                            : pct < 90
                                ? 'SYNCING DATA...'
                                : pct < 100
                                    ? 'FINALIZING...'
                                    : 'READY TO LAUNCH';
                    return Text(text,
                        style: TextStyle(
                          color: C.accent,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ));
                  },
                ),
              ),
              AnimatedBuilder(
                animation: _loadProgress,
                builder: (_, __) {
                  final pct = (_loadProgress.value * 100).toInt();
                  return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: Colors.black.withOpacity(0.7),
                      border: Border.all(
                          color: C.accent.withOpacity(0.7), width: 1),
                      boxShadow: [
                        BoxShadow(
                            color: C.accent.withOpacity(0.3),
                            blurRadius: 6),
                      ],
                    ),
                    child: Text('$pct%',
                        style: TextStyle(
                          color: C.accentShine,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                          shadows: [
                            Shadow(color: C.accent, blurRadius: 4),
                          ],
                        )),
                  );
                },
              ),
              const SizedBox(width: 8),
              _Screw(C: C, size: 11, rotation: 0),
            ],
          ),
          const SizedBox(height: 12),
          AnimatedBuilder(
            animation: _loadProgress,
            builder: (_, __) => Container(
              height: 12,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: Colors.black,
                border: Border.all(color: C.bgDark, width: 1.2),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.9),
                      offset: const Offset(0, 2),
                      blurRadius: 4),
                  const BoxShadow(
                      color: Colors.white10,
                      offset: Offset(0, -1),
                      blurRadius: 1),
                ],
              ),
              padding: const EdgeInsets.all(2),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: _loadProgress.value.clamp(0.0, 1.0),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    gradient: LinearGradient(
                      colors: [
                        C.primary,
                        C.accent,
                        C.accentHi,
                        C.accentShine
                      ],
                      stops: const [0.0, 0.4, 0.7, 1.0],
                    ),
                    boxShadow: [
                      BoxShadow(
                          color: C.accent.withOpacity(0.8),
                          blurRadius: 8,
                          spreadRadius: 1),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          AnimatedBuilder(
            animation: _loadProgress,
            builder: (_, __) => Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(11, (i) {
                final active = (_loadProgress.value * 10).round() >= i;
                return Container(
                  width: 2,
                  height: active ? 8 : 5,
                  decoration: BoxDecoration(
                    color: active ? C.accent : C.bgDark,
                    borderRadius: BorderRadius.circular(1),
                    boxShadow: active
                        ? [
                            BoxShadow(
                                color: C.accent.withOpacity(0.7),
                                blurRadius: 3)
                          ]
                        : null,
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BOTTOM INFO
  // ═══════════════════════════════════════════════════════════
  Widget _buildBottomInfo(AppPalette C, bool isComic, bool isHud) {
    if (isComic) {
      return Column(
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: C.accent,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.black, width: 3),
              boxShadow: const [
                BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 2),
                  ),
                ),
                const SizedBox(width: 8),
                const Text(
                  'SECURE · FAST · REBEL',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Bangers',
                    letterSpacing: 2,
                    shadows: [
                      Shadow(
                          color: Colors.black,
                          offset: Offset(1, 1),
                          blurRadius: 0),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 2),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'vantaniv zasta · NTED PROJECT',
            style: TextStyle(
              color: Colors.black.withOpacity(0.5),
              fontSize: 9,
              fontWeight: FontWeight.w700,
              fontFamily: 'ComicNeue',
              letterSpacing: 1.5,
            ),
          ),
        ],
      );
    }

    if (isHud) {
      return Column(
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: C.accent.withOpacity(0.15),
              border: Border.all(color: C.accent, width: 1.2),
              boxShadow: [
                BoxShadow(
                    color: C.accent.withOpacity(0.4), blurRadius: 8),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _Led(color: C.primaryHi, size: 5, blink: true),
                const SizedBox(width: 8),
                Text(
                  'SECURE · FAST · REBEL',
                  style: TextStyle(
                    color: C.hudNeon(),
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 3,
                    shadows: [
                      Shadow(
                          color: C.accent.withOpacity(0.5),
                          blurRadius: 6),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                _Led(color: C.accent, size: 5, blink: true),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'vantaniv zasta · NTED PROJECT',
            style: TextStyle(
              color: C.hudTextDim(),
              fontSize: 8,
              fontFamily: 'ShareTechMono',
              letterSpacing: 2,
            ),
          ),
        ],
      );
    }

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _Led(color: C.primaryHi, size: 5, blink: true),
            const SizedBox(width: 8),
            Text(
              'SECURE · FAST · REBEL',
              style: TextStyle(
                color: C.accent,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 3,
              ),
            ),
            const SizedBox(width: 8),
            _Led(color: C.accent, size: 5, blink: true),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'vantaniv zasta · NTED PROJECT',
          style: TextStyle(
            color: C.text.withOpacity(0.4),
            fontSize: 8,
            fontFamily: 'ShareTechMono',
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DASHED RING PAINTER
// ═══════════════════════════════════════════════════════════
class _DashedRingPainter extends CustomPainter {
  final Color color;
  final int dashCount;
  _DashedRingPainter({required this.color, this.dashCount = 36});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round
      ..color = color;

    const dashAngle = (2 * math.pi) / 36;
    const dashPortion = 0.4;

    for (int i = 0; i < dashCount; i++) {
      final startAngle = i * dashAngle;
      final sweepAngle = dashAngle * dashPortion;
      final path = Path()
        ..addArc(
          Rect.fromCircle(center: center, radius: radius),
          startAngle,
          sweepAngle,
        );
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_DashedRingPainter old) => false;
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// LEATHER WALL PAINTER
// ═══════════════════════════════════════════════════════════
class _LeatherWallPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rand = math.Random(42);

    final dotPaint = Paint()..color = Colors.black.withOpacity(0.05);
    for (int i = 0; i < 300; i++) {
      canvas.drawCircle(
        Offset(rand.nextDouble() * size.width,
            rand.nextDouble() * size.height),
        rand.nextDouble() * 1.4,
        dotPaint,
      );
    }

    final linePaint = Paint()
      ..color = Colors.black.withOpacity(0.04)
      ..strokeWidth = 0.5;
    for (int i = 0; i < 100; i++) {
      final x = rand.nextDouble() * size.width;
      final y = rand.nextDouble() * size.height;
      final len = rand.nextDouble() * 15 + 3;
      final angle = rand.nextDouble() * math.pi;
      canvas.drawLine(
        Offset(x, y),
        Offset(x + math.cos(angle) * len, y + math.sin(angle) * len),
        linePaint,
      );
    }
  }

  @override
  bool shouldRepaint(_LeatherWallPainter old) => false;
}