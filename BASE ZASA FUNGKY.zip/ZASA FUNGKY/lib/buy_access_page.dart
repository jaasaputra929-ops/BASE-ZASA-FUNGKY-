// lib/buy_access_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';
import 'smart_widgets.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════
// BUY ACCESS PAGE v2 — STEP BY STEP FLOW
// ═══════════════════════════════════════════════════════════
class BuyAccessPage extends StatefulWidget {
  const BuyAccessPage({super.key});

  @override
  State<BuyAccessPage> createState() => _BuyAccessPageState();
}

class _BuyAccessPageState extends State<BuyAccessPage> {
  List<Map<String, dynamic>> _roles = [];
  Map<String, dynamic>? _paymentInfo;
  bool _isLoading = true;
  String? _errorMsg;

  int _currentStep = 0;

  Map<String, dynamic>? _selectedRole;
  String? _paymentMethod;
  File? _proofImage;

  final _namaCtrl = TextEditingController();
  final _waCtrl = TextEditingController();
  final _telegramCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _durasiCtrl = TextEditingController();

  int _durasiHari = 30;

  static const String _adminWa = '628212347259';
  static const String _adminTelegram = 'zasaco';
  static const String _adminName = 'Developer Crylix Death';

  @override
  void initState() {
    super.initState();
    _fetchRoles();
  }

  @override
  void dispose() {
    _namaCtrl.dispose();
    _waCtrl.dispose();
    _telegramCtrl.dispose();
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _durasiCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchRoles() async {
    setState(() {
      _isLoading = true;
      _errorMsg = null;
    });

    try {
      final res = await http
          .get(Uri.parse('$baseUrl/buy-access/roles'))
          .timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _roles = List<Map<String, dynamic>>.from(data['roles'] ?? []);
            _paymentInfo = Map<String, dynamic>.from(data['payment'] ?? {});
            _isLoading = false;
          });
          return;
        }
      }
      setState(() {
        _isLoading = false;
        _errorMsg = 'Gagal memuat daftar role';
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMsg = 'Koneksi error: $e';
      });
    }
  }

  bool _validateStep(int step) {
    switch (step) {
      case 0:
        if (_selectedRole == null) {
          _showSnack('Pilih role dulu bro', isError: true);
          return false;
        }
        return true;
      case 1:
        if (_namaCtrl.text.trim().length < 3) {
          _showSnack('Nama minimal 3 karakter', isError: true);
          return false;
        }
        if (_waCtrl.text.trim().length < 8) {
          _showSnack('Nomor WhatsApp tidak valid', isError: true);
          return false;
        }
        if (_telegramCtrl.text.trim().length < 3) {
          _showSnack('Username Telegram minimal 3 karakter', isError: true);
          return false;
        }
        return true;
      case 2:
        if (_usernameCtrl.text.trim().length < 3) {
          _showSnack('Username akun minimal 3 karakter', isError: true);
          return false;
        }
        if (_passwordCtrl.text.trim().length < 3) {
          _showSnack('Password minimal 3 karakter', isError: true);
          return false;
        }
        final durasi = int.tryParse(_durasiCtrl.text.trim());
        if (durasi == null || durasi < 1) {
          _showSnack('Durasi minimal 1 hari', isError: true);
          return false;
        }
        if (durasi > 365) {
          _showSnack('Durasi maksimal 365 hari', isError: true);
          return false;
        }
        _durasiHari = durasi;
        return true;
      case 3:
        if (_paymentMethod == null) {
          _showSnack('Pilih metode pembayaran dulu', isError: true);
          return false;
        }
        return true;
      case 4:
        if (_proofImage == null) {
          _showSnack('Upload bukti transfer dulu!', isError: true);
          return false;
        }
        return true;
    }
    return false;
  }

  void _nextStep() {
    if (!_validateStep(_currentStep)) return;
    if (_currentStep < 4) {
      HapticFeedback.lightImpact();
      setState(() => _currentStep++);
    }
  }

  void _prevStep() {
    if (_currentStep > 0) {
      HapticFeedback.lightImpact();
      setState(() => _currentStep--);
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
        source: source,
        imageQuality: 70,
        maxWidth: 1080,
      );
      if (picked != null) {
        setState(() => _proofImage = File(picked.path));
      }
    } catch (e) {
      _showSnack('Gagal pilih gambar: $e', isError: true);
    }
  }

  void _showImageOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => StyleBuilder(
        builder: (context, C, kit) {
          final isComic = kit.style == ThemeStyle.comic3d;
          final isHud = kit.style == ThemeStyle.hudTactical;
          return Container(
            decoration: isHud
                ? BoxDecoration(
                    color: C.hudBg(),
                    border:
                        Border.all(color: C.hudBorder(), width: 1.2),
                  )
                : BoxDecoration(
                    color: C.bgDark,
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(24)),
                    border: isComic
                        ? Border.all(color: Colors.black, width: 4)
                        : null,
                  ),
            padding: const EdgeInsets.all(20),
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 50,
                    height: isComic ? 5 : 4,
                    decoration: BoxDecoration(
                      color: isComic ? Colors.black : C.textSub,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'PILIH SUMBER GAMBAR',
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudNeon() : C.accent),
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontSize: isComic ? 18 : 14,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: SmartButton(
                          color: C.accentHi,
                          height: 52,
                          onTap: () {
                            Navigator.pop(ctx);
                            _pickImage(ImageSource.camera);
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.camera_alt_rounded,
                                  color: C.comicText, size: 16),
                              const SizedBox(width: 6),
                              Text(
                                'KAMERA',
                                style: TextStyle(
                                  color: C.comicText,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: SmartButton(
                          color: C.accentHi,
                          height: 52,
                          onTap: () {
                            Navigator.pop(ctx);
                            _pickImage(ImageSource.gallery);
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.photo_library_rounded,
                                  color: C.comicText, size: 16),
                              const SizedBox(width: 6),
                              Text(
                                'GALERI',
                                style: TextStyle(
                                  color: C.comicText,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _submit() async {
    if (!_validateStep(4)) return;

    setState(() => _isSubmitting = true);

    try {
      final uri = Uri.parse('$baseUrl/buy-access/submit');
      final request = http.MultipartRequest('POST', uri);
      request.fields['nama'] = _namaCtrl.text.trim();
      request.fields['whatsapp'] = _waCtrl.text.trim();
      request.fields['telegram'] = _telegramCtrl.text.trim();
      request.fields['username'] = _usernameCtrl.text.trim();
      request.fields['password'] = _passwordCtrl.text.trim();
      request.fields['role'] = _selectedRole!['id'];
      request.fields['price'] = _selectedRole!['price'].toString();
      request.fields['duration'] = _durasiHari.toString();
      request.fields['paymentMethod'] = _paymentMethod!;

      request.files.add(await http.MultipartFile.fromPath(
        'proof',
        _proofImage!.path,
      ));

      final response = await request.send();
      final responseData = await response.stream.bytesToString();
      final json = jsonDecode(responseData);

      if (!mounted) return;

      if (json['valid'] == true) {
        _showSuccessDialog(json['requestId'] ?? '');
      } else {
        _showSnack(json['message'] ?? 'Gagal submit', isError: true);
      }
    } catch (e) {
      _showSnack('Error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  void _showSuccessDialog(String requestId) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => StyleBuilder(
        builder: (context, C, kit) {
          final isComic = kit.style == ThemeStyle.comic3d;
          final isHud = kit.style == ThemeStyle.hudTactical;
          return Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: const EdgeInsets.all(24),
            child: SmartPlate(
              padding: const EdgeInsets.all(24),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 64,
                      height: 64,
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.primaryHi.withOpacity(0.15),
                              border: Border.all(
                                  color: C.primaryHi, width: 1.4),
                              boxShadow: [
                                BoxShadow(
                                  color: C.primaryHi.withOpacity(0.4),
                                  blurRadius: 14,
                                ),
                              ],
                            )
                          : BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  isComic ? C.primaryHi : C.primaryLo,
                              border: Border.all(
                                color: isComic
                                    ? Colors.black
                                    : C.primaryHi,
                                width: isComic ? 4 : 2.5,
                              ),
                            ),
                      child: Icon(
                        Icons.check_rounded,
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : C.primaryHi,
                        size: 32,
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'TERKIRIM!',
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        fontSize: isComic ? 22 : 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : null,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Permintaan lu udah masuk ke admin.\n'
                      'Admin bakal konfirmasi, lalu data akun\n'
                      'dikirim ke WhatsApp & Telegram lu.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: isComic
                            ? C.comicText.withOpacity(0.85)
                            : (isHud
                                ? C.hudText()
                                : C.text.withOpacity(0.75)),
                        fontSize: isComic ? 13 : 11,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.bgDeep.withOpacity(0.7),
                              border: Border.all(
                                  color: C.accent.withOpacity(0.4),
                                  width: 1),
                            )
                          : BoxDecoration(
                              color: isComic ? C.bg : C.bgDeep,
                              borderRadius:
                                  BorderRadius.circular(isComic ? 10 : 8),
                              border: Border.all(
                                color: isComic ? Colors.black : C.bgDark,
                                width: isComic ? 3 : 1.5,
                              ),
                            ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.receipt_long_rounded,
                            color: isComic
                                ? C.comicText
                                : (isHud ? C.hudNeon() : C.accent),
                            size: 16,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'Request ID: $requestId',
                              style: TextStyle(
                                color: isComic
                                    ? C.comicText
                                    : (isHud ? C.hudText() : C.text),
                                fontSize: isComic ? 13 : 11,
                                fontFamily: isComic
                                    ? 'ComicNeue'
                                    : 'ShareTechMono',
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.accent.withOpacity(0.1),
                              border: Border.all(
                                  color: C.accent, width: 1),
                            )
                          : BoxDecoration(
                              color: isComic
                                  ? C.accent.withOpacity(0.2)
                                  : C.accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: isComic ? Colors.black : C.accent,
                                width: isComic ? 2 : 1,
                              ),
                            ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.info_outline_rounded,
                            color: isComic ? C.comicText : C.accent,
                            size: 14,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Konfirmasi max 1x24 jam. Cek WA/Telegram berkala.',
                              style: TextStyle(
                                color: isComic
                                    ? C.comicText
                                    : (isHud
                                        ? C.hudText()
                                        : C.accent),
                                fontSize: isComic ? 11 : 9,
                                fontFamily: isComic
                                    ? 'ComicNeue'
                                    : 'ShareTechMono',
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    SmartButton(
                      color: C.primaryHi,
                      height: 48,
                      onTap: () {
                        Navigator.pop(ctx);
                        Navigator.pop(context);
                      },
                      child: Text(
                        'OKE, SAYA TUNGGU',
                        style: TextStyle(
                          color: C.comicText,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: isComic ? 15 : 12,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        backgroundColor:
            isError ? Colors.red[700] : Colors.green[700],
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _copy(String text, String label) {
    HapticFeedback.lightImpact();
    Clipboard.setData(ClipboardData(text: text));
    _showSnack('$label disalin: $text');
  }

  Future<void> _openWa() async {
    final url = 'https://wa.me/$_adminWa';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      _showSnack('Gagal buka WhatsApp', isError: true);
    }
  }

  Future<void> _openTelegram() async {
    final url = 'https://t.me/$_adminTelegram';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      _showSnack('Gagal buka Telegram', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StyleBuilder(
      builder: (context, C, kit) {
        final isComic = kit.style == ThemeStyle.comic3d;
        final isHud = kit.style == ThemeStyle.hudTactical;

        return Scaffold(
          backgroundColor: isComic
              ? C.bg
              : (isHud ? C.hudBg() : C.bgDeep),
          appBar: AppBar(
            backgroundColor: isHud ? C.hudPanel() : C.bgDark,
            elevation: 0,
            iconTheme: IconThemeData(color: C.accent),
            title: Text(
              'BUY ACCESS',
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudNeon() : C.accentHi),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontSize: isComic ? 22 : 16,
                fontWeight: FontWeight.w900,
                letterSpacing: isComic ? 2 : 3,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        Shadow(color: C.accent, blurRadius: 8),
                      ],
              ),
            ),
          ),
          body: _isLoading
              ? Center(
                  child: CircularProgressIndicator(
                    color: C.accent,
                    strokeWidth: 2,
                  ),
                )
              : _errorMsg != null
                  ? _buildError(C, isComic)
                  : SmartBackground(
                      child: Column(
                        children: [
                          _buildStepIndicator(C, isComic),
                          Expanded(
                            child: SingleChildScrollView(
                              physics: const BouncingScrollPhysics(),
                              padding: const EdgeInsets.all(14),
                              child: _buildCurrentStep(C, isComic),
                            ),
                          ),
                          _buildBottomNav(C, isComic),
                        ],
                      ),
                    ),
        );
      },
    );
  }

  Widget _buildStepIndicator(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final steps = ['ROLE', 'DATA', 'AKUN', 'BAYAR', 'BUKTI'];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
      color: isHud ? C.hudPanel() : C.bgDark,
      child: Row(
        children: List.generate(steps.length, (i) {
          final isDone = i < _currentStep;
          final isActive = i == _currentStep;
          return Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: isHud
                            ? BoxDecoration(
                                color: isDone
                                    ? C.primaryHi.withOpacity(0.25)
                                    : isActive
                                        ? C.accent.withOpacity(0.25)
                                        : C.bgDeep.withOpacity(0.6),
                                border: Border.all(
                                  color: isDone
                                      ? C.primaryHi
                                      : isActive
                                          ? C.accent
                                          : C.accent.withOpacity(0.3),
                                  width: 1.2,
                                ),
                                boxShadow: isActive
                                    ? [
                                        BoxShadow(
                                          color:
                                              C.accent.withOpacity(0.5),
                                          blurRadius: 8,
                                        ),
                                      ]
                                    : null,
                              )
                            : BoxDecoration(
                                shape: BoxShape.circle,
                                color: isDone
                                    ? C.primaryHi
                                    : isActive
                                        ? (isComic ? C.accentHi : C.accent)
                                        : C.bgDeep,
                                border: Border.all(
                                  color: isComic ? Colors.black : C.accent,
                                  width: isComic ? 3 : 2,
                                ),
                              ),
                        child: Center(
                          child: isDone
                              ? Icon(
                                  Icons.check_rounded,
                                  color: isComic
                                      ? C.comicText
                                      : (isHud
                                          ? C.hudNeon()
                                          : C.comicText),
                                  size: 16,
                                )
                              : Text(
                                  '${i + 1}',
                                  style: TextStyle(
                                    color: isActive
                                        ? (isComic
                                            ? C.comicText
                                            : (isHud
                                                ? C.hudNeon()
                                                : C.comicText))
                                        : (isHud
                                            ? C.hudTextDim()
                                            : C.textSub),
                                    fontFamily: isComic
                                        ? 'Bangers'
                                        : 'Orbitron',
                                    fontSize: 13,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        steps[i],
                        style: TextStyle(
                          color: isActive
                              ? (isComic
                                  ? C.comicText
                                  : (isHud ? C.hudNeon() : C.accent))
                              : (isDone
                                  ? (isComic
                                      ? C.comicText
                                      : (isHud
                                          ? C.hudText()
                                          : C.accentHi))
                                  : (isHud ? C.hudTextDim() : C.textSub)),
                          fontSize: isComic ? 10 : 8,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                if (i < steps.length - 1)
                  Expanded(
                    child: Container(
                      height: isComic ? 3 : (isHud ? 1 : 2),
                      color: isDone
                          ? (isComic
                              ? C.comicText
                              : (isHud ? C.primaryHi : C.accent))
                          : C.bgDeep,
                      margin: const EdgeInsets.only(bottom: 18),
                    ),
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildBottomNav(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isHud ? C.hudPanel() : C.bgDark,
        border: Border(
          top: BorderSide(
            color: isComic
                ? Colors.black
                : (isHud ? C.hudBorder() : C.bg),
            width: isComic ? 4 : (isHud ? 1.2 : 1),
          ),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            if (_currentStep > 0)
              Expanded(
                child: SmartButton(
                  color: isHud ? C.accent.withOpacity(0.15) : C.bg,
                  height: 50,
                  onTap: _prevStep,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.arrow_back_rounded,
                          color: isComic
                              ? C.comicText
                              : (isHud ? C.hudText() : C.accent),
                          size: 16),
                      const SizedBox(width: 6),
                      Text(
                        'KEMBALI',
                        style: TextStyle(
                          color: isComic
                              ? C.comicText
                              : (isHud ? C.hudText() : C.accent),
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontSize: isComic ? 14 : 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            if (_currentStep > 0) const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: SmartButton(
                color: _isSubmitting ? C.bg : C.primaryHi,
                height: 50,
                onTap: _isSubmitting
                    ? null
                    : (_currentStep < 4 ? _nextStep : _submit),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (_isSubmitting)
                      SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          valueColor: AlwaysStoppedAnimation(
                            isComic
                                ? C.comicText
                                : (isHud ? C.hudText() : C.text),
                          ),
                        ),
                      )
                    else
                      Icon(
                        _currentStep < 4
                            ? Icons.arrow_forward_rounded
                            : Icons.send_rounded,
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudText() : C.text),
                        size: 18,
                      ),
                    const SizedBox(width: 8),
                    Text(
                      _isSubmitting
                          ? 'MENGIRIM...'
                          : (_currentStep < 4
                              ? 'LANJUT'
                              : 'KIRIM PEMBELIAN'),
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudText() : C.text),
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontSize: isComic ? 15 : 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentStep(AppPalette C, bool isComic) {
    switch (_currentStep) {
      case 0:
        return _buildStepRole(C, isComic);
      case 1:
        return _buildStepDataPembeli(C, isComic);
      case 2:
        return _buildStepDataAkun(C, isComic);
      case 3:
        return _buildStepBayar(C, isComic);
      case 4:
        return _buildStepBukti(C, isComic);
      default:
        return const SizedBox();
    }
  }

  Widget _buildStepRole(AppPalette C, bool isComic) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(C, isComic, '// STEP 1 — PILIH ROLE'),
        const SizedBox(height: 12),
        ..._roles.map((role) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _buildRoleCard(C, isComic, role),
            )),
      ],
    );
  }

  Widget _buildStepDataPembeli(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(C, isComic, '// STEP 2 — DATA PEMBELI'),
        const SizedBox(height: 8),
        Text(
          'Data ini dipake admin buat ngirim akun ke lu.',
          style: TextStyle(
            color: isComic
                ? C.comicTextSub
                : (isHud ? C.hudTextDim() : C.textSub),
            fontSize: isComic ? 12 : 10,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontStyle: FontStyle.italic,
          ),
        ),
        const SizedBox(height: 12),
        SmartPlate(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              _buildField(
                C: C,
                isComic: isComic,
                controller: _namaCtrl,
                label: 'NAMA / PANGGILAN',
                icon: Icons.person_outline_rounded,
                hint: 'Contoh: Budi Santoso',
              ),
              const SizedBox(height: 12),
              _buildField(
                C: C,
                isComic: isComic,
                controller: _waCtrl,
                label: 'NOMOR WHATSAPP',
                icon: Icons.phone_android_rounded,
                keyboardType: TextInputType.phone,
                hint: 'Contoh: 08123456789',
              ),
              const SizedBox(height: 12),
              _buildField(
                C: C,
                isComic: isComic,
                controller: _telegramCtrl,
                label: 'USERNAME TELEGRAM',
                icon: Icons.send_rounded,
                hint: 'Contoh: @username (tanpa @ boleh)',
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStepDataAkun(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(C, isComic, '// STEP 3 — DATA AKUN'),
        const SizedBox(height: 8),
        Text(
          'Tentukan username, password & durasi akun yang mau dibuat.',
          style: TextStyle(
            color: isComic
                ? C.comicTextSub
                : (isHud ? C.hudTextDim() : C.textSub),
            fontSize: isComic ? 12 : 10,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontStyle: FontStyle.italic,
          ),
        ),
        const SizedBox(height: 12),
        SmartPlate(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              _buildField(
                C: C,
                isComic: isComic,
                controller: _usernameCtrl,
                label: 'USERNAME AKUN',
                icon: Icons.alternate_email_rounded,
                hint: 'Min 3 karakter (huruf/angka/_)',
              ),
              const SizedBox(height: 12),
              _buildField(
                C: C,
                isComic: isComic,
                controller: _passwordCtrl,
                label: 'PASSWORD AKUN',
                icon: Icons.lock_outline_rounded,
                obscureText: true,
                hint: 'Min 3 karakter',
              ),
              const SizedBox(height: 12),
              _buildField(
                C: C,
                isComic: isComic,
                controller: _durasiCtrl,
                label: 'DURASI (HARI)',
                icon: Icons.calendar_today_rounded,
                keyboardType: TextInputType.number,
                hint: 'Contoh: 30',
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 6,
                children: [7, 30, 90, 180, 365].map((d) {
                  return GestureDetector(
                    onTap: () {
                      HapticFeedback.selectionClick();
                      setState(() => _durasiCtrl.text = d.toString());
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.accent.withOpacity(0.1),
                              border: Border.all(
                                  color: C.accent.withOpacity(0.5),
                                  width: 1),
                            )
                          : BoxDecoration(
                              color: isComic ? C.bg : C.bgDeep,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color:
                                    isComic ? Colors.black : C.bgDark,
                                width: isComic ? 2 : 1,
                              ),
                            ),
                      child: Text(
                        '$d hari',
                        style: TextStyle(
                          color: isComic
                              ? C.comicText
                              : (isHud ? C.hudText() : C.accent),
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontSize: isComic ? 12 : 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStepBayar(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final total = _selectedRole?['price'] as int? ?? 0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(C, isComic, '// STEP 4 — METODE BAYAR'),
        const SizedBox(height: 12),

        Container(
          padding: const EdgeInsets.all(14),
          decoration: isHud
              ? BoxDecoration(
                  color: C.primaryLo.withOpacity(0.15),
                  border: Border.all(color: C.primaryHi, width: 1.4),
                  boxShadow: [
                    BoxShadow(
                      color: C.primaryHi.withOpacity(0.3),
                      blurRadius: 12,
                    ),
                  ],
                )
              : BoxDecoration(
                  color: isComic ? C.primaryHi : C.primaryLo,
                  borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                  border: Border.all(
                    color: isComic ? Colors.black : C.primaryHi,
                    width: isComic ? 4 : 2,
                  ),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(4, 4),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'TOTAL BAYAR',
                style: TextStyle(
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : Colors.white),
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 14 : 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              Text(
                'Rp ${_formatPrice(total)}',
                style: TextStyle(
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : Colors.white),
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 20 : 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        _buildSectionTitle(C, isComic, '// PILIH SALAH SATU'),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _buildPaymentMethodCard(
                C: C,
                isComic: isComic,
                id: 'qris',
                label: 'QRIS',
                icon: Icons.qr_code_2_rounded,
                color: C.accentHi,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildPaymentMethodCard(
                C: C,
                isComic: isComic,
                id: 'dana',
                label: 'DANA',
                icon: Icons.account_balance_wallet_rounded,
                color: const Color(0xFF118EEA),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        if (_paymentMethod == 'qris') _buildQrisDetail(C, isComic),
        if (_paymentMethod == 'dana') _buildDanaDetail(C, isComic),
      ],
    );
  }

  Widget _buildPaymentMethodCard({
    required AppPalette C,
    required bool isComic,
    required String id,
    required String label,
    required IconData icon,
    required Color color,
  }) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final isSelected = _paymentMethod == id;

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _paymentMethod = id);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
        decoration: isHud
            ? BoxDecoration(
                color: isSelected
                    ? color.withOpacity(0.15)
                    : C.bgDeep.withOpacity(0.6),
                border: Border.all(
                  color: isSelected
                      ? color
                      : color.withOpacity(0.3),
                  width: isSelected ? 1.4 : 1,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: color.withOpacity(0.5),
                          blurRadius: 12,
                        ),
                      ]
                    : null,
              )
            : BoxDecoration(
                color: isComic
                    ? (isSelected ? color : C.bgDark)
                    : (isSelected ? color.withOpacity(0.15) : C.bgDark),
                borderRadius: BorderRadius.circular(isComic ? 14 : 12),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (isSelected ? color : C.textSub.withOpacity(0.3)),
                  width:
                      isComic ? (isSelected ? 4 : 3) : (isSelected ? 2 : 1),
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        if (isSelected)
                          BoxShadow(
                              color: color.withOpacity(0.4),
                              blurRadius: 10),
                      ],
              ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isComic
                  ? (isSelected ? Colors.white : C.comicText)
                  : (isHud
                      ? (isSelected ? C.hudNeon() : color)
                      : color),
              size: 34,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: isComic
                    ? (isSelected ? Colors.white : C.comicText)
                    : (isHud
                        ? (isSelected ? C.hudNeon() : C.hudText())
                        : (isSelected ? color : C.text)),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontSize: isComic ? 16 : 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            if (isSelected) ...[
              const SizedBox(height: 6),
              Icon(
                Icons.check_circle_rounded,
                color: isComic
                    ? Colors.white
                    : (isHud ? C.hudNeon() : color),
                size: 16,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildQrisDetail(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return SmartPlate(
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Text(
            'SCAN QRIS',
            style: TextStyle(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.hudNeon() : C.accent),
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              fontSize: isComic ? 14 : 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(isHud ? 2 : 12),
              border: Border.all(
                color: isComic
                    ? Colors.black
                    : (isHud ? C.accent : C.accent),
                width: isComic ? 4 : (isHud ? 1.4 : 2),
              ),
              boxShadow: isHud
                  ? [
                      BoxShadow(
                        color: C.accent.withOpacity(0.4),
                        blurRadius: 12,
                      ),
                    ]
                  : null,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/images/qris.jpg',
                width: 240,
                height: 240,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => Container(
                  width: 240,
                  height: 240,
                  color: C.bgDark,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.qr_code_2_rounded,
                        size: 60,
                        color: isComic
                            ? C.comicTextSub
                            : (isHud ? C.hudTextDim() : C.textSub),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'qris.jpg belum ada',
                        style: TextStyle(
                          color: isComic
                              ? C.comicTextSub
                              : (isHud
                                  ? C.hudTextDim()
                                  : C.text.withOpacity(0.5)),
                          fontSize: 10,
                          fontFamily: isComic
                              ? 'ComicNeue'
                              : 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Scan pake aplikasi apapun yang support QRIS.\n'
            'Pastikan nominal transfer SESUAI total di atas.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isComic
                  ? C.comicTextSub
                  : (isHud ? C.hudTextDim() : C.textSub),
              fontSize: isComic ? 11 : 9,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDanaDetail(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final dana = _paymentInfo?['dana'] ?? {};
    final number = dana['number'] ?? '-';
    final name = dana['name'] ?? '-';

    return SmartPlate(
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Text(
            'TRANSFER KE DANA',
            style: TextStyle(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.hudNeon() : C.accent),
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              fontSize: isComic ? 14 : 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: isHud
                ? BoxDecoration(
                    color: C.bgDeep.withOpacity(0.7),
                    border: Border.all(
                        color: C.accent.withOpacity(0.4), width: 1),
                  )
                : BoxDecoration(
                    color: isComic ? C.bg : C.bgDeep,
                    borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                    border: Border.all(
                      color: isComic ? Colors.black : C.bgDark,
                      width: isComic ? 3 : 1.5,
                    ),
                  ),
            child: Column(
              children: [
                Text(
                  'NOMOR DANA',
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : (isHud ? C.hudTextDim() : C.textSub),
                    fontSize: isComic ? 11 : 9,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  number,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudText() : C.text),
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontSize: isComic ? 22 : 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'a/n $name',
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : (isHud ? C.hudTextDim() : C.textSub),
                    fontSize: isComic ? 12 : 10,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 12),
                SmartButton(
                  color: C.accent,
                  height: 40,
                  onTap: () => _copy(number, 'Nomor DANA'),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.copy_rounded,
                        color: C.comicText,
                        size: 14,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'COPY NOMOR',
                        style: TextStyle(
                          color: C.comicText,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: isComic ? 12 : 10,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Transfer sesuai nominal, lalu screenshot bukti.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isComic
                  ? C.comicTextSub
                  : (isHud ? C.hudTextDim() : C.textSub),
              fontSize: isComic ? 11 : 9,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepBukti(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(C, isComic, '// STEP 5 — UPLOAD BUKTI'),
        const SizedBox(height: 12),

        _buildRingkasan(C, isComic),
        const SizedBox(height: 16),

        if (_proofImage != null)
          SmartPlate(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius:
                      BorderRadius.circular(isHud ? 2 : 10),
                  child: Image.file(
                    _proofImage!,
                    width: double.infinity,
                    height: 220,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: SmartButton(
                        color: C.accent,
                        height: 44,
                        onTap: _showImageOptions,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.refresh_rounded,
                                color: C.comicText, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              'GANTI',
                              style: TextStyle(
                                color: C.comicText,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 11,
                                letterSpacing: 2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: SmartButton(
                        color: C.primaryHi,
                        height: 44,
                        onTap: () =>
                            setState(() => _proofImage = null),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.delete_rounded,
                                color: C.comicText, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              'HAPUS',
                              style: TextStyle(
                                color: C.comicText,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 11,
                                letterSpacing: 2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )
        else
          GestureDetector(
            onTap: _showImageOptions,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 40),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.bgDeep.withOpacity(0.6),
                      border: Border.all(
                        color: C.accent.withOpacity(0.5),
                        width: 1.4,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: C.accent.withOpacity(0.2),
                          blurRadius: 12,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      color: isComic ? C.bg : C.bgDeep,
                      borderRadius:
                          BorderRadius.circular(isComic ? 14 : 10),
                      border: Border.all(
                        color: isComic ? Colors.black : C.bgDark,
                        width: isComic ? 4 : 2,
                      ),
                    ),
              child: Column(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: isHud
                        ? BoxDecoration(
                            color: C.primaryHi.withOpacity(0.15),
                            border: Border.all(
                                color: C.primaryHi, width: 1.4),
                            boxShadow: [
                              BoxShadow(
                                color: C.primaryHi.withOpacity(0.4),
                                blurRadius: 12,
                              ),
                            ],
                          )
                        : BoxDecoration(
                            shape: BoxShape.circle,
                            color:
                                isComic ? C.primaryHi : C.primaryLo,
                            border: Border.all(
                              color: isComic ? Colors.black : C.accent,
                              width: isComic ? 4 : 2,
                            ),
                          ),
                    child: Icon(
                      Icons.cloud_upload_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : (isHud ? C.primaryHi : C.accent),
                      size: 28,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'TAP UNTUK UPLOAD BUKTI',
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudNeon() : C.accent),
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontSize: isComic ? 16 : 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Format: JPG / PNG (max 10MB)',
                    style: TextStyle(
                      color: isComic
                          ? C.comicTextSub
                          : (isHud
                              ? C.hudTextDim()
                              : C.text.withOpacity(0.5)),
                      fontSize: isComic ? 12 : 10,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ),

        const SizedBox(height: 16),

        _buildTelegramInfoBox(C, isComic),

        const SizedBox(height: 20),
        _buildContactAdmin(C, isComic),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildRingkasan(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return SmartPlate(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.receipt_long_rounded,
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudNeon() : C.accent),
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(
                'RINGKASAN',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 13 : 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _ringkasanRow(C, isComic, 'Role', _selectedRole?['name'] ?? '-'),
          _ringkasanRow(C, isComic, 'Nama', _namaCtrl.text.trim()),
          _ringkasanRow(C, isComic, 'WhatsApp', _waCtrl.text.trim()),
          _ringkasanRow(C, isComic, 'Telegram', _telegramCtrl.text.trim()),
          _ringkasanRow(C, isComic, 'Username', _usernameCtrl.text.trim()),
          _ringkasanRow(C, isComic, 'Durasi', '$_durasiHari hari'),
          _ringkasanRow(C, isComic, 'Metode',
              _paymentMethod == 'qris' ? 'QRIS' : 'DANA'),
          Divider(
              height: 20,
              color: isHud
                  ? C.accent.withOpacity(0.3)
                  : null),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'TOTAL',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 14 : 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
              Text(
                'Rp ${_formatPrice(_selectedRole?['price'] as int? ?? 0)}',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accentHi),
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 18 : 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _ringkasanRow(
      AppPalette C, bool isComic, String label, String value) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: TextStyle(
                color: isComic
                    ? C.comicTextSub
                    : (isHud ? C.hudTextDim() : C.textSub),
                fontSize: isComic ? 11 : 9,
                fontFamily:
                    isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value.isEmpty ? '-' : value,
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudText() : C.text),
                fontSize: isComic ? 12 : 10,
                fontFamily:
                    isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTelegramInfoBox(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: isHud
          ? BoxDecoration(
              color: const Color(0xFF229ED9).withOpacity(0.1),
              border: Border.all(
                  color: const Color(0xFF229ED9), width: 1.4),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF229ED9).withOpacity(0.3),
                  blurRadius: 12,
                ),
              ],
            )
          : BoxDecoration(
              color: isComic
                  ? const Color(0xFF229ED9).withOpacity(0.15)
                  : const Color(0xFF229ED9).withOpacity(0.08),
              borderRadius: BorderRadius.circular(isComic ? 14 : 12),
              border: Border.all(
                color:
                    isComic ? Colors.black : const Color(0xFF229ED9),
                width: isComic ? 3.5 : 1.8,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(4, 4),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: const Color(0xFF229ED9).withOpacity(0.25),
                        blurRadius: 12,
                      ),
                    ],
            ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: const Color(0xFF229ED9).withOpacity(0.2),
                        border: Border.all(
                            color: const Color(0xFF229ED9), width: 1.4),
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: isComic ? const Color(0xFF229ED9) : null,
                        gradient: isComic
                            ? null
                            : const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Color(0xFF229ED9),
                                  Color(0xFF1A7BAA),
                                ],
                              ),
                        border: Border.all(
                          color: isComic
                              ? Colors.black
                              : const Color(0xFF229ED9),
                          width: isComic ? 3 : 1.5,
                        ),
                      ),
                child: const Icon(
                  Icons.send_rounded,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'AUTO-SEND VIA TELEGRAM',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud
                            ? C.hudNeon()
                            : const Color(0xFF229ED9)),
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontSize: isComic ? 15 : 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
              if (!isComic)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFF229ED9).withOpacity(0.2),
                    borderRadius:
                        BorderRadius.circular(isHud ? 2 : 4),
                    border: Border.all(
                      color: const Color(0xFF229ED9),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    'WAJIB',
                    style: TextStyle(
                      color: const Color(0xFF229ED9),
                      fontFamily: 'Orbitron',
                      fontSize: 8,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),

          Text(
            'Kalau kamu ingin bot auto-send data akun, '
            'kamu harus /start bot @Crylix_Infinity_Bot terlebih dahulu.',
            style: TextStyle(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.hudText() : C.text),
              fontSize: isComic ? 13 : 11,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w700,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Kamu bisa cari username bot @Crylix_Infinity_Bot di Telegram, '
            'lalu tekan /start. Nanti setelah di-approve admin, '
            'otomatis data akun dikirim ke Telegram kamu lewat bot ini.',
            style: TextStyle(
              color: isComic
                  ? C.comicText.withOpacity(0.85)
                  : (isHud
                      ? C.hudTextDim()
                      : C.text.withOpacity(0.75)),
              fontSize: isComic ? 12 : 10,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w600,
              height: 1.6,
            ),
          ),
          const SizedBox(height: 12),

          if (_telegramCtrl.text.trim().isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 8),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.bgDeep.withOpacity(0.7),
                      border: Border.all(
                          color:
                              const Color(0xFF229ED9).withOpacity(0.5),
                          width: 1),
                    )
                  : BoxDecoration(
                      color: isComic ? C.bg : C.bgDeep,
                      borderRadius:
                          BorderRadius.circular(isComic ? 8 : 6),
                      border: Border.all(
                        color: isComic
                            ? Colors.black
                            : const Color(0xFF229ED9)
                                .withOpacity(0.5),
                        width: isComic ? 2.5 : 1,
                      ),
                    ),
              child: Row(
                children: [
                  Icon(
                    Icons.alternate_email_rounded,
                    color: isComic
                        ? C.comicText
                        : (isHud
                            ? C.hudNeon()
                            : const Color(0xFF229ED9)),
                    size: 14,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Telegram kamu: ${_telegramCtrl.text.trim()}',
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudText() : C.text),
                        fontSize: isComic ? 12 : 10,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '⚠️ Pastiin username Telegram di atas bener & udah /start bot @Crylix_Infinity_Bot '
              'Kalo belum /start, data akun ga akan terkirim otomatis.',
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud
                        ? C.hudNeon()
                        : const Color(0xFFFF9800)),
                fontSize: isComic ? 11 : 9,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.w700,
                height: 1.4,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildContactAdmin(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(C, isComic, '// BANTUAN & KONTAK ADMIN'),
        const SizedBox(height: 10),
        SmartPlate(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: isHud
                        ? BoxDecoration(
                            color: C.primaryHi.withOpacity(0.15),
                            border: Border.all(
                                color: C.primaryHi, width: 1.4),
                            boxShadow: [
                              BoxShadow(
                                color: C.primaryHi.withOpacity(0.4),
                                blurRadius: 10,
                              ),
                            ],
                          )
                        : BoxDecoration(
                            shape: BoxShape.circle,
                            color:
                                isComic ? C.primaryHi : C.primaryLo,
                            border: Border.all(
                              color:
                                  isComic ? Colors.black : C.accent,
                              width: isComic ? 3 : 1.5,
                            ),
                          ),
                    child: Icon(
                      Icons.support_agent_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : (isHud ? C.primaryHi : C.accent),
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _adminName.toUpperCase(),
                          style: TextStyle(
                            color: isComic
                                ? C.comicText
                                : (isHud ? C.hudNeon() : C.accent),
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            fontSize: isComic ? 14 : 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Ada kendala? Chat admin langsung.',
                          style: TextStyle(
                            color: isComic
                                ? C.comicTextSub
                                : (isHud
                                    ? C.hudTextDim()
                                    : C.text.withOpacity(0.65)),
                            fontFamily: isComic
                                ? 'ComicNeue'
                                : 'ShareTechMono',
                            fontSize: isComic ? 12 : 10,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _buildContactButton(
                C: C,
                isComic: isComic,
                icon: Icons.chat_rounded,
                label: 'WHATSAPP',
                sublabel: '+$_adminWa',
                color: const Color(0xFF25D366),
                onTap: _openWa,
              ),
              const SizedBox(height: 8),
              _buildContactButton(
                C: C,
                isComic: isComic,
                icon: Icons.send_rounded,
                label: 'TELEGRAM',
                sublabel: '@$_adminTelegram',
                color: const Color(0xFF229ED9),
                onTap: _openTelegram,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildContactButton({
    required AppPalette C,
    required bool isComic,
    required IconData icon,
    required String label,
    required String sublabel,
    required Color color,
    required VoidCallback onTap,
  }) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: isHud
            ? BoxDecoration(
                color: color.withOpacity(0.12),
                border: Border.all(color: color, width: 1.4),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.35),
                    blurRadius: 10,
                  ),
                ],
              )
            : BoxDecoration(
                color: isComic ? color : color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                border: Border.all(
                  color: isComic ? Colors.black : color.withOpacity(0.5),
                  width: isComic ? 3 : 1.2,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isComic
                  ? C.contrastTextOn(color)
                  : (isHud ? color : color),
              size: 22,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: isComic
                          ? C.contrastTextOn(color)
                          : (isHud ? C.hudText() : color),
                      fontFamily:
                          isComic ? 'Bangers' : 'Orbitron',
                      fontSize: isComic ? 14 : 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    sublabel,
                    style: TextStyle(
                      color: isComic
                          ? C.contrastTextOn(color).withOpacity(0.85)
                          : (isHud
                              ? C.hudTextDim()
                              : color.withOpacity(0.85)),
                      fontFamily: isComic
                          ? 'ComicNeue'
                          : 'ShareTechMono',
                      fontSize: isComic ? 12 : 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              color: isComic
                  ? C.contrastTextOn(color)
                  : (isHud ? color : color),
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(
      AppPalette C, bool isComic, String text) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Text(
      text,
      style: TextStyle(
        color: isComic
            ? C.comicText
            : (isHud ? C.hudNeon() : C.accent),
        fontSize: isComic ? 15 : 12,
        fontWeight: FontWeight.w900,
        fontFamily: isComic ? 'Bangers' : 'Orbitron',
        letterSpacing: 1.5,
        shadows: isComic
            ? [
                Shadow(
                  color: C.comicTextOutline,
                  offset: const Offset(1, 1),
                  blurRadius: 0,
                ),
              ]
            : null,
      ),
    );
  }

  Widget _buildField({
    required AppPalette C,
    required bool isComic,
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    bool obscureText = false,
    String? hint,
  }) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            label,
            style: TextStyle(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.hudNeon() : C.accent),
              fontSize: isComic ? 11 : 9,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 1.5,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: isHud
              ? BoxDecoration(
                  color: C.bgDeep.withOpacity(0.7),
                  border: Border.all(
                      color: C.accent.withOpacity(0.4), width: 1),
                )
              : BoxDecoration(
                  color: isComic ? C.bg : C.bgDeep,
                  borderRadius: BorderRadius.circular(isComic ? 10 : 8),
                  border: Border.all(
                    color: isComic ? Colors.black : C.bgDark,
                    width: isComic ? 3 : 1.5,
                  ),
                ),
          child: Row(
            children: [
              Icon(
                icon,
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudNeon() : C.accent),
                size: 18,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  keyboardType: keyboardType,
                  obscureText: obscureText,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudText() : C.text),
                    fontSize: isComic ? 14 : 12,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                  cursorColor: isComic ? C.comicText : C.accent,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 16),
                    hintText: hint ?? 'Isi $label...',
                    hintStyle: TextStyle(
                      color: isComic
                          ? C.comicTextMuted
                          : (isHud
                              ? C.hudTextDim()
                              : C.textSub.withOpacity(0.5)),
                      fontSize: isComic ? 12 : 11,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildError(AppPalette C, bool isComic) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: SmartPlate(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline_rounded,
                  color: C.primaryHi, size: 48),
              const SizedBox(height: 14),
              Text(
                _errorMsg!,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudText() : C.text),
                  fontSize: 13,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
              ),
              const SizedBox(height: 20),
              SmartButton(
                color: C.primaryHi,
                height: 44,
                onTap: _fetchRoles,
                child: Text(
                  'COBA LAGI',
                  style: TextStyle(
                    color: C.comicText,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getRoleColor(AppPalette C, String roleId) {
    switch (roleId) {
      case 'member':
        return C.textSub;
      case 'reseller':
        return C.primaryHi;
      case 'vip':
        return C.accentHi;
      case 'admin':
        return C.accent;
      case 'partner':
        return C.primary;
      case 'moderator':
        return C.primaryHi;
      case 'owner':
        return C.accentShine;
      case 'high owner':
        return C.accentHi;
      case 'developer':
        return C.text;
      default:
        return C.accent;
    }
  }

  Widget _buildRoleCard(
      AppPalette C, bool isComic, Map<String, dynamic> role) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final isSelected = _selectedRole?['id'] == role['id'];
    final price = role['price'] as int;
    final roleColor = _getRoleColor(C, role['id'] as String);

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _selectedRole = role);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(14),
        decoration: isHud
            ? BoxDecoration(
                color: isSelected
                    ? roleColor.withOpacity(0.15)
                    : C.bgDeep.withOpacity(0.6),
                border: Border.all(
                  color: isSelected
                      ? roleColor
                      : roleColor.withOpacity(0.3),
                  width: isSelected ? 1.4 : 1,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: roleColor.withOpacity(0.5),
                          blurRadius: 12,
                        ),
                      ]
                    : null,
              )
            : BoxDecoration(
                color: isComic
                    ? (isSelected ? roleColor : C.bgDark)
                    : (isSelected
                        ? roleColor.withOpacity(0.15)
                        : C.bgDark),
                borderRadius: BorderRadius.circular(isComic ? 14 : 12),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (isSelected
                          ? roleColor
                          : C.textSub.withOpacity(0.3)),
                  width: isComic
                      ? (isSelected ? 4 : 3)
                      : (isSelected ? 2 : 1),
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        if (isSelected)
                          BoxShadow(
                            color: roleColor.withOpacity(0.4),
                            blurRadius: 12,
                          ),
                      ],
              ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: isHud
                  ? BoxDecoration(
                      color: roleColor.withOpacity(0.2),
                      border:
                          Border.all(color: roleColor, width: 1.4),
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      color:
                          isComic ? Colors.white : roleColor.withOpacity(0.2),
                      border: Border.all(
                        color: isComic ? Colors.black : roleColor,
                        width: isComic ? 3 : 1.5,
                      ),
                    ),
              child: Center(
                child: Text(
                  role['emoji'] ?? '👤',
                  style: const TextStyle(fontSize: 20),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    role['name'],
                    style: TextStyle(
                      color: isComic
                          ? (isSelected
                              ? C.contrastTextOn(roleColor)
                              : C.comicText)
                          : (isHud
                              ? (isSelected
                                  ? C.hudNeon()
                                  : C.hudText())
                              : C.text),
                      fontSize: isComic ? 16 : 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: isComic ? 1 : 0.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'Rp ${_formatPrice(price)} · ${role['durationDays']} hari',
                    style: TextStyle(
                      color: isComic
                          ? (isSelected
                              ? C.contrastTextOn(roleColor)
                                  .withOpacity(0.85)
                              : C.comicTextSub)
                          : roleColor,
                      fontSize: isComic ? 12 : 10,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Icon(
                Icons.check_circle_rounded,
                color: isComic
                    ? C.contrastTextOn(roleColor)
                    : (isHud ? C.hudNeon() : roleColor),
                size: 24,
              ),
          ],
        ),
      ),
    );
  }

  String _formatPrice(int price) {
    final str = price.toString();
    final buffer = StringBuffer();
    for (int i = 0; i < str.length; i++) {
      if (i > 0 && (str.length - i) % 3 == 0) buffer.write('.');
      buffer.write(str[i]);
    }
    return buffer.toString();
  }

  bool _isSubmitting = false;
}