// lib/profile_page.dart — Profile (3 Style Support)
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'app_theme.dart';
import 'change_password_page.dart';

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  late AnimationController _floatController;
  late Animation<double> _floatAnimation;

  @override
  void initState() {
    super.initState();
    _loadProfileImage();

    _glowController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine),
    );

    _floatController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    _floatAnimation = Tween<double>(begin: -5, end: 5).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOutSine),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    _floatController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  // ═══ SHADOW HELPER ═══
  List<BoxShadow> _shadow(double s) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    if (style == ThemeStyle.comic3d) {
      return [
        BoxShadow(color: Colors.black, offset: Offset(s, s), blurRadius: 0),
      ];
    }
    if (style == ThemeStyle.hudTactical) {
      return [
        BoxShadow(color: C.accent.withOpacity(0.2), blurRadius: 12),
      ];
    }
    return [
      BoxShadow(
          color: Colors.black.withOpacity(0.7),
          offset: const Offset(0, 6),
          blurRadius: 12),
    ];
  }

  // ═══ PANEL DECORATION ═══
  BoxDecoration _panel(AppPalette C, bool isComic, bool isHud,
      {double r = 16}) {
    if (isComic) {
      return BoxDecoration(
        color: C.bgDark,
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: Colors.black, width: 4),
        boxShadow: _shadow(5),
      );
    }
    if (isHud) {
      return BoxDecoration(
        color: C.hudPanel(),
        border: Border.all(color: C.hudBorder(), width: 1.2),
        boxShadow: _shadow(0),
      );
    }
    return BoxDecoration(
      color: C.bgDark,
      borderRadius: BorderRadius.circular(r),
      border: Border.all(color: C.accent.withOpacity(0.3), width: 1.2),
      boxShadow: _shadow(0),
    );
  }

  Future<void> _showImageSourceDialog(
      AppPalette C, bool isComic, bool isHud) {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          margin: isComic ? const EdgeInsets.all(16) : EdgeInsets.zero,
          decoration: isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: _shadow(6),
                )
              : (isHud
                  ? BoxDecoration(
                      color: C.hudPanel(),
                      border:
                          Border.all(color: C.hudBorder(), width: 1.2),
                    )
                  : BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          C.bg.withOpacity(0.95),
                          C.bgDark.withOpacity(0.95),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(20)),
                      border: Border.all(
                          color: C.primaryLo.withOpacity(0.3), width: 1),
                    )),
          padding: const EdgeInsets.all(20),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!isComic && !isHud)
                  Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: C.textSub.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                if (isComic)
                  Container(
                    width: 50,
                    height: 5,
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                if (isHud || isComic)
                  Text(
                    'PILIH SUMBER GAMBAR',
                    style: TextStyle(
                      color: isComic ? Colors.black : C.hudNeon(),
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontSize: isComic ? 18 : 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: isComic ? 2 : 2.5,
                      shadows: isHud
                          ? [
                              Shadow(
                                  color: C.accent.withOpacity(0.5),
                                  blurRadius: 8),
                            ]
                          : null,
                    ),
                  ),
                if (isHud || isComic) const SizedBox(height: 20),
                _buildImageOption(
                  C: C,
                  isComic: isComic,
                  isHud: isHud,
                  icon: Icons.camera_alt_rounded,
                  label: 'KAMERA',
                  color: isHud ? C.accent : C.primaryHi,
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.camera);
                  },
                ),
                const SizedBox(height: 12),
                _buildImageOption(
                  C: C,
                  isComic: isComic,
                  isHud: isHud,
                  icon: Icons.photo_library_rounded,
                  label: 'GALERI',
                  color: isHud ? C.accentHi : C.accent,
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.gallery);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildImageOption({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    final textColor =
        isComic ? C.contrastTextOn(color) : (isHud ? color : Colors.white);

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: isHud
            ? BoxDecoration(
                color: color.withOpacity(0.15),
                border: Border.all(color: color, width: 1.4),
                boxShadow: [
                  BoxShadow(
                      color: color.withOpacity(0.35), blurRadius: 10),
                ],
              )
            : BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: isComic ? Colors.black : color,
                    width: isComic ? 3 : 1),
                boxShadow: isComic ? _shadow(3) : null,
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: textColor, size: 22),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                color: textColor,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontSize: isComic ? 16 : 12,
                fontWeight: FontWeight.w900,
                letterSpacing: isComic ? 2 : 2.5,
                shadows: isComic
                    ? [
                        Shadow(
                            color: textColor == Colors.white
                                ? Colors.black
                                : Colors.white,
                            offset: const Offset(1, 1),
                            blurRadius: 0),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );

      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
            'profile_image_${widget.username}', imageFile.path);
        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              appBar: _buildAppBar(C, isComic, isHud),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              radius: 0.8,
                              colors: [
                                C.primaryHi.withValues(alpha: 0.08),
                                C.accent.withValues(alpha: 0.04),
                                C.bgDark,
                                C.bgDeep,
                              ],
                              stops: const [0.0, 0.3, 0.7, 1.0],
                            ),
                          )),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withValues(alpha: 0.12)),
                          ),
                        ),
                      ),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(20),
                        physics: const BouncingScrollPhysics(),
                        child: Column(
                          children: [
                            const SizedBox(height: 20),
                            _buildAvatar(C, isComic, isHud),
                            const SizedBox(height: 16),
                            _buildUsername(C, isComic, isHud),
                            const SizedBox(height: 30),
                            _buildInfoGrid(C, isComic, isHud),
                            const SizedBox(height: 12),
                            _buildSessionCard(C, isComic, isHud),
                            const SizedBox(height: 30),
                            _buildChangePasswordButton(C, isComic, isHud),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // APP BAR
  // ═══════════════════════════════════════════════════════════
  PreferredSizeWidget _buildAppBar(
      AppPalette C, bool isComic, bool isHud) {
    if (isComic) {
      return AppBar(
        backgroundColor: C.bgDark,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded,
              color: Colors.black, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [C.primaryHi, C.accent],
          ).createShader(bounds),
          child: const Text(
            "PROFILE",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Bangers',
              fontWeight: FontWeight.w900,
              letterSpacing: 3,
              fontSize: 22,
              shadows: [
                Shadow(
                  color: Colors.black,
                  offset: Offset(2, 2),
                  blurRadius: 0,
                ),
              ],
            ),
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: Container(height: 4, color: Colors.black),
        ),
      );
    }

    if (isHud) {
      return AppBar(
        backgroundColor: C.hudPanel(),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded,
              color: C.hudNeon(), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "PROFILE",
          style: TextStyle(
            color: C.hudNeon(),
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900,
            letterSpacing: 2.5,
            fontSize: 13,
            shadows: [
              Shadow(color: C.accent.withOpacity(0.5), blurRadius: 8),
            ],
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1.2),
          child: Container(height: 1.2, color: C.hudBorder()),
        ),
      );
    }

    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      flexibleSpace: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  C.bg.withValues(alpha: 0.6),
                  C.bgDark.withValues(alpha: 0.6),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border(
                bottom: BorderSide(
                  color: C.primaryLo.withValues(alpha: 0.3),
                  width: 0.5,
                ),
              ),
            ),
          ),
        ),
      ),
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_rounded,
            color: C.primaryHi, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      title: ShaderMask(
        shaderCallback: (bounds) => LinearGradient(
          colors: [C.primaryHi, C.accent],
        ).createShader(bounds),
        child: const Text(
          "PROFILE",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            fontFamily: 'Orbitron',
            fontSize: 16,
          ),
        ),
      ),
      centerTitle: true,
    );
  }

  // ═══════════════════════════════════════════════════════════
  // AVATAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildAvatar(AppPalette C, bool isComic, bool isHud) {
    return AnimatedBuilder(
      animation: _floatAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, (isComic || isHud) ? 0 : _floatAnimation.value),
          child: Center(
            child: GestureDetector(
              onTap: () => _showImageSourceDialog(C, isComic, isHud),
              child: Stack(
                children: [
                  Container(
                    width: 130,
                    height: 130,
                    decoration: isHud
                        ? BoxDecoration(
                            color: C.accent.withOpacity(0.1),
                            border: Border.all(
                                color: C.accent.withOpacity(0.6),
                                width: 1.5),
                            boxShadow: [
                              BoxShadow(
                                  color: C.accent.withOpacity(0.5),
                                  blurRadius: 25,
                                  spreadRadius: 2),
                            ],
                          )
                        : BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: isComic
                                ? null
                                : LinearGradient(
                                    colors: [C.primaryHi, C.accent],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                            color: isComic ? C.primaryHi : null,
                            border: isComic
                                ? Border.all(color: Colors.black, width: 5)
                                : null,
                            boxShadow: isComic
                                ? _shadow(7)
                                : [
                                    BoxShadow(
                                      color: C.primaryHi
                                          .withValues(alpha: 0.3),
                                      blurRadius: 30,
                                      spreadRadius: 5,
                                    ),
                                  ],
                          ),
                    padding: EdgeInsets.all(isComic ? 6 : (isHud ? 5 : 3)),
                    child: Container(
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.bgDeep.withOpacity(0.7),
                              border: Border.all(
                                  color: C.accent.withOpacity(0.5),
                                  width: 1),
                            )
                          : BoxDecoration(
                              shape: BoxShape.circle,
                              color: isComic ? Colors.white : C.bgDark,
                              border: isComic
                                  ? Border.all(
                                      color: Colors.black, width: 4)
                                  : null,
                            ),
                      padding: EdgeInsets.all(isComic ? 4 : 0),
                      child: ClipOval(
                        child: _profileImage != null
                            ? Image.file(
                                _profileImage!,
                                fit: BoxFit.cover,
                              )
                            : Container(
                                color: isComic ? Colors.white : C.bgDark,
                                child: FaIcon(
                                  FontAwesomeIcons.userAstronaut,
                                  size: 50,
                                  color: isComic
                                      ? C.bgDeep
                                      : (isHud
                                          ? C.hudNeon()
                                          : C.primaryHi
                                              .withValues(alpha: 0.8)),
                                ),
                              ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: EdgeInsets.all(isComic ? 12 : 10),
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.accent.withOpacity(0.2),
                              border: Border.all(
                                  color: C.accent, width: 1.2),
                              boxShadow: [
                                BoxShadow(
                                    color: C.accent.withOpacity(0.5),
                                    blurRadius: 10),
                              ],
                            )
                          : BoxDecoration(
                              gradient: isComic
                                  ? null
                                  : LinearGradient(
                                      colors: [C.primaryHi, C.accent],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                              color: isComic ? C.accent : null,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: isComic ? Colors.black : C.bgDark,
                                width: 3,
                              ),
                              boxShadow: isComic
                                  ? _shadow(3)
                                  : [
                                      BoxShadow(
                                        color: C.primaryHi
                                            .withValues(alpha: 0.4),
                                        blurRadius: 10,
                                      ),
                                    ],
                            ),
                      child: Icon(
                        Icons.camera_alt,
                        size: isComic ? 18 : 16,
                        color: isComic
                            ? Colors.white
                            : (isHud ? C.hudNeon() : Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // USERNAME + ROLE
  // ═══════════════════════════════════════════════════════════
  Widget _buildUsername(AppPalette C, bool isComic, bool isHud) {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        if (isComic) {
          return Column(
            children: [
              Text(
                widget.username,
                style: TextStyle(
                  color: C.comicText,
                  fontSize: 26,
                  fontFamily: 'Bangers',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                  shadows: [
                    Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(2, 2),
                        blurRadius: 0),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: C.primaryHi,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.black, width: 3),
                  boxShadow: _shadow(3),
                ),
                child: Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    color: C.contrastTextOn(C.primaryHi),
                    fontSize: 13,
                    fontFamily: 'Bangers',
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                    shadows: [
                      Shadow(
                        color: C.contrastTextOn(C.primaryHi) == Colors.white
                            ? Colors.black
                            : Colors.white,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        }

        if (isHud) {
          return Column(
            children: [
              Text(
                widget.username,
                style: TextStyle(
                  color: C.hudNeon(),
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                  shadows: [
                    Shadow(
                        color: C.accent.withOpacity(0.6),
                        blurRadius: 12),
                    const Shadow(
                        color: Colors.black,
                        offset: Offset(0, 1),
                        blurRadius: 2),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: C.accent.withOpacity(
                      0.15 * _glowAnimation.value),
                  border: Border.all(
                    color: C.accent.withOpacity(
                        0.5 + 0.4 * _glowAnimation.value),
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: C.accent.withOpacity(
                          0.4 * _glowAnimation.value),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    color: C.hudNeon(),
                    fontSize: 11,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.5,
                  ),
                ),
              ),
            ],
          );
        }

        return Column(
          children: [
            ShaderMask(
              shaderCallback: (bounds) => LinearGradient(
                colors: [C.text, C.primaryHi],
              ).createShader(bounds),
              child: Text(
                widget.username,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        C.primaryHi
                            .withValues(alpha: 0.15 * _glowAnimation.value),
                        C.accent
                            .withValues(alpha: 0.1 * _glowAnimation.value),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: C.primaryHi
                          .withValues(alpha: 0.2 * _glowAnimation.value),
                      width: 0.8,
                    ),
                  ),
                  child: Text(
                    widget.role.toUpperCase(),
                    style: TextStyle(
                      color: C.text,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INFO GRID
  // ═══════════════════════════════════════════════════════════
  Widget _buildInfoGrid(AppPalette C, bool isComic, bool isHud) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.4,
      children: [
        _buildInfoCard(
          C: C,
          isComic: isComic,
          isHud: isHud,
          icon: Icons.person_outline_rounded,
          label: "USERNAME",
          value: _censorText(widget.username),
        ),
        _buildInfoCard(
          C: C,
          isComic: isComic,
          isHud: isHud,
          icon: Icons.lock_outline_rounded,
          label: "PASSWORD",
          value: _censorText(widget.password, isPassword: true),
        ),
        _buildInfoCard(
          C: C,
          isComic: isComic,
          isHud: isHud,
          icon: Icons.verified_user_rounded,
          label: "ROLE",
          value: widget.role.toUpperCase(),
        ),
        _buildInfoCard(
          C: C,
          isComic: isComic,
          isHud: isHud,
          icon: Icons.calendar_today_rounded,
          label: "EXPIRED",
          value: widget.expiredDate,
        ),
      ],
    );
  }

  Widget _buildInfoCard({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required IconData icon,
    required String label,
    required String value,
  }) {
    if (isComic) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: _panel(C, isComic, isHud, r: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: C.primaryHi,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.black, width: 2.5),
              ),
              child: Icon(icon,
                  color: C.contrastTextOn(C.primaryHi), size: 18),
            ),
            const SizedBox(height: 12),
            Text(
              label,
              style: TextStyle(
                color: C.comicText.withValues(alpha: 0.6),
                fontSize: 10,
                fontFamily: 'Bangers',
                fontWeight: FontWeight.w600,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(
                color: C.comicText,
                fontSize: 15,
                fontFamily: 'Bangers',
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
                shadows: [
                  Shadow(
                      color: C.comicTextOutline,
                      offset: const Offset(1, 1),
                      blurRadius: 0),
                ],
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ],
        ),
      );
    }

    if (isHud) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
                color: C.accent.withOpacity(0.15), blurRadius: 10),
          ],
        ),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: C.accent.withOpacity(0.15),
                    border:
                        Border.all(color: C.accent, width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: C.accent.withOpacity(0.4),
                          blurRadius: 6),
                    ],
                  ),
                  child: Icon(icon, color: C.hudNeon(), size: 16),
                ),
                const SizedBox(height: 12),
                Text(
                  label,
                  style: TextStyle(
                    color: C.hudTextDim(),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: C.hudText(),
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                    shadows: [
                      Shadow(
                          color: C.accent.withOpacity(0.4),
                          blurRadius: 6),
                    ],
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ],
            ),
            Positioned(
              top: -1,
              left: -1,
              child: SizedBox(
                width: 10,
                height: 10,
                child: CustomPaint(
                  painter: _HudCornerPainter(
                      color: C.accent.withOpacity(0.8)),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    C.bg.withValues(alpha: 0.15),
                    C.bgDark.withValues(alpha: 0.1),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: C.primaryLo.withValues(
                      alpha: 0.3 + 0.2 * _glowAnimation.value),
                  width: 0.5,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          C.primaryHi.withValues(alpha: 0.15),
                          C.accent.withValues(alpha: 0.05),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: C.primaryLo.withValues(alpha: 0.3),
                          width: 0.3),
                    ),
                    child: Icon(icon, color: C.primaryHi, size: 16),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    label,
                    style: TextStyle(
                      color: C.textSub.withValues(alpha: 0.6),
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: TextStyle(
                      color: C.text,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SESSION CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildSessionCard(AppPalette C, bool isComic, bool isHud) {
    if (isComic) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: _panel(C, isComic, isHud),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: C.accent,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 2.5),
                  ),
                  child: Icon(Icons.vpn_key_rounded,
                      color: C.contrastTextOn(C.accent), size: 18),
                ),
                const SizedBox(width: 12),
                Text(
                  "SESSION KEY",
                  style: TextStyle(
                    color: C.comicText,
                    fontSize: 14,
                    fontFamily: 'Bangers',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 2.5),
              ),
              child: SelectableText(
                widget.sessionKey,
                style: TextStyle(
                  color: C.bgDeep,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'ComicNeue',
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ],
        ),
      );
    }

    if (isHud) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: _panel(C, isComic, isHud),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                        boxShadow: [
                          BoxShadow(
                              color: C.accent.withOpacity(0.4),
                              blurRadius: 8),
                        ],
                      ),
                      child: Icon(Icons.vpn_key_rounded,
                          color: C.hudNeon(), size: 18),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      "SESSION KEY",
                      style: TextStyle(
                        color: C.hudNeon(),
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2.5,
                        shadows: [
                          Shadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 8),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: C.bgDeep.withOpacity(0.6),
                    border: Border.all(
                        color: C.accent.withOpacity(0.4), width: 1),
                  ),
                  child: SelectableText(
                    widget.sessionKey,
                    style: TextStyle(
                      color: C.hudText(),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
            Positioned(
              top: -1,
              left: -1,
              child: SizedBox(
                width: 12,
                height: 12,
                child: CustomPaint(
                  painter: _HudCornerPainter(
                      color: C.accent.withOpacity(0.8)),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    C.bg.withValues(alpha: 0.15),
                    C.bgDark.withValues(alpha: 0.1),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: C.primaryHi
                      .withValues(alpha: 0.1 * _glowAnimation.value),
                  width: 0.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: C.primaryHi
                        .withValues(alpha: 0.05 * _glowAnimation.value),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              C.primaryHi.withValues(alpha: 0.2),
                              C.accent.withValues(alpha: 0.1),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: C.primaryLo.withValues(alpha: 0.3),
                              width: 0.3),
                        ),
                        child: Icon(Icons.vpn_key_rounded,
                            color: C.primaryHi, size: 18),
                      ),
                      const SizedBox(width: 12),
                      ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          colors: [C.primaryHi, C.accent],
                        ).createShader(bounds),
                        child: const Text(
                          "SESSION KEY",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: C.primaryLo.withValues(alpha: 0.2),
                          width: 0.5),
                    ),
                    child: SelectableText(
                      widget.sessionKey,
                      style: TextStyle(
                        color: C.primaryHi,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'monospace',
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // CHANGE PASSWORD BUTTON
  // ═══════════════════════════════════════════════════════════
  Widget _buildChangePasswordButton(
      AppPalette C, bool isComic, bool isHud) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChangePasswordPage(
              username: widget.username,
              sessionKey: widget.sessionKey,
            ),
          ),
        );
      },
      child: isComic
          ? Container(
              width: double.infinity,
              height: 60,
              decoration: BoxDecoration(
                color: C.primaryHi,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: _shadow(5),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.lock_reset_rounded,
                      color: C.contrastTextOn(C.primaryHi), size: 24),
                  const SizedBox(width: 12),
                  Text(
                    "CHANGE PASSWORD",
                    style: TextStyle(
                      color: C.contrastTextOn(C.primaryHi),
                      fontSize: 16,
                      fontFamily: 'Bangers',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color:
                              C.contrastTextOn(C.primaryHi) == Colors.white
                                  ? Colors.black
                                  : Colors.white,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          : isHud
              ? Container(
                  width: double.infinity,
                  height: 56,
                  decoration: BoxDecoration(
                    color: C.accent.withOpacity(0.15),
                    border: Border.all(color: C.accent, width: 1.4),
                    boxShadow: [
                      BoxShadow(
                          color: C.accent.withOpacity(0.4),
                          blurRadius: 12),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.lock_reset_rounded,
                          color: C.hudNeon(), size: 22),
                      const SizedBox(width: 12),
                      Text(
                        "CHANGE PASSWORD",
                        style: TextStyle(
                          color: C.hudNeon(),
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.5,
                          fontFamily: 'Orbitron',
                          shadows: [
                            Shadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 8),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              : AnimatedBuilder(
                  animation: _glowAnimation,
                  builder: (context, child) {
                    return ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                        child: Container(
                          width: double.infinity,
                          height: 56,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                C.primaryHi.withValues(
                                    alpha: 0.2 * _glowAnimation.value),
                                C.accent.withValues(
                                    alpha: 0.2 * _glowAnimation.value),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: C.primaryHi.withValues(
                                  alpha: 0.2 * _glowAnimation.value),
                              width: 0.8,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: C.primaryHi.withValues(
                                    alpha: 0.2 * _glowAnimation.value),
                                blurRadius: 20,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () {
                                HapticFeedback.lightImpact();
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => ChangePasswordPage(
                                      username: widget.username,
                                      sessionKey: widget.sessionKey,
                                    ),
                                  ),
                                );
                              },
                              borderRadius: BorderRadius.circular(14),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.lock_reset_rounded,
                                      color: Colors.white, size: 22),
                                  const SizedBox(width: 12),
                                  const Text(
                                    "CHANGE PASSWORD",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.5,
                                      fontFamily: 'Orbitron',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}