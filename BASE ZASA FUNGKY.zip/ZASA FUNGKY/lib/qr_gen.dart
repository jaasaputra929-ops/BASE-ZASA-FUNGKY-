// qr_gen.dart — QR Generator (3 Style Support)
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'app_theme.dart';

class QrGeneratorPage extends StatefulWidget {
  const QrGeneratorPage({super.key});

  @override
  State<QrGeneratorPage> createState() => _QrGeneratorPageState();
}

class _QrGeneratorPageState extends State<QrGeneratorPage> {
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  Uint8List? _qrImage;
  String? _errorMessage;

  // ═══ SHADOW HELPER ═══
  List<BoxShadow> _shadow(double s) {
    final style = AppTheme.currentStyle.value;
    final C = AppTheme.current.value;
    if (style == ThemeStyle.comic3d) {
      return [
        BoxShadow(color: Colors.black, offset: Offset(s, s), blurRadius: 0),
      ];
    }
    if (style == ThemeStyle.hudTactical) {
      return [
        BoxShadow(color: C.accent.withOpacity(0.25), blurRadius: 12),
      ];
    }
    return [
      BoxShadow(
          color: Colors.black.withOpacity(0.6),
          offset: const Offset(0, 4),
          blurRadius: 10),
    ];
  }

  Future<void> _generateQR() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      setState(() {
        _errorMessage = "Text tidak boleh kosong.";
        _qrImage = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _qrImage = null;
    });

    final encodedText = Uri.encodeComponent(text);
    final url = Uri.parse(
        "https://api.siputzx.my.id/api/tools/text2qr?text=$encodedText");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          _qrImage = response.bodyBytes;
          _errorMessage = null;
        });
      } else {
        setState(() {
          _errorMessage = "Gagal generate QR Code.";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _shareQR() async {
    if (_qrImage == null) return;
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final isHud = AppTheme.currentStyle.value == ThemeStyle.hudTactical;

    try {
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/qr_code_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_qrImage!);

      await Share.shareXFiles([XFile(file.path)],
          text: 'QR Code dari: ${_textController.text}');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error sharing: $e'),
          backgroundColor: isHud ? C.hudPanel() : C.bgDark,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(isComic ? 16 : 12),
            side: BorderSide(
              color: isComic
                  ? Colors.black
                  : (isHud ? C.hudBorder() : C.accent.withOpacity(0.3)),
              width: isComic ? 3 : 1,
            ),
          ),
        ),
      );
    }
  }

  // ═══ PANEL DECORATION ═══
  BoxDecoration _panel(AppPalette C, bool isComic, bool isHud,
      {double r = 20}) {
    if (isComic) {
      return BoxDecoration(
        color: C.bgDark,
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: Colors.black, width: 3.5),
        boxShadow: _shadow(5),
      );
    }
    if (isHud) {
      return BoxDecoration(
        color: C.hudPanel(),
        border: Border.all(color: C.hudBorder(), width: 1.2),
        boxShadow: _shadow(0),
      );
    }
    return BoxDecoration(
      borderRadius: BorderRadius.circular(r),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [C.bgDark, C.bgDark.withOpacity(0.8)],
      ),
      border: Border.all(color: C.accent.withOpacity(0.35), width: 1.2),
      boxShadow: _shadow(0),
    );
  }

  Widget _buildInput(AppPalette C, bool isComic, bool isHud) {
    return Container(
      decoration: isComic
          ? BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.black, width: 3),
            )
          : (isHud
              ? BoxDecoration(
                  color: C.bgDeep.withOpacity(0.6),
                  border: Border.all(
                      color: C.accent.withOpacity(0.5), width: 1.2),
                )
              : BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                      colors: [C.bgDark, C.bgDark.withOpacity(0.8)]),
                  border: Border.all(
                      color: C.accent.withOpacity(0.3), width: 1.2),
                )),
      child: TextField(
        controller: _textController,
        style: TextStyle(
          color: isComic
              ? Colors.black
              : (isHud ? C.hudText() : Colors.white),
          fontSize: isComic ? 14 : 15,
          fontFamily:
              isComic ? 'ComicNeue' : (isHud ? 'Orbitron' : 'ShareTechMono'),
          fontWeight: FontWeight.w700,
          letterSpacing: isHud ? 1 : 0,
        ),
        cursorColor: isComic ? Colors.black : C.accent,
        decoration: InputDecoration(
          labelText: 'Masukkan Text/URL',
          labelStyle: TextStyle(
            color: isComic
                ? Colors.black.withOpacity(0.6)
                : (isHud ? C.hudTextDim() : C.accent.withOpacity(0.7)),
            fontFamily:
                isComic ? 'ComicNeue' : 'ShareTechMono',
            fontWeight: FontWeight.w700,
            letterSpacing: isHud ? 1 : 0,
          ),
          hintText: 'Contoh: https://google.com',
          hintStyle: TextStyle(
            color: isComic
                ? Colors.black.withOpacity(0.4)
                : (isHud ? C.hudTextDim() : C.textSub.withOpacity(0.5)),
            fontFamily:
                isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 12,
          ),
          prefixIcon: Icon(Icons.text_fields,
              color: isComic ? Colors.black : C.accent),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        ),
        onSubmitted: (_) => _generateQR(),
      ),
    );
  }

  Widget _buildActionButton({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
    required Color color,
    bool isLoading = false,
  }) {
    final textColor =
        isComic ? C.contrastTextOn(color) : Colors.white;

    if (isHud) {
      return GestureDetector(
        onTap: isLoading ? null : onPressed,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          decoration: BoxDecoration(
            color: color.withOpacity(isLoading ? 0.05 : 0.15),
            border: Border.all(
                color: color.withOpacity(isLoading ? 0.4 : 1),
                width: 1.4),
            boxShadow: isLoading
                ? []
                : [
                    BoxShadow(
                        color: color.withOpacity(0.4), blurRadius: 12),
                  ],
          ),
          child: isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: color),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: color, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      text,
                      style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
        ),
      );
    }

    if (isComic) {
      return GestureDetector(
        onTap: isLoading ? null : onPressed,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.black, width: 3.5),
            boxShadow: _shadow(4),
          ),
          child: isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: textColor),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: textColor, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      text,
                      style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        fontFamily: 'Bangers',
                        letterSpacing: 1.5,
                        shadows: [
                          Shadow(
                            color: textColor == Colors.white
                                ? Colors.black
                                : Colors.white,
                            offset: const Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
            colors: [color.withOpacity(0.8), color.withOpacity(0.6)]),
        boxShadow: [
          BoxShadow(
              color: color.withOpacity(0.3),
              blurRadius: 15,
              spreadRadius: 2),
        ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
        ),
        child: isLoading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    text,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Stack(
                children: [
                  // Background decoration
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withOpacity(0.12)),
                            ),
                          )
                        : (isHud
                            ? Container(
                                color: C.hudBg(),
                                child: CustomPaint(
                                  painter: _HudGridPainter(
                                      color: C.hudGridLine()),
                                ),
                              )
                            : Stack(
                                children: [
                                  Positioned(
                                    top: -100,
                                    right: -100,
                                    child: Container(
                                      width: 300,
                                      height: 300,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: RadialGradient(
                                          colors: [
                                            C.primary.withOpacity(0.1),
                                            Colors.transparent,
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: -150,
                                    left: -100,
                                    child: Container(
                                      width: 400,
                                      height: 400,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: RadialGradient(
                                          colors: [
                                            C.accent.withOpacity(0.08),
                                            Colors.transparent,
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              )),
                  ),
                  SafeArea(
                    child: Column(
                      children: [
                        _buildTopBar(C, isComic, isHud),
                        Expanded(
                          child: SingleChildScrollView(
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                // Input card
                                Container(
                                  padding: const EdgeInsets.all(20),
                                  decoration: _panel(C, isComic, isHud),
                                  child: Column(
                                    children: [
                                      _buildInput(C, isComic, isHud),
                                      const SizedBox(height: 16),
                                      _buildActionButton(
                                        C: C,
                                        isComic: isComic,
                                        isHud: isHud,
                                        text: "GENERATE QR",
                                        icon: Icons.qr_code,
                                        onPressed: _generateQR,
                                        color: isHud
                                            ? C.accent
                                            : (isComic
                                                ? C.primaryHi
                                                : C.primary),
                                        isLoading: _isLoading,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 16),

                                // Error card
                                if (_errorMessage != null)
                                  Container(
                                    padding: const EdgeInsets.all(16),
                                    decoration: _panel(C, isComic, isHud),
                                    child: Row(
                                      children: [
                                        Icon(Icons.error_outline,
                                            color: isHud
                                                ? C.hudWarning()
                                                : C.primaryHi),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Text(
                                            _errorMessage!,
                                            style: TextStyle(
                                              color: isComic
                                                  ? C.comicText
                                                  : (isHud
                                                      ? C.hudText()
                                                      : Colors.white70),
                                              fontSize: 13,
                                              fontFamily: isComic
                                                  ? 'ComicNeue'
                                                  : 'ShareTechMono',
                                              letterSpacing: isHud ? 1 : 0,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                // QR Result
                                if (_qrImage != null) ...[
                                  const SizedBox(height: 16),
                                  Container(
                                    padding: const EdgeInsets.all(20),
                                    decoration: _panel(C, isComic, isHud),
                                    child: Column(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(20),
                                          decoration: isHud
                                              ? BoxDecoration(
                                                  color: C.bgDeep
                                                      .withOpacity(0.6),
                                                  border: Border.all(
                                                      color: C.accent
                                                          .withOpacity(0.5),
                                                      width: 1.2),
                                                  boxShadow: [
                                                    BoxShadow(
                                                        color: C.accent
                                                            .withOpacity(
                                                                0.3),
                                                        blurRadius: 15),
                                                  ],
                                                )
                                              : BoxDecoration(
                                                  color: isComic
                                                      ? Colors.white
                                                      : C.bgDark,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16),
                                                  border: Border.all(
                                                    color: isComic
                                                        ? Colors.black
                                                        : C.accent
                                                            .withOpacity(
                                                                0.3),
                                                    width:
                                                        isComic ? 3 : 1,
                                                  ),
                                                ),
                                          child: Image.memory(_qrImage!),
                                        ),
                                        const SizedBox(height: 20),

                                        // Text preview
                                        Container(
                                          padding: const EdgeInsets.all(12),
                                          decoration: isHud
                                              ? BoxDecoration(
                                                  color: C.bgDeep
                                                      .withOpacity(0.5),
                                                  border: Border.all(
                                                      color: C.accent
                                                          .withOpacity(
                                                              0.3),
                                                      width: 1),
                                                )
                                              : BoxDecoration(
                                                  color: isComic
                                                      ? Colors.white
                                                      : C.bgDark,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          12),
                                                  border: Border.all(
                                                    color: isComic
                                                        ? Colors.black
                                                        : C.accent
                                                            .withOpacity(
                                                                0.2),
                                                    width:
                                                        isComic ? 2.5 : 1,
                                                  ),
                                                ),
                                          child: Row(
                                            children: [
                                              Icon(Icons.text_snippet,
                                                  color: isComic
                                                      ? Colors.black
                                                      : C.accent,
                                                  size: 16),
                                              const SizedBox(width: 8),
                                              Expanded(
                                                child: Text(
                                                  _textController.text,
                                                  style: TextStyle(
                                                    color: isComic
                                                        ? Colors.black
                                                        : (isHud
                                                            ? C.hudText()
                                                            : Colors
                                                                .white70),
                                                    fontSize: 12,
                                                    fontFamily: isComic
                                                        ? 'ComicNeue'
                                                        : 'ShareTechMono',
                                                    letterSpacing:
                                                        isHud ? 0.5 : 0,
                                                  ),
                                                  overflow: TextOverflow
                                                      .ellipsis,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        _buildActionButton(
                                          C: C,
                                          isComic: isComic,
                                          isHud: isHud,
                                          text: "SHARE QR CODE",
                                          icon: Icons.share,
                                          onPressed: _shareQR,
                                          color: isHud
                                              ? C.accentHi
                                              : (isComic
                                                  ? C.accent
                                                  : C.accentHi),
                                          isLoading: false,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 16),
                                  Container(
                                    padding: const EdgeInsets.all(14),
                                    decoration: _panel(C, isComic, isHud,
                                        r: 12),
                                    child: Row(
                                      children: [
                                        Icon(Icons.info,
                                            color: isComic
                                                ? Colors.black
                                                : C.accent,
                                            size: 18),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Text(
                                            "QR Code berhasil digenerate dari teks/URL",
                                            style: TextStyle(
                                              color: isComic
                                                  ? Colors.black
                                                      .withOpacity(0.7)
                                                  : (isHud
                                                      ? C.hudTextDim()
                                                      : Colors.white70),
                                              fontSize: 12,
                                              fontFamily: isComic
                                                  ? 'ComicNeue'
                                                  : 'ShareTechMono',
                                              letterSpacing: isHud ? 1 : 0,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: _panel(C, isComic, isHud, r: isHud ? 4 : 14),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36,
                height: 36,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border: Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: isComic
                            ? null
                            : LinearGradient(
                                colors: [C.text, C.bg, C.bgDark]),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color:
                                isComic ? Colors.black : C.primaryLo,
                            width: isComic ? 2.5 : 1.5),
                      ),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : C.accent,
                    size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36,
              height: 36,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border: Border.all(color: C.accent, width: 1.2),
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(colors: [
                              C.accentHi,
                              C.accent,
                              C.primaryLo
                            ]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color:
                              isComic ? Colors.black : C.accentShine,
                          width: isComic ? 3 : 1.5),
                    ),
              child: Icon(Icons.qr_code,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : C.bgDeep),
                  size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('QR GENERATOR',
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 18 : 13,
                        letterSpacing: isComic ? 2 : 2.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0),
                              ]
                            : (isHud
                                ? [
                                    Shadow(
                                        color: C.accent
                                            .withOpacity(0.5),
                                        blurRadius: 8),
                                  ]
                                : null),
                      )),
                  const SizedBox(height: 2),
                  Text('TEXT/URL → QR CODE',
                      style: TextStyle(
                        color: isComic
                            ? C.comicTextSub
                            : (isHud
                                ? C.hudTextDim()
                                : C.text.withOpacity(0.55)),
                        fontFamily: isComic
                            ? 'ComicNeue'
                            : 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        fontSize: 8,
                        letterSpacing: 1.2),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}