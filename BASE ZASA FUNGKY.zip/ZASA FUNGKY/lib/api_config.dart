const String baseUrl = "http://angelacantik.zone.id:3631";
const String WS_URL = 'ws://reviactyserver.szxennofficialid.web.id:3054';