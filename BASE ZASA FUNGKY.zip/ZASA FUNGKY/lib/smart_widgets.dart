// lib/smart_widgets.dart — Widget universal auto-adapt style
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// HUD CORNER PAINTER (dipakai SmartScrew di mode HUD)
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER (background HUD)
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// SMART PLATE
// ═══════════════════════════════════════════════════════════
class SmartPlate extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double? radius;
  final Color? accent;
  final bool elevated;

  const SmartPlate({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius,
    this.accent,
    this.elevated = true,
  });

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final style = AppThemeScope.styleOf(context);
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final r = radius ?? (isComic ? 18.0 : (isHud ? 4.0 : 16.0));

    // ═══ HUD TACTICAL ═══
    if (isHud) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: elevated
              ? [
                  BoxShadow(
                    color: C.accent.withOpacity(0.15),
                    blurRadius: 12,
                  ),
                ]
              : null,
        ),
        child: Stack(
          children: [
            child,
            Positioned(
                top: 0,
                left: 0,
                child: SizedBox(
                  width: 12,
                  height: 12,
                  child: CustomPaint(
                    painter: _HudCornerPainter(
                        color: C.accent.withOpacity(0.7)),
                  ),
                )),
            Positioned(
                top: 0,
                right: 0,
                child: SizedBox(
                  width: 12,
                  height: 12,
                  child: CustomPaint(
                    painter: _HudCornerPainter(
                        color: C.accent.withOpacity(0.7)),
                  ),
                )),
            Positioned(
                bottom: 0,
                left: 0,
                child: SizedBox(
                  width: 12,
                  height: 12,
                  child: CustomPaint(
                    painter: _HudCornerPainter(
                        color: C.accent.withOpacity(0.7)),
                  ),
                )),
            Positioned(
                bottom: 0,
                right: 0,
                child: SizedBox(
                  width: 12,
                  height: 12,
                  child: CustomPaint(
                    painter: _HudCornerPainter(
                        color: C.accent.withOpacity(0.7)),
                  ),
                )),
          ],
        ),
      );
    }

    // ═══ COMIC 3D ═══
    if (isComic) {
      final baseColor = brass
          ? C.primaryHi
          : (accent != null
              ? Color.lerp(C.bgDark, accent!, 0.15)!
              : C.bgDark);
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: baseColor,
          borderRadius: BorderRadius.circular(r),
          border: Border.all(color: Colors.black, width: 3.5),
          boxShadow: elevated
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ]
              : null,
        ),
        child: child,
      );
    }

    // ═══ ORIGINAL ═══
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(r),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
          const BoxShadow(
            color: Colors.white12,
            offset: Offset(-1, -1),
            blurRadius: 3,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(r - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART BUTTON — auto contrast teks ke button color
// ═══════════════════════════════════════════════════════════
class SmartButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color? color;
  final double height;
  final EdgeInsets padding;

  const SmartButton({
    super.key,
    required this.child,
    required this.onTap,
    this.color,
    this.height = 56,
    this.padding = const EdgeInsets.symmetric(horizontal: 20),
  });

  @override
  State<SmartButton> createState() => _SmartButtonState();
}

class _SmartButtonState extends State<SmartButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final style = AppThemeScope.styleOf(context);
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final color = widget.color ?? C.primaryHi;
    final enabled = widget.onTap != null;

    final textColor = isComic ? C.contrastTextOn(color) : Colors.white;
    final textOutline =
        textColor == Colors.white ? Colors.black : Colors.white;

    // ═══ HUD TACTICAL ═══
    if (isHud) {
      return GestureDetector(
        onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
        onTapUp: enabled
            ? (_) {
                setState(() => _pressed = false);
                widget.onTap?.call();
              }
            : null,
        onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          height: widget.height,
          decoration: BoxDecoration(
            color: _pressed
                ? color.withOpacity(0.25)
                : color.withOpacity(0.12),
            border: Border.all(color: color, width: 1.4),
            boxShadow: _pressed
                ? []
                : [
                    BoxShadow(
                      color: color.withOpacity(0.35),
                      blurRadius: 10,
                    ),
                  ],
          ),
          child: Padding(
            padding: widget.padding,
            child: Center(
              child: Opacity(
                opacity: enabled ? 1 : 0.5,
                child: DefaultTextStyle(
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontSize: 13,
                    letterSpacing: 1.5,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                  child: IconTheme(
                    data: const IconThemeData(color: Colors.white),
                    child: widget.child,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    // ═══ COMIC 3D ═══
    if (isComic) {
      return GestureDetector(
        onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
        onTapUp: enabled
            ? (_) {
                setState(() => _pressed = false);
                widget.onTap?.call();
              }
            : null,
        onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          height: widget.height,
          transform: Matrix4.translationValues(
            _pressed ? 4 : 0,
            _pressed ? 4 : 0,
            0,
          ),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.black, width: 3.5),
            boxShadow: _pressed
                ? []
                : const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(4, 4),
                      blurRadius: 0,
                    ),
                  ],
          ),
          child: Padding(
            padding: widget.padding,
            child: Center(
              child: DefaultTextStyle(
                style: TextStyle(
                  fontFamily: 'Bangers',
                  fontSize: 16,
                  letterSpacing: 1.5,
                  color: textColor,
                  shadows: [
                    Shadow(
                      color: textOutline,
                      offset: const Offset(2, 2),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: IconTheme(
                  data: IconThemeData(color: textColor),
                  child: widget.child,
                ),
              ),
            ),
          ),
        ),
      );
    }

    // ═══ ORIGINAL ═══
    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            }
          : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin:
                _pressed ? Alignment.bottomCenter : Alignment.topCenter,
            end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
            colors: [
              color.withOpacity(0.9),
              color,
              color.withOpacity(0.7),
            ],
          ),
          border:
              Border.all(color: color.withOpacity(0.9), width: 1.5),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(
                    color: color.withOpacity(0.35),
                    blurRadius: 10,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 4),
                    blurRadius: 6,
                  ),
                ],
        ),
        child: Padding(
          padding: widget.padding,
          child: Center(
            child: Opacity(
              opacity: enabled ? 1 : 0.5,
              child: widget.child,
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART LED
// ═══════════════════════════════════════════════════════════
class SmartLed extends StatelessWidget {
  final Color? color;
  final double size;
  final bool blink;

  const SmartLed({
    super.key,
    this.color,
    this.size = 8,
    this.blink = false,
  });

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final style = AppThemeScope.styleOf(context);
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final c = color ?? C.primaryHi;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: c,
          border: Border.all(color: Colors.black, width: size * 0.15),
        ),
      );
    }

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: c,
          boxShadow: [
            BoxShadow(
              color: c.withOpacity(0.9),
              blurRadius: size * 1.8,
              spreadRadius: size * 0.3,
            ),
          ],
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [
            Colors.white.withOpacity(0.85),
            c,
            c.withOpacity(0.55),
          ],
          stops: const [0.0, 0.4, 1.0],
        ),
        border: Border.all(
          color: Colors.black.withOpacity(0.85),
          width: size * 0.1,
        ),
        boxShadow: [
          BoxShadow(
            color: c.withOpacity(0.75),
            blurRadius: size * 1.4,
            spreadRadius: size * 0.2,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART SCREW
// ═══════════════════════════════════════════════════════════
class SmartScrew extends StatelessWidget {
  final double size;
  final double rotation;
  const SmartScrew({super.key, this.size = 12, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) {
    final style = AppThemeScope.styleOf(context);
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    final C = AppThemeScope.paletteOf(context);

    if (isHud) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.8, 1.5),
            blurRadius: 2.5,
          ),
        ],
      ),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART RIVET
// ═══════════════════════════════════════════════════════════
class SmartRivet extends StatelessWidget {
  final double size;
  const SmartRivet({super.key, this.size = 10});

  @override
  Widget build(BuildContext context) {
    final style = AppThemeScope.styleOf(context);
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    final C = AppThemeScope.paletteOf(context);

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withOpacity(0.6), width: 1),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART BACKGROUND
// ═══════════════════════════════════════════════════════════
class SmartBackground extends StatelessWidget {
  final Widget child;
  final bool halftone;
  const SmartBackground({
    super.key,
    required this.child,
    this.halftone = true,
  });

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final style = AppThemeScope.styleOf(context);
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        color: C.bg,
        child: halftone
            ? CustomPaint(
                painter: _HalftonePainter(
                  color: C.primaryLo.withOpacity(0.12),
                ),
                child: child,
              )
            : child,
      );
    }

    if (isHud) {
      return Container(
        color: C.hudBg(),
        child: halftone
            ? CustomPaint(
                painter: _HudGridPainter(color: C.hudGridLine()),
                child: child,
              )
            : child,
      );
    }

    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(-0.3, -0.3),
          radius: 1.2,
          colors: [C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.6, 1.0],
        ),
      ),
      child: child,
    );
  }
}

class _HalftonePainter extends CustomPainter {
  final Color color;
  _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// SMART TEXT — auto contrast
// ═══════════════════════════════════════════════════════════
class SmartText extends StatelessWidget {
  final String text;
  final double fontSize;
  final Color? color;
  final bool outline;
  final FontWeight fontWeight;
  final double? letterSpacing;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  const SmartText(
    this.text, {
    super.key,
    this.fontSize = 14,
    this.color,
    this.outline = false,
    this.fontWeight = FontWeight.w900,
    this.letterSpacing,
    this.textAlign,
    this.maxLines,
    this.overflow,
  });

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final style = AppThemeScope.styleOf(context);
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    final c = color ?? (isComic ? C.comicText : C.text);

    if (isComic) {
      return Text(
        text,
        textAlign: textAlign,
        maxLines: maxLines,
        overflow: overflow,
        style: TextStyle(
          color: c,
          fontFamily: 'Bangers',
          fontSize: fontSize + 1,
          fontWeight: FontWeight.w900,
          letterSpacing: letterSpacing ?? 1.0,
          shadows: [
            Shadow(
              color: C.comicTextOutline.withOpacity(0.7),
              offset: const Offset(1.5, 1.5),
              blurRadius: 0,
            ),
          ],
        ),
      );
    }

    if (isHud) {
      return Text(
        text,
        textAlign: textAlign,
        maxLines: maxLines,
        overflow: overflow,
        style: TextStyle(
          color: c,
          fontFamily: 'Orbitron',
          fontSize: fontSize,
          fontWeight: fontWeight,
          letterSpacing: letterSpacing ?? 1.5,
          shadows: [
            Shadow(
              color: C.accent.withOpacity(0.5),
              blurRadius: 8,
            ),
            const Shadow(
              color: Colors.black,
              offset: Offset(0, 1),
              blurRadius: 2,
            ),
          ],
        ),
      );
    }

    return Text(
      text,
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow,
      style: TextStyle(
        color: c,
        fontFamily: 'Orbitron',
        fontSize: fontSize,
        fontWeight: fontWeight,
        letterSpacing: letterSpacing ?? 0.5,
        shadows: const [
          Shadow(
            color: Colors.black,
            offset: Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
    );
  }
}