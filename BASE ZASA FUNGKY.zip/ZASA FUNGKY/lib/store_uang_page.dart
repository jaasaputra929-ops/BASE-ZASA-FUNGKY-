// lib/store_uang_page.dart — Full 3 Style Support
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:http_parser/http_parser.dart';
import 'app_theme.dart';

const String _kBaseUrl = 'http://angelacantik.zone.id:3631';

// ══════════════════════════════════════════════════════════════
// GLOBAL PULSE
// ══════════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ══════════════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ══════════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

// ══════════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ══════════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ══════════════════════════════════════════════════════════════
// LED
// ══════════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      if (!blink) {
        return Container(
          width: size, height: size,
          decoration: BoxDecoration(
            color: color,
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3,
              ),
            ],
          ),
        );
      }
      return ValueListenableBuilder<double>(
        valueListenable: _Pulse.v,
        builder: (_, v, __) => Container(
          width: size, height: size,
          decoration: BoxDecoration(
            color: color.withOpacity(0.4 + v * 0.6),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.9),
                blurRadius: size * 1.8,
                spreadRadius: size * 0.3,
              ),
            ],
          ),
        ),
      );
    }

    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55));
  }

  Widget _dot(double opacity) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
              color: Colors.black.withOpacity(0.85),
              width: size * 0.1),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.75 * opacity),
                blurRadius: size * 1.4, spreadRadius: size * 0.2),
            BoxShadow(color: color.withOpacity(0.35 * opacity),
                blurRadius: size * 2.6, spreadRadius: size * 0.4),
          ],
        ),
      );
}

// ══════════════════════════════════════════════════════════════
// SCREW
// ══════════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return SizedBox(
        width: size, height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.7)),
        ),
      );
    }

    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7, height: size * 0.11,
            color: Colors.black.withOpacity(0.9)),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// RIVET
// ══════════════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withOpacity(0.6), width: 1),
        ),
      );
    }

    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// METAL PLATE
// ══════════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6),
                blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12, height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.8)),
        ),
      );
}

// ══════════════════════════════════════════════════════════════
// INSET PANEL
// ══════════════════════════════════════════════════════════════
class _InsetPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  const _InsetPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(12),
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3)),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDeep.withOpacity(0.7),
          border: Border.all(color: C.accent.withOpacity(0.4), width: 1),
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [C.bgDeep, C.bgDark]),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.95),
              offset: const Offset(0, 2), blurRadius: 4),
          const BoxShadow(color: Colors.white10,
              offset: Offset(0, -1), blurRadius: 1),
        ],
        border: Border.all(color: C.bgDark, width: 1.5),
      ),
      child: child,
    );
  }
}

// ══════════════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ══════════════════════════════════════════════════════════════
class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final enabled = widget.onTap != null;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);
    final widgetDark = _widgetDark(widget.color);

    final textColor = isComic
        ? C.contrastTextOn(widget.color)
        : (isHud ? widget.color : Colors.white);

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled ? (_) {
        setState(() => _pressed = false);
        widget.onTap?.call();
      } : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: isHud
            ? BoxDecoration(
                color: widget.color.withOpacity(
                    _pressed ? 0.25 : (enabled ? 0.15 : 0.05)),
                border: Border.all(
                    color: widget.color
                        .withOpacity(enabled ? 1 : 0.4),
                    width: 1.4),
                boxShadow: _pressed || !enabled
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withOpacity(0.4),
                          blurRadius: 12,
                        ),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: isComic ? null : LinearGradient(
                  begin: _pressed ? Alignment.bottomCenter : Alignment.topCenter,
                  end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
                  colors: _pressed
                      ? [widgetDark, widgetDark, widget.color]
                      : [light, widget.color, dark],
                  stops: const [0.0, 0.5, 1.0],
                ),
                color: isComic ? widget.color : null,
                boxShadow: isComic
                    ? (_pressed ? [] : const [
                        BoxShadow(color: Colors.black, offset: Offset(4, 4),
                            blurRadius: 0)])
                    : (_pressed
                        ? [BoxShadow(color: Colors.black.withOpacity(0.9),
                            offset: const Offset(0, 1), blurRadius: 3)]
                        : [
                            BoxShadow(color: widget.color.withOpacity(0.45),
                                offset: const Offset(0, 5), blurRadius: 10,
                                spreadRadius: -2),
                            BoxShadow(color: Colors.black.withOpacity(0.75),
                                offset: const Offset(0, 4), blurRadius: 6),
                          ]),
                border: Border.all(
                    color: isComic ? Colors.black : dark.withOpacity(0.9),
                    width: isComic ? 3.5 : 1.5),
              ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic && !isHud) ...[
              Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, right: 5, child: _Rivet(C: C, size: 6)),
            ],
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Opacity(
                opacity: enabled ? 1 : 0.5,
                child: IconTheme(
                  data: IconThemeData(color: textColor),
                  child: DefaultTextStyle(
                    style: TextStyle(
                      color: textColor,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w900,
                    ),
                    child: widget.child,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(c.alpha,
      (c.red + 40).clamp(0, 255),
      (c.green + 40).clamp(0, 255),
      (c.blue + 30).clamp(0, 255));
  static Color _darken(Color c) => Color.fromARGB(c.alpha,
      (c.red - 60).clamp(0, 255),
      (c.green - 50).clamp(0, 255),
      (c.blue - 40).clamp(0, 255));
  static Color _widgetDark(Color c) => Color.fromARGB(c.alpha,
      (c.red - 30).clamp(0, 255),
      (c.green - 25).clamp(0, 255),
      (c.blue - 20).clamp(0, 255));
}

// ══════════════════════════════════════════════════════════════
// STORE UANG PAGE
// ══════════════════════════════════════════════════════════════
class StoreUangPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const StoreUangPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<StoreUangPage> createState() => _StoreUangPageState();
}

class _StoreUangPageState extends State<StoreUangPage> {
  final TextEditingController _amountCtrl = TextEditingController();
  final TextEditingController _namaPanggilanCtrl = TextEditingController();
  final TextEditingController _namaAkunCtrl = TextEditingController();

  File? _proofImage;
  String? _paymentMethod;
  bool _isUploading = false;

  static const String _danaNumber = '083890054086';
  static const String _danaName = 'Really xxxx';

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _namaAkunCtrl.text = widget.username;
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _namaPanggilanCtrl.dispose();
    _namaAkunCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
          source: source, imageQuality: 70, maxWidth: 1080);
      if (picked != null) setState(() => _proofImage = File(picked.path));
    } catch (e) {
      _showSnack('Gagal pilih gambar: $e', isError: true);
    }
  }

  void _showImageOptions(AppPalette C, bool isComic, bool isHud) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 50, height: isComic ? 5 : 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: isComic
                    ? Colors.black
                    : (isHud ? C.accent : C.textSub),
                borderRadius: BorderRadius.circular(2)),
            ),
            Text('PILIH SUMBER GAMBAR',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontSize: isComic ? 16 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                  shadows: isHud
                      ? [
                          Shadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 8),
                        ]
                      : null)),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(child: _IndustrialButton(
                  C: C, color: isHud ? C.accent : C.accentHi, height: 52,
                  onTap: () {
                    Navigator.pop(ctx);
                    _pickImage(ImageSource.camera);
                  },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.camera_alt_rounded, size: 16),
                      SizedBox(width: 6),
                      Text('KAMERA', style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2, fontSize: 11)),
                    ],
                  ),
                )),
                const SizedBox(width: 10),
                Expanded(child: _IndustrialButton(
                  C: C, color: isHud ? C.accent : C.accentHi, height: 52,
                  onTap: () {
                    Navigator.pop(ctx);
                    _pickImage(ImageSource.gallery);
                  },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.photo_library_rounded, size: 16),
                      SizedBox(width: 6),
                      Text('GALERI', style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2, fontSize: 11)),
                    ],
                  ),
                )),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  void _showQrisDialog(AppPalette C, bool isComic, bool isHud) {
    final amountText = _amountCtrl.text.replaceAll('.', '').trim();
    final amount = int.tryParse(amountText) ?? 0;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.9),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('SCAN QRIS',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: isComic ? 20 : 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2.5,
                    shadows: isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 10),
                          ]
                        : null)),
              const SizedBox(height: 6),
              Text('Scan pake aplikasi apapun yang support QRIS',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : (isHud ? C.hudTextDim() : C.textSub),
                    fontSize: isComic ? 12 : 10,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.5)),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 4 : 2),
                  boxShadow: isHud
                      ? [
                          BoxShadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 15),
                        ]
                      : null,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    'assets/images/qris.jpg',
                    width: 260, height: 260,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => Container(
                      width: 260, height: 260,
                      color: C.bgDark,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.qr_code_2_rounded, size: 64,
                              color: isComic ? C.comicTextSub : C.textSub),
                          const SizedBox(height: 8),
                          Text('qris.jpg belum ada',
                              style: TextStyle(
                                color: isComic ? C.comicTextSub
                                    : C.text.withOpacity(0.5),
                                fontSize: 10,
                                fontFamily: isComic ? 'ComicNeue'
                                    : 'ShareTechMono')),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              if (amount > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: isHud
                        ? C.accent.withOpacity(0.15)
                        : (isComic ? C.primaryHi : C.primaryLo),
                    borderRadius: BorderRadius.circular(isComic ? 12 : 8),
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : (isHud ? C.accent : C.primaryHi),
                        width: isComic ? 3 : 1.5),
                    boxShadow: isHud
                        ? [
                            BoxShadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 10),
                          ]
                        : null,
                  ),
                  child: Text(
                    'Transfer: Rp ${_formatPrice(amount)}',
                    style: TextStyle(
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : (isHud ? C.hudNeon() : Colors.white),
                      fontSize: isComic ? 14 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 0.5,
                      shadows: isHud
                          ? [
                              Shadow(
                                  color: C.accent.withOpacity(0.6),
                                  blurRadius: 6),
                            ]
                          : null),
                  ),
                ),
              const SizedBox(height: 18),
              _IndustrialButton(
                C: C,
                color: isHud ? C.accent : C.primaryHi, height: 46,
                onTap: () => Navigator.pop(ctx),
                child: Text('OKE, SAYA BAYAR',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2.5,
                      fontSize: isComic ? 15 : 11)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showDanaDialog(AppPalette C, bool isComic, bool isHud) {
    final amountText = _amountCtrl.text.replaceAll('.', '').trim();
    final amount = int.tryParse(amountText) ?? 0;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.9),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    width: 42, height: 42,
                    decoration: isHud
                        ? BoxDecoration(
                            color: const Color(0xFF118EEA)
                                .withOpacity(0.15),
                            border: Border.all(
                                color: const Color(0xFF118EEA),
                                width: 1.2),
                            boxShadow: [
                              BoxShadow(
                                  color: const Color(0xFF118EEA)
                                      .withOpacity(0.5),
                                  blurRadius: 10),
                            ],
                          )
                        : BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: isComic ? null
                                : RadialGradient(colors: [
                                    const Color(0xFF118EEA).withOpacity(0.6),
                                    const Color(0xFF118EEA).withOpacity(0.2),
                                    Colors.black]),
                            color: isComic ? const Color(0xFF118EEA) : null,
                            border: Border.all(
                                color: isComic
                                    ? Colors.black
                                    : const Color(0xFF118EEA),
                                width: isComic ? 3 : 2),
                          ),
                    child: Icon(Icons.account_balance_wallet_rounded,
                        color: isComic
                            ? C.contrastTextOn(const Color(0xFF118EEA))
                            : (isHud ? const Color(0xFF118EEA) : Colors.white),
                        size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text('TRANSFER KE DANA',
                        style: TextStyle(
                          color: isComic
                              ? C.comicText
                              : (isHud ? C.hudNeon() : C.accent),
                          fontSize: isComic ? 18 : 14,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                          shadows: isHud
                              ? [
                                  Shadow(
                                      color: C.accent.withOpacity(0.5),
                                      blurRadius: 8),
                                ]
                              : null)),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isComic ? C.bg : C.bgDeep,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : const Color(0xFF118EEA),
                      width: isComic ? 3 : 1.5),
                  boxShadow: isHud
                      ? [
                          BoxShadow(
                              color: const Color(0xFF118EEA)
                                  .withOpacity(0.4),
                              blurRadius: 12),
                        ]
                      : null,
                ),
                child: Column(
                  children: [
                    Text('NOMOR DANA',
                        style: TextStyle(
                          color: isComic
                              ? C.comicTextSub
                              : (isHud ? C.hudTextDim() : C.textSub),
                          fontSize: isComic ? 11 : 9,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.5)),
                    const SizedBox(height: 6),
                    Text(_danaNumber,
                        style: TextStyle(
                          color: isComic
                              ? C.comicText
                              : (isHud ? C.hudText() : C.text),
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontSize: isComic ? 22 : 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1)),
                    const SizedBox(height: 4),
                    Text('a/n $_danaName',
                        style: TextStyle(
                          color: isComic
                              ? C.comicTextSub
                              : (isHud ? C.hudTextDim() : C.textSub),
                          fontSize: isComic ? 12 : 10,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono')),
                    const SizedBox(height: 12),
                    _IndustrialButton(
                      C: C,
                      color: const Color(0xFF118EEA),
                      height: 40,
                      onTap: () {
                        Clipboard.setData(
                            const ClipboardData(text: _danaNumber));
                        HapticFeedback.lightImpact();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Nomor DANA disalin!'),
                            backgroundColor: Colors.green,
                            behavior: SnackBarBehavior.floating,
                            duration: Duration(seconds: 2),
                          ),
                        );
                      },
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.copy_rounded, size: 14),
                          SizedBox(width: 6),
                          Text('COPY NOMOR',
                              style: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.5, fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              if (amount > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: isHud
                        ? C.accent.withOpacity(0.15)
                        : (isComic ? C.primaryHi : C.primaryLo),
                    borderRadius: BorderRadius.circular(isComic ? 12 : 8),
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : (isHud ? C.accent : C.primaryHi),
                        width: isComic ? 3 : 1.5),
                    boxShadow: isHud
                        ? [
                            BoxShadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 10),
                          ]
                        : null,
                  ),
                  child: Text(
                    'Transfer: Rp ${_formatPrice(amount)}',
                    style: TextStyle(
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : (isHud ? C.hudNeon() : Colors.white),
                      fontSize: isComic ? 14 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 0.5,
                      shadows: isHud
                          ? [
                              Shadow(
                                  color: C.accent.withOpacity(0.6),
                                  blurRadius: 6),
                            ]
                          : null),
                  ),
                ),
              const SizedBox(height: 18),
              _IndustrialButton(
                C: C,
                color: isHud ? C.accent : C.primaryHi, height: 46,
                onTap: () => Navigator.pop(ctx),
                child: Text('OKE, SAYA BAYAR',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2.5,
                      fontSize: isComic ? 15 : 11)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submit(AppPalette C, bool isComic, bool isHud) async {
    final amountText = _amountCtrl.text.replaceAll('.', '').trim();
    final amount = int.tryParse(amountText) ?? 0;

    if (amount < 1000) {
      _showSnack('Minimal Rp 1.000', isError: true);
      return;
    }

    if (_paymentMethod == null) {
      _showSnack('Pilih metode pembayaran dulu!', isError: true);
      return;
    }

    if (_proofImage == null) {
      _showSnack('Upload bukti transfer dulu!', isError: true);
      return;
    }

    if (_namaPanggilanCtrl.text.trim().length < 2) {
      _showSnack('Isi nama panggilan lu!', isError: true);
      return;
    }

    if (_namaAkunCtrl.text.trim().length < 2) {
      _showSnack('Isi nama akun app lu!', isError: true);
      return;
    }

    setState(() => _isUploading = true);

    try {
      final uri = Uri.parse('$_kBaseUrl/store-uang');
      final request = http.MultipartRequest('POST', uri);

      request.fields['username'] = widget.username;
      request.fields['sessionKey'] = widget.sessionKey;
      request.fields['amount'] = amount.toString();
      request.fields['paymentMethod'] = _paymentMethod!;
      request.fields['namaPanggilan'] = _namaPanggilanCtrl.text.trim();
      request.fields['namaAkun'] = _namaAkunCtrl.text.trim();

      final fileName = _proofImage!.path.split('/').last;
      final ext = fileName.contains('.')
          ? fileName.split('.').last.toLowerCase()
          : 'jpg';

      String mimeType = 'image/jpeg';
      if (ext == 'png') mimeType = 'image/png';
      if (ext == 'gif') mimeType = 'image/gif';
      if (ext == 'webp') mimeType = 'image/webp';

      request.files.add(await http.MultipartFile.fromPath(
        'proof', _proofImage!.path,
        contentType: MediaType.parse(mimeType),
      ));

      final response = await request.send();
      final responseData = await response.stream.bytesToString();
      final json = jsonDecode(responseData);

      if (!mounted) return;

      if (json['valid'] == true) {
        _showSuccessDialog(C, isComic, isHud, amount);
        setState(() {
          _amountCtrl.clear();
          _paymentMethod = null;
          _proofImage = null;
        });
      } else {
        _showSnack(json['message'] ?? 'Gagal kirim', isError: true);
      }
    } catch (e) {
      if (mounted) _showSnack('Error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  void _showSuccessDialog(AppPalette C, bool isComic, bool isHud, int amount) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.9),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 70, height: 70,
                    decoration: isHud
                        ? BoxDecoration(
                            color: C.accent.withOpacity(0.15),
                            border: Border.all(
                                color: C.accent, width: 1.5),
                            boxShadow: [
                              BoxShadow(
                                  color: C.accent.withOpacity(0.5),
                                  blurRadius: 15),
                            ],
                          )
                        : BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: isComic ? null : RadialGradient(
                                colors: [C.primaryHi, C.primary, Colors.black]),
                            color: isComic ? C.primaryHi : null,
                            border: Border.all(
                                color: isComic ? Colors.black : C.primaryHi,
                                width: isComic ? 5 : 3),
                          ),
                    child: Icon(Icons.check_rounded,
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : (isHud ? C.hudNeon() : C.primaryHi),
                        size: 36),
                  ),
                  if (!isComic)
                    Positioned(top: 0, right: 0,
                        child: _Led(color: C.primaryHi, size: 10,
                            blink: true)),
                ],
              ),
              const SizedBox(height: 20),
              Text('STORE UANG TERKIRIM!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.accent),
                    fontSize: isComic ? 20 : 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2,
                    shadows: isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 8),
                          ]
                        : null)),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                decoration: BoxDecoration(
                  color: isHud
                      ? C.accent.withOpacity(0.15)
                      : (isComic ? C.primaryHi : C.primaryLo),
                  borderRadius: BorderRadius.circular(isComic ? 12 : 8),
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : (isHud ? C.accent : C.primaryHi),
                      width: isComic ? 3 : 1.5),
                  boxShadow: isHud
                      ? [
                          BoxShadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 10),
                        ]
                      : null,
                ),
                child: Text(
                  'Rp ${_formatPrice(amount)}',
                  style: TextStyle(
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.hudNeon() : Colors.white),
                    fontSize: isComic ? 18 : 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1,
                    shadows: isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.6),
                                blurRadius: 6),
                          ]
                        : null),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Terima kasih telah store uang ke admin,\n'
                'jangan lupa untuk store lagi ya 🤑',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicText.withOpacity(0.9)
                      : (isHud ? C.hudText() : C.text.withOpacity(0.85)),
                  fontSize: isComic ? 14 : 12,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.6,
                  fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 10),
              Text(
                'Bukti transfer udah masuk ke admin.\n'
                'Admin bakal konfirmasi dalam waktu dekat.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud ? C.hudTextDim() : C.text.withOpacity(0.55)),
                  fontSize: isComic ? 12 : 10,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.5),
              ),
              const SizedBox(height: 20),
              _IndustrialButton(
                C: C, color: isHud ? C.accent : C.primaryHi, height: 46,
                onTap: () => Navigator.pop(ctx),
                child: Text('OKE, MANTAP!',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2.5, fontSize: isComic ? 16 : 12)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnack(String msg, {bool isError = false}) {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: C.primaryHi, size: 8, blink: !isComic),
            const SizedBox(width: 10),
            Expanded(child: Text(msg,
                style: TextStyle(fontWeight: FontWeight.w700,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudText() : C.text)))),
          ],
        ),
        backgroundColor: isHud ? C.hudPanel() : C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(
              color: C.primaryHi,
              width: isComic ? 3 : 1.5)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  String _formatPrice(int price) {
    final str = price.toString();
    final buffer = StringBuffer();
    for (int i = 0; i < str.length; i++) {
      if (i > 0 && (str.length - i) % 3 == 0) buffer.write('.');
      buffer.write(str[i]);
    }
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              radius: 1.2,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                              stops: const [0.0, 0.6, 1.0])),
                          ),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12))))),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine())))),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildAppBar(C, isComic, isHud),
                          const SizedBox(height: 10),
                          Expanded(
                            child: SingleChildScrollView(
                              padding:
                                  const EdgeInsets.fromLTRB(14, 4, 14, 32),
                              physics: const BouncingScrollPhysics(),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _buildMainHeader(C, isComic, isHud),
                                  const SizedBox(height: 20),
                                  _buildSectionTitle(C, isComic, isHud,
                                      '1. MASUKKIN JUMLAH UANG',
                                      Icons.attach_money_rounded),
                                  const SizedBox(height: 10),
                                  _buildAmountInput(C, isComic, isHud),
                                  const SizedBox(height: 20),
                                  _buildSectionTitle(C, isComic, isHud,
                                      '2. PILIH METODE PEMBAYARAN',
                                      Icons.payment_rounded),
                                  const SizedBox(height: 10),
                                  _buildPaymentMethodRow(C, isComic, isHud),
                                  const SizedBox(height: 12),
                                  _buildShowPaymentButton(C, isComic, isHud),
                                  const SizedBox(height: 20),
                                  _buildSectionTitle(C, isComic, isHud,
                                      '3. UPLOAD BUKTI TRANSFER',
                                      Icons.cloud_upload_rounded),
                                  const SizedBox(height: 10),
                                  _buildUploadArea(C, isComic, isHud),
                                  const SizedBox(height: 20),
                                  _buildSectionTitle(C, isComic, isHud,
                                      '4. DATA LU',
                                      Icons.person_rounded),
                                  const SizedBox(height: 10),
                                  _buildUserData(C, isComic, isHud),
                                  const SizedBox(height: 22),
                                  _IndustrialButton(
                                    C: C,
                                    color: _isUploading
                                        ? C.bg
                                        : (isHud ? C.accent : C.primaryHi),
                                    height: 56,
                                    onTap: _isUploading
                                        ? null
                                        : () => _submit(C, isComic, isHud),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        if (_isUploading)
                                          SizedBox(
                                            width: 18, height: 18,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2.5,
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                      C.accent)))
                                        else
                                          const Icon(Icons.store_rounded, size: 18),
                                        const SizedBox(width: 10),
                                        Text(
                                          _isUploading
                                              ? 'MENGIRIM...'
                                              : 'STORE UANG',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w900,
                                            fontFamily: isComic
                                                ? 'Bangers'
                                                : 'Orbitron',
                                            letterSpacing: 2,
                                            fontSize: isComic ? 16 : 13),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  Text(
                                    'Uang yang udah dikirim ga bisa ditarik kembali.\n'
                                    'Pastiin jumlahnya bener sebelum kirim ya.',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicTextSub
                                          : (isHud
                                              ? C.hudTextDim()
                                              : C.text.withOpacity(0.5)),
                                      fontSize: isComic ? 12 : 10,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                      height: 1.5),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 40, height: 40,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border:
                            Border.all(color: C.accent, width: 1.2),
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: isComic ? null
                            : LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [C.textSub, C.bg, C.bgDark]),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : Colors.black.withOpacity(0.7),
                            width: isComic ? 3 : 1.2),
                        boxShadow: isComic
                            ? const [
                                BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(3, 3),
                                    blurRadius: 0),
                              ]
                            : null,
                      ),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : (isHud ? C.hudNeon() : C.accent),
                    size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border:
                              Border.all(color: C.accent, width: 1.2),
                          boxShadow: [
                            BoxShadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 10),
                          ],
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic ? null
                              : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                              color: isComic ? Colors.black : C.primaryHi,
                              width: isComic ? 3 : 2)),
                  child: Icon(Icons.account_balance_wallet_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : (isHud ? C.hudNeon() : C.primaryHi),
                      size: 20),
                ),
                if (!isComic)
                  Positioned(top: -2, right: -2,
                      child: _Led(color: C.primaryHi, size: 6, blink: true)),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('STORE UANG',
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accentHi),
                        fontSize: isComic ? 18 : 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 2, height: 1,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : (isHud
                                ? [
                                    Shadow(
                                        color: C.accent
                                            .withOpacity(0.5),
                                        blurRadius: 8),
                                  ]
                                : [
                                    Shadow(color: C.primaryLo,
                                        offset: const Offset(0, 1),
                                        blurRadius: 1),
                                    const Shadow(color: Colors.black,
                                        offset: Offset(0, 2),
                                        blurRadius: 3),
                                  ]),
                      )),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(color: C.primaryHi, size: 4, blink: !isComic),
                      const SizedBox(width: 5),
                      Text('KIRIM KE ADMIN',
                          style: TextStyle(
                            color: isComic
                                ? C.comicTextSub
                                : (isHud
                                    ? C.hudTextDim()
                                    : C.text.withOpacity(0.55)),
                            fontSize: 8,
                            fontWeight: FontWeight.w700,
                            fontFamily:
                                isComic ? 'ComicNeue' : 'ShareTechMono',
                            letterSpacing: 1.2)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainHeader(AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(20),
      brass: !isComic && !isHud,
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 56, height: 56,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border: Border.all(color: C.accent, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 15),
                        ],
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isComic ? null
                            : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                        color: isComic ? C.primaryHi : null,
                        border: Border.all(
                            color: isComic ? Colors.black : C.accent,
                            width: isComic ? 4 : 2.5)),
                child: Icon(Icons.storefront_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : (isHud ? C.hudNeon() : C.accent),
                    size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('STORE UANG KE ADMIN',
                        style: TextStyle(
                          color: isComic
                              ? C.comicText
                              : (isHud ? C.hudNeon() : C.accentHi),
                          fontSize: isComic ? 20 : 15,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.5,
                          height: 1.1,
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : (isHud
                                  ? [
                                      Shadow(
                                          color: C.accent
                                              .withOpacity(0.5),
                                          blurRadius: 8),
                                    ]
                                  : null))),
                    const SizedBox(height: 6),
                    Text(
                      'Kirim uang lu ke admin, langsung masuk notif.\n'
                      'Uang ga bisa ditarik kembali.',
                      style: TextStyle(
                        color: isComic
                            ? C.comicText.withOpacity(0.85)
                            : (isHud
                                ? C.hudText()
                                : C.text.withOpacity(0.7)),
                        fontSize: isComic ? 12 : 10,
                        fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                        height: 1.5,
                        fontWeight: isComic ? FontWeight.w700 : null),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(AppPalette C, bool isComic, bool isHud,
      String title, IconData icon) {
    return Row(
      children: [
        Container(
          width: 28, height: 28,
          decoration: isHud
              ? BoxDecoration(
                  color: C.accent.withOpacity(0.15),
                  border: Border.all(color: C.accent, width: 1.2),
                  boxShadow: [
                    BoxShadow(
                        color: C.accent.withOpacity(0.4),
                        blurRadius: 6),
                  ],
                )
              : BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isComic ? null
                      : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                  color: isComic ? C.primaryHi : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 3 : 1.5)),
          child: Icon(icon,
              color: isComic
                  ? C.contrastTextOn(C.primaryHi)
                  : (isHud ? C.hudNeon() : C.accent),
              size: 14),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(title,
              style: TextStyle(
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudNeon() : C.accent),
                fontSize: isComic ? 14 : 11,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 1.5,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : (isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 6),
                          ]
                        : null))),
        ),
        if (!isComic && !isHud) _Rivet(C: C, size: 6),
      ],
    );
  }

  Widget _buildAmountInput(AppPalette C, bool isComic, bool isHud) {
    return Column(
      children: [
        _MetalPlate(
          C: C,
          padding: EdgeInsets.zero,
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 18, vertical: 20),
                decoration: isHud
                    ? BoxDecoration(
                        color: C.accent.withOpacity(0.15),
                        border: Border(
                          right: BorderSide(color: C.accent, width: 1.2),
                        ),
                      )
                    : BoxDecoration(
                        gradient: isComic ? null
                            : LinearGradient(colors: [C.primaryHi, C.primaryLo]),
                        color: isComic ? C.primaryHi : null,
                        borderRadius: const BorderRadius.horizontal(
                            left: Radius.circular(13))),
                child: Text('Rp',
                    style: TextStyle(
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : (isHud ? C.hudNeon() : Colors.white),
                      fontSize: isComic ? 20 : 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.contrastTextOn(C.primaryHi) ==
                                        Colors.white
                                    ? Colors.black
                                    : Colors.white,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : (isHud
                              ? [
                                  Shadow(
                                      color: C.accent.withOpacity(0.6),
                                      blurRadius: 6),
                                ]
                              : const [
                                  Shadow(
                                      color: Colors.black38,
                                      offset: Offset(0, 1),
                                      blurRadius: 2)
                                ]))),
              ),
              Expanded(
                child: TextField(
                  controller: _amountCtrl,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudText() : C.text),
                    fontSize: isComic ? 22 : 20,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 0.5),
                  cursorColor: isComic
                      ? Colors.black
                      : (isHud ? C.accent : C.primaryHi),
                  decoration: InputDecoration(
                    hintText: '0',
                    hintStyle: TextStyle(
                      color: isComic ? C.comicTextMuted : C.textSub,
                      fontSize: isComic ? 22 : 20,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron'),
                    border: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16))),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: [5000, 10000, 25000, 50000, 100000, 250000]
              .map((amt) => GestureDetector(
                    onTap: () {
                      HapticFeedback.selectionClick();
                      setState(() => _amountCtrl.text = amt.toString());
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: isHud
                          ? BoxDecoration(
                              color: C.accent.withOpacity(0.15),
                              border: Border.all(
                                  color: C.accent, width: 1.2),
                              boxShadow: [
                                BoxShadow(
                                    color: C.accent.withOpacity(0.4),
                                    blurRadius: 8),
                              ],
                            )
                          : BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(isComic ? 10 : 8),
                              gradient: isComic
                                  ? null
                                  : LinearGradient(colors: [
                                      C.textSub.withOpacity(0.9),
                                      C.bg.withOpacity(0.7)]),
                              color: isComic ? C.accent : null,
                              border: Border.all(
                                  color: isComic
                                      ? Colors.black
                                      : C.accent.withOpacity(0.5),
                                  width: isComic ? 2.5 : 1.2)),
                      child: Text('Rp ${_formatPrice(amt)}',
                          style: TextStyle(
                            color: isComic
                                ? C.contrastTextOn(C.accent)
                                : (isHud ? C.hudNeon() : C.accentShine),
                            fontSize: isComic ? 13 : 11,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 0.5,
                            shadows: isHud
                                ? [
                                    Shadow(
                                        color: C.accent
                                            .withOpacity(0.5),
                                        blurRadius: 4),
                                  ]
                                : null)),
                    ),
                  ))
              .toList(),
        ),
      ],
    );
  }

  Widget _buildPaymentMethodRow(
      AppPalette C, bool isComic, bool isHud) {
    return Row(
      children: [
        Expanded(
          child: _PaymentCard(
            C: C,
            isComic: isComic,
            isHud: isHud,
            id: 'qris',
            label: 'QRIS',
            subtitle: 'Scan QR',
            icon: Icons.qr_code_2_rounded,
            color: isHud ? C.accent : C.accentHi,
            isSelected: _paymentMethod == 'qris',
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _paymentMethod = 'qris');
            },
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _PaymentCard(
            C: C,
            isComic: isComic,
            isHud: isHud,
            id: 'dana',
            label: 'DANA',
            subtitle: 'Transfer manual',
            icon: Icons.account_balance_wallet_rounded,
            color: const Color(0xFF118EEA),
            isSelected: _paymentMethod == 'dana',
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _paymentMethod = 'dana');
            },
          ),
        ),
      ],
    );
  }

  Widget _buildShowPaymentButton(
      AppPalette C, bool isComic, bool isHud) {
    if (_paymentMethod == null) {
      return _InsetPanel(
        C: C,
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.touch_app_rounded,
                color: isComic
                    ? C.comicTextSub
                    : (isHud ? C.hudTextDim() : C.textSub),
                size: 16),
            const SizedBox(width: 8),
            Text('PILIH METODE DULU',
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud ? C.hudTextDim() : C.textSub),
                  fontSize: isComic ? 13 : 10,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 1.5)),
          ],
        ),
      );
    }

    if (_paymentMethod == 'qris') {
      return _IndustrialButton(
        C: C,
        color: isHud ? C.accent : C.accentHi,
        height: 50,
        onTap: () => _showQrisDialog(C, isComic, isHud),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.qr_code_scanner_rounded, size: 16),
            SizedBox(width: 8),
            Text('TAMPILKAN QRIS',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                  fontSize: 11)),
          ],
        ),
      );
    }

    return _IndustrialButton(
      C: C,
      color: const Color(0xFF118EEA),
      height: 50,
      onTap: () => _showDanaDialog(C, isComic, isHud),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.account_balance_wallet_rounded, size: 16),
          SizedBox(width: 8),
          Text('TAMPILKAN NOMOR DANA',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 2,
                fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildUploadArea(AppPalette C, bool isComic, bool isHud) {
    if (_proofImage != null) {
      return _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.file(_proofImage!,
                  width: double.infinity, height: 240, fit: BoxFit.cover),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _IndustrialButton(
                  C: C, color: isHud ? C.accent : C.accent, height: 44,
                  onTap: () => _showImageOptions(C, isComic, isHud),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.refresh_rounded, size: 14),
                      SizedBox(width: 6),
                      Text('GANTI', style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron', letterSpacing: 2,
                        fontSize: 11)),
                    ],
                  ),
                )),
                const SizedBox(width: 8),
                Expanded(child: _IndustrialButton(
                  C: C, color: isHud ? C.primaryHi : C.primaryHi, height: 44,
                  onTap: () => setState(() => _proofImage = null),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.delete_rounded, size: 14),
                      SizedBox(width: 6),
                      Text('HAPUS', style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron', letterSpacing: 2,
                        fontSize: 11)),
                    ],
                  ),
                )),
              ],
            ),
          ],
        ),
      );
    }

    return GestureDetector(
      onTap: () => _showImageOptions(C, isComic, isHud),
      child: _InsetPanel(
        C: C,
        padding: const EdgeInsets.symmetric(vertical: 44),
        child: Column(
          children: [
            Container(
              width: 64, height: 64,
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border: Border.all(color: C.accent, width: 1.2),
                      boxShadow: [
                        BoxShadow(
                            color: C.accent.withOpacity(0.5),
                            blurRadius: 12),
                      ],
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic ? null
                          : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color: isComic ? Colors.black : C.accent,
                          width: isComic ? 4 : 2)),
              child: Icon(Icons.cloud_upload_rounded,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : C.accent),
                  size: 28,
                  shadows: isHud
                      ? [
                          Shadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 6),
                        ]
                      : null),
            ),
            const SizedBox(height: 14),
            Text('TAP UNTUK UPLOAD',
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudNeon() : C.accent),
                  fontSize: isComic ? 16 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 1.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : (isHud
                          ? [
                              Shadow(
                                  color: C.accent.withOpacity(0.5),
                                  blurRadius: 6),
                            ]
                          : null))),
            const SizedBox(height: 4),
            Text('Format: JPG / PNG',
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : (isHud ? C.hudTextDim() : C.text.withOpacity(0.5)),
                  fontSize: isComic ? 12 : 10,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildUserData(AppPalette C, bool isComic, bool isHud) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          _buildTextField(
            C: C,
            isComic: isComic,
            isHud: isHud,
            controller: _namaPanggilanCtrl,
            label: 'NAMA PANGGILAN',
            icon: Icons.person_outline_rounded,
            hint: 'Contoh: Budi / Om Budi',
          ),
          const SizedBox(height: 12),
          _buildTextField(
            C: C,
            isComic: isComic,
            isHud: isHud,
            controller: _namaAkunCtrl,
            label: 'NAMA AKUN APP',
            icon: Icons.account_circle_outlined,
            hint: 'Username login app lu',
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required AppPalette C,
    required bool isComic,
    required bool isHud,
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required String hint,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            label,
            style: TextStyle(
              color: isComic
                  ? C.comicText
                  : (isHud ? C.hudNeon() : C.accent),
              fontSize: isComic ? 11 : 9,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 1.5,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : (isHud
                      ? [
                          Shadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 4),
                        ]
                      : null),
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: isHud
              ? BoxDecoration(
                  color: C.bgDeep.withOpacity(0.6),
                  border: Border.all(
                      color: C.accent.withOpacity(0.5), width: 1.2),
                  boxShadow: [
                    BoxShadow(
                        color: C.accent.withOpacity(0.2),
                        blurRadius: 6),
                  ],
                )
              : BoxDecoration(
                  color: isComic ? C.bg : C.bgDeep,
                  borderRadius: BorderRadius.circular(isComic ? 10 : 8),
                  border: Border.all(
                    color: isComic ? Colors.black : C.bgDark,
                    width: isComic ? 3 : 1.5,
                  ),
                ),
          child: Row(
            children: [
              Icon(
                icon,
                color: isComic
                    ? C.comicText
                    : (isHud ? C.hudNeon() : C.accent),
                size: 18,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudText() : C.text),
                    fontSize: isComic ? 14 : 12,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                  cursorColor: isComic
                      ? C.comicText
                      : (isHud ? C.accent : C.accent),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 16),
                    hintText: hint,
                    hintStyle: TextStyle(
                      color: isComic
                          ? C.comicTextMuted
                          : (isHud
                              ? C.hudTextDim()
                              : C.textSub.withOpacity(0.5)),
                      fontSize: isComic ? 12 : 11,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ══════════════════════════════════════════════════════════════
// PAYMENT CARD
// ══════════════════════════════════════════════════════════════
class _PaymentCard extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final bool isHud;
  final String id;
  final String label;
  final String subtitle;
  final IconData icon;
  final Color color;
  final bool isSelected;
  final VoidCallback onTap;

  const _PaymentCard({
    required this.C,
    required this.isComic,
    required this.isHud,
    required this.id,
    required this.label,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
        decoration: isHud
            ? BoxDecoration(
                color: isSelected
                    ? color.withOpacity(0.2)
                    : color.withOpacity(0.05),
                border: Border.all(
                  color: isSelected ? color : color.withOpacity(0.3),
                  width: isSelected ? 1.4 : 1,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                            color: color.withOpacity(0.5),
                            blurRadius: 12),
                      ]
                    : null,
              )
            : BoxDecoration(
                color: isComic
                    ? (isSelected ? color : C.bgDark)
                    : (isSelected ? color.withOpacity(0.15) : C.bgDark),
                borderRadius: BorderRadius.circular(isComic ? 14 : 12),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (isSelected ? color : C.textSub.withOpacity(0.3)),
                  width: isComic
                      ? (isSelected ? 4 : 3)
                      : (isSelected ? 2 : 1),
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        if (isSelected)
                          BoxShadow(
                              color: color.withOpacity(0.4),
                              blurRadius: 12),
                      ],
              ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isComic
                  ? (isSelected ? Colors.white : C.comicText)
                  : color,
              size: 32,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: isComic
                    ? (isSelected ? Colors.white : C.comicText)
                    : (isSelected ? color : C.text),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontSize: isComic ? 16 : 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              style: TextStyle(
                color: isComic
                    ? (isSelected
                        ? Colors.white.withOpacity(0.85)
                        : C.comicTextSub)
                    : (isSelected ? color : C.textSub),
                fontSize: isComic ? 11 : 9,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w600,
              ),
            ),
            if (isSelected) ...[
              const SizedBox(height: 6),
              Icon(
                Icons.check_circle_rounded,
                color: isComic ? Colors.white : color,
                size: 16,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ══════════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}