// lib/cakun.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'services/cakun_service.dart';

// ═══════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});
  @override
  Widget build(BuildContext context) {
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }
  Widget _dot(double opacity) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.85), width: size * 0.1),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.75 * opacity), blurRadius: size * 1.4, spreadRadius: size * 0.2),
            BoxShadow(color: color.withOpacity(0.35 * opacity), blurRadius: size * 2.6, spreadRadius: size * 0.4),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [C.text, C.textSub, C.bgDark, C.bgDeep],
            stops: const [0.0, 0.35, 0.7, 1.0],
          ),
        ),
        child: Center(
          child: Transform.rotate(
            angle: 0.785,
            child: Container(
              width: size * 0.7, height: size * 0.11,
              color: Colors.black.withOpacity(0.9),
            ),
          ),
        ),
      );
}

// ═══════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
            stops: const [0.0, 0.3, 0.65, 1.0],
          ),
        ),
      );
}

// ═══════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  const _MetalPlate({required this.C, required this.child, this.padding = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.textSub, C.bgDark, C.bgDeep, C.bg],
            stops: const [0.0, 0.4, 0.7, 1.0],
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.75), offset: const Offset(0, 6), blurRadius: 12),
          ],
        ),
        padding: const EdgeInsets.all(3),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(13),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [C.bgDark, C.bg, C.bgDeep],
            ),
            border: Border.all(color: Colors.black.withOpacity(0.5)),
          ),
          child: child,
        ),
      );
}

// ═══════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ═══════════════════════════════════════════════════════
class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });
  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);
    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled ? (_) { setState(() => _pressed = false); widget.onTap?.call(); } : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin: _pressed ? Alignment.bottomCenter : Alignment.topCenter,
            end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
            colors: _pressed ? [dark, dark, widget.color] : [light, widget.color, dark],
            stops: const [0.0, 0.5, 1.0],
          ),
          boxShadow: _pressed
              ? [BoxShadow(color: Colors.black.withOpacity(0.9), offset: const Offset(0, 1), blurRadius: 3)]
              : [
                  BoxShadow(color: widget.color.withOpacity(0.45), offset: const Offset(0, 5), blurRadius: 10, spreadRadius: -2),
                  BoxShadow(color: Colors.black.withOpacity(0.75), offset: const Offset(0, 4), blurRadius: 6),
                ],
          border: Border.all(color: dark.withOpacity(0.9), width: 1.5),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(top: 5, left: 5, child: _Rivet(C: widget.C, size: 6)),
            Positioned(top: 5, right: 5, child: _Rivet(C: widget.C, size: 6)),
            Positioned(bottom: 5, left: 5, child: _Rivet(C: widget.C, size: 6)),
            Positioned(bottom: 5, right: 5, child: _Rivet(C: widget.C, size: 6)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Opacity(opacity: enabled ? 1 : 0.5, child: widget.child),
            ),
          ],
        ),
      ),
    );
  }
  static Color _lighten(Color c) => Color.fromARGB(c.alpha, (c.red + 40).clamp(0, 255), (c.green + 40).clamp(0, 255), (c.blue + 30).clamp(0, 255));
  static Color _darken(Color c) => Color.fromARGB(c.alpha, (c.red - 60).clamp(0, 255), (c.green - 50).clamp(0, 255), (c.blue - 40).clamp(0, 255));
}

// ═══════════════════════════════════════════════════════
// SKEO TEXT FIELD
// ═══════════════════════════════════════════════════════
class _SkeuoField extends StatelessWidget {
  final AppPalette C;
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool numericOnly;
  final String? Function(String?)? validator;
  const _SkeuoField({
    required this.C,
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.numericOnly = false,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _Rivet(C: C, size: 6),
              const SizedBox(width: 6),
              Text(label,
                  style: TextStyle(
                    color: C.accent,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  )),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [C.bgDeep, C.bg],
              ),
              border: Border.all(color: C.bgDark, width: 1.2),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.9), offset: const Offset(0, 2), blurRadius: 3),
              ],
            ),
            child: TextFormField(
              controller: controller,
              validator: validator,
              keyboardType: numericOnly ? TextInputType.number : TextInputType.text,
              inputFormatters: numericOnly ? [FilteringTextInputFormatter.digitsOnly] : null,
              style: TextStyle(
                color: C.accentHi,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.5,
              ),
              cursorColor: C.primaryHi,
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(
                  color: C.text.withOpacity(0.3),
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
                prefixIcon: Icon(icon, color: C.accent, size: 18),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// COPYABLE ROW
// ═══════════════════════════════════════════════════════
class _CopyableResultRow extends StatefulWidget {
  final AppPalette C;
  final String label;
  final String value;
  final Color color;
  final IconData copyIcon;
  const _CopyableResultRow({
    required this.C,
    required this.label,
    required this.value,
    required this.color,
    this.copyIcon = Icons.copy_rounded,
  });

  @override
  State<_CopyableResultRow> createState() => _CopyableResultRowState();
}

class _CopyableResultRowState extends State<_CopyableResultRow> {
  bool _copied = false;
  bool _pressed = false;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.value));
    HapticFeedback.lightImpact();
    setState(() => _copied = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 78,
            child: Text(
              widget.label,
              style: TextStyle(
                color: C.text.withOpacity(0.55),
                fontSize: 9,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1,
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTapDown: (_) => setState(() => _pressed = true),
              onTapUp: (_) {
                setState(() => _pressed = false);
                _copy();
              },
              onTapCancel: () => setState(() => _pressed = false),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 120),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: _copied
                      ? C.primaryHi.withOpacity(0.15)
                      : Colors.black.withOpacity(0.5),
                  border: Border.all(
                    color: _copied
                        ? C.primaryHi
                        : (_pressed ? widget.color : widget.color.withOpacity(0.4)),
                    width: _pressed ? 1.5 : 1,
                  ),
                  boxShadow: _copied
                      ? [BoxShadow(color: C.primaryHi.withOpacity(0.4), blurRadius: 8, spreadRadius: 1)]
                      : null,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        widget.value,
                        style: TextStyle(
                          color: _copied ? C.primaryHi : widget.color,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                          shadows: [
                            Shadow(
                              color: (_copied ? C.primaryHi : widget.color).withOpacity(0.5),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 200),
                      child: _copied
                          ? Icon(Icons.check_circle_rounded, key: const ValueKey('check'), color: C.primaryHi, size: 16)
                          : Icon(widget.copyIcon, key: const ValueKey('copy'), color: widget.color.withOpacity(0.7), size: 14),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// INFO ROW
// ═══════════════════════════════════════════════════════
class _InfoResultRow extends StatelessWidget {
  final AppPalette C;
  final String label;
  final String value;
  final Color color;
  const _InfoResultRow({required this.C, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 78,
            child: Text(
              label,
              style: TextStyle(
                color: C.text.withOpacity(0.55),
                fontSize: 9,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1,
              ),
            ),
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: Colors.black.withOpacity(0.5),
                border: Border.all(color: color.withOpacity(0.4), width: 1),
              ),
              child: Text(
                value,
                style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                  shadows: [Shadow(color: color.withOpacity(0.5), blurRadius: 4)],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// CAKUN PAGE
// ═══════════════════════════════════════════════════════
class CakunPage extends StatefulWidget {
  final String? sessionKey;
  final String? username;
  final String? role;
  const CakunPage({
    super.key,
    this.sessionKey,
    this.username,
    this.role,
  });

  @override
  State<CakunPage> createState() => _CakunPageState();
}

class _CakunPageState extends State<CakunPage> {
  final _formKey = GlobalKey<FormState>();
  final _usernameCtrl = TextEditingController();
  final _telegramIdCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  bool _loading = false;
  bool _useCustomPassword = false;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
  }

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _telegramIdCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit(AppPalette C) async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);

    final res = await CakunService.createAkun(
      username: _usernameCtrl.text.trim(),
      telegramId: _telegramIdCtrl.text.trim(),
      password: _useCustomPassword && _passwordCtrl.text.trim().isNotEmpty
          ? _passwordCtrl.text.trim()
          : null,
    );

    if (!mounted) return;
    setState(() => _loading = false);

    if (res.success) {
      HapticFeedback.mediumImpact();
      _showResultDialog(C, res.data!);
      _usernameCtrl.clear();
      _telegramIdCtrl.clear();
      _passwordCtrl.clear();
      setState(() => _useCustomPassword = false);
    } else {
      HapticFeedback.heavyImpact();
      _showSnack(C, res.message ?? 'Error', C.primaryHi);
    }
  }

  void _showSnack(AppPalette C, String msg, Color c) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: c, size: 8, blink: true),
            const SizedBox(width: 10),
            Expanded(
              child: Text(msg,
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
        backgroundColor: C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: c, width: 1.5),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _showResultDialog(AppPalette C, AkunData data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(16),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(18),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    _Led(color: C.primaryHi, size: 10, blink: true),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'AKUN BERHASIL',
                        style: TextStyle(
                          color: C.accent,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(ctx),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: C.bgDark,
                          border: Border.all(color: C.primaryHi, width: 1),
                        ),
                        child: Icon(Icons.close, color: C.accent, size: 16),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: C.accent.withOpacity(0.15),
                    border: Border.all(color: C.accent.withOpacity(0.6), width: 0.8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.touch_app_rounded, color: C.accent, size: 11),
                      const SizedBox(width: 5),
                      Text(
                        'Tap username / password untuk copy',
                        style: TextStyle(
                          color: C.accent.withOpacity(0.95),
                          fontSize: 9,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                _CopyableResultRow(
                  C: C,
                  label: 'USERNAME',
                  value: data.username,
                  color: C.accentShine,
                  copyIcon: Icons.person_rounded,
                ),
                _CopyableResultRow(
                  C: C,
                  label: 'PASSWORD',
                  value: data.password,
                  color: C.accent,
                  copyIcon: Icons.key_rounded,
                ),

                _InfoResultRow(C: C, label: 'ROLE', value: data.role.toUpperCase(), color: C.primaryHi),
                _InfoResultRow(C: C, label: 'EXPIRED', value: data.expiredDate, color: C.primaryHi),
                _InfoResultRow(C: C, label: 'PAIR ID', value: data.pairId, color: C.accent),
                _InfoResultRow(C: C, label: 'DURATION', value: '${data.durationDays} HARI', color: C.text),

                const SizedBox(height: 12),

                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    color: C.primaryHi.withOpacity(0.12),
                    border: Border.all(color: C.primaryHi.withOpacity(0.5), width: 1),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.check_circle_rounded, color: C.primaryHi, size: 13),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Akun aktif · Notif terkirim ke group',
                          style: TextStyle(
                            color: C.primaryHi.withOpacity(0.95),
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                _IndustrialButton(
                  C: C,
                  color: C.primaryHi,
                  height: 44,
                  onTap: () async {
                    await Clipboard.setData(ClipboardData(
                      text:
                          '╭─『 ACCOUNT DETAIL 』─⪩\n'
                          'Username: ${data.username}\n'
                          'Password: ${data.password}\n'
                          'Role: ${data.role.toUpperCase()}\n'
                          'Expired: ${data.expiredDate}\n'
                          'PairId: ${data.pairId}\n'
                          '╰─────────────────⪩',
                    ));
                    if (ctx.mounted) Navigator.pop(ctx);
                    _showSnack(C, 'Semua credential dicopy!', C.primaryHi);
                  },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.copy_all_rounded, color: Colors.white, size: 16),
                      SizedBox(width: 8),
                      Text(
                        'COPY SEMUA',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return Scaffold(
          backgroundColor: C.bgDeep,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            iconTheme: IconThemeData(color: C.accent),
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _Led(color: C.primaryHi, size: 6, blink: true),
                const SizedBox(width: 10),
                Text(
                  'CREATE AKUN',
                  style: TextStyle(
                    color: C.accentHi,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
            flexibleSpace: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bgDark, C.bg, C.bgDeep],
                ),
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.3, -0.3),
                radius: 1.2,
                colors: [C.bgDark, C.bg, C.bgDeep],
                stops: const [0.0, 0.6, 1.0],
              ),
            ),
            child: SafeArea(
              child: Form(
                key: _formKey,
                child: ListView(
                  padding: const EdgeInsets.all(14),
                  physics: const BouncingScrollPhysics(),
                  children: [
                    _buildFormPlate(C),
                    const SizedBox(height: 14),
                    _buildInfoPlate(C),
                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildFormPlate(AppPalette C) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _Screw(C: C, size: 12),
              const SizedBox(width: 10),
              Expanded(
                child: Center(
                  child: Text(
                    'FORM CREATE AKUN',
                    style: TextStyle(
                      color: C.accent,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              _Screw(C: C, size: 12),
            ],
          ),
          const SizedBox(height: 16),

          _SkeuoField(
            C: C,
            controller: _usernameCtrl,
            label: 'USERNAME',
            hint: 'minimal 3 karakter',
            icon: Icons.person_rounded,
            validator: (v) {
              if (v == null || v.trim().isEmpty) return 'Username wajib diisi';
              if (v.trim().length < 3) return 'Username minimal 3 karakter';
              return null;
            },
          ),

          _SkeuoField(
            C: C,
            controller: _telegramIdCtrl,
            label: 'TELEGRAM ID',
            hint: 'contoh: 123456789',
            icon: Icons.badge_rounded,
            numericOnly: true,
            validator: (v) {
              if (v == null || v.trim().isEmpty) return 'Telegram ID wajib diisi';
              if (!RegExp(r'^\d+$').hasMatch(v.trim())) return 'Harus angka';
              return null;
            },
          ),

          GestureDetector(
            onTap: () => setState(() => _useCustomPassword = !_useCustomPassword),
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: Colors.black.withOpacity(0.4),
                border: Border.all(
                  color: _useCustomPassword ? C.primaryHi : C.bgDark,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: _useCustomPassword ? C.primaryHi.withOpacity(0.2) : Colors.transparent,
                      border: Border.all(
                        color: _useCustomPassword ? C.primaryHi : C.textSub,
                        width: 1.5,
                      ),
                    ),
                    child: _useCustomPassword
                        ? Icon(Icons.check, color: C.primaryHi, size: 14)
                        : null,
                  ),
                  const SizedBox(width: 10),
                  Icon(Icons.key_rounded, color: C.accent, size: 14),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Pakai password custom',
                      style: TextStyle(
                        color: C.text,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  _Led(color: C.accent, size: 5, blink: true),
                ],
              ),
            ),
          ),

          if (_useCustomPassword)
            _SkeuoField(
              C: C,
              controller: _passwordCtrl,
              label: 'PASSWORD CUSTOM',
              hint: 'minimal 4 karakter',
              icon: Icons.lock_rounded,
              validator: (v) {
                if (!_useCustomPassword) return null;
                if (v == null || v.trim().isEmpty) return 'Password wajib diisi';
                if (v.trim().length < 4) return 'Password minimal 4 karakter';
                return null;
              },
            ),

          const SizedBox(height: 8),

          _IndustrialButton(
            C: C,
            color: _loading ? C.bgDark : C.primaryHi,
            height: 54,
            onTap: _loading ? null : () => _submit(C),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_loading)
                  const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                  )
                else
                  const Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 18),
                const SizedBox(width: 10),
                Text(
                  _loading ? 'MEMPROSES...' : 'CREATE AKUN',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 2,
                    shadows: [
                      Shadow(color: Colors.black54, offset: Offset(0, 1), blurRadius: 2),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoPlate(AppPalette C) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Row(
            children: [
              _Rivet(C: C, size: 8),
              const SizedBox(width: 8),
              Icon(Icons.info_outline, color: C.accent, size: 14),
              const SizedBox(width: 6),
              Text(
                'INFORMASI',
                style: TextStyle(
                  color: C.accent,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _infoLine(C, '• Setiap ID Telegram hanya bisa 1 akun'),
          _infoLine(C, '• Role otomatis: MEMBER'),
          _infoLine(C, '• Duration: 50000 hari (lifetime)'),
          _infoLine(C, '• Password: custom atau auto-generate'),
          _infoLine(C, '• Akun langsung muncul di popup, tap untuk copy'),
        ],
      ),
    );
  }

  Widget _infoLine(AppPalette C, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            text,
            style: TextStyle(
              color: C.text.withOpacity(0.65),
              fontSize: 10,
              fontFamily: 'ShareTechMono',
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}