// verified_slides.dart — 3 Style Support
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';

class VerifiedSlidesPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String sessionKey;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGlobal;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const VerifiedSlidesPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.sessionKey,
    required this.expiredDate,
    required this.listBug,
    this.listBugGlobal = const [],
    this.listBugGroup = const [],
    required this.listDoos,
    required this.news,
  });

  @override
  State<VerifiedSlidesPage> createState() => _VerifiedSlidesPageState();
}

class _VerifiedSlidesPageState extends State<VerifiedSlidesPage> {
  late final PageController _pageCtrl;
  int _currentPage = 0;

  static const _slides = <_SlideData>[
    _SlideData(
      image: 'assets/verified/foto.jpg',
      emoji: '🚀',
      title: 'CRYLIX DEATH V5.0.0',
      subtitle: 'Tentang Apk Crylix Death',
      info:
          'Platform executor premium dengan payload super gacor dan anti-ampas. Dipercaya ribuan pengguna di seluruh Indonesia.',
      buttonLabel: 'TAP CONTINUE',
      buttonIcon: Icons.arrow_forward_rounded,
      hint: 'TAP CONTINUE · Lanjutkan',
      imageAspectRatio: 1.0,
    ),
    _SlideData(
      image: 'assets/verified/foto2.jpg',
      emoji: '💻',
      title: 'DEVELOPER CRYLIX DEATH',
      subtitle: 'Telegram : @zasaco',
      info:
          'Hubungi Developer Langsung Untuk Support, Laporan Bug, Atau Request Fitur Baru, Fast Response 24/7.',
      buttonLabel: 'CHAT DEVELOPER',
      buttonIcon: Icons.send_rounded,
      actionUrl: 'https://t.me/zasaco',
      hint: 'TAP CONTINUE · Lanjutkan',
      imageAspectRatio: 1.0,
    ),
    _SlideData(
      image: 'assets/verified/foto3.jpg',
      emoji: '🤝',
      title: 'INFORMATION CRYLIX DEATH',
      subtitle: 'Telegram : @testizasa',
      info:
          'Join Komunitas Crylix Death, Sharing Tips, Dan Dapatkan Update Terbaru Seputar Payload.',
      buttonLabel: 'INFORMATION',
      buttonIcon: Icons.send_rounded,
      actionUrl: 'https://t.me/testizasa',
      hint: 'TAP CONTINUE · Lanjutkan',
      imageAspectRatio: 6 / 19,
    ),
    _SlideData(
      image: 'assets/verified/foto4.jpg',
      emoji: '📢',
      title: 'JOIN CHANNEL CRYLIX DEATH',
      subtitle: 'Dapatkan Update Terbaru',
      info:
          'Channel Resmi Crylix Death, Berisi Info Update, Payload Baru, Dan Pengumuman Penting Lainnya.',
      buttonLabel: 'JOIN CHANNEL',
      buttonIcon: Icons.send_rounded,
      actionUrl: 'https://t.me/testizasa',
      hint: 'TAP CONTINUE · Lanjutkan',
      imageAspectRatio: 1.0,
    ),
    _SlideData(
      image: 'assets/verified/foto5.jpg',
      emoji: '🎉',
      title: 'ENJOY & THANK YOU',
      subtitle: 'Terima Kasih Telah Menggunakan Apk Crylix Death',
      info:
          'Selamat Menggunakan Apk Crylix Death, Nikmati Fitur Fitur Keren Nya Ya, Jangan Lupa Share Apk Crylix Death Ke Public Ya, Agar Apk Crylix Death Makin Terkenal',
      buttonLabel: 'MASUK APLIKASI',
      buttonIcon: Icons.check_circle_rounded,
      hint: 'TAP UNTUK MASUK APLIKASI',
      isFinal: true,
      imageAspectRatio: 1.0,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _pageCtrl = PageController();
    _pageCtrl.addListener(() {
      final page = _pageCtrl.page?.round() ?? 0;
      if (page != _currentPage) {
        setState(() => _currentPage = page);
      }
    });
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    super.dispose();
  }

  void _next() {
    if (_currentPage < _slides.length - 1) {
      HapticFeedback.lightImpact();
      _pageCtrl.nextPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
      );
    } else {
      _finish();
    }
  }

  void _prev() {
    if (_currentPage > 0) {
      HapticFeedback.lightImpact();
      _pageCtrl.previousPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
      );
    }
  }

  void _finish() {
    HapticFeedback.mediumImpact();
    Navigator.pushReplacementNamed(context, '/landing');
  }

  Future<void> _openUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  void _onButtonTap(_SlideData slide) {
    HapticFeedback.mediumImpact();
    if (slide.isFinal) {
      _finish();
    } else if (slide.actionUrl != null) {
      _openUrl(slide.actionUrl!);
      Future.delayed(const Duration(milliseconds: 400), _next);
    } else {
      _next();
    }
  }

  @override
  Widget build(BuildContext context) {
    return StyleBuilder(
      builder: (context, C, kit) {
        final isComic = kit.style == ThemeStyle.comic3d;
        final isHud = kit.style == ThemeStyle.hudTactical;

        final txtMain = isHud
            ? C.hudText()
            : (isComic ? C.comicText : C.text);
        final txtSub = isHud
            ? C.hudTextDim()
            : (isComic ? C.comicTextSub : C.textSub);
        final txtMuted = isHud
            ? C.hudTextDim()
            : (isComic ? C.comicTextMuted : C.textSub);
        final fontMain = isComic ? 'Bangers' : 'Orbitron';
        final fontSub = isComic ? 'ComicNeue' : 'ShareTechMono';

        final accent = isHud ? C.hudNeon() : C.primaryHi;
        final accentBorder =
            isHud ? C.hudBorder() : (isComic ? Colors.black : accent);

        return Scaffold(
          backgroundColor: isHud ? C.hudBg() : C.bgDeep,
          body: Container(
            decoration: isHud
                ? BoxDecoration(color: C.hudBg())
                : (isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                        ),
                      )),
            child: Stack(
              children: [
                if (isComic)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(
                        painter: _BgPatternPainter(color: accent),
                      ),
                    ),
                  ),
                if (isHud)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(
                        painter: _HudGridPainter(color: C.hudGridLine()),
                      ),
                    ),
                  ),
                SafeArea(
                  child: Column(
                    children: [
                      _buildTopBar(C, isComic, isHud, accent, accentBorder,
                          txtMain, txtSub, fontMain),
                      Expanded(
                        child: PageView.builder(
                          controller: _pageCtrl,
                          itemCount: _slides.length,
                          physics: const BouncingScrollPhysics(),
                          itemBuilder: (_, i) => _buildSlide(
                            C,
                            isComic,
                            isHud,
                            accent,
                            accentBorder,
                            txtMain,
                            txtSub,
                            txtMuted,
                            fontMain,
                            fontSub,
                            _slides[i],
                          ),
                        ),
                      ),
                      _buildBottomBar(C, isComic, isHud, accent, accentBorder,
                          txtMain, fontMain),
                      const SizedBox(height: 14),
                      _buildPageDots(C, isComic, isHud, accent, txtSub),
                      const SizedBox(height: 18),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTopBar(
    AppPalette C, bool isComic, bool isHud,
    Color accent, Color accentBorder,
    Color txtMain, Color txtSub, String fontMain,
  ) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: isHud
                ? BoxDecoration(
                    color: accent.withOpacity(0.15),
                    border: Border.all(color: accent, width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: accent.withOpacity(0.5), blurRadius: 10),
                    ],
                  )
                : BoxDecoration(
                    color: accent,
                    shape: BoxShape.circle,
                    boxShadow: isComic
                        ? const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(3, 3),
                              blurRadius: 0,
                            ),
                          ]
                        : [
                            BoxShadow(
                              color: accent.withOpacity(0.5),
                              blurRadius: 12,
                              spreadRadius: 1,
                            ),
                          ],
                  ),
            child: Icon(Icons.verified_user_rounded,
                color: isHud ? accent : Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          Text(
            'VERIFIED',
            style: TextStyle(
              fontFamily: fontMain,
              fontSize: isComic ? 18 : 15,
              fontWeight: FontWeight.w900,
              color: txtMain,
              letterSpacing: 2.5,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : (isHud
                      ? [
                          Shadow(
                              color: accent.withOpacity(0.6),
                              blurRadius: 10),
                        ]
                      : null),
            ),
          ),
          const Spacer(),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              color: isComic ? C.bgDark : (isHud ? C.hudPanel() : null),
              borderRadius: BorderRadius.circular(isHud ? 2 : 20),
              border: Border.all(
                color: accentBorder,
                width: isComic ? 3 : (isHud ? 1.2 : 1.5),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${_currentPage + 1}',
                  style: TextStyle(
                    fontFamily: fontMain,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: txtMain,
                  ),
                ),
                Text(
                  ' / ${_slides.length}',
                  style: TextStyle(
                    fontFamily: fontMain,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: txtSub,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSlide(
    AppPalette C, bool isComic, bool isHud,
    Color accent, Color accentBorder,
    Color txtMain, Color txtSub, Color txtMuted,
    String fontMain, String fontSub,
    _SlideData slide,
  ) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: isComic ? C.bgDark : (isHud ? C.hudPanel() : null),
                borderRadius: BorderRadius.circular(isHud ? 2 : 20),
                border: Border.all(
                  color: accentBorder,
                  width: isComic ? 3 : (isHud ? 1.2 : 1.5),
                ),
              ),
              child: Text(
                'CRYLIX DEATH',
                style: TextStyle(
                  fontFamily: fontMain,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: txtMain.withOpacity(0.85),
                  letterSpacing: 2,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          _buildCard(C, isComic, isHud, accent, accentBorder, txtMain,
              txtSub, txtMuted, fontMain, fontSub, slide),
          const SizedBox(height: 20),
          _buildActionButton(C, isComic, isHud, accent, accentBorder,
              txtMain, fontMain, slide),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.touch_app_rounded,
                  size: 12, color: accent.withOpacity(0.7)),
              const SizedBox(width: 6),
              Text(
                slide.hint,
                style: TextStyle(
                  fontFamily: fontMain,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: accent.withOpacity(0.75),
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildCard(
    AppPalette C, bool isComic, bool isHud,
    Color accent, Color accentBorder,
    Color txtMain, Color txtSub, Color txtMuted,
    String fontMain, String fontSub,
    _SlideData slide,
  ) {
    final screenH = MediaQuery.of(context).size.height;
    final maxImgH = screenH * 0.40;

    return Container(
      width: double.infinity,
      decoration: isHud
          ? BoxDecoration(
              color: C.hudPanel(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
              boxShadow: [
                BoxShadow(
                    color: accent.withOpacity(0.3), blurRadius: 15),
              ],
            )
          : BoxDecoration(
              color: isComic ? C.bgDark : C.bg.withOpacity(0.65),
              borderRadius: BorderRadius.circular(isComic ? 20 : 24),
              border: Border.all(
                color: accentBorder,
                width: isComic ? 4 : 2,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(6, 6),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: accent.withOpacity(0.35),
                        blurRadius: 20,
                        spreadRadius: 1,
                      ),
                    ],
            ),
      child: ClipRRect(
        borderRadius:
            BorderRadius.circular(isHud ? 0 : (isComic ? 16 : 22)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildImageSection(C, slide, maxImgH),
            Container(
              height: isComic ? 3 : 1.5,
              color: accentBorder.withOpacity(0.7),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    slide.title,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: fontMain,
                      fontSize: isComic ? 24 : (isHud ? 18 : 22),
                      fontWeight: FontWeight.w900,
                      color: isComic ? txtMain : accent,
                      letterSpacing: isComic ? 2.5 : (isHud ? 2 : 2.5),
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(2, 2),
                                blurRadius: 0,
                              ),
                            ]
                          : (isHud
                              ? [
                                  Shadow(
                                      color: accent.withOpacity(0.6),
                                      blurRadius: 10),
                                ]
                              : [
                                  Shadow(
                                      color: accent.withOpacity(0.5),
                                      blurRadius: 10),
                                ]),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    slide.subtitle,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: fontSub,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: txtMain.withOpacity(0.85),
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 1,
                          color: accent.withOpacity(0.3),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: Container(
                          width: 5, height: 5,
                          decoration: BoxDecoration(
                            color: accent.withOpacity(0.7),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          height: 1,
                          color: accent.withOpacity(0.3),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Text(
                    slide.info,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 11.5,
                      color: txtMuted,
                      height: 1.6,
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSection(
      AppPalette C, _SlideData slide, double maxH) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final availableW = constraints.maxWidth;
        final desiredH = availableW / slide.imageAspectRatio;

        double finalW;
        double finalH;

        if (desiredH <= maxH) {
          finalW = availableW;
          finalH = desiredH;
        } else {
          finalH = maxH;
          finalW = finalH * slide.imageAspectRatio;
        }

        return Container(
          width: double.infinity,
          height: finalH,
          color: C.bg.withOpacity(0.4),
          alignment: Alignment.center,
          child: SizedBox(
            width: finalW,
            height: finalH,
            child: Image.asset(
              slide.image,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Center(
                child: Text(
                  slide.emoji,
                  style: const TextStyle(fontSize: 60),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildActionButton(
    AppPalette C, bool isComic, bool isHud,
    Color accent, Color accentBorder,
    Color txtMain, String fontMain,
    _SlideData slide,
  ) {
    final textColor = isComic
        ? C.contrastTextOn(accent)
        : (isHud ? accent : txtMain);

    return GestureDetector(
      onTap: () => _onButtonTap(slide),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
        decoration: isHud
            ? BoxDecoration(
                color: accent.withOpacity(0.15),
                border: Border.all(color: accent, width: 1.4),
                boxShadow: [
                  BoxShadow(
                      color: accent.withOpacity(0.5), blurRadius: 12),
                ],
              )
            : BoxDecoration(
                color: isComic ? accent : C.bg.withOpacity(0.5),
                borderRadius:
                    BorderRadius.circular(isComic ? 14 : 30),
                border: Border.all(
                  color: accentBorder,
                  width: isComic ? 4 : 2,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(5, 5),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: accent.withOpacity(0.4),
                          blurRadius: 15,
                          spreadRadius: 1,
                        ),
                      ],
              ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              slide.buttonLabel,
              style: TextStyle(
                fontFamily: fontMain,
                fontSize: isComic ? 16 : 14,
                fontWeight: FontWeight.w900,
                color: textColor,
                letterSpacing: 2,
                shadows: isComic
                    ? [
                        Shadow(
                          color: textColor == Colors.white
                              ? Colors.black
                              : Colors.white,
                          offset: const Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: isComic ? Colors.black : accent,
                shape: BoxShape.circle,
              ),
              child: Icon(slide.buttonIcon,
                  color: isComic ? Colors.white : C.bgDeep, size: 14),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar(
    AppPalette C, bool isComic, bool isHud,
    Color accent, Color accentBorder,
    Color txtMain, String fontMain,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: isHud
            ? BoxDecoration(
                color: C.hudPanel(),
                border: Border.all(color: C.hudBorder(), width: 1.2),
                boxShadow: [
                  BoxShadow(
                      color: accent.withOpacity(0.3), blurRadius: 10),
                ],
              )
            : BoxDecoration(
                color: isComic ? C.bgDark : C.bg.withOpacity(0.5),
                borderRadius: BorderRadius.circular(40),
                border: Border.all(
                  color: accentBorder,
                  width: isComic ? 4 : 2,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
        child: Row(
          children: [
            GestureDetector(
              onTap: _currentPage > 0 ? _prev : null,
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: _currentPage > 0
                      ? accent
                      : accent.withOpacity(0.3),
                  shape: isHud ? BoxShape.rectangle : BoxShape.circle,
                  borderRadius: isHud ? BorderRadius.circular(2) : null,
                ),
                child: Icon(Icons.arrow_back_rounded,
                    color: isHud ? C.hudBg() : Colors.white, size: 18),
              ),
            ),
            Expanded(
              child: Center(
                child: Text(
                  'GESER UNTUK LANJUT',
                  style: TextStyle(
                    fontFamily: fontMain,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: txtMain,
                    letterSpacing: 2.5,
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: _next,
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: accent,
                  shape: isHud ? BoxShape.rectangle : BoxShape.circle,
                  borderRadius: isHud ? BorderRadius.circular(2) : null,
                ),
                child: Icon(Icons.arrow_forward_rounded,
                    color: isHud ? C.hudBg() : Colors.white, size: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPageDots(
    AppPalette C, bool isComic, bool isHud,
    Color accent, Color txtSub,
  ) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_slides.length, (i) {
        final active = i == _currentPage;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: active ? 24 : 6,
          height: 6,
          decoration: BoxDecoration(
            color: active ? accent : txtSub.withOpacity(0.3),
            borderRadius: BorderRadius.circular(isHud ? 0 : 10),
          ),
        );
      }),
    );
  }
}

class _SlideData {
  final String image;
  final String emoji;
  final String title;
  final String subtitle;
  final String info;
  final String buttonLabel;
  final IconData buttonIcon;
  final String? actionUrl;
  final String hint;
  final bool isFinal;
  final double imageAspectRatio;

  const _SlideData({
    required this.image,
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.info,
    required this.buttonLabel,
    required this.buttonIcon,
    this.actionUrl,
    required this.hint,
    this.isFinal = false,
    this.imageAspectRatio = 1.0,
  });
}

class _BgPatternPainter extends CustomPainter {
  final Color color;
  const _BgPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.06)
      ..style = PaintingStyle.fill;

    final zigzag = Path();
    zigzag.moveTo(0, size.height * 0.08);
    for (double x = 0; x < size.width; x += 40) {
      zigzag.lineTo(x + 20, size.height * 0.08 - 10);
      zigzag.lineTo(x + 40, size.height * 0.08);
    }
    zigzag.lineTo(size.width, size.height * 0.08 - 20);
    zigzag.lineTo(size.width, size.height * 0.08 + 20);
    zigzag.lineTo(0, size.height * 0.08 + 20);
    zigzag.close();
    canvas.drawPath(zigzag, paint);

    canvas.drawCircle(
        Offset(size.width * 0.1, size.height * 0.3), 60, paint);
    canvas.drawCircle(
        Offset(size.width * 0.9, size.height * 0.5), 80, paint);
    canvas.drawCircle(
        Offset(size.width * 0.2, size.height * 0.75), 50, paint);
  }

  @override
  bool shouldRepaint(covariant _BgPatternPainter old) =>
      old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}