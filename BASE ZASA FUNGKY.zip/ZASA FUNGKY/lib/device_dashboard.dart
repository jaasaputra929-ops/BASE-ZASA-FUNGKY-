import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'app_theme.dart';
import 'control_panel.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════
// HUD PAINTERS
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.4;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - l, 0), p);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, l), p);
    canvas.drawLine(Offset(0, size.height), Offset(l, size.height), p);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// MODELS
// ═══════════════════════════════════════════════════════════
class PermissionResult {
  final bool approved;
  final bool allDevices;
  final List<String> devices;

  PermissionResult({
    required this.approved,
    required this.allDevices,
    required this.devices,
  });

  factory PermissionResult.fromJson(Map<String, dynamic> json) {
    return PermissionResult(
      approved: json['approved'] == true,
      allDevices: json['allDevices'] == true,
      devices: List<String>.from(json['devices'] ?? []),
    );
  }

  Map<String, dynamic> toJson() => {
        'approved': approved,
        'allDevices': allDevices,
        'devices': devices,
      };
}

class DevicePermissionStore {
  static Future<Map<String, dynamic>> getAll(String sessionKey) async => {};
  static Future<PermissionResult> getFor(
          String username, String sessionKey) async =>
      PermissionResult(approved: true, allDevices: true, devices: []);
  static Future<bool> setPerm(String sessionKey, String username,
          {required bool approved,
          required bool allDevices,
          required List<String> devices}) async =>
      true;
  static Future<bool> removePerm(String sessionKey, String username) async =>
      true;
}

// ═══════════════════════════════════════════════════════════
// REUSABLE COMPONENTS
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  const _Led({required this.color, this.size = 7});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color,
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.9),
              blurRadius: size * 1.8,
              spreadRadius: size * 0.3,
            ),
          ],
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.7),
            blurRadius: size,
            spreadRadius: 0.5,
          ),
          BoxShadow(
            color: color.withValues(alpha: 0.4),
            blurRadius: size * 2,
            spreadRadius: 1,
          ),
        ],
      ),
    );
  }
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 5});
  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          border: Border.all(color: C.accent.withValues(alpha: 0.6), width: 1),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.accentHi, C.primaryLo],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.5),
            offset: const Offset(1, 1),
            blurRadius: 1,
          ),
        ],
      ),
    );
  }
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) return const SizedBox.shrink();

    if (isHud) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _HudCornerPainter(color: C.accent.withValues(alpha: 0.7)),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.6),
            offset: const Offset(1, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Center(
        child: Container(
          width: size * 0.6,
          height: 1.2,
          color: Colors.black.withValues(alpha: 0.7),
        ),
      ),
    );
  }
}

class _SoftPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? accent;
  const _SoftPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 12,
    this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;
    final accentColor = accent ?? C.textSub;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(
            color: accentColor == C.textSub
                ? C.hudBorder()
                : accentColor.withValues(alpha: 0.7),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: C.accent.withValues(alpha: 0.15),
              blurRadius: 12,
            ),
          ],
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark],
        ),
        border: Border.all(color: accentColor, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.55),
            offset: const Offset(0, 4),
            blurRadius: 8,
          ),
          BoxShadow(
            color: Colors.white.withValues(alpha: 0.06),
            offset: const Offset(-1, -1),
            blurRadius: 2,
          ),
        ],
      ),
      child: child,
    );
  }
}

class _SoftInset extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  const _SoftInset({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 12),
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }

    if (isHud) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDeep.withValues(alpha: 0.7),
          border: Border.all(color: C.accent.withValues(alpha: 0.4), width: 1),
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: C.bgDeep,
        border: Border.all(color: C.bgDark, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.8),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
          BoxShadow(
            color: Colors.white.withValues(alpha: 0.04),
            offset: const Offset(0, -1),
            blurRadius: 1,
          ),
        ],
      ),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// PAIRING INFO PAGE
// ═══════════════════════════════════════════════════════════
class _PairingInfoPage extends StatelessWidget {
  final AppPalette C;
  final String pairId;
  final VoidCallback onCopy;
  final bool isOwner;

  const _PairingInfoPage({
    required this.C,
    required this.pairId,
    required this.onCopy,
    required this.isOwner,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(14),
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SoftPanel(
            C: C,
            padding: const EdgeInsets.all(14),
            accent: C.primaryHi.withValues(alpha: 0.6),
            child: Column(
              children: [
                Row(
                  children: [
                    _Screw(C: C, size: 10),
                    const SizedBox(width: 8),
                    _Led(color: C.primaryHi, size: 8),
                    const SizedBox(width: 8),
                    Text(
                      'PAIRING ID',
                      style: TextStyle(
                        color: isHud ? C.hudNeon() : C.accent,
                        fontSize: 11,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                        shadows: const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(0, 1),
                            blurRadius: 2,
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    _Screw(C: C, size: 10),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _SoftInset(
                        C: C,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 14),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: C.primaryLo,
                                border: Border.all(
                                    color: C.primaryHi.withValues(alpha: 0.5),
                                    width: 1),
                              ),
                              child: Icon(Icons.link_rounded,
                                  color: C.primaryHi, size: 14),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                pairId.isEmpty ? 'MEMUAT...' : pairId,
                                style: TextStyle(
                                  color: isHud ? C.hudText() : C.text,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 3,
                                  shadows: [
                                    Shadow(
                                      color: C.primaryHi,
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    if (pairId.isNotEmpty)
                      GestureDetector(
                        onTap: onCopy,
                        child: Container(
                          width: 46,
                          height: 46,
                          decoration: isHud
                              ? BoxDecoration(
                                  color: C.primaryHi.withValues(alpha: 0.15),
                                  border: Border.all(
                                      color: C.primaryHi, width: 1.4),
                                  boxShadow: [
                                    BoxShadow(
                                      color: C.primaryHi
                                          .withValues(alpha: 0.4),
                                      blurRadius: 10,
                                    ),
                                  ],
                                )
                              : BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      C.primaryHi,
                                      C.primaryHi,
                                      C.primary,
                                      C.primaryLo,
                                    ],
                                  ),
                                  border: Border.all(
                                      color: C.primaryLo, width: 2),
                                  boxShadow: [
                                    BoxShadow(
                                      color: C.primaryHi.withValues(alpha: 0.4),
                                      blurRadius: 12,
                                    ),
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.5),
                                      offset: const Offset(0, 3),
                                      blurRadius: 5,
                                    ),
                                  ],
                                ),
                          child: Icon(Icons.copy_rounded,
                              color: isHud ? C.primaryHi : Colors.white,
                              size: 18),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              children: [
                _Led(color: C.accent, size: 7),
                const SizedBox(width: 10),
                Text(
                  'CARA MENAUTKAN DEVICE',
                  style: TextStyle(
                    color: isHud ? C.hudNeon() : C.accent,
                    fontSize: 11,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          C.primaryHi.withValues(alpha: 0.5),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _StepCard(
            C: C,
            number: 1,
            title: 'INSTALL APK',
            description: 'Install aplikasi target di perangkat',
            icon: Icons.download_rounded,
            color: C.primaryHi,
          ),
          const SizedBox(height: 10),
          _StepCard(
            C: C,
            number: 2,
            title: 'MASUKKAN PAIRING ID',
            description: 'Buka aplikasi lalu masukkan ID di atas',
            icon: Icons.qr_code_scanner_rounded,
            color: C.accent,
          ),
          const SizedBox(height: 10),
          _StepCard(
            C: C,
            number: 3,
            title: 'BERI IZIN AKSES',
            description: 'Izinkan semua permission yang diminta',
            icon: Icons.security_rounded,
            color: C.accentHi,
          ),
          const SizedBox(height: 10),
          _StepCard(
            C: C,
            number: 4,
            title: 'SELESAI',
            description: 'Device akan muncul di halaman Devices',
            icon: Icons.check_circle_rounded,
            color: C.primaryHi,
          ),
          const SizedBox(height: 18),
          _SoftPanel(
            C: C,
            padding: const EdgeInsets.all(14),
            accent: C.accent.withValues(alpha: 0.5),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: C.primaryLo,
                    border: Border.all(
                        color: C.accent.withValues(alpha: 0.6), width: 1),
                  ),
                  child: Icon(Icons.info_rounded,
                      color: C.accent, size: 16),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'CATATAN PENTING',
                        style: TextStyle(
                          color: isHud ? C.hudNeon() : C.accent,
                          fontSize: 9,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'ID Pairing hanya dimiliki Owner. Jangan bagikan ke orang yang tidak dikenal.',
                        style: TextStyle(
                          color: isHud
                              ? C.hudTextDim()
                              : C.text.withValues(alpha: 0.65),
                          fontSize: 10,
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (!isOwner) ...[
            const SizedBox(height: 12),
            _SoftPanel(
              C: C,
              padding: const EdgeInsets.all(14),
              accent: C.accent.withValues(alpha: 0.5),
              child: Row(
                children: [
                  Icon(Icons.lock_rounded,
                      color: C.accent, size: 16),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Anda bukan Owner, ID Pairing tidak tersedia.',
                      style: TextStyle(
                        color: isHud ? C.hudText() : C.accent,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _StepCard extends StatelessWidget {
  final AppPalette C;
  final int number;
  final String title;
  final String description;
  final IconData icon;
  final Color color;

  const _StepCard({
    required this.C,
    required this.number,
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: color.withValues(alpha: 0.6), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.2),
              blurRadius: 10,
            ),
          ],
        ),
        padding: const EdgeInsets.all(12),
        child: _buildContent(isHud, true),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark],
        ),
        border: Border.all(color: color.withValues(alpha: 0.4), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.5),
            offset: const Offset(0, 3),
            blurRadius: 6,
          ),
          BoxShadow(
            color: color.withValues(alpha: 0.15),
            blurRadius: 10,
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(top: 4, left: 4, child: _Rivet(C: C, size: 4)),
          Positioned(top: 4, right: 4, child: _Rivet(C: C, size: 4)),
          Positioned(bottom: 4, left: 4, child: _Rivet(C: C, size: 4)),
          Positioned(bottom: 4, right: 4, child: _Rivet(C: C, size: 4)),
          Padding(
            padding: const EdgeInsets.all(12),
            child: _buildContent(isHud, false),
          ),
        ],
      ),
    );
  }

  Widget _buildContent(bool isHud, bool isHudLayout) {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: isHud
              ? BoxDecoration(
                  color: color.withValues(alpha: 0.2),
                  border: Border.all(color: color, width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: color.withValues(alpha: 0.4),
                      blurRadius: 8,
                    ),
                  ],
                )
              : BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      color.withValues(alpha: 0.9),
                      color.withValues(alpha: 0.6),
                      color.withValues(alpha: 0.9),
                    ],
                  ),
                  border: Border.all(
                      color: color.withValues(alpha: 0.9), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: color.withValues(alpha: 0.4),
                      blurRadius: 10,
                    ),
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.5),
                      offset: const Offset(0, 2),
                      blurRadius: 3,
                    ),
                  ],
                ),
          child: Center(
            child: Text(
              '$number',
              style: TextStyle(
                color: isHud ? color : Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                shadows: isHud
                    ? null
                    : const [
                        Shadow(
                          color: Colors.black54,
                          offset: Offset(0, 1),
                          blurRadius: 2,
                        ),
                      ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Container(
          width: 38,
          height: 38,
          decoration: isHud
              ? BoxDecoration(
                  color: color.withValues(alpha: 0.15),
                  border: Border.all(
                      color: color.withValues(alpha: 0.6), width: 1),
                )
              : BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withValues(alpha: 0.15),
                  border: Border.all(
                      color: color.withValues(alpha: 0.6), width: 1.2),
                ),
          child: Icon(icon,
              color: isHud ? color : color, size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: isHud ? C.hudText() : C.text,
                  fontSize: 11,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                  shadows: isHud
                      ? null
                      : const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(0, 1),
                            blurRadius: 2,
                          ),
                        ],
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 3),
              Text(
                description,
                style: TextStyle(
                  color: isHud
                      ? C.hudTextDim()
                      : C.text.withValues(alpha: 0.55),
                  fontSize: 9,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  height: 1.4,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        Icon(
          Icons.arrow_forward_ios_rounded,
          color: isHud ? C.hudTextDim() : C.textSub,
          size: 12,
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DEVICE LIST PAGE
// ═══════════════════════════════════════════════════════════
class _DeviceListPage extends StatefulWidget {
  final AppPalette C;
  final List<dynamic> devices;
  final String role;
  final bool isOwner;
  final PermissionResult? perm;
  final bool denied;
  final VoidCallback onRefresh;

  const _DeviceListPage({
    required this.C,
    required this.devices,
    required this.role,
    required this.isOwner,
    required this.perm,
    required this.denied,
    required this.onRefresh,
  });

  @override
  State<_DeviceListPage> createState() => _DeviceListPageState();
}

class _DeviceListPageState extends State<_DeviceListPage> {
  List<dynamic> _selectedDevices = [];
  bool _isManagementMode = false;

  void _toggleSelection(String deviceId) {
    setState(() {
      if (_selectedDevices.contains(deviceId)) {
        _selectedDevices.remove(deviceId);
      } else {
        _selectedDevices.add(deviceId);
      }
    });
  }

  void _toggleManagementMode() {
    setState(() {
      _isManagementMode = !_isManagementMode;
      _selectedDevices.clear();
    });
  }

  void _toast(String msg, Color color) {
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: isHud ? widget.C.hudPanel() : widget.C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isHud ? 4 : 8),
          side: BorderSide(color: color.withValues(alpha: 0.6), width: 1.5),
        ),
        margin: const EdgeInsets.all(14),
        content: Row(
          children: [
            _Led(color: color, size: 8),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(
                  color: isComic
                      ? widget.C.comicText
                      : (isHud ? widget.C.hudText() : widget.C.text),
                  fontWeight: FontWeight.w700,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<bool> _confirmDelete({
    required String title,
    required String message,
    required Color color,
    String confirmLabel = 'HAPUS',
  }) async {
    final C = widget.C;
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    final result = await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: _SoftPanel(
          C: C,
          padding: const EdgeInsets.all(20),
          accent: color.withValues(alpha: 0.6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: isHud
                    ? BoxDecoration(
                        color: color.withValues(alpha: 0.15),
                        border: Border.all(
                            color: color.withValues(alpha: 0.6), width: 1.4),
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: color.withValues(alpha: 0.15),
                        border: Border.all(
                            color: color.withValues(alpha: 0.6), width: 1.5),
                      ),
                child: Icon(Icons.delete_forever_rounded,
                    color: color, size: 26),
              ),
              const SizedBox(height: 14),
              Text(
                title,
                style: TextStyle(
                  color: color,
                  fontSize: 13,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.8,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isHud
                      ? C.hudTextDim()
                      : C.text.withValues(alpha: 0.65),
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: _MetalButton(
                      C: C,
                      label: 'BATAL',
                      color: C.textSub,
                      height: 42,
                      onTap: () => Navigator.pop(context, false),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _MetalButton(
                      C: C,
                      label: confirmLabel,
                      color: color,
                      height: 42,
                      icon: Icons.delete_outline_rounded,
                      onTap: () => Navigator.pop(context, true),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    return result == true;
  }

  Future<void> _deleteSingleDevice(
      String deviceId, String deviceName) async {
    final confirmed = await _confirmDelete(
      title: 'HAPUS DEVICE',
      message:
          'Hapus device "$deviceName"?\nTindakan ini tidak bisa dibatalkan!',
      color: widget.C.primaryHi,
    );
    if (!confirmed) return;

    try {
      final response = await http.delete(Uri.parse(
              '$baseUrl/rat/delete-device?key=${widget.role}&deviceId=$deviceId'))
          .timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          widget.onRefresh();
          _toast('Device berhasil dihapus!', widget.C.primaryHi);
          return;
        }
      }
      _toast('Gagal menghapus device', widget.C.primaryHi);
    } catch (e) {
      _toast('Error: $e', widget.C.primaryHi);
    }
  }

  Future<void> _deleteSelectedDevices() async {
    if (_selectedDevices.isEmpty) return;

    final confirmed = await _confirmDelete(
      title: 'HAPUS DEVICE',
      message:
          'Yakin ingin menghapus ${_selectedDevices.length} device?\nTindakan ini tidak bisa dibatalkan!',
      color: widget.C.primaryHi,
    );
    if (!confirmed) return;

    setState(() => _isManagementMode = false);

    try {
      List<String> failed = [];
      for (var deviceId in _selectedDevices) {
        final response = await http.delete(Uri.parse(
                '$baseUrl/rat/delete-device?key=${widget.role}&deviceId=$deviceId'))
            .timeout(const Duration(seconds: 8));
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['success'] != true) failed.add(deviceId);
        } else {
          failed.add(deviceId);
        }
      }

      _selectedDevices.clear();
      widget.onRefresh();

      if (failed.isEmpty) {
        _toast('Semua device berhasil dihapus!', widget.C.primaryHi);
      } else {
        _toast('${failed.length} device gagal dihapus', widget.C.accent);
      }
    } catch (e) {
      _toast('Error: $e', widget.C.primaryHi);
    }
  }

  Future<void> _clearOfflineDevices() async {
    final C = widget.C;
    final offlineDevices =
        widget.devices.where((d) => d['online'] != true).toList();
    if (offlineDevices.isEmpty) {
      _toast('Tidak ada device offline untuk dihapus', C.accent);
      return;
    }

    final confirmed = await _confirmDelete(
      title: 'BERSIHKAN OFFLINE',
      message:
          'Hapus ${offlineDevices.length} device offline?\nTindakan ini tidak bisa dibatalkan!',
      color: C.accent,
      confirmLabel: 'HAPUS SEMUA',
    );
    if (!confirmed) return;

    try {
      List<String> failed = [];
      for (var device in offlineDevices) {
        final deviceId = device['id']?.toString() ?? '';
        if (deviceId.isNotEmpty) {
          final response = await http.delete(Uri.parse(
                  '$baseUrl/rat/delete-device?key=${widget.role}&deviceId=$deviceId'))
              .timeout(const Duration(seconds: 8));
          if (response.statusCode == 200) {
            final data = jsonDecode(response.body);
            if (data['success'] != true) failed.add(deviceId);
          } else {
            failed.add(deviceId);
          }
        }
      }
      widget.onRefresh();

      if (failed.isEmpty) {
        _toast(
            '${offlineDevices.length} device offline berhasil dibersihkan!',
            C.primaryHi);
      } else {
        _toast('${failed.length} device gagal dihapus', C.accent);
      }
    } catch (e) {
      _toast('Error: $e', C.primaryHi);
    }
  }

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final activeCount =
        widget.devices.where((d) => d['online'] == true).length;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
          child: _SoftPanel(
            C: C,
            padding: const EdgeInsets.all(12),
            accent: C.primaryHi.withValues(alpha: 0.5),
            child: Column(
              children: [
                Row(
                  children: [
                    _Screw(C: C, size: 10),
                    const SizedBox(width: 8),
                    _Led(color: C.primaryHi, size: 7),
                    const SizedBox(width: 8),
                    Text(
                      'DEVICE STATUS',
                      style: TextStyle(
                        color: C.accent,
                        fontSize: 10,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                      ),
                    ),
                    const Spacer(),
                    _Screw(C: C, size: 10),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _StatBox(
                        C: C,
                        label: 'ONLINE',
                        value: '$activeCount',
                        color: C.primaryHi,
                        icon: Icons.wifi_rounded,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _StatBox(
                        C: C,
                        label: 'OFFLINE',
                        value: '${widget.devices.length - activeCount}',
                        color: C.primaryHi,
                        icon: Icons.wifi_off_rounded,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _StatBox(
                        C: C,
                        label: 'TOTAL',
                        value: '${widget.devices.length}',
                        color: C.accent,
                        icon: Icons.devices_rounded,
                      ),
                    ),
                  ],
                ),
                if (widget.isOwner && widget.devices.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _SmallActionButton(
                          C: C,
                          label: _isManagementMode
                              ? 'BATAL PILIH'
                              : 'PILIH DEVICE',
                          color: _isManagementMode
                              ? C.primaryHi
                              : C.accentHi,
                          icon: _isManagementMode
                              ? Icons.close_rounded
                              : Icons.checklist_rounded,
                          onTap: _toggleManagementMode,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _SmallActionButton(
                          C: C,
                          label: 'BERSIHKAN OFFLINE',
                          color: C.accent,
                          icon: Icons.cleaning_services_rounded,
                          onTap: _clearOfflineDevices,
                        ),
                      ),
                    ],
                  ),
                  if (_isManagementMode && _selectedDevices.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    _SmallActionButton(
                      C: C,
                      label:
                          'HAPUS ${_selectedDevices.length} DEVICE TERPILIH',
                      color: C.primaryHi,
                      icon: Icons.delete_forever_rounded,
                      onTap: _deleteSelectedDevices,
                    ),
                  ],
                ],
              ],
            ),
          ),
        ),
        Expanded(
          child: widget.devices.isEmpty
              ? _EmptyDeviceWidget(C: C, isOwner: widget.isOwner)
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 100),
                  physics: const BouncingScrollPhysics(),
                  itemCount: widget.devices.length,
                  itemBuilder: (ctx, i) {
                    final d = widget.devices[i];
                    final isOnline = d['online'] == true;
                    final deviceId = d['id']?.toString() ?? '';
                    final isSelected = _selectedDevices.contains(deviceId);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: _DeviceCard(
                        C: C,
                        device: d,
                        isOnline: isOnline,
                        role: widget.role,
                        isManagementMode: _isManagementMode,
                        isSelected: isSelected,
                        onToggleSelect: () => _toggleSelection(deviceId),
                        onDelete: () => _deleteSingleDevice(
                            deviceId, d['model'] ?? 'Unknown'),
                        isOwner: widget.isOwner,
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// STAT BOX
// ═══════════════════════════════════════════════════════════
class _StatBox extends StatelessWidget {
  final AppPalette C;
  final String label;
  final String value;
  final Color color;
  final IconData icon;

  const _StatBox({
    required this.C,
    required this.label,
    required this.value,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
      decoration: BoxDecoration(
        color: isHud
            ? C.bgDeep.withValues(alpha: 0.6)
            : Colors.black.withValues(alpha: 0.5),
        border: Border.all(color: color.withValues(alpha: 0.4), width: 1),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.15),
            blurRadius: 8,
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 14,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
              shadows: [
                Shadow(color: color.withValues(alpha: 0.6), blurRadius: 6),
              ],
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: isHud
                  ? C.hudTextDim()
                  : C.text.withValues(alpha: 0.5),
              fontSize: 7,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMALL ACTION BUTTON
// ═══════════════════════════════════════════════════════════
class _SmallActionButton extends StatefulWidget {
  final AppPalette C;
  final String label;
  final Color color;
  final IconData icon;
  final VoidCallback onTap;
  const _SmallActionButton({
    required this.C,
    required this.label,
    required this.color,
    required this.icon,
    required this.onTap,
  });

  @override
  State<_SmallActionButton> createState() => _SmallActionButtonState();
}

class _SmallActionButtonState extends State<_SmallActionButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        padding: const EdgeInsets.symmetric(vertical: 8),
        transform: isHud
            ? null
            : Matrix4.translationValues(
                _pressed ? 1.5 : 0,
                _pressed ? 1.5 : 0,
                0,
              ),
        decoration: isHud
            ? BoxDecoration(
                color: _pressed
                    ? widget.color.withValues(alpha: 0.25)
                    : widget.color.withValues(alpha: 0.15),
                border: Border.all(color: widget.color, width: 1.2),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withValues(alpha: 0.3),
                          blurRadius: 8,
                        ),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: _pressed
                      ? [
                          widget.color.withValues(alpha: 0.4),
                          widget.color.withValues(alpha: 0.2)
                        ]
                      : [
                          widget.color.withValues(alpha: 0.8),
                          widget.color.withValues(alpha: 0.5)
                        ],
                ),
                border: Border.all(color: widget.color, width: 1.2),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withValues(alpha: 0.3),
                          blurRadius: 6,
                        ),
                      ],
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(widget.icon,
                color: isHud ? widget.color : Colors.white, size: 12),
            const SizedBox(width: 5),
            Text(
              widget.label,
              style: TextStyle(
                color: isHud ? widget.color : Colors.white,
                fontSize: 8,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DEVICE CARD
// ═══════════════════════════════════════════════════════════
class _DeviceCard extends StatelessWidget {
  final AppPalette C;
  final dynamic device;
  final bool isOnline;
  final String role;
  final bool isManagementMode;
  final bool isSelected;
  final VoidCallback onToggleSelect;
  final VoidCallback onDelete;
  final bool isOwner;

  const _DeviceCard({
    required this.C,
    required this.device,
    required this.isOnline,
    required this.role,
    required this.isManagementMode,
    required this.isSelected,
    required this.onToggleSelect,
    required this.onDelete,
    required this.isOwner,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;
    final statusColor = isOnline ? C.primaryHi : C.primaryHi;

    return GestureDetector(
      onTap: isManagementMode
          ? onToggleSelect
          : () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ControlCenterPage(
                      targetDevice: device, role: role),
                ),
              ),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        decoration: isHud
            ? BoxDecoration(
                color: isSelected
                    ? C.accent.withValues(alpha: 0.15)
                    : C.hudPanel(),
                border: Border.all(
                  color: isSelected
                      ? C.accent
                      : (isOnline
                          ? statusColor.withValues(alpha: 0.5)
                          : C.accent.withValues(alpha: 0.3)),
                  width: isSelected ? 1.6 : 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: (isSelected ? C.accent : statusColor)
                        .withValues(alpha: isSelected ? 0.4 : 0.15),
                    blurRadius: isSelected ? 14 : 8,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: isSelected
                      ? [C.primary, C.primaryLo]
                      : [C.bg, C.bgDark],
                ),
                border: Border.all(
                  color: isSelected
                      ? C.accent
                      : (isOnline
                          ? statusColor.withValues(alpha: 0.5)
                          : C.textSub),
                  width: isSelected ? 1.8 : 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: isSelected
                        ? C.primaryHi.withValues(alpha: 0.35)
                        : Colors.black.withValues(alpha: 0.5),
                    offset: const Offset(0, 4),
                    blurRadius: isSelected ? 10 : 6,
                  ),
                  if (isOnline && !isSelected)
                    BoxShadow(
                      color: C.primaryHi.withValues(alpha: 0.15),
                      blurRadius: 12,
                    ),
                ],
              ),
        child: Stack(
          children: [
            if (!isHud) ...[
              Positioned(top: 4, left: 4, child: _Rivet(C: C, size: 4)),
              Positioned(top: 4, right: 4, child: _Rivet(C: C, size: 4)),
              Positioned(bottom: 4, left: 4, child: _Rivet(C: C, size: 4)),
              Positioned(bottom: 4, right: 4, child: _Rivet(C: C, size: 4)),
            ],
            if (isHud) ...[
              Positioned(top: 0, left: 0, child: _Screw(C: C, size: 10)),
              Positioned(top: 0, right: 0, child: _Screw(C: C, size: 10)),
              Positioned(bottom: 0, left: 0, child: _Screw(C: C, size: 10)),
              Positioned(bottom: 0, right: 0, child: _Screw(C: C, size: 10)),
            ],
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  if (isManagementMode) ...[
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 120),
                      width: 22,
                      height: 22,
                      decoration: isHud
                          ? BoxDecoration(
                              color: isSelected
                                  ? C.accent.withValues(alpha: 0.25)
                                  : Colors.transparent,
                              border: Border.all(
                                color: isSelected ? C.accent : C.accent.withValues(alpha: 0.4),
                                width: 1.2,
                              ),
                            )
                          : BoxDecoration(
                              shape: BoxShape.circle,
                              color: isSelected
                                  ? C.accent
                                  : Colors.transparent,
                              border: Border.all(
                                color: isSelected ? C.accent : C.textSub,
                                width: 1.8,
                              ),
                            ),
                      child: isSelected
                          ? Icon(Icons.check_rounded,
                              color: isHud ? C.accent : C.bgDeep, size: 14)
                          : null,
                    ),
                    const SizedBox(width: 10),
                  ],
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: isHud
                            ? BoxDecoration(
                                color: C.bgDeep.withValues(alpha: 0.5),
                                border: Border.all(
                                  color: isOnline
                                      ? statusColor.withValues(alpha: 0.6)
                                      : C.accent.withValues(alpha: 0.3),
                                  width: 1.2,
                                ),
                                boxShadow: isOnline
                                    ? [
                                        BoxShadow(
                                          color: statusColor.withValues(alpha: 0.3),
                                          blurRadius: 8,
                                        ),
                                      ]
                                    : null,
                              )
                            : BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: C.bg.withValues(alpha: 0.5),
                                border: Border.all(
                                  color: isOnline
                                      ? statusColor.withValues(alpha: 0.6)
                                      : C.textSub,
                                  width: 1.2,
                                ),
                                boxShadow: [
                                  if (isOnline)
                                    BoxShadow(
                                      color: statusColor.withValues(alpha: 0.3),
                                      blurRadius: 8,
                                    ),
                                ],
                              ),
                        child: Icon(
                          device['model']
                                      ?.toString()
                                      .toLowerCase()
                                      .contains('samsung') ==
                                  true
                              ? Icons.phone_android_rounded
                              : Icons.devices_rounded,
                          color: isOnline
                              ? C.primaryHi
                              : (isHud ? C.hudTextDim() : C.textSub),
                          size: 20,
                        ),
                      ),
                      Positioned(
                        top: 0,
                        right: 0,
                        child: _Led(color: statusColor, size: 8),
                      ),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          device['model'] ?? 'Unknown Device',
                          style: TextStyle(
                            color: isOnline
                                ? (isHud ? C.hudText() : C.text)
                                : (isHud
                                    ? C.hudTextDim()
                                    : C.text.withValues(alpha: 0.6)),
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 0.3,
                            shadows: isHud
                                ? null
                                : const [
                                    Shadow(
                                      color: Colors.black,
                                      offset: Offset(0, 1),
                                      blurRadius: 2,
                                    ),
                                  ],
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 3),
                        Text(
                          device['id'] ?? 'ID: ---',
                          style: TextStyle(
                            color: isHud
                                ? C.hudTextDim()
                                : C.text.withValues(alpha: 0.4),
                            fontSize: 9,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w700,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 5),
                        Row(
                          children: [
                            Icon(
                              Icons.battery_charging_full_rounded,
                              color: isOnline
                                  ? C.accent
                                  : (isHud ? C.hudTextDim() : C.textSub),
                              size: 11,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              '${device['battery'] ?? '?'}%',
                              style: TextStyle(
                                color: isOnline
                                    ? C.accent
                                    : (isHud
                                        ? C.hudTextDim()
                                        : C.text.withValues(alpha: 0.4)),
                                fontSize: 9,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            if (!isOnline &&
                                device['lastSeen'] != null) ...[
                              const SizedBox(width: 8),
                              Text(
                                _formatLastSeen(device['lastSeen']),
                                style: TextStyle(
                                  color: isHud
                                      ? C.hudTextDim()
                                      : C.text.withValues(alpha: 0.4),
                                  fontSize: 8,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: isHud
                            ? BoxDecoration(
                                color: statusColor.withValues(alpha: 0.15),
                                border: Border.all(
                                    color: statusColor, width: 1),
                              )
                            : BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color: C.primaryLo,
                                border: Border.all(
                                  color: statusColor.withValues(alpha: 0.6),
                                  width: 1,
                                ),
                              ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _Led(color: statusColor, size: 5),
                            const SizedBox(width: 4),
                            Text(
                              isOnline ? 'ONLINE' : 'OFFLINE',
                              style: TextStyle(
                                color: statusColor,
                                fontSize: 7,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (!isManagementMode && isOwner) ...[
                        const SizedBox(height: 6),
                        GestureDetector(
                          onTap: onDelete,
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: isHud
                                ? BoxDecoration(
                                    color: C.primaryHi.withValues(alpha: 0.15),
                                    border: Border.all(
                                        color: C.primaryHi, width: 1),
                                  )
                                : BoxDecoration(
                                    borderRadius: BorderRadius.circular(6),
                                    color: C.primaryLo,
                                    border: Border.all(
                                        color:
                                            C.primaryHi.withValues(alpha: 0.6),
                                        width: 1),
                                  ),
                            child: Icon(
                              Icons.delete_outline_rounded,
                              color: C.primaryHi,
                              size: 12,
                            ),
                          ),
                        ),
                      ],
                      if (!isManagementMode) ...[
                        const SizedBox(height: 4),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: isHud ? C.hudTextDim() : C.textSub,
                          size: 11,
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatLastSeen(String? lastSeenStr) {
    if (lastSeenStr == null) return 'Never';
    try {
      final lastSeen = DateTime.parse(lastSeenStr);
      final diff = DateTime.now().difference(lastSeen);
      if (diff.inSeconds < 60) return '${diff.inSeconds}s';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m';
      if (diff.inHours < 24) return '${diff.inHours}h';
      return '${diff.inDays}d';
    } catch (_) {
      return 'Never';
    }
  }
}

// ═══════════════════════════════════════════════════════════
// EMPTY STATE
// ═══════════════════════════════════════════════════════════
class _EmptyDeviceWidget extends StatelessWidget {
  final AppPalette C;
  final bool isOwner;
  const _EmptyDeviceWidget({required this.C, required this.isOwner});

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _SoftPanel(
          C: C,
          padding:
              const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: isHud
                    ? BoxDecoration(
                        color: C.primaryHi.withValues(alpha: 0.15),
                        border: Border.all(
                            color: C.primaryHi, width: 1.4),
                        boxShadow: [
                          BoxShadow(
                            color: C.primaryHi.withValues(alpha: 0.35),
                            blurRadius: 15,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [C.bg, C.bgDark],
                        ),
                        border: Border.all(
                            color: C.primaryHi.withValues(alpha: 0.4),
                            width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: C.primaryHi.withValues(alpha: 0.15),
                            blurRadius: 15,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                child: Icon(
                  Icons.devices_rounded,
                  size: 36,
                  color: isHud ? C.primaryHi : C.textSub,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'BELUM ADA DEVICE',
                style: TextStyle(
                  color: isHud ? C.hudNeon() : C.accent,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Tautkan device menggunakan ID Pairing\ndi halaman sebelumnya',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isHud
                      ? C.hudTextDim()
                      : C.text.withValues(alpha: 0.55),
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  height: 1.5,
                ),
              ),
              if (isOwner) ...[
                const SizedBox(height: 20),
                _SoftInset(
                  C: C,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 8),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.swipe_left_rounded,
                          color: C.accent, size: 14),
                      const SizedBox(width: 8),
                      Text(
                        'GESER KIRI UNTUK PAIRING ID',
                        style: TextStyle(
                          color: isHud ? C.hudNeon() : C.accent,
                          fontSize: 8,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL BUTTON
// ═══════════════════════════════════════════════════════════
class _MetalButton extends StatefulWidget {
  final AppPalette C;
  final String label;
  final Color color;
  final double height;
  final VoidCallback onTap;
  final IconData? icon;
  const _MetalButton({
    required this.C,
    required this.label,
    required this.color,
    required this.height,
    required this.onTap,
    this.icon,
  });

  @override
  State<_MetalButton> createState() => _MetalButtonState();
}

class _MetalButtonState extends State<_MetalButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isHud
            ? null
            : Matrix4.translationValues(
                _pressed ? 1.5 : 0,
                _pressed ? 1.5 : 0,
                0,
              ),
        decoration: isHud
            ? BoxDecoration(
                color: _pressed
                    ? widget.color.withValues(alpha: 0.25)
                    : widget.color.withValues(alpha: 0.15),
                border: Border.all(color: widget.color, width: 1.4),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withValues(alpha: 0.35),
                          blurRadius: 10,
                        ),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    widget.color.withValues(alpha: 0.9),
                    widget.color,
                    widget.color.withValues(alpha: 0.7),
                  ],
                ),
                border: Border.all(
                  color: widget.color.withValues(alpha: 0.9),
                  width: 1.5,
                ),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withValues(alpha: 0.35),
                          blurRadius: 8,
                        ),
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.5),
                          offset: const Offset(0, 3),
                          blurRadius: 5,
                        ),
                      ],
              ),
        child: Stack(
          children: [
            if (!isHud) ...[
              Positioned(top: 3, left: 3, child: _Rivet(C: C, size: 4)),
              Positioned(top: 3, right: 3, child: _Rivet(C: C, size: 4)),
              Positioned(bottom: 3, left: 3, child: _Rivet(C: C, size: 4)),
              Positioned(bottom: 3, right: 3, child: _Rivet(C: C, size: 4)),
            ],
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.icon != null) ...[
                    Icon(widget.icon,
                        color: isHud ? widget.color : Colors.white, size: 13),
                    const SizedBox(width: 5),
                  ],
                  Text(
                    widget.label,
                    style: TextStyle(
                      color: isHud ? widget.color : Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// PERMISSION BOTTOM SHEET
// ═══════════════════════════════════════════════════════════
class _PermissionBottomSheet extends StatelessWidget {
  final AppPalette C;
  final String sessionKey;
  final List<dynamic> allDevices;

  const _PermissionBottomSheet({
    required this.C,
    required this.sessionKey,
    required this.allDevices,
  });

  @override
  Widget build(BuildContext context) {
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return Container(
      decoration: isHud
          ? BoxDecoration(
              color: C.hudBg(),
              border: Border.all(color: C.hudBorder(), width: 1.2),
            )
          : BoxDecoration(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(20)),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [C.bg, C.bgDark, C.bgDeep],
              ),
            ),
      padding: const EdgeInsets.all(20),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: const EdgeInsets.only(bottom: 20),
              width: 50,
              height: 4,
              decoration: BoxDecoration(
                color: C.textSub,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: isHud
                  ? BoxDecoration(
                      color: C.primaryHi.withValues(alpha: 0.15),
                      border: Border.all(
                          color: C.primaryHi, width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: C.primaryHi.withValues(alpha: 0.4),
                          blurRadius: 14,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [C.primaryLo, C.primary],
                      ),
                      border: Border.all(
                          color: C.primaryHi.withValues(alpha: 0.6),
                          width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: C.primaryHi.withValues(alpha: 0.3),
                          blurRadius: 15,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
              child: Icon(Icons.check_circle_rounded,
                  color: C.primaryHi, size: 40),
            ),
            const SizedBox(height: 16),
            Text(
              'AKSES UNIVERSAL',
              style: TextStyle(
                color: isHud ? C.hudNeon() : C.accent,
                fontSize: 14,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Semua user memiliki akses ke semua device',
              style: TextStyle(
                color: isHud
                    ? C.hudTextDim()
                    : C.text.withValues(alpha: 0.6),
                fontSize: 11,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 22),
            _MetalButton(
              C: C,
              label: 'TUTUP',
              color: C.primaryHi,
              height: 44,
              icon: Icons.check_rounded,
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// MAIN DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════
class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const DeviceDashboardPage({
    super.key,
    this.username = '',
    this.role = '',
    this.sessionKey = '',
  });

  @override
  State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> {
  List<dynamic> _visible = [];
  bool _loading = true;
  String? _errorMsg;
  String _pairId = '';
  PermissionResult? _perm;
  Timer? _timer;
  late PageController _pageController;
  int _currentPage = 0;

  bool get _isOwner => widget.role.toLowerCase() == 'owner';
  bool get _denied => false;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _initialize();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _initialize() async {
    try {
      await _loadAll();
      _timer = Timer.periodic(
          const Duration(seconds: 20), (_) => _loadAll());
    } catch (e) {
      setState(() {
        _loading = false;
        _errorMsg = e.toString();
      });
    }
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    try {
      final pRes = await http
          .get(Uri.parse(
              '$baseUrl/rat/pairid?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 8));
      if (pRes.statusCode == 200) {
        final pd = jsonDecode(pRes.body);
        if (pd['valid'] == true && pd['pairId'] != null) {
          if (mounted) {
            setState(() => _pairId = pd['pairId'].toString());
          }
        }
      }

      final dRes = await http
          .get(Uri.parse(
              '$baseUrl/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;
      if (dRes.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Server error ${dRes.statusCode}';
        });
        return;
      }

      final body = jsonDecode(dRes.body);
      if (body['valid'] != true) {
        setState(() {
          _loading = false;
          _errorMsg = body['message'] ?? 'Error';
        });
        return;
      }

      List<dynamic> devices =
          List<dynamic>.from(body['devices'] ?? []);
      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen =
              DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) {
          d['online'] = false;
        }
      }

      PermissionResult perm = PermissionResult(
          approved: true, allDevices: true, devices: []);

      if (mounted) {
        setState(() {
          _visible = devices;
          _perm = perm;
          _loading = false;
          _errorMsg = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _errorMsg = e.toString();
        });
      }
    }
  }

  void _copyPairId(AppPalette C) {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    final style = AppTheme.currentStyle.value;
    final isComic = style == ThemeStyle.comic3d;
    final isHud = style == ThemeStyle.hudTactical;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: isHud ? C.hudPanel() : C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isHud ? 4 : 8),
          side: BorderSide(
              color: C.primaryHi.withValues(alpha: 0.6), width: 1.5),
        ),
        margin: const EdgeInsets.all(14),
        content: Row(
          children: [
            _Led(color: C.primaryHi, size: 8),
            const SizedBox(width: 12),
            Text(
              'ID Pairing berhasil disalin!',
              style: TextStyle(
                color: isComic ? C.comicText : (isHud ? C.hudText() : C.text),
                fontWeight: FontWeight.w700,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openPermissionBottomSheet(AppPalette C) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => _PermissionBottomSheet(
        C: C,
        sessionKey: widget.sessionKey,
        allDevices: _visible,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDark),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                            ),
                          )),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withValues(alpha: 0.12)),
                          ),
                        ),
                      ),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildTopBar(C, isComic, isHud),
                          _buildPageIndicator(C, isHud),
                          Expanded(
                            child: _loading
                                ? Center(
                                    child: CircularProgressIndicator(
                                        color: isComic
                                            ? Colors.black
                                            : C.accent,
                                        strokeWidth: 2),
                                  )
                                : _errorMsg != null
                                    ? _buildErrorView(C, isComic, isHud)
                                    : Stack(
                                        children: [
                                          PageView(
                                            controller: _pageController,
                                            onPageChanged: (page) {
                                              setState(
                                                  () => _currentPage = page);
                                            },
                                            children: [
                                              _PairingInfoPage(
                                                C: C,
                                                pairId: _pairId,
                                                onCopy: () => _copyPairId(C),
                                                isOwner: _isOwner,
                                              ),
                                              _DeviceListPage(
                                                C: C,
                                                devices: _visible,
                                                role: widget.role,
                                                isOwner: _isOwner,
                                                perm: _perm,
                                                denied: _denied,
                                                onRefresh: _loadAll,
                                              ),
                                            ],
                                          ),
                                          if (_isOwner)
                                            Positioned(
                                              right: 16,
                                              bottom: 16,
                                              child: GestureDetector(
                                                onTap: () =>
                                                    _openPermissionBottomSheet(
                                                        C),
                                                child: Container(
                                                  width: 56,
                                                  height: 56,
                                                  decoration: isHud
                                                      ? BoxDecoration(
                                                          color: C.primaryHi
                                                              .withValues(
                                                                  alpha: 0.15),
                                                          border: Border.all(
                                                              color: C.primaryHi,
                                                              width: 1.4),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: C.primaryHi
                                                                  .withValues(
                                                                      alpha:
                                                                          0.5),
                                                              blurRadius: 14,
                                                            ),
                                                          ],
                                                        )
                                                      : BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          gradient:
                                                              LinearGradient(
                                                            begin: Alignment
                                                                .topLeft,
                                                            end: Alignment
                                                                .bottomRight,
                                                            colors: [
                                                              C.primaryHi,
                                                              C.primary,
                                                              C.primaryLo,
                                                            ],
                                                          ),
                                                          border: Border.all(
                                                              color: C.primaryLo,
                                                              width: 2),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: C.primaryHi
                                                                  .withValues(
                                                                      alpha:
                                                                          0.4),
                                                              blurRadius: 16,
                                                              spreadRadius: -2,
                                                            ),
                                                            BoxShadow(
                                                              color: Colors.black
                                                                  .withValues(
                                                                      alpha:
                                                                          0.6),
                                                              offset:
                                                                  const Offset(
                                                                      0, 4),
                                                              blurRadius: 8,
                                                            ),
                                                          ],
                                                        ),
                                                  child: Icon(
                                                    Icons.security_rounded,
                                                    color: isHud
                                                        ? C.primaryHi
                                                        : Colors.white,
                                                    size: 24,
                                                  ),
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        height: 56,
        decoration: isHud
            ? BoxDecoration(
                color: C.hudPanel(),
                border: Border.all(color: C.hudBorder(), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: C.accent.withValues(alpha: 0.2),
                    blurRadius: 10,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark],
                ),
                border: Border.all(
                    color: C.primaryHi.withValues(alpha: 0.4), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.6),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                  BoxShadow(
                    color: C.primaryHi.withValues(alpha: 0.15),
                    blurRadius: 12,
                  ),
                ],
              ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              _Screw(C: C, size: 12),
              const SizedBox(width: 8),
              _MetalIconButton(
                C: C,
                icon: Icons.arrow_back_rounded,
                onTap: () => Navigator.pop(context),
              ),
              const SizedBox(width: 10),
              _Led(color: C.primaryHi, size: 8),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'TR4SHER NULL DASBOARD',
                      style: TextStyle(
                        color: isHud ? C.hudNeon() : C.primaryHi,
                        fontSize: 11,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                        shadows: [
                          const Shadow(
                            color: Colors.black,
                            offset: Offset(0, 1),
                            blurRadius: 2,
                          ),
                          Shadow(
                            color: C.primaryHi,
                            blurRadius: 6,
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 1),
                    Text(
                      '@${widget.username}',
                      style: TextStyle(
                        color: isHud
                            ? C.hudTextDim()
                            : C.text.withValues(alpha: 0.55),
                        fontSize: 9,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
              _MetalIconButton(
                C: C,
                icon: Icons.refresh_rounded,
                onTap: () {
                  setState(() => _loading = true);
                  _loadAll();
                },
              ),
              const SizedBox(width: 8),
              _Screw(C: C, size: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPageIndicator(AppPalette C, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _PageDot(
            isActive: _currentPage == 0,
            color: C.primaryHi,
            isHud: isHud,
          ),
          const SizedBox(width: 8),
          _PageDot(
            isActive: _currentPage == 1,
            color: C.accent,
            isHud: isHud,
          ),
        ],
      ),
    );
  }

  Widget _buildErrorView(AppPalette C, bool isComic, bool isHud) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _SoftPanel(
          C: C,
          padding:
              const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
          accent: C.primaryHi.withValues(alpha: 0.6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: isHud
                    ? BoxDecoration(
                        color: C.primaryHi.withValues(alpha: 0.15),
                        border: Border.all(
                            color: C.primaryHi, width: 1.4),
                        boxShadow: [
                          BoxShadow(
                            color: C.primaryHi.withValues(alpha: 0.4),
                            blurRadius: 12,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryLo,
                        border: Border.all(
                            color: C.primaryHi.withValues(alpha: 0.6),
                            width: 1.5),
                      ),
                child: Icon(Icons.error_rounded,
                    color: C.primaryHi, size: 32),
              ),
              const SizedBox(height: 18),
              Text(
                'TERJADI KESALAHAN',
                style: TextStyle(
                  color: isHud ? C.hudNeon() : C.primaryHi,
                  fontSize: 12,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.8,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                _errorMsg ?? 'Unknown error',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isHud
                      ? C.hudTextDim()
                      : C.text.withValues(alpha: 0.6),
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              _MetalButton(
                C: C,
                label: 'COBA LAGI',
                color: C.primaryHi,
                height: 44,
                icon: Icons.refresh_rounded,
                onTap: () {
                  setState(() {
                    _loading = true;
                    _errorMsg = null;
                  });
                  _loadAll();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// PAGE DOT
// ═══════════════════════════════════════════════════════════
class _PageDot extends StatelessWidget {
  final bool isActive;
  final Color color;
  final bool isHud;

  const _PageDot({
    required this.isActive,
    required this.color,
    required this.isHud,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: isActive ? 26 : 8,
      height: 8,
      decoration: isHud
          ? BoxDecoration(
              color: isActive
                  ? color.withValues(alpha: 0.2)
                  : Colors.transparent,
              border: Border.all(
                color: isActive ? color : color.withValues(alpha: 0.3),
                width: isActive ? 1.4 : 1,
              ),
              boxShadow: isActive
                  ? [
                      BoxShadow(
                        color: color.withValues(alpha: 0.5),
                        blurRadius: 10,
                      ),
                    ]
                  : null,
            )
          : BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: isActive ? color : Colors.grey,
              border: Border.all(
                color: isActive ? color : Colors.black26,
                width: 1,
              ),
              boxShadow: isActive
                  ? [
                      BoxShadow(
                        color: color.withValues(alpha: 0.7),
                        blurRadius: 10,
                      ),
                    ]
                  : null,
            ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL ICON BUTTON
// ═══════════════════════════════════════════════════════════
class _MetalIconButton extends StatefulWidget {
  final AppPalette C;
  final IconData icon;
  final VoidCallback onTap;
  final double size;
  const _MetalIconButton({
    required this.C,
    required this.icon,
    required this.onTap,
    this.size = 34,
  });

  @override
  State<_MetalIconButton> createState() => _MetalIconButtonState();
}

class _MetalIconButtonState extends State<_MetalIconButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final style = AppTheme.currentStyle.value;
    final isHud = style == ThemeStyle.hudTactical;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size,
        height: widget.size,
        transform: isHud
            ? null
            : Matrix4.translationValues(
                _pressed ? 1 : 0,
                _pressed ? 1 : 0,
                0,
              ),
        decoration: isHud
            ? BoxDecoration(
                color: _pressed
                    ? C.accent.withValues(alpha: 0.25)
                    : C.accent.withValues(alpha: 0.1),
                border: Border.all(color: C.accent, width: 1.2),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: C.accent.withValues(alpha: 0.35),
                          blurRadius: 8,
                        ),
                      ],
              )
            : BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [C.textSub, C.bgDark],
                ),
                border: Border.all(
                  color: C.text.withValues(alpha: 0.5),
                  width: 1,
                ),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.6),
                          offset: const Offset(0, 2),
                          blurRadius: 3,
                        ),
                      ],
              ),
        child: Icon(
          widget.icon,
          color: isHud ? C.accent : C.primaryHi,
          size: widget.size * 0.42,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HALFTONE PAINTER (for comic mode)
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}