// lib/tqto.dart — 3 Style Support
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';

class TqtoPage extends StatelessWidget {
  const TqtoPage({super.key});

  final List<Map<String, String>> contributors = const [
    {
      'name': 'Zasa',
      'role': 'Developer',
      'avatar': 'https://files.catbox.moe/2ryxq0.jpg',
      'contact': 'https://t.me/zasajir',
    },
    {
      'name': 'Shiro',
      'role': 'Dev Zeus',
      'avatar': 'https://files.catbox.moe/2ryxq0.jpg',
      'contact': 'https://t.me/rdsimmune',
    },
    {
      'name': 'Randa',
      'role': 'Developer Rxhl',
      'avatar': 'https://files.catbox.moe/y6ab5n.jpg',
      'contact': 'https://t.me/rxhlvr',
    },
    {
      'name': 'Melvin',
      'role': 'My best friend',
      'avatar': 'https://files.catbox.moe/y6ab5n.jpg',
      'contact': 'https://t.me/luyatiem',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final isHud = style == ThemeStyle.hudTactical;

            return Scaffold(
              backgroundColor:
                  isComic ? C.bg : (isHud ? C.hudBg() : C.bgDeep),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : (isHud
                        ? BoxDecoration(color: C.hudBg())
                        : BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                            ),
                          )),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    if (isHud)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HudGridPainter(
                                color: C.hudGridLine()),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildTopBar(context, C, isComic, isHud),
                          const SizedBox(height: 4),
                          _buildTitle(C, isComic, isHud),
                          const SizedBox(height: 12),
                          _buildStatsBar(C, isComic, isHud),
                          const SizedBox(height: 14),
                          Expanded(
                            child: GridView.builder(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 4),
                              physics: const BouncingScrollPhysics(),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 12,
                                mainAxisSpacing: 12,
                                childAspectRatio: 0.82,
                              ),
                              itemCount: contributors.length,
                              itemBuilder: (context, index) {
                                final item = contributors[index];
                                return _ContributorCard(
                                  C: C,
                                  isComic: isComic,
                                  isHud: isHud,
                                  name: item['name']!,
                                  role: item['role']!,
                                  avatarUrl: item['avatar']!,
                                  contactUrl: item['contact']!,
                                  index: index,
                                );
                              },
                            ),
                          ),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(
      BuildContext context, AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        height: 54,
        decoration: isComic
            ? BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
              )
            : (isHud
                ? BoxDecoration(
                    color: C.hudPanel(),
                    border: Border.all(color: C.hudBorder(), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: C.accent.withOpacity(0.3),
                          blurRadius: 10),
                    ],
                  )
                : BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [C.bg, C.bgDark],
                    ),
                    border: Border.all(color: C.textSub, width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        offset: const Offset(0, 3),
                        blurRadius: 6,
                      ),
                    ],
                  )),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 36, height: 36,
                  decoration: isHud
                      ? BoxDecoration(
                          color: C.accent.withOpacity(0.15),
                          border:
                              Border.all(color: C.accent, width: 1.2),
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic
                              ? null
                              : LinearGradient(
                                  colors: [C.textSub, C.bgDark]),
                          color: isComic ? C.accent : null,
                          border: Border.all(
                              color: isComic ? Colors.black : C.textSub,
                              width: isComic ? 3 : 1),
                        ),
                  child: Icon(Icons.arrow_back_ios_new_rounded,
                      color: isComic
                          ? Colors.white
                          : (isHud ? C.hudNeon() : C.accent),
                      size: 14),
                ),
              ),
              const SizedBox(width: 10),
              if (!isComic) _PulseDot(color: C.primaryHi, size: 6),
              if (!isComic) const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'SPECIAL FAMILY',
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (isHud ? C.hudNeon() : C.accent),
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 18 : 13,
                    letterSpacing: isComic ? 2 : 2,
                    shadows: isComic
                        ? null
                        : [
                            Shadow(
                                color: C.accent.withOpacity(0.5),
                                blurRadius: 8),
                            const Shadow(
                              color: Colors.black,
                              offset: Offset(0, 1),
                              blurRadius: 2,
                            ),
                          ],
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 8 : 5),
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          colors: [C.accentHi, C.primaryLo]),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 2.5 : 1),
                ),
                child: Text(
                  '${contributors.length} MEMBER',
                  style: TextStyle(
                    color: isComic ? Colors.white : C.bgDeep,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 11 : 9,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTitle(AppPalette C, bool isComic, bool isHud) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        decoration: isComic
            ? BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
              )
            : (isHud
                ? BoxDecoration(
                    color: C.hudPanel(),
                    border: Border.all(color: C.hudBorder(), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: C.accent.withOpacity(0.3),
                          blurRadius: 12),
                    ],
                  )
                : BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [C.bg, C.bgDark],
                    ),
                    border: Border.all(color: C.textSub, width: 1.2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        offset: const Offset(0, 4),
                        blurRadius: 8,
                      ),
                    ],
                  )),
        child: Column(
          children: [
            isComic
                ? Text(
                    'THANK YOU',
                    style: TextStyle(
                      color: C.bgDeep,
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Bangers',
                      letterSpacing: 4,
                    ),
                  )
                : isHud
                    ? Text(
                        'THANK YOU',
                        style: TextStyle(
                          color: C.hudNeon(),
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 6,
                          shadows: [
                            Shadow(
                                color: C.accent.withOpacity(0.6),
                                blurRadius: 12),
                          ],
                        ),
                      )
                    : Stack(
                        alignment: Alignment.center,
                        children: [
                          Transform.translate(
                            offset: const Offset(2, 2),
                            child: Text(
                              'THANK YOU',
                              style: TextStyle(
                                color: Colors.black.withOpacity(0.7),
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 6,
                              ),
                            ),
                          ),
                          Text(
                            'THANK YOU',
                            style: TextStyle(
                              color: C.accent,
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 6,
                              shadows: [
                                Shadow(
                                  color: C.accentHi,
                                  offset: const Offset(0, -1),
                                  blurRadius: 3,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
            const SizedBox(height: 8),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 8 : 3),
                color: isHud
                    ? C.accent.withOpacity(0.15)
                    : (isComic
                        ? C.primaryHi
                        : C.primaryLo.withOpacity(0.6)),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (isHud
                          ? C.accent
                          : C.accent.withOpacity(0.7)),
                  width: isComic ? 3 : 1,
                ),
                boxShadow: isHud
                    ? [
                        BoxShadow(
                            color: C.accent.withOpacity(0.4),
                            blurRadius: 8),
                      ]
                    : null,
              ),
              child: Text(
                'TO ALL CONTRIBUTORS',
                style: TextStyle(
                  color: isComic
                      ? Colors.white
                      : (isHud ? C.hudNeon() : C.accentShine),
                  fontSize: isComic ? 12 : 9,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: isComic ? 1.5 : 2,
                  shadows: isHud
                      ? [
                          Shadow(
                              color: C.accent.withOpacity(0.6),
                              blurRadius: 6),
                        ]
                      : null,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsBar(AppPalette C, bool isComic, bool isHud) {
    final creatorCount = contributors
        .where((c) =>
            c['role']!.toLowerCase() == 'creator' ||
            c['role']!.toLowerCase() == 'ceo' ||
            c['role']!.toLowerCase() == 'maker')
        .length;
    final supportCount = contributors
        .where((c) => c['role']!.toLowerCase() == 'support')
        .length;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: isComic
            ? BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
              )
            : (isHud
                ? BoxDecoration(
                    color: C.hudPanel(),
                    border: Border.all(color: C.hudBorder(), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: C.accent.withOpacity(0.3),
                          blurRadius: 10),
                    ],
                  )
                : BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: C.bgDark,
                    border: Border.all(color: C.textSub, width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        offset: const Offset(0, 3),
                        blurRadius: 6,
                      ),
                    ],
                  )),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _statItem(C, isComic, isHud, Icons.star_rounded,
                '$creatorCount', 'CREATOR',
                isHud ? C.hudNeon() : C.accentHi),
            _statItem(C, isComic, isHud, Icons.support_agent_rounded,
                '$supportCount', 'SUPPORT',
                isHud ? C.accent : C.accent),
            _statItem(C, isComic, isHud, Icons.favorite_rounded,
                '∞', 'THANKS',
                isHud ? C.hudNeon() : C.primaryHi),
          ],
        ),
      ),
    );
  }

  Widget _statItem(AppPalette C, bool isComic, bool isHud, IconData icon,
      String value, String label, Color color) {
    return Column(
      children: [
        Container(
          width: 40, height: 40,
          decoration: isHud
              ? BoxDecoration(
                  color: color.withOpacity(0.15),
                  border: Border.all(color: color, width: 1.2),
                  boxShadow: [
                    BoxShadow(
                        color: color.withOpacity(0.5),
                        blurRadius: 8),
                  ],
                )
              : BoxDecoration(
                  shape: BoxShape.circle,
                  color: isComic ? color : color.withOpacity(0.15),
                  border: Border.all(
                    color: isComic
                        ? Colors.black
                        : color.withOpacity(0.5),
                    width: isComic ? 3 : 1.2,
                  ),
                ),
          child: Icon(icon,
              color: isHud ? color : Colors.white, size: 18),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            color: isComic
                ? Colors.white
                : (isHud ? color : color),
            fontWeight: FontWeight.w900,
            fontSize: isComic ? 18 : 14,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            letterSpacing: 0.8,
            shadows: isHud
                ? [
                    Shadow(
                        color: color.withOpacity(0.5),
                        blurRadius: 6),
                  ]
                : null,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: isComic
                ? Colors.white.withOpacity(0.6)
                : (isHud
                    ? C.hudTextDim()
                    : C.text.withOpacity(0.55)),
            fontSize: isComic ? 10 : 8,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            letterSpacing: 1,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CONTRIBUTOR CARD
// ═══════════════════════════════════════════════════════════
class _ContributorCard extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final bool isHud;
  final String name;
  final String role;
  final String avatarUrl;
  final String contactUrl;
  final int index;

  const _ContributorCard({
    required this.C,
    required this.isComic,
    required this.isHud,
    required this.name,
    required this.role,
    required this.avatarUrl,
    required this.contactUrl,
    required this.index,
  });

  Color _roleColor(String r) {
    switch (r.toLowerCase()) {
      case 'creator':
      case 'maker':
        return isHud ? C.hudNeon() : C.accentHi;
      case 'ceo':
        return isHud ? C.hudNeon() : C.accentShine;
      case 'support':
        return isHud ? C.accent : C.accent;
      default:
        return isHud ? C.accent : C.primaryHi;
    }
  }

  @override
  Widget build(BuildContext context) {
    final roleColor = _roleColor(role);

    if (isComic) {
      return Container(
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 62, height: 62,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: roleColor,
                    border: Border.all(color: Colors.black, width: 4),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.all(4),
                  width: 54, height: 54,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 3),
                  ),
                  child: ClipOval(
                    child: Image.network(
                      avatarUrl,
                      width: 48, height: 48,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: Colors.white,
                        child: Icon(
                          Icons.person_rounded,
                          color: C.bgDeep,
                          size: 26,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              name,
              style: TextStyle(
                color: C.text,
                fontWeight: FontWeight.w900,
                fontSize: 16,
                fontFamily: 'Bangers',
                letterSpacing: 1,
                shadows: const [
                  Shadow(
                    color: Colors.black,
                    offset: Offset(1, 1),
                    blurRadius: 0,
                  ),
                ],
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: roleColor,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: Colors.black, width: 2),
              ),
              child: Text(
                role.toUpperCase(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontFamily: 'Bangers',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 10),
            _ContactButton(
              C: C,
              isComic: true,
              isHud: false,
              color: roleColor,
              onTap: () async {
                final Uri uri = Uri.parse(contactUrl);
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri,
                      mode: LaunchMode.externalApplication);
                }
              },
            ),
          ],
        ),
      );
    }

    if (isHud) {
      return Container(
        decoration: BoxDecoration(
          color: C.hudPanel(),
          border: Border.all(color: C.hudBorder(), width: 1.2),
          boxShadow: [
            BoxShadow(
                color: C.accent.withOpacity(0.3), blurRadius: 12),
          ],
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 62, height: 62,
                    decoration: BoxDecoration(
                      color: roleColor.withOpacity(0.15),
                      border:
                          Border.all(color: roleColor, width: 1.5),
                      boxShadow: [
                        BoxShadow(
                            color: roleColor.withOpacity(0.5),
                            blurRadius: 12),
                      ],
                    ),
                    child: Container(
                      margin: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: C.bgDeep,
                        border: Border.all(
                            color: roleColor.withOpacity(0.5),
                            width: 1),
                      ),
                      child: ClipOval(
                        child: Image.network(
                          avatarUrl,
                          width: 52, height: 52,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: C.bgDeep,
                            child: Icon(
                              Icons.person_rounded,
                              color: roleColor,
                              size: 26,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    name,
                    style: TextStyle(
                      color: C.hudText(),
                      fontWeight: FontWeight.w900,
                      fontSize: 13,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                      shadows: [
                        Shadow(
                            color: C.accent.withOpacity(0.4),
                            blurRadius: 6),
                      ],
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: roleColor.withOpacity(0.15),
                      border: Border.all(
                          color: roleColor.withOpacity(0.7),
                          width: 1),
                    ),
                    child: Text(
                      role.toUpperCase(),
                      style: TextStyle(
                        color: roleColor,
                        fontSize: 8,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                        shadows: [
                          Shadow(
                              color: roleColor.withOpacity(0.6),
                              blurRadius: 4),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  _ContactButton(
                    C: C,
                    isComic: false,
                    isHud: true,
                    color: roleColor,
                    onTap: () async {
                      final Uri uri = Uri.parse(contactUrl);
                      if (await canLaunchUrl(uri)) {
                        await launchUrl(uri,
                            mode: LaunchMode.externalApplication);
                      }
                    },
                  ),
                ],
              ),
            ),
            Positioned(
              top: -1,
              left: -1,
              child: SizedBox(
                width: 10,
                height: 10,
                child: CustomPaint(
                  painter: _HudCornerPainter(
                      color: C.accent.withOpacity(0.8)),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark],
        ),
        border: Border.all(color: C.textSub, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            offset: const Offset(0, 4),
            blurRadius: 8,
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 62, height: 62,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    roleColor.withOpacity(0.7),
                    roleColor.withOpacity(0.3),
                    C.bgDark,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: roleColor.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Container(
                margin: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: C.bgDark,
                ),
                child: ClipOval(
                  child: Image.network(
                    avatarUrl,
                    width: 56, height: 56,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 56, height: 56,
                      color: C.bgDark,
                      child: Icon(
                        Icons.person_rounded,
                        color: roleColor.withOpacity(0.6),
                        size: 26,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              name,
              style: TextStyle(
                color: C.text,
                fontWeight: FontWeight.w900,
                fontSize: 13,
                fontFamily: 'Orbitron',
                letterSpacing: 0.5,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                color: roleColor.withOpacity(0.2),
                border: Border.all(
                    color: roleColor.withOpacity(0.6), width: 1),
              ),
              child: Text(
                role.toUpperCase(),
                style: TextStyle(
                  color: roleColor,
                  fontSize: 8,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
            ),
            const SizedBox(height: 10),
            _ContactButton(
              C: C,
              isComic: false,
              isHud: false,
              color: roleColor,
              onTap: () async {
                final Uri uri = Uri.parse(contactUrl);
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri,
                      mode: LaunchMode.externalApplication);
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CONTACT BUTTON
// ═══════════════════════════════════════════════════════════
class _ContactButton extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  final bool isHud;
  final Color color;
  final VoidCallback onTap;
  const _ContactButton({
    required this.C,
    required this.isComic,
    required this.isHud,
    required this.color,
    required this.onTap,
  });

  @override
  State<_ContactButton> createState() => _ContactButtonState();
}

class _ContactButtonState extends State<_ContactButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final textColor = widget.isComic
        ? Colors.white
        : (widget.isHud ? widget.color : Colors.white);

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        transform: widget.isComic
            ? Matrix4.translationValues(
                _pressed ? 3 : 0, _pressed ? 3 : 0, 0)
            : Matrix4.translationValues(
                _pressed ? 1 : 0, _pressed ? 1 : 0, 0),
        decoration: widget.isHud
            ? BoxDecoration(
                color: widget.color.withOpacity(
                    _pressed ? 0.25 : 0.15),
                border: Border.all(color: widget.color, width: 1.2),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                            color: widget.color.withOpacity(0.5),
                            blurRadius: 8),
                      ],
              )
            : BoxDecoration(
                borderRadius:
                    BorderRadius.circular(widget.isComic ? 10 : 6),
                gradient: widget.isComic
                    ? null
                    : LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: _pressed
                            ? [
                                widget.color.withOpacity(0.4),
                                widget.color.withOpacity(0.2),
                              ]
                            : [
                                widget.color.withOpacity(0.7),
                                widget.color.withOpacity(0.4),
                              ],
                      ),
                color: widget.isComic ? widget.color : null,
                border: Border.all(
                  color: widget.isComic
                      ? Colors.black
                      : widget.color.withOpacity(0.8),
                  width: widget.isComic ? 3 : 1.2,
                ),
                boxShadow: _pressed
                    ? []
                    : (widget.isComic
                        ? const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(3, 3),
                              blurRadius: 0,
                            ),
                          ]
                        : [
                            BoxShadow(
                              color: widget.color.withOpacity(0.3),
                              blurRadius: 6,
                            ),
                          ]),
              ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.chat_rounded,
              color: textColor,
              size: widget.isComic ? 14 : 12,
            ),
            const SizedBox(width: 5),
            Text(
              'CONTACT',
              style: TextStyle(
                color: textColor,
                fontSize: widget.isComic ? 11 : 9,
                fontWeight: FontWeight.w900,
                fontFamily:
                    widget.isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 1,
                shadows: widget.isComic
                    ? const [
                        Shadow(
                          color: Colors.black,
                          offset: Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// PULSE DOT
// ═══════════════════════════════════════════════════════════
class _PulseDot extends StatefulWidget {
  final Color color;
  final double size;
  const _PulseDot({required this.color, this.size = 8});

  @override
  State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isHud = AppTheme.currentStyle.value == ThemeStyle.hudTactical;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final o = 0.4 + _c.value * 0.6;
        if (isHud) {
          return Container(
            width: widget.size,
            height: widget.size,
            decoration: BoxDecoration(
              color: widget.color.withOpacity(o),
              boxShadow: [
                BoxShadow(
                  color: widget.color.withOpacity(0.9 * o),
                  blurRadius: widget.size * 1.8,
                  spreadRadius: widget.size * 0.3,
                ),
              ],
            ),
          );
        }
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              center: const Alignment(-0.35, -0.35),
              colors: [
                Colors.white.withOpacity(o),
                widget.color.withOpacity(o),
                widget.color.withOpacity(0.5 * o),
              ],
              stops: const [0.0, 0.4, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.8 * o),
                blurRadius: widget.size * 1.5,
                spreadRadius: widget.size * 0.3,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HUD CORNER PAINTER
// ═══════════════════════════════════════════════════════════
class _HudCornerPainter extends CustomPainter {
  final Color color;
  const _HudCornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;
    final l = size.width * 0.5;
    canvas.drawLine(Offset.zero, Offset(l, 0), p);
    canvas.drawLine(Offset.zero, Offset(0, l), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width - l, size.height), p);
    canvas.drawLine(Offset(size.width, size.height),
        Offset(size.width, size.height - l), p);
  }

  @override
  bool shouldRepaint(_HudCornerPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) =>
      old.color != color;
}

// ═══════════════════════════════════════════════════════════
// HUD GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _HudGridPainter extends CustomPainter {
  final Color color;
  const _HudGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 0.6;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_HudGridPainter old) => old.color != color;
}